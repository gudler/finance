<?php
if(empty($lang)){
	$lang = array();
}

//系统模块
$lang['sys'] = array();
$lang['sys']['serverunavailable'] = '服务器出错，请稍候重试';
$lang['sys']['invalid_params'] = '参数不合法';
$lang['sys']['database_error'] = '数据库错误';

//用户模块
$lang['user'] = array();
$lang['user']['uploadeimageerror'] = '图片上传出错';
$lang['user']['uploadeimagelimits'] = '仅允许上传图片，且小于2MB';

$lang['user']['passwordlengthlimits'] = '密码长度不得小于6位';
$lang['user']['invalidephonenumber'] = '请输入正确的手机号';
$lang['user']['getsmscodeerror'] = '获取CODE出错，请重试';
$lang['user']['smscodeexpired'] = '验证码已过期，请重新获取验证码';
$lang['user']['smscodenotmatch'] = '验证码错误，请检查后重新输入';

$lang['user']['sms_day_limited'] = '本机验证码发送达当日发送上限';
$lang['user']['sms_hour_limited'] = '本机验证码发送达每小时发送上限';
$lang['user']['sms_minute_limited'] = '本机验证码发送达每分钟发送上限';

$lang['user']['notexists'] = '用户不存在';
$lang['user']['phoneexists'] = '此用户已存在';
$lang['user']['passworderror'] = '密码错误';
$lang['user']['paymentpassworderror'] = '交易密码错误';
$lang['user']['oldpassworderror'] = '原密码错误';
$lang['user']['pay_password_invalid'] = '交易密码不合法';
$lang['user']['otherside_logged_in'] = '您的账号已在另一个终端登录，如果不是您操作，请立刻通过“忘记密码”进行密码修改！';

$lang['user']['tokenexpired'] = '登录已过期，请重新登录';

$lang['user']['idverifiedcannotbemodified'] = '账户已实名认证不可修改';

//账户
$lang['account'] = array();
$lang['account']['not_rookie'] = '您已不是新手啦（注册后不超过180天）';
$lang['account']['same_user_accounts_limit'] = '超过同用户账号最大数限制';
$lang['account']['invalidephonenumber'] = '请输入正确的手机号';
$lang['account']['bankcardexists'] = '账户存在已绑定的银行卡，每人只可绑定一张银行卡';
$lang['account']['infogetsfailed'] = '账户信息获取失败';
$lang['account']['bankacc_not_exists'] = '账户未绑定银行卡，请先进行绑定操作';
$lang['account']['need_bind_one_card'] = '账户未绑定银行卡，请先进行绑定操作';
$lang['account']['amountnotenough'] = '账户余额不足';
$lang['account']['card_verify_service_down'] = '银行卡信息获取失败，请稍后再试';
$lang['account']['card_type_only_debit_card'] = '我司只支持借记卡，请换张银行卡重试';
$lang['account']['old_card_not_match'] = '原卡号错误，请确认后重试';
$lang['account']['identcode_not_same'] = '证件号不匹配，不可进行换卡操作';
$lang['account']['realname_not_same'] = '用户名不匹配，不可进行换卡操作';

$lang['account']['get_bankacc_verify_id_failed'] = '银行卡验证信息获取凭证失败，请稍后重试';

$lang['account']['amount_shift_onoff_invalid'] = '余额转投设置参数有误';
$lang['account']['amount_shift_on_ok'] = '余额转投设置开启成功';
$lang['account']['amount_shift_on_failed'] = '余额转投设置开启失败';
$lang['account']['amount_shift_off_ok'] = '余额转投设置关闭成功';
$lang['account']['amount_shift_off_failed'] = '余额转投设置关闭失败';

$lang['account']['amount_shift_description'] = '余额转投将于每日早晨8点30分左右由系统自动处理';

$lang['account']['account_not_exists'] = '账户不存在';
$lang['account']['its_an_online_account'] = '此为线上账户';
$lang['account']['withdraw_amount_not_enough'] = '您的账户可提现金额为{amount}元，您排队中的金额为{inqueue_amount}元';
$lang['account']['withdraw_amount_not_enough_with_fee'] = '您的账户可提现金额为{amount}元，提现手续费为{fee}元';

$lang['account']['cert_card_rpc_invalid'] = '身份证卡号不正确，请检查后再试';
$lang['account']['recharge_limit_min'] = '单次充值金额限制最少100元';
$lang['account']['recharge_limit_max'] = '单次充值金额限制最多5万元';
$lang['account']['offline_recharge_limit_min'] = '转账金额限制最少1元';
$lang['account']['offline_recharge_limit_max'] = '转账金额限制最多2千万元';
$lang['account']['recharge_create_order_failed'] = '创建充值订单失败，请稍后再试';
$lang['account']['recharge_update_trans_id_failed'] = '更新充值订单流水号失败，请稍后再试';
$lang['account']['recharge_order_query_failed'] = '充值订单未查到，请稍后再试';
$lang['account']['recharge_order_not_exists'] = '充值订单不存在';
$lang['account']['recharge_order_expired'] = '充值订单已过期';
$lang['account']['recharge_order_pay_failed'] = '订单充值失败';
$lang['account']['recharge_order_failed'] = '充值订单失败';
$lang['account']['recharge_order_created'] = '充值订单已创建';
$lang['account']['recharge_order_paid'] = '充值订单已支付';
$lang['account']['recharge_order_done'] = '充值订单已完成';
$lang['account']['recharge_status_error'] = '充值订单状态错误';

$lang['account']['recharge_failed_and_return'] = '支付失败，请重试，系统将返回充值页面';
$lang['account']['recharge_ok_and_return'] = '支付成功，系统将返回充值页面';

$lang['account']['offline_recharge_notice_already'] = '已通知，我们将在工作日2个小时内处理完您的转账，请耐心等待，谢谢';
$lang['account']['offline_recharge_notice_ok'] = '通知成功，我们将在工作日2个小时内处理完您的转账';
$lang['account']['offline_recharge_notice_failed'] = '通知失败，请重试。或在工作时间拨打我司电话4007-201-518';

$lang['account']['not_allowed'] = '您无此权限';
$lang['account']['withdraw_not_offline_account'] = '您无此权限';
$lang['account']['bind_card_first'] = '请先绑定银行卡';

$lang['account']['withdraw_limit_min'] = '单次提现金额限制最少100元';
$lang['account']['withdraw_limit_max'] = '单次提现金额限制最多50万元';
$lang['account']['withdraw_limit_total_max'] = '当日提现金额限制最多50万元，您今日({date})的额度还有{amount}元';
$lang['account']['withdraw_limit_month_total_max'] = '当月提现金额限制最多200万元，您今日({date})的额度还有{amount}元';
$lang['account']['withdraw_create_order_failed'] = '创建提现订单失败，请稍后再试';
$lang['account']['withdraw_order_query_failed'] = '提现订单未查到，请稍后再试';
$lang['account']['withdraw_order_not_exists'] = '提现订单不存在';
$lang['account']['withdraw_order_canceled'] = '提现已取消';
$lang['account']['withdraw_order_failed'] = '提现失败，请再试一遍';
$lang['account']['withdraw_order_created'] = '提现已创建';
$lang['account']['withdraw_order_account_rollback'] = '提现失败，您的余额已回滚';
$lang['account']['withdraw_order_done'] = '提现已完成';
$lang['account']['withdraw_status_error'] = '提现订单状态错误';
$lang['account']['order_not_exists'] = '订单不存在';
$lang['account']['withdraw_tp_status_not_confirmed'] = '退票订单状态不是确认';
$lang['account']['withdraw_tp_user_not_match'] = '退票订单用户不匹配';
$lang['account']['withdraw_tp_cardno_not_match'] = '退票订单卡号不匹配';
$lang['account']['withdraw_tp_money_not_match'] = '退票订单金额不匹配';
$lang['account']['withdraw_tp_withdraw_status_not_done'] = '退票订单原提现订单状态不是完成';

//终端
$lang['device'] = array();
$lang['device']['publickeyalreadyexists'] = '公钥已存在';
$lang['device']['aeskeyfetcherror'] = '加密密码获取失败';

//交易
$lang['trade'] = array();
$lang['trade']['obligationamountlimitmin'] = '债权的购买金额不可小于{amount}元';
$lang['trade']['eagleeyed_amount_limit_min'] = '鹰眼宝购买金额不可小于{amount}元';
$lang['trade']['fastentry_amount_limit_min'] = '易购宝购买金额不可小于{amount}元';
$lang['trade']['rookie_amount_limit_min'] = '新人专享购买金额不可小于{amount}元';
$lang['trade']['rookie_amount_limit_max'] = '新人专享购买金额不可大于{amount}元';
$lang['trade']['inqueue_count_limit'] = '您还有{count}笔在队列中的交易未处理，请稍后再交易';
$lang['trade']['inqueue_amount_limit'] = '您在交易队列中未处理的金额已达{amount}元，请稍后再交易';
$lang['trade']['add_queue_failed'] = '进入交易队列失败，请稍后再试';
$lang['trade']['add_auto_queue_failed'] = '进入排队队列失败，请稍后再试';
$lang['trade']['add_rookie_queue_failed'] = '进入排队队列失败，请稍后再试';
$lang['trade']['eagleeyed_total_cap_limited'] = '鹰眼宝购买队列已满，请明日再试';
$lang['trade']['eagleeyed_user_cap_limited'] = '每个用户鹰眼宝单次排队金额不能超过{amount}元';
$lang['trade']['fastentry_total_cap_limited'] = '购买队列已满，请明日再试';
$lang['trade']['fastentry_user_cap_limited'] = '每个用户易购宝单次排队金额不能超过{amount}元';
$lang['trade']['rookie_bought_already'] = '您已购买过新人专享理财产品';
$lang['trade']['rookie_inqueue_already'] = '您购买的新人专享理财产品已在队列中';
$lang['trade']['rookie_user_cap_limited'] = '新人专享理财产品购买队列已满，请稍后再试';
$lang['trade']['rookie_total_cap_limited'] = '今日新人专享理财产品已售完，请明日再试';

$lang['trade']['trade_queue_not_exists'] = '交易队列不存在';
$lang['trade']['auto_queue_not_exists'] = '等待队列不存在';
$lang['trade']['sell_queue_not_exists'] = '待转让队列不存在';
$lang['trade']['user_obligation_not_exists'] = '此用户债权不存在';
$lang['trade']['user_apqueue_not_exists'] = '此排队债权不存在';
$lang['trade']['no_permission'] = '您无权进行此项操作';
$lang['trade']['eagleeyed_cannot_change_autoshift'] = '鹰眼宝产品不可关闭自动转投';
$lang['trade']['rookie_cannot_change_autoshift'] = '新人专享产品不可自动转投';
$lang['trade']['rookie_cannot_sell'] = '新人专享不可转让';
$lang['trade']['in_closed_period'] = '在封闭期内不可转让';
$lang['trade']['no_permission_of_auto_shift'] = '您没有获得自动转投的授权';

$lang['trade']['transcation_not_open'] = '交易开放时间为：每日{open}时00分 至 {close}时00分';
$lang['trade']['transcation_sell_not_open'] = '债权转让的开放时间为：工作日 {open} 至 {close}';

$lang['trade']['empty_idstr'] = '债权ID不能为空';
$lang['trade']['user_hoid_not_exists'] = '用户债权{uoid}不存在';
$lang['trade']['uoid_in_closed_period'] = '用户债权{uoid}在封闭期内不可转让';

$lang['trade']['into_sell_queue_success'] = '您的债权已进入转让队列';
$lang['trade']['into_fastentry_queue_success'] = '您已进入易购宝购买队列';
$lang['trade']['into_eagleeyed_queue_success'] = '您已进入鹰眼宝购买队列';
$lang['trade']['into_rookie_queue_success'] = '您已进入新人专享购买队列';
$lang['trade']['into_trade_queue_success'] = '您已进入所需债权购买队列';

$lang['obligation'] = array();
$lang['obligation']['not_exists'] = '债权不存在';
$lang['obligation']['projcar_not_exists'] = '借款合同不存在';
$lang['obligation']['status'] = '债权{status}';
$lang['obligation']['left_amount_not_enough'] = '债权可投资余额不足';
$lang['obligation']['closed_period_too_long'] = '您选择的债权封闭期太长';
$lang['obligation']['closed_period_too_short'] = '您选择的债权封闭期太短';

$lang['obligation']['cmpt_param_err_rate'] = '计算参数[利率]错误';
$lang['obligation']['cmpt_param_err_amount'] = '计算参数[金额]错误';
$lang['obligation']['cmpt_param_err_monthes'] = '计算参数[期数]错误';
$lang['obligation']['cmpt_param_err_repayment_day'] = '计算参数[还款日]错误';
$lang['obligation']['cmpt_param_err_day'] = '计算参数[日]错误';
$lang['obligation']['cmpt_param_err_month'] = '计算参数[月]错误';
$lang['obligation']['cmpt_param_err_year'] = '计算参数[年]错误';

$lang['product'] = array();
$lang['product']['rookie'] = '新人专享';
$lang['product']['eagleeyed'] = '鹰眼宝';
$lang['product']['fastentry'] = '易购宝';
$lang['product']['fastentry_1'] = '一月宝';
$lang['product']['fastentry_3'] = '三月宝';
$lang['product']['fastentry_6'] = '六月宝';
$lang['product']['rookie_tips'] = '此理财产品仅限注册180天内的新人购买，且仅限购买一次。';
$lang['product']['eagleeyed_tips'] = '鹰眼宝是类活期且无封闭期优先自动购买债权的理财工具。';
$lang['product']['fastentry_tips'] = '易购宝是鹰眼理财推出的用于自动购买债权的快捷理财工具，购买后系统将自动为用户挑选债权，并将封闭期设为1个月。';

$lang['repayment'] = array();
$lang['repayment']['principal_and_interest_equal'] = '等额本息';
$lang['repayment']['repayment_equal_principal'] = '等额本金';
$lang['repayment']['repayment_principal_and_interest_at_maturity'] = '到期还本付息';
$lang['repayment']['repayment_principal_at_maturity_regular_interest_payment'] = '到期还本按期付息';

$lang['fuiou'] = array();
$lang['fuiou']['recharge_failed_and_return'] = '支付失败，请重试，系统将返回充值页面';
$lang['fuiou']['recharge_ok_and_return'] = '支付成功，系统将返回充值页面';
$lang['fuiou']['var_empty'] = '必须参数缺失';
$lang['fuiou']['sign_not_match'] = '数据签名不正确';
$lang['fuiou']['id_not_exists'] = '交易数据不存在';
$lang['fuiou']['status_query_failed'] = '查询交易状态获取信息失败';
$lang['fuiou']['status_check_failed'] = '交易状态非成功';

$lang['msgtpl'] = array();
$lang['msgtpl']['oblbuy_ok'] = '债权购买成功[|||]ID {id} 购买成功，请去“持有债权”查看详情';//消息模板：债权购买成功
$lang['msgtpl']['oblsell_ok'] = '债权转让成功[|||]ID {id} 债权转让成功，请去“持有债权”查看详情';//消息模板：债权转让成功
$lang['msgtpl']['withdraw_ok'] = '提现成功[|||]提现 {amount} 元，请去“交易记录”中“账户变更记录”查看详情';//消息模板：提现成功
$lang['msgtpl']['withdraw_failed'] = '提现失败[|||]金额 {amount} 元已回滚进入您的余额账户';//消息模板：提现失败
$lang['msgtpl']['recharge_ok'] = '充值[|||]成功充值 {amount} 元，请去“交易记录”中“账户变更记录”查看详情';//消息模板：充值成功
$lang['msgtpl']['recharge_ok_60'] = '转账充值[|||]成功转账充值 {amount} 元，请去“交易记录”中“账户变更记录”查看详情';//消息模板：转账充值成功
$lang['msgtpl']['recharge_ok_6'] = '线下充值[|||]成功线下充值 {amount} 元，请去“交易记录”中“账户变更记录”查看详情';//消息模板：线下充值成功
$lang['msgtpl']['recharge_ok_22'] = '退保证金[|||]已退保证金 {amount} 元，请去“交易记录”中“账户变更记录”查看详情';//消息模板：退保证金成功
$lang['msgtpl']['repayment_ok'] = '本息到账[|||]ID {id} 本息{amount}元到账，请查看“可用余额”';//消息模板：本息到账
$lang['msgtpl']['paysignbonus_ok'] = '签到金到账[|||]{date} 签到金{amount}元到账，请查看“可用余额”';//消息模板：签到金到账
$lang['msgtpl']['rookprin_ok'] = '新人专享本金到账[|||]ID {id} 本金{amount}元到账，请查看“可用余额”，利息将于付息日发放';//消息模板：新人专享到账
$lang['msgtpl']['payinviter_ok'] = '邀请奖励到账[|||]邀请用户 {phone} 奖励{amount}元到账，请查看“可用余额”';//消息模板：邀请奖励到账
$lang['msgtpl']['pay_bindcardinvitee_ok'] = '被邀请注册绑卡奖励到账[|||]奖励{amount}元到账，请查看“可用余额”';//消息模板：被邀请注册绑卡奖励到账
$lang['msgtpl']['pay_buylonginviter_ok'] = '邀请成功奖励到账[|||]奖励{amount}元到账，请查看“可用余额”';//消息模板：邀请成功奖励到账
$lang['msgtpl']['loan_repayment_ok'] = '还款成功[|||]月还款 {pid} 还款{amount}元成功，请查看“借款列表”';//消息模板：还款成功
$lang['msgtpl']['loan_repayment_piece_ok'] = '还款（部分）成功[|||]月还款 {pid} 因余额不足，部分还款{amount}元，请查看“借款列表”';//消息模板：部分还款成功
$lang['msgtpl']['loan_repayment_ok2'] = '还款成功[|||]月还款 {pid} 还款{amount}元成功，其中逾期费用{fee}，请查看“借款列表”';//消息模板：还款成功
$lang['msgtpl']['loan_repayment_piece_ok2'] = '还款（部分）成功[|||]月还款 {pid} 因余额不足，部分还款{amount}元，其中逾期费用{fee}，请查看“借款列表”';//消息模板：部分还款成功
$lang['msgtpl']['loan_repayment_time_less_amount'] = '还款温馨提示[|||]月还款 {pid} 到 {date} 还款需{amount}元，您目前余额不足，请保证还款当日余额充足';//消息模板：还款将到期余额不足提醒
$lang['msgtpl']['loan_repayment_time_overdue'] = '月还款逾期[|||]月还款 {pid} 已逾期，您的余额不足';//消息模板：还款逾期余额不足提醒
$lang['msgtpl']['payback_tradefee_ok'] = '返还手续费[|||]返还债权 {id} 转让手续费 {amount} 元';//消息模板：返还手续费
$lang['msgtpl']['pay_award_ok'] = '奖励[|||]奖励 {amount} 元已发放，请去“交易记录”中“账户变更记录”查看详情';//消息模板：发放奖励
$lang['msgtpl']['obl_paidearly'] = '债权提前结清[|||]因借款人提前结清债权，ID {id} 剩余本金{amount}元已到账，请去“交易记录”中“账户变更记录”查看详情';//消息模板：提前结清本金
$lang['msgtpl']['obl_paidearly_interest'] = '债权提前结清付息[|||]因借款人提前结清债权，ID {id} 剩余利息{amount}元已到账，请去“交易记录”中“账户变更记录”查看详情';//消息模板：提前结清利息

$lang['msgtpl']['notice_high_rate_obligation_open'] = '通知[|||]高利率债权已开售';//消息模板：高利率债权已开售
$lang['msgtpl']['notice_high_rate_obligation_plan'] = '通知[|||]高利率债权即将开售';//消息模板：高利率债权即将开售
$lang['msgtpl']['notice_high_rate_fastentry'] = '易购宝限时抢购[|||]利率高达{rate}，将于{start}开始，于{end}结束';//消息模板：易购宝限时抢购利率

$lang['msgtpl']['buyer_no_enough_money'] = '中转账户余额不足通知[|||]{datetime}，用户转让债权{o_count}笔共{o_amount}元，中转账户余额{amount}元，余额不足';//消息模板：中转账户余额不足
$lang['msgtpl']['seller_appointment'] = '用户转让预约处理通知[|||]{datetime}，用户(ID:{uid},手机:{mobile},姓名:{name})转让债权{count}笔共{amount}元(批次:{batch})，超过系统设置，需要进行预约处理';//消息模板：用户债权转让预约处理
$lang['msgtpl']['withdraw_tp'] = '提现退票通知[|||]{datetime}，订单:{orderno}，金额:{amount}，发生退票，请及时处理';//消息模板：用户债权转让预约处理

$lang['qa'] = array();
$lang['qa']['answer_empty'] = '答案为空';
$lang['qa']['not_answer_question'] = '没有回答问题【{question}】';
$lang['qa']['answer_not_in_question'] = '问题【{question}】的答案超出允许范围';

$lang['loan'] = array();
$lang['loan']['info_already_exists'] = '借款信息已存在';
$lang['loan']['info_not_exists'] = '借款信息不存在，请检查数据库';
$lang['loan']['list_already_exists'] = '借款信息列表已存在';
$lang['loan']['list_not_exists'] = '借款信息列表不存在，请检查数据库';
$lang['loan']['rate_not_exists'] = '利率不存在，请先填入';
$lang['loan']['rate_error'] = '利率错误，最高不能超过0.12，也不能小于0.01';
$lang['loan']['all_period_rate_error'] = '买断利率错误，最高不能超过0.12，也不能小于年利率';
$lang['loan']['has_count_overdued'] = '您有{count}笔月还款逾期';
$lang['loan']['has_count_recent_less'] = '您有{count}笔共{amount}元的月还款即将到期，您的余额不足';
$lang['loan']['has_count_recent'] = '您有{count}笔共{amount}元的月还款即将到期';
$lang['loan']['auto_return_not_agreed'] = '您只有在同意《还款协议》的情况下才能使用自动还款';
$lang['loan']['successfully_set_auto_return'] = '设置自动还款成功，请在每个还款日保证您的余额充值';
$lang['loan']['obl_plan_exists'] = '债权上线计划已存在';
$lang['loan']['obl_exists'] = '债权已上线';
$lang['loan']['user_not_exists'] = '用户不存在';
$lang['loan']['user_not_bind_card'] = '用户没有绑卡';
$lang['loan']['user_realname_not_matched'] = '用户姓名不匹配';
$lang['loan']['projcar_not_exists'] = '借款合同不存在';
$lang['loan']['projcar_frd_not_matched'] = '借款合同首次还款日期不匹配';
$lang['loan']['projcar_rd_not_matched'] = '借款合同每月还款日期不匹配';
$lang['loan']['projcar_finished'] = '借款合同按首次还款日期计算已经结束了';
$lang['loan']['projcar_left_period_not_matched'] = '借款合同首次还款日期同剩余期数不匹配';
$lang['loan']['up_time_error'] = '上线时间错误，至少在当前时间10分钟以后';
$lang['loan']['show_time_error'] = '显示时间错误，不能为空且比上线时间小';
$lang['loan']['closed_period_error'] = '封闭期错误';
$lang['loan']['user_not_matched'] = '债权还款人不匹配';

$lang['notice']['notexists'] = '公告不存在';

$lang['selling_channel']['not_exist'] = '记录不存在';
$lang['selling_channel']['buy_time_invalid'] = '预约时间不正确(必须大于当前时间)';
$lang['selling_channel']['uid_invalid'] = 'uid参数不正确';
$lang['selling_channel']['batch_invalid'] = 'batch参数不正确';
$lang['selling_channel']['operation_failed'] = '操作失败';

