<?php

define('DS', DIRECTORY_SEPARATOR);
define('ROOT', dirname(__FILE__) . DS);
define('DIR_CORE', ROOT . 'core' . DS);
define('DIR_LIB', ROOT . 'lib' . DS);
define('DIR_CTRL', ROOT . 'controllers' . DS);
define('DIR_MODEL', ROOT . 'models' . DS);
define('DIR_HELPER', ROOT . 'helpers' . DS);
define('DIR_ETC', ROOT . 'etc' . DS);
define('DIR_VIEW', ROOT . 'view' . DS);
define('DIR_LANG', ROOT . 'language' . DS);
define('DIR_LOG', ROOT . 'logs' . DS);
define('DIR_DATAHOUSE', ROOT . 'datahouse' . DS);

define('PATH_BASE_CONTROLLER', DIR_CTRL . 'controller.php');
define('PATH_BASE_CB_CONTROLLER', DIR_CTRL . 'callback_controller.php');
define('PATH_BASE_MODEL', DIR_MODEL . 'model.php');
define('PATH_LIB_TAOBAO', DIR_LIB . 'taobao' . DS .'TopSdk.php');
define('PATH_PAYMENT_FUIOU', DIR_LIB . 'payment' . DS .'FuiouPay.php');

require DIR_CORE . 'common.php';

load_define('codes');
load_define('inline');
date_default_timezone_set("Asia/Shanghai");
// date_default_timezone_set("America/Los_Angeles");