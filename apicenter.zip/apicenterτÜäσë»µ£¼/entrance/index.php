<?php

if(!isset($_SERVER['ENVIRONMENT']) || empty($_SERVER['ENVIRONMENT'])){
	$environment = 'development';
}else{
	$environment = strtolower($_SERVER['ENVIRONMENT']);
}

define('ENVIRONMENT', $environment);

if (defined('ENVIRONMENT'))
{
	switch (ENVIRONMENT)
	{
		case 'development':
			error_reporting(E_ALL);
		break;

		case 'testing':
		case 'production':
			error_reporting(0);
		break;

		default:
			exit('The application environment is not set correctly.');
	}
}

require dirname(dirname(__FILE__)) . '/base.php';
require DIR_CORE . 'cipher.php';
require DIR_CORE . 'dispatch.php';