<?php
echo "Your POST: \n";
print_r($_POST);

echo "\n\nYour GET: \n";
print_r($_GET);
