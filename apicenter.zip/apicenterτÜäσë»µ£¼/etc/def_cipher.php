<?php
/*
*/
if(!defined('CIPHER_AESKEY_LENGTH')){
	define('CIPHER_AESKEY_LENGTH', 32);//加密密码长度
	define('CIPHER_INFO_MEMCACHE_TIMEOUT', 10*60);//公钥信息缓存时长
	define('CIPHER_AESKEY_MEMCACHE_TIMEOUT', 3*3600);//加密密码信息缓存时长
}
