<?php

if(!defined('MAIL_INFO_HOST')){
	define('MAIL_INFO_HOST', 'smtp.exmail.qq.com');//
	define('MAIL_INFO_USER', 'srvmail@egeyed.com');//
	define('MAIL_INFO_USERNAME', '萌萌哒服务器');//
	define('MAIL_INFO_PASSWD', 'AutoMail123@EgEyed.com');//
	define('MAIL_INFO_SECURE', 'ssl');//
	define('MAIL_INFO_PORT', 465);//
	define('MAIL_INFO_REPLY_EMAIL', 'tao@egeyed.com');//
	define('MAIL_INFO_REPLY_NAME', '陶');//
	define('MAIL_INFO_ADDRESS_OPERATION', 'tao@egeyed.com|陶,srvmail@egeyed.com|萌萌哒服务器');//
	define('MAIL_INFO_ADDRESS_MONTHLY', 'tao@egeyed.com|陶,srvmail@egeyed.com|萌萌哒服务器');//
	define('MAIL_INFO_ADDRESS_ACCOUNTING', 'accounting@egeyed.com|查账,srvmail@egeyed.com|萌萌哒服务器');//
}
