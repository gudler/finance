<?php
/*
*/
if(!defined('CODES_OK')){
	define('CODES_OK', 0);//正常
	define('CODES_FAILED', -1);//失败
	
	define('CODES_PASSWD_ERROR', -2);//密码错误
	define('CODES_PAY_PASSWD_ERROR', -3);//支付密码错误

	define('CODES_NO_USER_RSAKEY', -10);//用户公钥信息缺失
	define('CODES_USER_RSAKEY_EXPIRED', -11);//用户公钥信息过期
	define('CODES_USER_RSAKEY_EXISTS', -12);//用户公钥信息已存在
	define('CODES_NO_AESKEY', -20);//加密密码缺失
	define('CODES_AESKEY_EXPIRED', -21);//加密密码过期
	define('CODES_AESKEY_NOTGOT', -22);//加密密码获取失败
	define('CODES_DATA_ILLEGAL', -30);//非法数据

	define('CODES_TRADE_LIMIT', -40);//交易限制
	define('CODES_TRADE_ADD_QUEUE_FAILED', -41);//进入交易队列失败
	define('CODES_TRADE_INQUEUE_COUNT_LIMIT', -42);//触及允许在队列中的交易次数的限制
	define('CODES_TRADE_INQUEUE_AMOUNT_RATE_LIMIT', -43);//触及允许在队列中的交易金额的限制
	define('CODES_TRADE_QUEUE_NOT_EXISTS', -44);//交易队列不存在

	define('CODES_ACCOUNT_INFO_ERROR', -50);//用户账户错误
	define('CODES_ACCOUNT_INFO_GETS_FAILED', -51);//用户账户信息获取失败
	define('CODES_ACCOUNT_AMOUNT_NOT_ENOUGH', -52);//用户账户余额不足
	define('CODES_ACCOUNT_BANKACC_NOT_EXISTS', -53);//用户账户银行卡不存在
	define('CODES_ACCOUNT_BANKACC_IN_BINDING', -54);//用户账户银行卡绑定中
	define('CODES_ACCOUNT_BANKACC_EXPIRED', -55);//用户账户银行卡已过期

	define('CODES_OBLIGATION_NOT_EXISTS', -60);//债权不存在

	define('CODES_OBLIGATION_LEFT_AMOUNT_NOT_ENOUGH', -61);//债权剩余可投金额不足
	define('CODES_OBLIGATION_CLOSED_PERIOD_TOO_LONG', -62);//债权封闭期小于提交数据
	define('CODES_OBLIGATION_CLOSED_PERIOD_TOO_SHORT', -63);//提交的封闭期太短

	define('CODES_AUTO_PROCESS_ADD_QUEUE_FAILED', -70);//进入自动队列失败
	define('CODES_AUTO_PROCESS_QUEUE_NOT_EXISTS', -71);//进入自动队列失败

	define('CODES_SELL_QUEUE_NOT_EXISTS', -80);//出售队列不存在

	define('CODES_SERVICE_UNAVAILABLE', -999);//服务不可用
}
