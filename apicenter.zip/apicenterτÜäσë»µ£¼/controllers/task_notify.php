<?php

require_once PATH_BASE_CONTROLLER;

class Task_notify extends Controller{
	// 邮件通知的配置，从config.php读取
	protected $cnf_email_notify = array();

	protected function check_runner_exists( $runner_name ){
		$pid_file = sys_get_temp_dir() . '/' . $runner_name . '.run.pid';
		if(file_exists($pid_file)){
			$pid = file_get_contents($pid_file);
			if(file_exists('/proc/')){
				if(file_exists('/proc/'.$pid)){
					return true;
				}
			}else{
				@$r = pcntl_getpriority($pid);
				if($r>0){
					return true;
				}
			}
		}
		if(function_exists('posix_getpid')){
			$pid = posix_getpid();
		}else{
			return null;
		}
		file_put_contents($pid_file, $pid);
		return false;
	}

	protected function runner_clean( $runner_name ){
		$pid_file = sys_get_temp_dir() . '/' . $runner_name . '.run.pid';
		if(file_exists($pid_file)){
			unlink($pid_file);
		}
	}

	protected function runner_wait($start_ts, $microsec, $busy_stop = 1000000){
		$end_ts = microtime(true);
		$cost = ($end_ts - $start_ts) * 1000000;
		if($cost > $microsec){
			usleep( $busy_stop );
		}else{
			usleep( $microsec - $cost );
		}
	}

	protected function log_result($func, $result){
		$filename = DIR_LOG . 'task_notify_result_' . date('Y-m') . '.log';
		$data = sprintf("%s\t%s\t%s\n", date('Y-m-d H:i:s'), $func, json_encode($result));
		file_put_contents($filename, $data, FILE_APPEND);
	}

	public function __construct(){
		
		if(!defined('IN_TASK') || !IN_TASK){
			exit('Not allowed');
		}
		get_config();
		// 获取邮件通知的配置信息
		$this->cnf_email_notify = config_item('email_notify');
	}
	/**
	 * 发送邮件
	 * @param $subject 主题
	 * @param $content 内容
	 * @param $tos 收件人，数组
	 * @param $ccs 抄送人，数组
	 */
	protected function send_email($subject,$content,$tos,$ccs) {
		$lib_email = & load_library('smailer');
		$cnf_email = $this->cnf_email_notify['email'];		
		$lib_email->init($cnf_email['user'],$cnf_email['password'],$cnf_email['secure'],$cnf_email['host'],$cnf_email['port']);
		$lib_email->setFrom($cnf_email['from'],$cnf_email['name']);
		$lib_email->setSubject($subject);
		$lib_email->setContent($content);
		foreach($tos as $to) {
			$lib_email->addMail($to);
		}
		foreach($ccs as $cc) {
			$lib_email->addCCMail($cc);
		}
		$result = $lib_email->send();
		if ($result==false) {
			$this->log_result(__METHOD__,array('subject'=>$subject,'content'=>$content,'tos'=>$tos,'ccs'=>$ccs,'result'=>$result));
		}
		return $result;
	}
	/**
	 * 解析邮件通知记录并发送邮件
	 * @param $notify 表email_notify_list中的一条记录
	 */
	protected function send_notify_mail($notify) {
		$id = $notify['id'];
		$type = $notify['type'];
		// 从配置中获取邮件发送的地址
		$cnf_notify = $this->cnf_email_notify[$type];
		if (empty($cnf_notify)) {
			$this->log_result(__METHOD__,"no email notify config for id:{$id},type:{$type}.");
			return false;
		}
		$tos = explode(',',$cnf_notify['to']);
		if (empty($tos)) {
			$this->log_result(__METHOD__,"no email to config for id:{$id},type:{$type}.");
			return false;
		}
		$ccs = explode(',',$cnf_notify['cc']);
		// 获取发送邮件的内容
		$str = $notify['content'];
		$firstchar = $str[0];
		$endchar = $str[strlen($str) - 1];
		if(( $firstchar == '{' && $endchar == '}' ) || ( $firstchar == '[' && $endchar == ']' )){
			$d = json_decode($str, true);
			$tpl = $d['tpl'];
			$param = $d['param'];
			// 格式化参数中所有含amount金额
			foreach($param as $key=>$value) {
				if (strpos($key,'amount',0)!==false) {					
					$param[$key] = floor($value)/100;
				}
			}			
			$str = getLang("msgtpl.{$tpl}", $param);
		}
		list($subject, $content) = explode('[|||]', $str);		
		return $this->send_email($subject,$content,$tos,$ccs);
	}
	/**
	 * 邮件通知，系统CRONTAB调度任务
	 * 使用方式： * * * * * /usr/bin/php /sites/apicenter/tasks/task.php task_notify email_notify &
	 */
	public function email_notify(){
		$loop = 1;
		$is_exists = $this->check_runner_exists( __METHOD__ );
		if($is_exists){
			$this->log_result(__METHOD__,"another email_notify is running.");			
			return;
		}
		$init_ts = microtime(true);
		if(false === $is_exists){
			$loop = 50;
		}
		$limit = 10;
		$md_email_notify= & load_model('email_notify');
		$total_count = $failed_count = 0;
		do{
			$start_ts = microtime(true);
			$arr = $md_email_notify->getNotifySendList($limit);
			if (empty($arr)) {
				break;
			}
			$succeed_ids = array();
			$failed_ids = array();
			foreach ($arr as $row) {
				$id = $row['id'];
				$total_count ++;
				if ($this->send_notify_mail($row)) {
					$succeed_ids[] = $id;
				} else {
					$failed_ids[] = $id;
					$failed_count++;
				}
			}
			if(!empty($succeed_ids)){
				$md_email_notify->setNotifySent($succeed_ids,true);
			}
			if(!empty($failed_ids)){
				$md_email_notify->setNotifySent($failed_ids,false);
			}
			$this->runner_wait($start_ts, 1500000);
		}while(--$loop);
		$this->runner_clean( __METHOD__ );
		$res = array(
			'total_count' => $total_count,
			'failed_count' => $failed_count,
			'cost' => microtime(true) - $init_ts
			);
		$this->log_result(__FUNCTION__, $res);
	}

}