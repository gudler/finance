<?php
require_once PATH_BASE_CONTROLLER;

class Sign extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function day(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$md_sign = & load_model('sign');
		$today = date('Y-m-d');
		$today_info = $md_sign->dayGet($uid, $today);
		$day_idx = 1;
		if ($today_info) {
			$day_idx = $today_info['day_idx'];
			$money = $this->convHaoToFen( $today_info['amount'] );
		}else{
			$lastday = date('Y-m-d', strtotime("-1 day"));
			$lastday_info = $md_sign->dayGet($uid, $lastday);
			if($lastday_info){
				$_day_idx = $lastday_info['day_idx'];
				// 2017-10-17 
				// 加强判断逻辑,有可能数据库中记录修改过，值已经超过了7		
				if($_day_idx >= 7){
					$day_idx = 1;
				}else{
					$day_idx = $_day_idx + 1;
				}
			}
			$money = 1 * $day_idx;//单位分
			// 2017-11-14
			// 添加用户签到的额外信息收集
			$channel = $this->postval('channel');
			if (!$channel) {
				$channel  =0;
			}
			$app_version = $this->postval('app_version');
			if (!$app_version) {
				$app_version  = 'unknown';
			}
			$system_version = $this->postval('system_version');
			if (!$system_version) {
				$system_version  = 'unknown';
			}
			$device_model = $this->postval('device_model');
			if (!$device_model) {
				$device_model  = 'unknown';
			}
	
			$id = $md_sign->dayAdd($uid, $today, $this->convFenToHao( $money ), $day_idx, 
				$channel, $app_version, $system_version, $device_model);
		}
		// 2017-09-20 FIX BUG
		// 增加一个当天签到是否存在的标志:first_time，便于客户端来判断当天是否未第一次签到，不要重复显示签到页面		
		$res = array(
			'date' => $today,
			'day_idx' => $day_idx,
			'money' => $money,
			'first_time' => $today_info?0:1
			);
		$this->setData($res);
		$this->setCodeSuccess();
	}
}