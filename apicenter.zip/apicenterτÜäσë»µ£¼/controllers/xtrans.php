<?php
require_once PATH_BASE_CONTROLLER;
require_once PATH_PAYMENT_FUIOU;

class Xtrans extends Controller{
	
	protected $xtrans;

	public function __construct(){
		parent::__construct();
		$lib_xtransfer = & load_library('xtransfer');
		$allowed_ips = $lib_xtransfer->getAllowedIps();
		if( !$this->checkIP( $allowed_ips ) ){
			exit('Denied.');
		}
		$this->xtrans = $lib_xtransfer;
	}

	public function rechargeSmsCodeRequest(){
		$type = trim($this->postval('type'));// 60:转账充值,6:线下充值,22:退保证金；
		$id = trim($this->postval('id'));// 充值列表ID
		$role = trim($this->postval('role'));// acc:会计 / fin:财务 / mng:经理

		$tpinfo = $this->xtrans->getTemplateAndPhoneByTypeRole( $type, $role );
		if(false === $tpinfo){
			$this->setMsg( 'Error type or role' );
			return;
		}
		$md_accounts = & load_model('accounts');
		$orinfo = $md_accounts->getOfflineRechargeByRLID($id);
		if(empty($orinfo)){
			$this->setMsg( 'Recharge info not exists' );
			return;
		}
		if($orinfo['status'] != OFFLINE_RECHARGE_STATUS_NOTICED_LOCAL_SRV){
			$this->setMsg( 'Recharge info status incorrect' );
			return;
		}
		$code = mt_rand(100000, 999999);
		$md_sms = & load_model('sms');
		$code_id = $md_sms->addXtransVerifyCode($tpinfo['phone'], $code, $tpinfo['sms_type'], $tpinfo['template'], $id);
		if($code_id){
			$this->setResult(array('code_id' => $code_id));
			$this->setCodeSuccess();
		}
	}

	public function withdrawSmsCodeRequest(){
		$id = trim($this->postval('id'));//提现列表ID
		$order_id = trim($this->postval('order_id'));
		$role = trim($this->postval('role'));// acc:会计 / fin:财务 / mng:经理
		$cardno = trim($this->postval('cardno'));
		$username = trim($this->postval('username'));
		$money = trim($this->postval('money'));

		$tpinfo = $this->xtrans->getTemplateAndPhoneByRole( $role );
		if(false === $tpinfo){
			$this->setMsg( 'Error type or role' );
			return;
		}
		$md_accounts = & load_model('accounts');
		$owinfo = $md_accounts->getOfflineWithdrawByWLID($id);
		if(empty($owinfo)){
			$this->setMsg( 'Withdraw info not exists' );
			return;
		}
		require_once DIR_CORE . 'cipher.php';
		$cipher = Cipher::getInstance();

		$uid = $owinfo['uid'];
		$key = $cipher->getMDHashKey( $uid );
		$str = base64_decode($owinfo['cardno']);
		$raw = $cipher->aesDecode( $key, $str );
		$x_cardno = trim($raw);
		$str = base64_decode($owinfo['username']);
		$raw = $cipher->aesDecode( $key, $str );
		$x_username = trim($raw);
		$x_money = $owinfo['money'] - $owinfo['fee'];
		if($money != $x_money || $cardno != $x_cardno || $username != $x_username){
			$this->setMsg( 'Withdraw info error!!!' );
			return;
		}

		$code = mt_rand(100000, 999999);
		$md_sms = & load_model('sms');
		$code_id = $md_sms->addXtransVerifyCode($tpinfo['phone'], $code, $tpinfo['sms_type'], $tpinfo['template'], $id);
		if($code_id){
			$this->setResult(array('code_id' => $code_id));
			$this->setCodeSuccess();
		}
	}
	
	public function rechargeSmsCodeVerify(){
		
		$id = trim($this->postval('id'));
		$code_id = trim($this->postval('code_id'));
		$code = trim($this->postval('code'));
		$type = trim($this->postval('type'));
		$role = trim($this->postval('role'));
		
		$tpinfo = $this->xtrans->getTemplateAndPhoneByTypeRole( $type, $role );
		if(false === $tpinfo){
			$this->setMsg( 'Error type or role' );
			return;
		}
		$md_accounts = & load_model('accounts');
		$orinfo = $md_accounts->getOfflineRechargeByRLID($id);
		if(empty($orinfo)){
			$this->setMsg( 'Recharge info not exists' );
			return;
		}
		if($orinfo['status'] != OFFLINE_RECHARGE_STATUS_NOTICED_LOCAL_SRV){
			$this->setMsg( 'Recharge info status incorrect' );
			return;
		}

		$md_sms = & load_model('sms');
		
		$row = $md_sms->getPhoneCodeById($code_id);
		if(!$row){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		$matched = false;
		if( $row['code'] == $code 
			&& $row['ext_id'] == $id 
			&& $row['phone'] == $tpinfo['phone']
			&& $row['type'] == $tpinfo['sms_type']
			){
			$matched = true;
		}else{
			$this->setMsg( getlang('user.smscodenotmatch') );
		}
		if( strtotime($row['created_time']) < time() - 600 ){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$this->setResult(array('matched' => $matched));
		$this->setCodeSuccess();
	}

	public function withDrawSmsCodeVerify(){
		
		$id = trim($this->postval('id'));
		$code_id = trim($this->postval('code_id'));
		$code = trim($this->postval('code'));
		$role = trim($this->postval('role'));
		
		$tpinfo = $this->xtrans->getTemplateAndPhoneByRole( $role );
		if(false === $tpinfo){
			$this->setMsg( 'Error type or role' );
			return;
		}
		
		$md_sms = & load_model('sms');
		
		$row = $md_sms->getPhoneCodeById($code_id);
		if(!$row){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		$matched = false;
		if( $row['code'] == $code 
			&& $row['ext_id'] == $id 
			&& $row['phone'] == $tpinfo['phone']
			&& $row['type'] == $tpinfo['sms_type']
			){
			$matched = true;
		}else{
			$this->setMsg( getlang('user.smscodenotmatch') );
		}
		if( strtotime($row['created_time']) < time() - 600 ){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$this->setResult(array('matched' => $matched));
		$this->setCodeSuccess();
	}

	/**
	 * 获取未绑定还款人的借款列表
	 */
	public function getNotBoundProjcars(){
		$md_obligation = & load_model('obligation');
		$list = $md_obligation->getNotBoundProjcars();
		$this->setResult( $list );
		$this->setCodeSuccess();
	}

	/**
	 * 获取未上线债权
	 */
	public function getNotOnlineProjcar(){
		$md_obligation = & load_model('obligation');
		$list = $md_obligation->getReadyObligationInDH();
		$this->setResult( $list );
		$this->setCodeSuccess();
	}
	/**
	 *	获取债权综合信息列表：基本信息，绑定的还款人信息，是否上线中，是否已经在出售中，便于线下系统操作
	 */
	public function getComprehensiveProjcars() {
		$page = intval($this->postval('page'));
		$pagesize = intval($this->postval('pagesize'));
		$status = intval($this->postval('status'));
		if($pagesize<1 || $pagesize > 100){
			$pagesize = 30;
		}
		$index = max($page, 0);
		$filter_id = $this->postval('filter_id');
		
		$md_obligation = & load_model('obligation');
		$total = $md_obligation->getComprehensiveProjcarCount($status,$filter_id);
		$data = $md_obligation->getComprehensiveProjcarList( $index,$pagesize,$status,$filter_id);
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();		
	}

	/**
	 * 绑定借款还款人
	 * 内部应用系统测试
	 */
	public function bindProjcarPayer(){
		$uid = $this->postval('uid');
		$pid = $this->postval('pid');
		$skiprate = $this->postval('skiprate');
		if(empty($uid) || empty($pid)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		// 检查用户是否存在
		$md_user = & load_model('user');
		$user = $md_user->getUserById($uid);
		if(empty($user)){
			$this->setMsg( getLang('loan.user_not_exists') );
			return;
		}
		// 检查用户是否绑卡
		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
		if(empty($accinfo)){
			$this->setMsg( getLang('loan.user_not_bind_card') );
			return;
		}
		// 检查合同
		$md_loan = & load_model('loan');
		// 检查合同是否存在
		$projcar = $md_loan->getProjcarDetail( $pid );
		if(empty($projcar)){
			$this->setMsg( getLang('loan.projcar_not_exists') );
			return;
		}
		// 检查合同利率，
		// 2018-05-08 有的合同利息提前支付，只还本金，利率可以是0
		$rate = $projcar['rate'];
		if(!$skiprate && $rate < 0 ){
			$this->setMsg( getLang('loan.rate_not_exists') );
			return;
		}
		// 检查还款是否存在
		$loan = $md_loan->getLoanInfo($pid, true);
		if(!empty($loan)){
			$this->setMsg( getLang('loan.info_already_exists') );
			return;
		}
		// 检查还款列表是否存在
		$list = $md_loan->getLoanRepaymentListByPid($pid);
		if(!empty($list)){
			$this->setMsg( getLang('loan.list_already_exists') );
			return;
		}
		// 生成数据
		$repayment_method = $projcar['repayment_method'];
		$total_loan = $projcar['total_loan'];
		$total_period = $projcar['total_period'];
		$left_period = $projcar['left_period'];
		$repayment_date = $projcar['repayment_date'];
		$first_repayment_date = $projcar['first_repayment_date'];
		$repayment_day = $projcar['repayment_day'];
		$helper_in = load_helper('interest');
		$each_month = round( $helper_in::principalAndInterestEqual($total_loan, $rate, $total_period)/100 ) * 100;//精确到分

		$now = time();
		$ts_first_date = strtotime($first_repayment_date);
		$year = date('Y', $ts_first_date);
		$month = date('n', $ts_first_date);

		// 检查当前操作的时间是否在合同的剩余期数允许的时间内
		// 如果不在，需要同财务确认，用户还款到底多少，剩余期数是怎样的，并并手动修改合同的剩余
		$past_period = $total_period - $left_period;
		$past_year = intval($past_period/12);
		$past_month = intval($past_period%12);
		$last_year = $year+$past_year;
		$last_month = $month+$past_month;
		if ($last_month>=12) {
			$last_month -= 12;
			$last_year++;
		}
		// 根据剩余期数算出来的用户最后一次支付的日期
		$last_paid_date = $helper_in::getRepaymentDate($repayment_day, $last_month, $last_year);
		$prev_year = $last_year;
		$prev_month = $last_month-1;
		if ($prev_month<=0) {
			$prev_month = 12;
			$prev_year--;
		}
		// 根据剩余期数算出来的用户最后一次支付的上一个月日期
		$prev_paid_date = $helper_in::getRepaymentDate($repayment_day, $prev_month, $prev_year);
		$last_paid_time = strtotime($last_paid_date.' 22:00:00');//23点系统就停止自动还款了，所以设置成22点
		$prev_paid_time = strtotime($prev_paid_date.' 23:59:59'); 
		if ( ($now>$prev_paid_time && $now<=$last_paid_time) || $prev_paid_time>=$now ) {
			// 正好落在剩余期数所在的时间访问或者剩余期数比现在还提前多还了（提前绑定债权或者用户多还款的情况）。
		} else {
			$this->setMsg( getLang('loan.projcar_left_period_not_matched') );
			return;
		}

		$paid_interest = 0;
		$left_loan = 0;
		$paid_loan = 0;
		$last_loan = $total_loan;
		$recent_repayment_date = null;
		$loan_repayment_list = array();
		for($period_id = $total_period; $period_id > 0; $period_id --){
			$date = $helper_in::getRepaymentDate($repayment_day, $month, $year);
			$interest = round($last_loan * $rate/12/100) * 100;//精确到分
			$principal = $each_month - $interest;
			$last_loan -= $principal;
			$interest_days = $helper_in::getRepaymentMonthDays($repayment_day, 1, $month, $year);
			$day_interest = ceil($interest/$interest_days/100) * 100;//精确到分
			if($period_id > $left_period){
				$status = LOAN_REPAYMENT_STATUS_RETURNED;
				$paid_interest += $interest;
				$paid_loan += $principal;
			}else{
				if(empty($recent_repayment_date)){
					$recent_repayment_date = $date;
				}
				$status = LOAN_REPAYMENT_STATUS_NORMAL;
			}
			$loan_repayment_list[] = array(
				'principal'=>$principal,
				'interest'=>$interest,
				'each_month'=>$each_month,
				'day_interest'=>$day_interest,
				'interest_days'=>$interest_days,
				'period_id' => $period_id,
				'repayment_date' => $date,
				'status' => $status,
			);
			$month ++;
			if($month>12){
				$year ++;
				$month = 1;
			}
		}
		$left_loan = $total_loan - $paid_loan;
		$loan_info = array(
			'total_loan' => $total_loan,
			'paid_loan' => $paid_loan,
			'left_loan' => $left_loan,
			'paid_interest' => $paid_interest,
			'recent_repayment_date' => $recent_repayment_date,
		);
		// 检查还款合同按首次还款日期计算是否已经结束		
		if (empty($recent_repayment_date)||$left_loan<=0) {
			$this->setMsg( getLang('loan.projcar_finished') );
			return;
		}
		// 插入数据库
		$result = $md_loan->addLoan($uid,$pid,$loan_info,$loan_repayment_list);
		if (!$result) {
			$this->setMsg( getLang('sys.database_error'));
			return;
		}
		// 检查是否插入了还款信息
		$loan = $md_loan->getLoanInfo($pid, true);
		if(empty($loan)){
			$this->setMsg( getLang('loan.info_not_exists') );
			return;
		}
		// 检查是否插入了还款列表信息
		$list = $md_loan->getLoanRepaymentListByPid($pid);
		if(empty($list)){
			$this->setMsg( getLang('loan.list_not_exists') );
			return;
		}
		$this->setData(array('uid' => $uid, 'pid' => $pid));
		$this->setCodeSuccess();
	}

	/**
	 * 获取借款信息
	 */
	public function getLoanDetail(){
		$id = $this->postval('id');
		$uid = $this->postval('uid');
		if(empty($id)||empty($uid)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_loan = & load_model('loan');
		$helper = load_helper('codemap');
		$data = $md_loan->getLoanInfo( $id );
		if(!empty($data)){
			if($uid != $data['uid']){
				$this->setMsg( getLang('sys.invalid_params') );
				return;
			}
			$data['name'] = "{$data['make']} {$data['model']}";
			$data['total_loan'] = $this->convHaoToFen( $data['total_loan'] );
			$data['left_loan'] = $this->convHaoToFen( $data['left_loan'] );
			$data['returned_loan'] = $this->convHaoToFen( $data['returned_loan'] );
			$data['paid_interest'] = $this->convHaoToFen( $data['paid_interest'] );
			$data['paid_overdue_fee'] = $this->convHaoToFen( $data['paid_overdue_fee'] );
			$data['repayment_method_txt'] = $helper::repaymentMethod( $data['repayment_method'] );
			$data['status_txt'] = $helper::loanInfoStatusCodeName( $data['status'], $data['curr_overdue_days'] );
			$list = $md_loan->getLoanRepaymentListByPid( $id );
			foreach ($list as &$row) {
				$row['principal'] = $this->convHaoToFen( $row['principal'] );
				$row['paid_principal'] = $this->convHaoToFen( $row['paid_principal'] );
				$row['interest'] = $this->convHaoToFen( $row['interest'] );
				$row['paid_interest'] = $this->convHaoToFen( $row['paid_interest'] );
				$row['day_interest'] = $this->convHaoToFen( $row['day_interest'] );
				$row['overdue_fee'] = $this->convHaoToFen( $row['overdue_fee'] );
				$row['paid_overdue_fee'] = $this->convHaoToFen( $row['paid_overdue_fee'] );
				$row['status_txt'] = $helper::loanRepaymentStatusCodeName( $row['status'], $row['overdue_days'] );
				$row['index'] = $data['total_period'] - $row['period_id'] + 1;
			}
			$data['list'] = $list;
		}
		$this->setData( $data );
		$this->setCodeSuccess();
	}	
	/**
	 * 设置债权上线时间
	 */
	public function setProjcarOnline(){
		$id = $this->postval('id');
		// 2018-02-26
		// 增加债权上线时间相关逻辑
		$show_time = $this->postval('show_time');
		$up_time = $this->postval('up_time');
		$rate = $this->postval('rate');
		$closed_period = intval($this->postval('closed_period'));
		if($rate > 0.12 || $rate < 0.01){
			$this->setMsg( getlang('loan.rate_error') );
			return;
		}
		$ts = strtotime($up_time);
		if($ts < time() - 600){
			$this->setMsg( getlang('loan.up_time_error') );
			return;
		}
		$ts_show = strtotime($show_time);
		if(empty($show_time) || $ts <= $ts_show){
			$this->setMsg( getlang('loan.show_time_error') );
			return;
		}
		
		if($closed_period <= 0 || $closed_period > 36){
			$this->setMsg( getlang('loan.closed_period_error') );
			return;
		}
		$up_time = date('Y-m-d H:i:s', $ts);

		$md_obligation = & load_model('obligation');
		$md_rate = & load_model('rate');
		$plan_info = $md_obligation->getObligationsPlanById($id);
		if(!empty($plan_info)){
			$this->setMsg( getlang('loan.obl_plan_exists') );
			return;
		}

		$md_loan = & load_model('loan');
		$loan = $md_loan->getLoanInfo($id, true);
		if(empty($loan)){
			$this->setMsg( getLang('loan.info_not_exists') );
			return;
		}
		
		$obl_info = $md_obligation->getOblDetailByExtid( $id );
		if(!empty($obl_info)){
			$this->setMsg( getlang('loan.obl_exists') );
			return;
		}		
		$proj_info = $md_obligation->getProjcarDetail( $id );
		if(empty($proj_info)){
			$this->setMsg( getlang('loan.projcar_not_exists') );
			return;
		}
		$left_period = $proj_info['left_period'];
		$all_period_rate = $this->postval('all_period_rate');
		if (empty($all_period_rate)) {
			$all_period_rate = $md_rate->getAllClosedRate($md_rate->getCurrentRate(), $left_period);
		}
		if($all_period_rate > 0.12 || $all_period_rate < $rate){
			$this->setMsg( getlang('loan.all_period_rate_error') );
			return;
		}
		$closed_days = $closed_period * 30;
		$bool = $md_obligation->addObligationPlan2($id, $rate, $all_period_rate, $closed_days, $show_time, $up_time);
		if($bool){
			$this->setCodeSuccess();
		} else {
			$this->setMsg( getlang('sys.database_error') );			
		}
	}

	/**
	 * 提前结清贷款
	 * 内部应用系统测试
	 */
	public function finishLoanEarly(){
		$pid = $this->postval('pid');
		// 2017-09-28 增加用户ID参数，用于检查
		$uid = $this->postval('uid');
		if(empty($pid) ||empty($uid) ){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_loan = & load_model('loan');
		$md_obligation = & load_model('obligation');

		//获取债权信息
		$detail = $md_obligation->getOblDetailByExtid( $pid );
		$loan = $md_loan->getLoanInfo($pid, true);
		if(empty($detail) && empty($loan)){
			$this->setMsg( getLang('obligation.not_exists') );
			return;
		}
		if ($loan['uid']!=$uid) {
			$this->setMsg( getLang('loan.user_not_matched') );
			return;
		}
		$md_msg = & load_model('msg');
		$codemap = load_helper('codemap');
		$counter = array(
			'total_all' => 0,
			'ok_total' => 0,
			'total_interest' => 0,
			'ok_interest' => 0,
			'total_loan' => 0,
			'ok_loan' => 0,
			);
		if(!empty($detail)){
			//辨别债权状态，若债权不为开放or售空，则跳出
			if($detail['status'] != OBL_STATUS_OPEN && $detail['status'] != OBL_STATUS_SOLDOUT){
				$this->setMsg( getLang('obligation.status', array('status' => $codemap::obligationStatusCodeName($detail['status']))) );
				return;
			}
			//标记债权处理完毕
			$id = $detail['id'];
			$b_obl = $md_obligation->updateObligationDone( $id );
			$list = $md_obligation->getHoldingObligationByOid( $id );
			if(!empty($list)){
				foreach ($list as $row) {
					$counter['total_all']++;
					$uid = $row['uid'];
					$oid = $row['oid'];
					$uoid = $row['id'];
					$amount = $row['left_amount'];
					// 2017-11-15 新邀请 DONE
					// 提前结清债权的时候，添加支付记录到obligation_repayment表中，这些是需要的数据
					$name = $row['name'];
					$via = $row['via'];
					$auto_shift = $row['auto_shift'];
					$shift_to = $row['shift_to'];
					
					//获取未付利息，若利息>0，则进行支付操作
					$interest = $md_obligation->getObligationInterest( $uoid );
					$interest = intval($interest);
					if($interest>0){
						$counter['total_interest']++;
						$bool = $md_obligation->paybackObligationInterestEarly( $uoid, $oid, $uid, $interest );
						if($bool){
							$counter['ok_interest']++;
							$content = json_encode(array(
								'tpl' => MSGTPL_OBL_PAIDEARLY_INTEREST,
								'param' => array(
									'id' => $uoid,
									'amount' => floor($interest/100)
									),
								));
							$md_msg->addMsg($uid, $content);
						}
					}
					// 将剩余本金还给用户
					// 2017-11-15 新邀请 DONE
					// 提前结清债权的时候，添加支付记录到obligation_repayment表中，这些是需要的数据
					// 2017-11-22 VERIFIED
					$bool = $md_obligation->paybackObligationEarly( $uoid, $oid, $uid, $amount, $interest, $name, $via, $auto_shift, $shift_to );
					if($bool){
						$counter['ok_total']++;
						$content = json_encode(array(
							'tpl' => MSGTPL_OBL_PAIDEARLY,
							'param' => array(
								'id' => $uoid,
								'amount' => floor($amount/100)
								),
							));
						$md_msg->addMsg($uid, $content);
					}
				}
			}
			// 2018-07-06
            // 原来持有的已经转让给其他用户的记录不在列表中，但是这些转让的用户持有的债权利息还未支付
            // 所以这里提前结清的话，那一部分用户持有的利息没有支付，这里调用处理一下
            $unpaid_list = $md_obligation->getUnpaidObligationInterestsForEarly($id);
            if (!empty($unpaid_list)) {
                $name = $detail['name'];
                foreach ($unpaid_list as $row) {
					$counter['total_all']++;
					$uid = $row['uid'];
					$oid = $row['oid'];
					$uoid = $row['uoid'];
					$interest = $row['interest'];
					$interest = intval($interest);
					if($interest>0){
						$counter['total_interest']++;
						$bool = $md_obligation->paybackObligationInterestEarlyWithRepayment( $uoid, $name, $oid, $uid, $interest );
						if($bool){
							$counter['ok_interest']++;
							$content = json_encode(array(
								'tpl' => MSGTPL_OBL_PAIDEARLY_INTEREST,
								'param' => array(
									'id' => $uoid,
									'amount' => floor($interest/100)
								),
							));
							$md_msg->addMsg($uid, $content);
						}
					}
				}
            }
		}
		if(!empty($loan) && in_array($loan['status'], array(LOAN_INFO_STATUS_NORMAL, LOAN_INFO_STATUS_OVERDUED))){
			$counter['total_loan']++;
			$bool = $md_loan->loanPayEarly($pid);
			if($bool){
				$counter['ok_loan']++;
			}
		}
		$this->setData($counter);
		$this->setCodeSuccess();
	}

	/**
	 * 校验用户信息，可以对于输入的手机号码和卡号进行单独或者组合查询
	 */
	public function verifyUser(){
		$mobile = $this->postval('mobile');
		if(!empty($mobile)){
			$mobile = $this->checkMobileNumber($mobile);
			if($mobile==false){
				return;
			}
		}
		$p_cardno = $this->postval('cardno');
		$key_cardno = '';
		if (!empty($p_cardno)) {
			$key_cardno = $this->getUniqKey($p_cardno);
		}		
		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserCurrentBankAccount2($mobile, $key_cardno);
		if (empty($accinfo)) {
			$this->setMsg( getlang('user.notexists') );
			return;		
		}
		$uid = $accinfo['uid'];
		$info = $md_accounts->getUserAccountInfo($uid);
		$helper = load_helper('codemap');
		$matched = false;
		if(isset($accinfo['bid'])){
			$key = $this->getMDHashKey( $uid );
			$bank = $accinfo['bank'];
			$phone = $this->mdataDecrypt($key, $accinfo['phone']);
			$identcode = $this->mdataDecrypt($key, $accinfo['identcode']);
			$cardno = $this->mdataDecrypt($key, $accinfo['cardno']);
			$realname = $this->mdataDecrypt($key, $accinfo['realname']);
			if($p_cardno == $cardno){
				$matched = true;
			}
			/* 2017-11-21， 内部管理系统可以查看全部信息

			$len = strlen($cardno);
			$cardno = substr($cardno, 0, 6) . str_pad('', $len - 10, '*') . substr($cardno, -4);
			
			$len = strlen($phone);
			$phone = substr($phone, 0, 3) . str_pad('', $len - 7, '*') . substr($phone, -4);

			$len = strlen($identcode);
			if($len > 8){
				$identcode = substr($identcode, 0, 1) . '***' . substr($identcode, 4, 5) . str_pad('', $len - 10, '*') . substr($identcode, -1);
			}else{
				$identcode = substr($identcode, 0, 1) . '***' . substr($identcode, 4, 5);
			}
			*/
			
			// 2018-04-10
			// 内部系统可以看到用户充值、提现相关的所有记录
			$logs = $md_accounts->getUserAccountLogs($uid, array(
				USRACCOUNT_ACTION_RECHARGE,USRACCOUNT_ACTION_OFFLINE_RECHARGE,
				USRACCOUNT_ACTION_WITHDRAW_ROLLBACK,USRACCOUNT_ACTION_LARGE_AMT_RECHARGE,
				USRACCOUNT_ACTION_PAYBACK_TRADEFEE,USRACCOUNT_ACTION_PAYBACK_DEPOSIT,
				USRACCOUNT_ACTION_WITHDRAW,USRACCOUNT_ACTION_OFFLINE_WITHDRAW,
				USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK,USRACCOUNT_ACTION_RETURN_LOAN,
				USRACCOUNT_ACTION_RETURN_LOAN_PIECE));

			if(!empty($logs))
				foreach ($logs as &$row) {
					$row['action'] = $helper::accountActionName($row['action']);
					$row['amount_before'] = $this->convHaoToFen($row['amount_before']);
					$row['amount_change'] = $this->convHaoToFen($row['amount_change']);
					$row['amount_after'] = $this->convHaoToFen($row['amount_after']);
				}
		}else{
			$bank = '';
			$phone = '';
			$identcode = '';
			$cardno = '';
			$realname = '';
			$logs = getLang('account.need_bind_one_card');
		}
		if(!is_array($info)){
			$info = array();
		}else{
			$info['amount'] = $this->convHaoToFen($info['amount']);
			$info['total_amount'] = $this->convHaoToFen($info['total_amount']);
			$info['total_interest'] = $this->convHaoToFen($info['total_interest']);
		}
		$this->setData('info', array_merge($info, array(
			'bank' => $bank,
			'bank_phone' => $phone,
			'identcode' => $identcode,
			'cardno' => $cardno,
			'cardno_matched' => $matched,
			'realname' => $realname,
			'logs' => $logs,
			)));
		$this->setCodeSuccess();
	}

	public function cardRelSmsCodeRequest(){
		$type = trim($this->postval('type'));// 1:换卡； 2:线下绑卡
		if($type == 1){
			$type = SMS_CODE_TYPE_CHANGE_CARD;
			$phone = '13564905868';//操作换卡人员的电话
			$template = 'SMS_74675022';
		}elseif($type == 2){
			$type = SMS_CODE_TYPE_BIND_OFFLINE_CARD;
			$phone = '13564905868';//操作线下绑卡人员的电话
			$template = 'SMS_74545032';
		}else{
			$this->setMsg( 'Error type.' );
			return;
		}
		$md_accounts = & load_model('accounts');
		$code = mt_rand(100000, 999999);
		$md_sms = & load_model('sms');
		$code_id = $md_sms->addPhoneCode($phone, $code, $type, $template);
		if($code_id){
			$this->setResult(array('code_id' => $code_id));
			$this->setCodeSuccess();
		}
	}

	/**
	 *	绑定OFFLINE银行卡。线下绑卡使用
	 */
	public function bindOfflineCard(){
		$idtype = $this->postval('idtype');//默认身份证: 0，身份证；1，台胞证； 2，护照
		$idno = $this->postval('idno');
		$user = $this->postval('mobile');// 所需更换或绑定银行卡鹰眼理财账户手机号
		$phone = $this->postval('bank_phone');
		$realname = $this->postval('realname');
		$cardno = $this->postval('cardno');
		$code_id = $this->postval('code_id');//操作人员验证码ID
		$code = $this->postval('code');//操作人员验证码

		$md_sms = & load_model('sms');
		$sms_info = $md_sms->getPhoneCodeById($code_id);
		if(!$sms_info){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		$matched = false;
		if( $sms_info['code'] != $code || $sms_info['type'] != SMS_CODE_TYPE_BIND_OFFLINE_CARD ){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		if( strtotime($sms_info['created_time']) < time() - 300 ){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}

		//人工校验身份证是否合法
		
		$md_user = & load_model('user');
		$userinfo = $md_user->getUserByPhone($user);
		if(empty($userinfo) || !isset($userinfo['id']) || empty($userinfo['id'])){
			$this->setMsg( getlang('user.notexists') );
			return;
		}
		$uid = $userinfo['id'];

		$md_accounts = & load_model('accounts');

		$info = $md_accounts->getUserAccountInfo($uid);
		if(!empty($info)){
			if($info['status'] == USRACCOUNT_STATUS_NORMAL){
				//线下用户不可绑卡，但返回为服务不可用
				$this->setMsg( getlang('account.its_an_online_account') );
				return;
			}elseif($info['status'] == USRACCOUNT_STATUS_OFFLINE){
				$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
				if (!empty($accinfo)) {
					//用户已绑卡
					$this->setMsg( getlang('account.bankcardexists') );
					return;
				}
			}
		}

		//检查银行卡是否支持
		$bkq = new BankcardQuery_pub;
		$bkq->setBankcardno( $cardno );
		$res = $bkq->getUseful();
		// 2017-11-29 
		// 修改返回错误提示信息
		if(false === $res){
			$this->setMsg( getlang('account.card_verify_service_down') );
			return;
		}
		if($res['code'] != BANK_CARD_OK){
			$error = '';
			if(!empty($res['msg'])){
				$error = $res['msg'];
			}else{
				$error = getlang('account.card_verify_service_down');
			}
			$this->setMsg( $error );
			return;
		}
		if($res['cardtype'] != BANK_CARD_TYPE_DEBIT_CARD){
			$this->setMsg( getlang('account.card_type_only_debit_card') );
			return;
		}
		$bank = $res['bankname'];


		$key = $this->getMDHashKey( $uid );
		$_cardno = $this->mdataEncrypt($key, $cardno);
		$_idno = $this->mdataEncrypt($key, $idno);
		$_phone = $this->mdataEncrypt($key, $phone);
		$_realname = $this->mdataEncrypt($key, $realname);

		$seqid = $md_accounts->regBankAccountVerify($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone);
		if(empty($seqid)){
			$this->setMsg( getlang('account.get_bankacc_verify_id_failed') );
			return false;
		}
		
		$key_mobile = $this->getUniqKey( $phone );
		$key_cardno = $this->getUniqKey( $cardno );
		$key_identcode = $this->getUniqKey( $idno );
		// 2018-05-18 线下绑卡加上证件个数限制
		$numb = $md_accounts->countAccByIdentID($key_identcode);
		if($numb && $numb >= LIMIT_ACC_SAME_USER){
			$this->setMsg( getlang('account.same_user_accounts_limit') );
			return;
		}
		
		$bool = $md_accounts->regBankAccount($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone, $key_mobile, $key_cardno, $key_identcode);
		if(!$bool){
			$msg = stored_messages();
			if(empty($msg)){
				$msg = getlang('sys.serverunavailable');
			}
			$this->setMsg( $msg );
			return;
		}
		
		if(null === $info){
			$md_accounts->regAccountOffline( $uid );
		}elseif($info && $info['status'] == USRACCOUNT_STATUS_EGG){
			$md_accounts->updateAccountOffline( $uid );
		}
		// 2018-05-31
		// BUG FIX 不是‘mobile’而是‘phone’
		$md_sms->useCode($sms_info['phone'], $code);
		$this->setData('success', true);
		$this->setCodeSuccess();
	}


	/**
	 *	换绑定银行卡。
	 */
	public function changeBoundCard(){
		$idtype = intval($this->postval('idtype'));
		$idno = $this->postval('idno');
		$user = $this->postval('mobile');
		$phone = $this->postval('bank_phone');
		$realname = $this->postval('realname');
		$cardno = $this->postval('cardno');
		$old_cardno = $this->postval('old_cardno');

		$code_id = $this->postval('code_id');//操作人员验证码ID
		$code = $this->postval('code');//操作人员验证码

		$md_sms = & load_model('sms');
		$sms_info = $md_sms->getPhoneCodeById($code_id);
		if(!$sms_info){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		$matched = false;
		if( $sms_info['code'] != $code || $sms_info['type'] != SMS_CODE_TYPE_CHANGE_CARD ){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		if( strtotime($sms_info['created_time']) < time() - 300 ){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}

		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}
		if($idtype === 0){
			//如果是身份证，则校验身份证是否合法
			$helper = load_helper('certcardrpc');
			if(!$helper::check_id($idno)){
				$this->setMsg( getlang('account.cert_card_rpc_invalid') );
				return;
			}
		}

		$md_user = & load_model('user');
		$info = $md_user->getUserByPhone($user);
		if(empty($info) || !isset($info['id']) || empty($info['id'])){
			$this->setMsg( getlang('user.notexists') );
			return;
		}
		$uid = $info['id'];

		//检查银行卡是否支持
		$bkq = new BankcardQuery_pub;
		$bkq->setBankcardno( $cardno );
		$res = $bkq->getUseful();
		// 2017-11-29 
		// 修改返回错误提示信息
		if(false === $res){
			$this->setMsg( getlang('account.card_verify_service_down') );
			return;
		}
		if($res['code'] != BANK_CARD_OK){
			$error = '';
			if(!empty($res['msg'])){
				$error = $res['msg'];
			}else{
				$error = getlang('account.card_verify_service_down');
			}
			$this->setMsg( $error );
			return;
		}
		if($res['cardtype'] != BANK_CARD_TYPE_DEBIT_CARD){
			$this->setMsg( getlang('account.card_type_only_debit_card') );
			return;
		}
		$bank = $res['bankname'];


		$key = $this->getMDHashKey( $uid );
		$_cardno = $this->mdataEncrypt($key, $cardno);
		$_idno = $this->mdataEncrypt($key, $idno);
		$_phone = $this->mdataEncrypt($key, $phone);
		$_realname = $this->mdataEncrypt($key, $realname);

		$md_accounts = & load_model('accounts');

		$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
		$need_remove_card = false;
		if(!empty($accinfo) && isset($accinfo['id'])){
			$x_identcode = $this->mdataDecrypt($key, $accinfo['identcode']);
			$x_cardno = $this->mdataDecrypt($key, $accinfo['cardno']);
			$x_realname = $this->mdataDecrypt($key, $accinfo['realname']);
			if($x_cardno != $old_cardno){
				$this->setMsg( getlang('account.old_card_not_match') );
				return;
			}
			if($x_identcode != $idno){
				$this->setMsg( getlang('account.identcode_not_same') );
				return;
			}
			if($x_realname != $realname){
				$this->setMsg( getlang('account.realname_not_same') );
				return;
			}
			$need_remove_card = true;
			
		}else{
			$this->setMsg( getlang('account.bankacc_not_exists') );
			return;
		}
		$seqid = $md_accounts->regBankAccountVerify($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone);
		if(empty($seqid)){
			$this->setMsg( getlang('account.get_bankacc_verify_id_failed') );
			return false;
		}
		if ($idtype === 0) {
			//当类型为身份证时可以进行四要素验证
			$vci = new VerifyCardInfo_pub;
			$vci->setSequnceID( $seqid );
			$vci->setBankcardno( $cardno );
			$vci->setUsername( $realname );
			$vci->setIDNumber( $idno );
			$res = $vci->getResponse();

			if(true !== $res){
				if(empty($res)){
					$res = getLang('account.card_verify_service_down');
				}
				$this->setMsg( $res );
				return;
			}
		}
		if($need_remove_card){
			$md_accounts->removeBankAccount($uid, $accinfo['id']);
		}

		$key_mobile = $this->getUniqKey( $phone );
		$key_cardno = $this->getUniqKey( $cardno );
		$key_identcode = $this->getUniqKey( $idno );
		$bool = $md_accounts->regBankAccount($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone, $key_mobile, $key_cardno, $key_identcode);
		if(!$bool){
			$msg = stored_messages();
			if(empty($msg)){
				$msg = getlang('sys.serverunavailable');
			}
			$this->setMsg( $msg );
			return;
		}
		$info = $md_accounts->getUserAccountInfo($uid);
		if(null === $info){
			$md_accounts->regAccount( $uid );
		}
		// 2018-05-31
		// BUG FIX 不是‘mobile’而是‘phone’
		$md_sms->useCode($sms_info['phone'], $code);
		$this->setData('success', true);
		$this->setCodeSuccess();
	}

	/**
	 *	获取平台退票
	 */
	public function getUserWithdrawTPs() {
		$page = intval($this->postval('page'));
		$pagesize = intval($this->postval('pagesize'));
		$status = $this->postval('status');
		if ($status!==null) {
			$status = intval($status);
		}
		if($pagesize<1 || $pagesize > 100){
			$pagesize = 30;
		}
		$page = max($page, 0);
		$filter_orderno = $this->postval('filter_orderno');
		
		$md_accounts = & load_model('accounts');
		$total = $md_accounts->getWithdrawTPCount($status,$filter_orderno);
		$data = $md_accounts->getWithdrawTPs( $page,$pagesize,$status,$filter_orderno);
		$this->setData( array(
			'total' => $total,
			'page' => $page,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();		
	}

	/**
	 *	用户退票返还
	 */
	public function accWithdrawTP(){
		$orderno = $this->postval('orderno');
		$md_accounts = & load_model('accounts');
		$info = $md_accounts->getWithdrawTuipiao($orderno);
		if(empty($info)){
			$this->setMsg( getLang('account.order_not_exists') );
			return;
		}
		$order = $md_accounts->getWithdrawOrderByOrderId( $orderno );
		if(empty($order)){
			$this->setMsg( getLang('account.withdraw_order_not_exists') );
			return;
		}
		// 判断退票订单状态
		if ($info['status']!=WITHDRAW_TUIPIAO_CONFIRMED){
			$this->setMsg( getLang('account.withdraw_tp_status_not_confirmed') );
			return;
		}
		// 判断用户ID是否正确
		if ($info['uid']!=$order['uid']){
			$this->setMsg( getLang('account.withdraw_tp_user_not_match') );
			return;
		}		
		// 判断卡号是否正确
		$key = $this->getMDHashKey( $order['uid'] );
		$raw_cardno = $this->mdataDecrypt($key, $order['cardno']);
		if ($info['accntno']!=$raw_cardno) {
			$this->setMsg( getLang('account.withdraw_tp_cardno_not_match') );
			return;
		}
		// 判断金额是否正确
		if ($info['amt']+$info['fee']!=$order['money']) {
			$this->setMsg( getLang('account.withdraw_tp_money_not_match') );
			return;
		}
		// 判断提现记录状态是否正确
		if ($order['status']!=WITHDRAW_STATUS_DONE){
			$this->setMsg( getLang('account.withdraw_tp_withdraw_status_not_done') );
			return;
		}		
		$bool = false;
		$amt = floor($info['amt']);//分，不作处理
		$fee = floor($info['fee']);//分，不作处理
		$amount = $amt + $fee;
		$uid = $info['uid'];
		$tpid = $info['id'];
		$id = $order['id'];
		$baid = $order['baid'];
		$bool = $md_accounts->withdrawOrderTuipiaoRollbacked( $id, $tpid, $uid, $amount, $baid );
		if ($bool==false) {
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$this->setCodeSuccess();
	}

    /**
     * 设置用户其他联系方式
     */
    public function setUserContact(){
        $mobile = trim($this->postval('mobile'));
        $contact = trim($this->postval('contact'));
        if(empty($mobile) || empty($contact)){
            $this->setMsg( getLang('sys.invalid_params') );
            return;
        }

        $md_user = & load_model('user');
        // 检查用户是否存在
        $user = $md_user->getUserByPhone($mobile);
        if(empty($user)){
            $this->setMsg( getLang('user.notexists') );
            return;
        }
        // 更新数据库
        $result = $md_user->updateUserContact($mobile,$contact);
        if(!$result) {
            $this->setMsg( getLang('sys.database_error'));
            return;
        }

        $this->setData('success', true);
        $this->setCodeSuccess();
    }
}