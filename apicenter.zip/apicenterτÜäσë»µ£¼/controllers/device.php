<?php
require_once PATH_BASE_CONTROLLER;

class Device extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function regPublicKey(){
		$cipher = $this->getCipher();
		$pubkey = $cipher->getUserPublicKey();
		if($pubkey){
			$this->setCode(CODES_USER_RSAKEY_EXISTS);
			$this->setMsg( getlang('device.publickeyalreadyexists') );
			return;
		}
		$code = $cipher->initRSAKey();
		if(CODES_OK === $code){
			$pubkey = $cipher->getUserPublicKey();
			$aeskey = $cipher->getAESKey();
			if($aeskey){
				$data = $cipher->rsaPuEncode( $pubkey, $aeskey );
				$data = base64_encode($data);
				$this->setCodeSuccess();
				$this->setData( array('key'=>$data) );
			}else{
				$this->setCode(CODES_AESKEY_NOTGOT);
				$this->setMsg( getlang('device.aeskeyfetcherror') );
			}
		}else{
			$this->setCode( $code );
			$this->setMsg(stored_messages());
		}
	}

	public function iOSToken(){
		$logintoken = trim($this->postval('logintoken'));
		$devicetoken = trim($this->postval('devicetoken'));
		$md_user = & load_model('user');
		$uid = null;
		$plantform = 'iOS';
		if(!empty($logintoken)){
			$info = $md_user->getHistoryInfoByToken($logintoken);
			if(!empty($info) && isset($info['id'])){
				$uid = $info['id'];
			}
		}
		if(!empty($devicetoken)){
			// 2018-08-23 69豪车整合
			$app = $this->getApp();
			$bool = $md_user->addDeviceToken( $uid, $devicetoken, $plantform, $this->getDeviceID(), $this->getIP(), $app);
			if($bool){
				$this->setCodeSuccess();
			}
		}

	}

}