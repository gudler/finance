<?php

require_once PATH_BASE_CONTROLLER;
/**
 * 债权导入单独任务
 */
class Task_projcar_import extends Controller{

	protected function check_runner_exists( $runner_name ){
		$pid_file = sys_get_temp_dir() . '/' . $runner_name . '.run.pid';
		if(file_exists($pid_file)){
			$pid = file_get_contents($pid_file);
			if(file_exists('/proc/')){
				if(file_exists('/proc/'.$pid)){
					return true;
				}
			}else{
				@$r = pcntl_getpriority($pid);
				if($r>0){
					return true;
				}
			}
		}
		if(function_exists('posix_getpid')){
			$pid = posix_getpid();
		}else{
			return null;
		}
		file_put_contents($pid_file, $pid);
		return false;
	}

	protected function runner_clean( $runner_name ){
		$pid_file = sys_get_temp_dir() . '/' . $runner_name . '.run.pid';
		if(file_exists($pid_file)){
			unlink($pid_file);
		}
	}

	protected function runner_wait($start_ts, $microsec, $busy_stop = 1000000){
		$end_ts = microtime(true);
		$cost = ($end_ts - $start_ts) * 1000000;
		if($cost > $microsec){
			usleep( $busy_stop );
		}else{
			usleep( $microsec - $cost );
		}
	}

	protected function log_result($func, $result){
		$filename = DIR_LOG . 'task_projcar_import_result_' . date('Y-m') . '.log';
		$data = sprintf("%s\t%s\t%s\n", date('Y-m-d H:i:s'), $func, json_encode($result));
		file_put_contents($filename, $data, FILE_APPEND);
	}

	public function __construct(){
		
		if(!defined('IN_TASK') || !IN_TASK){
			exit('Not allowed');
		}
		get_config();
	}
	/**
	 * 获取数据存放目录，如果目录不存在就创建
	 */
	protected function get_dest_dir($ext_id){
		$date = date('Ymd');
		$dir = DIR_DATAHOUSE . $date;
		if(!is_dir($dir)){
			if(!mkdir($dir)){
				return false;
			}
		}
		$des_path = $dir . DS . $ext_id;
		if(!is_dir($des_path)){
			if(!mkdir($des_path)){
				return false;
			}
		}
		return $des_path;
	}

	/**
	 * 从info.ini包信息中导入projcar
	 */
	protected function import_projcar_by_package($package_info,$lib){
		$ext_id = $package_info['extid'];
		$file_path = $package_info['filepath'];
		$file_md5 = $package_info['filemd5'];
		$time_flag = date('His');
		// 获取数据存放目录		
		$data_path = $this->get_dest_dir($ext_id);
		if ($data_path===false) {
			return "get data path:{$time_flag} failed";
		}
		// 删除原来目录下的所有文件，特别是重新更新债权图片的时候
		if ($handle = opendir($data_path)) {
			while (false!==($item=readdir($handle))) {
				if ($item!="." && $item!=".." ) {
					@unlink($data_path.DS.$item);
				}
			}
			closedir( $handle );
		}
		// 获取压缩文件并解压到存放目录
		$result = $lib->fetchProjcarZipAndUnzip($file_path,$file_md5,$data_path);
		if($result===false){
			return 'fetch and unzip failed';						
		}
		// 创建最后CDN存放图片文件目录 '2120180412001'变成'212017/0412/001'
		$cnf = config_item('projcar');
		$image_folder = $cnf['image_folder'];
		$image_web_root = $cnf['image_web_root'];
		$poses = array(
			'0' => '-7',
			'-7' => '4',
			'-3' => '3',
		);
		$dest_dir = realpath($image_folder) . DS;
		$path = '';
		foreach($poses as $pos => $length){
			$dest_dir .= substr($ext_id, $pos, $length) . DS;
			$path .= substr($ext_id, $pos, $length) . '/';
			if(!is_dir($dest_dir)){
				mkdir($dest_dir);
			}
		}
		if(!is_dir($dest_dir)){
			return 'cannot create end dir ' . $dest_dir;
		}
		// 拷贝图片到CDN目录
		$source_dir = $data_path . DS;
		$t = date('YmdHis');
		$keys_arr = array(
			'credit' => "credit.jpg",
			'financial' => 'financial.jpg',
			'import_certificate' => 'import_certificate.jpg',
			'insurance' => 'insurance.jpg',
			'invoices' => 'invoices.jpg',
			'person_id_pic' => 'person_id_pic.jpg',
			'whole_report' => 'whole_report.jpg'
		);
		foreach ($keys_arr as $key => $filename) {
			$src = $source_dir . $filename;
			$dst = $dest_dir . $filename;
			if (file_exists($src)) {
				$need_to_copy = true;
				if (file_exists($dst)) {
					// 检查MD5，决定是否copy
					$src_md5 = md5_file($src);
					$dst_md5 = md5_file($dst);
					if($src_md5 == $dst_md5){
						$need_to_copy = false;
					}
				} 
				if ($need_to_copy) {
					$bool = copy($src, $dst);
					if(!$bool){
						return "copy $src to $dst failed";
					}
					// 加上文件更新的时间戳，这样可以更新CDN
					$$key = $image_web_root . $path . $filename . "?t={$t}";
				} else {
					// 本次不更新
					$$key = null;
				}
			} else {
				// 不存在的文件，统一用 'empty.jpg'
				$$key = $image_web_root.'empty.jpg';
			}	
		}
		// 获取债权合同信息，看看是否存在
		$md_obligation = & load_model('obligation');
		$info = $md_obligation->getProjcarDetail($ext_id);
		if(empty($info) || !isset($info['id']) || empty($info['id'])){
			// 不存在，创建新的记录
			$file_info = $source_dir . 'info.ini';
			$info = parse_ini_file($file_info);
			$keys_arr = array('extid', 'make', 'year', 'price', 'total_amount', 'left_amount', 'total_period', 'left_period', 'repayment_day', 'model', 'purpose', 'vehicle_id', 'person_name', 'person_sex', 'rate', 'first_repayment_date');
			foreach ($keys_arr as $key) {
				if(!isset($info[$key])){
					return "info[$key] not exists";
				}else{
					$$key = $info[$key];
				}
			}
			if($left_amount <= 0){
				return "left_amount $left_amount <= 0";
			}
			if($left_period <= 0){
				return "left_period $left_period <= 0";
			}
			$total_amount = intval($total_amount * 10000);//单位变更：元to豪
			$left_amount = intval($left_amount * 10000);
			$price = intval($price * 10000);
			$make = strtoupper($make);
			$repayment_method = REPAYMENT_PRINCIPAL_AND_INTEREST_EQUAL;
			$id = $md_obligation->addProjcar($extid, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $credit, $financial, $whole_report, $first_repayment_date);
			if(empty($id)){
				return "insert projcar {$extid} failed";
			}		
		} else {
			// 只允许更新图片
			$result = $md_obligation->updateProjcarPictures($ext_id, $invoices, $insurance, $import_certificate, $person_id_pic, $credit, $financial, $whole_report);
			if(!$result){
				return "update projcar {$ext_id} failed";
			}
		}
		return true;
	}	
	/**
	 * 导入债权合同
	 * 系统CRONTAB调度任务，每三分钟调用一次
	 */		
	public function import_projcar(){
		$start_ts = microtime(true);
		$result = array(
			'total' => 0,
			'failed' => 0,
			);
		$lib_xtransfer = & load_library('xtransfer');
		$data = $lib_xtransfer->fetchNewProjcarList();
		if(!empty($data)){
			foreach ($data as $row) {
				$result['total'] ++;				
				$ext_id = $row['extid'];
				$err_msg = $this->import_projcar_by_package($row,$lib_xtransfer);
				if ($err_msg===true) {
					$bool = $lib_xtransfer->noticeProjcarImported( $ext_id );
					if($bool===false){
						$result['msg'][$ext_id] = 'notice failed';						
					}
				} else {
					$result['msg'][$ext_id] = $err_msg;	
					$result['failed'] ++;					
				}
			}
		}
		$result['cost'] = microtime(true) - $start_ts;
		$this->log_result(__FUNCTION__, $result);
	}
}
