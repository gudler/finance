<?php
require_once PATH_BASE_CONTROLLER;

class Notice extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function getCurrentNoticeList(){
		$md_notice = & load_model('notice');
		$current_time = $this->postval('current_time');
		// 如果为空，取当前时间
		if (empty($current_time)) {
			$current_time = date("Y-m-d H:i:s");
		}
		// 最多10条
		$limit = 10;
		$notices = $md_notice->getCurrentNoticeList($current_time,$limit);	
		$this->setData( array(
			'list' => $notices
			) );
		$this->setCodeSuccess();
	}

	public function getNoticeList() {
		$md_notice = & load_model('notice');
		$page = intval($this->postval('page'));
		$page_size = intval($this->postval('page_size'));
		if ($page_size<=0) {
			$page_size = 30;
		}
		$total = $md_notice->getNoticeCount();
		$notices = array();
		if ($total>=0) {
			$notices = $md_notice->getNoticeList($page, $page_size);
		}
		$this->setData( array(
			'total' => $total,
			'page' => $page,
			'page_size' => $page_size,
			'list' => $notices
			) 
		);
		$this->setCodeSuccess();	
	}

	public function getNotice(){
		$md_notice = & load_model('notice');
		$id = $this->postval('id');
		$notice = $md_notice->getNoticeDetail($id);	
		if ($notice==false) {
			$this->setMsg( getlang('notice.notexists') );
			return;
		}
		$this->setData( array(
			'notice' => $notice
			) );
		$this->setCodeSuccess();
	}
	
}