<?php

class Controller{
	
	private static $instance;

	/**
	 * Result code spec.
	 *		code		integer.
	 *		encrypted	boolean.
	 *		data		String(encrypted) or Object(raw)
	 */
	private static $res = array( 'code' => CODES_FAILED, 'message' => '', 'encrypted' => false, 'data' => array() );

	protected $skipcrypt = false;

	protected $cipher = null;

	protected $uid = null;

	protected $channel = null;

	// 2018-08-23,69豪车整合
	protected $app = APP_DEFAULT;

	protected $extra_log = array();

	private function _initCipher(){
		if(null === $this->cipher){
			$this->cipher = Cipher::getInstance();
		}
	}

	protected function & getCipher(){
		$this->_initCipher();
		return $this->cipher;
	}

	protected function encryptTurnOn(){
		self::$res['encrypted'] = true;
	}

	protected function encryptTurnOff(){
		self::$res['encrypted'] = false;
	}

	protected function getMDHashKey( $uid ){
		$this->_initCipher();
		return $this->cipher->getMDHashKey( $uid );
	}

	protected function mdataEncrypt($key, $str){
		$this->_initCipher();
		$raw = $this->cipher->aesEncode( $key, $str );
		return base64_encode($raw);
	}

	protected function mdataDecrypt($key, $str){
		$this->_initCipher();
		$str = base64_decode($str);
		$raw = $this->cipher->aesDecode( $key, $str );
		$raw = trim($raw);
		return $raw;
	}
	
	protected function encryptPasswd($passwd, $salt){
		return strtoupper(md5(sha1($salt . $passwd) . $salt));
	}

	protected function convFenToHao( $number ){
		return intval($number) * 100;
	}

	protected function convHaoToFen( $number ){
		return floor($number / 100);
	}

	protected function getUniqKey($value){
		$salt = md5('yOUhAVemYkEywORDs');
		return md5( sha1($value . $salt) . $salt );
	}

	protected function postval($key){
		static $cipher = null;
		if($this->skipcrypt){
			return postval($key);
		}
		if(null === $cipher){
			$cipher = $this->getCipher();
			if(null === $cipher->getAESKey()){
				$this->setCode( CODES_NO_AESKEY );
				$this->output();
				exit();
			}
			self::$res['encrypted'] = true;
		}
		return $cipher->getValue($key);
	}

	protected function getDeviceID(){
		$this->_initCipher();
		return $this->cipher->getDeviceID();
	}

	protected function setCode($code){
		self::$res['code'] = $code;
	}

	protected function setCodeSuccess(){
		$this->setCode(CODES_OK);
	}

	protected function setCodeFailed(){
		$this->setCode(CODES_FAILED);
	}

	protected function setMsg($msg){
		if(is_array($msg)){
			$msg = implode("\n", $msg);
		}
		$this->setData('msg', $msg);
		// 2018-05-25
		// 新的API接口,message同code在一级
		self::$res['message'] = $msg;
	}

	protected function setResult($data){
		self::$res['data'] = $data;
	}

	protected function setData($key, $value = null){
		if(is_array($key)){
			foreach ($key as $k => $val) {
				$this->setData($k, $val);
			}
		}else{
			self::$res['data'][$key] = $value;
		}
	}

	protected function setExpires($ts){
		if($ts){
			header('Expires: '. gmdate('r', time()+$ts));
		}
	}

	protected function checkUserLogin(){

		$token = $this->postval('token');
		$md_user = & load_model('user');
		$idev = $md_user->getUserIdByToken($token);
		if(!$idev){
			$info = $md_user->getHistoryInfoByToken( $token );
			$this->setData('login_expired', true);
			if($info &&
			( time() - strtotime($info['created_time']) < 86400 * 30 )){
				$this->setMsg( getlang('user.otherside_logged_in') );
			}else{
				$this->setMsg( getlang('user.tokenexpired') );
			}
			return false;
		}
		$this->uid = $idev['id'];
		return true;
	}

	protected function checkIP($ips){
		$ra = $_SERVER["REMOTE_ADDR"];
		foreach ($ips as $ip => $v) {
			if($v == 0){
				if($ip == $ra){
					return true;
				}
			}else{
				if(substr($ra, 0, $v) == $ip){
					return true;
				}
			}
		}
		return false;
	}

	protected function getIP(){
		return $_SERVER["REMOTE_ADDR"];
	}

	protected function verifyVisitor(){
		$tester_ips = config_item('tester_ips');
		if( (
				(isset($_GET['c']) && $_GET['c'] == 'tester') || 
				(isset($_SERVER['HTTP_REFERER']) &&  ( strpos($_SERVER['HTTP_REFERER'], $_SERVER['SERVER_NAME'] . '/tester') || strpos($_SERVER['HTTP_REFERER'], $_SERVER['SERVER_ADDR'] . '/tester') ) ) 
			) && $this->checkIP( $tester_ips )
		){
			$this->skipcrypt = true;
			$this->channel = 1;
			return;
		}
		$secrets = config_item('cnlsecrets');
		$agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null;
		if(empty($agent)){
			exit('Denied 0');
		}
		@list($channel, $ts, $nonce, $sign) = explode(' ', $agent);
		if(!isset($secrets[$channel])){
			exit('Denied 1');
		}
		if(time()-$ts > 5*60){
			exit('Denied 2');
		}
		if(md5( $channel . $ts . $nonce . md5($secrets[$channel] . $nonce) . $secrets[$channel] ) != $sign){
			exit('Sign error');
		}
		$chn = 1;
		if($channel == 'ios'){
			$chn = 2;
		} elseif ($channel == 'android') {
			$chn = 3;
		} elseif ($channel == APP_69HC) {
			// 2018-08-23,69豪车整合
			$chn = 4;
		}
		$this->channel = $chn;
		if($chn == 1 || $chn == 4){
			$front_ips = config_item('front_ips');
			if($this->checkIP($front_ips)){
				$this->skipcrypt = true;
			}
		}
		// 2018-08-23,69豪车整合
		// 来自于69豪车的后台请求，在nonce中添加了APP（android,ios等）的封装
		if ($chn == 4) {
			$this->app = APP_69HC;
			@list($nonce_n, $nonce_c) = explode('.', $nonce);
			$this->channel = 1;
			if($nonce_c == 'ios'){
				$this->channel = 2;
			} elseif ($nonce_c == 'android') {
				$this->channel = 3;
			}
		}
	}

	/**
	 * 2018-05-23
	 * 获取用户访问的channel，$this->channel做转换,
	 */
	protected function getUserTokenChannel() {
		$token_channel = 0;
		if ($this->channel==1) { 
			// web channel,
			$token_channel = 1;
		} else if ($this->channel==2 || $this->channel==3) {
			// IOS and Android use same channel 
			$token_channel = 0;
		}
		return $token_channel;
	}
	/*
	 * 2018-08-23,69豪车整合
	 * 获取用户访问的app
	 */
	protected function getApp() {
		return $this->app;
	}

	protected function detectUserLanguage(){
		if(!defined('USER_LANGUAGE')){
			/* 逻辑待补充 */
			define('USER_LANGUAGE', 'chinese');
		}
	}

	/* 不同控制器使用的共用部分代码 START */

	/**
	 *	检查用户支付密码
	 */
	protected function checkUserPaymentPassword($uid, $password){
		$md_user = & load_model('user');
		$user = $md_user->getUserById( $uid );
		if(empty($user)){
			$this->setMsg( getlang('user.tokenexpired') );
			return;
		}
		
		if($user['pay_passwd'] != $this->encryptPasswd($password, $user['salt'])){
			$this->setCode( CODES_PAY_PASSWD_ERROR );
			$this->setMsg( getLang('user.paymentpassworderror') );
			return;
		}
		return true;
	}

	protected function checkTranscationAvailable(){
		$curr_hour = date('G');
		if($curr_hour < TRANSACTION_OPEN_HOUR || $curr_hour >= TRANSACTION_CLOSE_HOUR){
			$this->setCode( CODES_TRADE_LIMIT );
			$this->setMsg( getLang('trade.transcation_not_open', array('open' => TRANSACTION_OPEN_HOUR, 'close' => TRANSACTION_CLOSE_HOUR)) );
			return false;
		}
		return true;
	}

    public function isChineseHoliday($date) {
        //非周末的特别节假日
        $holidays_out_weekend = array(
            '2018-12-31','2019-01-01',
            '2019-02-04','2019-02-05','2019-02-06','2019-02-07','2019-02-08',
            '2019-04-05',
            '2019-05-01','2019-05-02','2019-05-03',
            '2019-06-07',
            '2019-09-13',
            '2019-10-01','2019-10-02','2019-10-03','2019-10-04','2019-10-07'
        );
        if (in_array($date,$holidays_out_weekend)) {
            return true;
        }
        //周末的工作日
        $workdays_in_weekend = array(
            '2018-12-29',
            '2019-02-02','2019-02-03',
            '2019-04-28','2019-05-05',
            '2019-09-29','2019-10-12'
        );
        $weekday = intval(date('w',strtotime($date)));
        //周末
        if ($weekday==0 || $weekday==6){
            if (in_array($date,$workdays_in_weekend)) {
                return false;
            }
            return true;
        }
        return false;
	}	
	
	protected function checkSellTranscationAvailable(){
		$curr_date = date('Y-m-d');
		if ($this->isChineseHoliday($curr_date)) {
			$this->setCode( CODES_TRADE_LIMIT );
			$this->setMsg( getLang('trade.transcation_sell_not_open', array('open' => TRANSACTION_SELL_OPEN_TIME, 'close' => TRANSACTION_SELL_CLOSE_TIME)) );
			return false;
		}
		$curr_time = date('H:i:s');
        if( strnatcmp($curr_time,TRANSACTION_SELL_OPEN_TIME)<=0 || strnatcmp($curr_time,TRANSACTION_SELL_CLOSE_TIME)>=0){
			$this->setCode( CODES_TRADE_LIMIT );
			$this->setMsg( getLang('trade.transcation_sell_not_open', array('open' => TRANSACTION_SELL_OPEN_TIME, 'close' => TRANSACTION_SELL_CLOSE_TIME)) );
			return false;
		}
		return true;
	}


	protected function logExtraColumns($key, $value = null){
		if(is_array($key)){
			foreach ($key as $k => $v) {
				$this->extra_log[$k] = $v;
			}
		}else{
			$this->extra_log[$key] = $value;
		}
	}

	protected function checkMobileNumber($mobile){
		$mobile = preg_replace('/^\+?86-?/', '', $mobile);
		$mobile_int = intval($mobile);
		if(strlen($mobile_int) != 11){
			$this->setMsg( getlang('account.invalidephonenumber') );
			return false;
		}
		return $mobile;
	}


	/* 不同控制器使用的共用部分代码 END */

	public function __construct(){
		self::$instance = & $this;
		$this->detectUserLanguage();
		$this->verifyVisitor();
	}

	public function analyticsLog($c, $m, $start_ts){
		//IP controller method CODE costtime uid CHANNEL extrajson
		$costtime = 1000 * (microtime(true) - $start_ts);
		if(isset($_SERVER['REMOTE_ADDR'])){
			$ipaddr = $_SERVER['REMOTE_ADDR'];
		}else{
			$ipaddr = '0.0.0.0';
		}
		$message = sprintf("%s %s %s %s %s %s %d %s", $ipaddr, $c, $m, self::$res['code'], $costtime, $this->uid, $this->channel, json_encode($this->extra_log));
		openlog('apicenter', LOG_PID, LOG_LOCAL0);
		syslog(LOG_INFO, $message);
		closelog();
	}

	public static function &getInstance(){
		return self::$instance;
	}

	public function notExists(){
		$this->setMsg(sprintf('NOT EXISTS: Controller: %s, Method: %s'
			, (isset($_GET['c'])?$_GET['c']:'NOT PASS')
			, (isset($_GET['m'])?$_GET['m']:'NOT PASS')
			));
	}

	public function output(){
		$error_info = ob_get_clean();
		if(self::$res['encrypted']){
			$this->_initCipher();
			$data = json_encode(self::$res['data']);
			//file_put_contents('/tmp/a.txt', $data . "\n", FILE_APPEND);
			self::$res['data'] = $this->cipher->encryptData( $data );
		}
		if(!empty($error_info)){
			$filename = DIR_LOG . 'output.err';
			$str = sprintf("%s\t%s\n", date('Y-m-d H:i:s'), $error_info);
			file_put_contents($filename, $str, FILE_APPEND);
		}
		echo json_encode(self::$res);
		ob_end_flush();
	}
}