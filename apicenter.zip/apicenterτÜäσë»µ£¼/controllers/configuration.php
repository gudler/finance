<?php
require_once PATH_BASE_CONTROLLER;

class Configuration extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function staticDomains(){
		$data = array(
			's1.egeyed.com',
			's2.egeyed.com',
			's3.egeyed.com',
			's4.egeyed.com',
			's5.egeyed.com',
		);
		$this->setExpires(7*86400);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function startupPage(){
		$md_banners = & load_model('banners');
		//每页停留时间2秒
		$page_timeout = 2000;
		$pages = $md_banners->getBannersByPosition(BANNER_POSITION_APP_STARTUP);
		$timeout = count($pages)*$page_timeout;
		$data['pages'] = $pages;
		$data['timeout'] = $timeout;
		$data['auto_switch'] = true;
		$data['auto_switch_time'] = $page_timeout;
		$key = md5(json_encode($data));
		$data['key'] = $key;
		$this->setExpires(600);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function agreementsList(){
		$data = array(
			'user' => 'http://www.eagleeyedfinance.com/articles/user/user.html',
			'invest' => 'http://www.eagleeyedfinance.com/articles/invest/invest.html',
		);
		$this->setExpires(86400);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function blocks(){
		$data = array(
			'platform' => array(
				'method' => 'video',
				'text' => '平台介绍',
				'url' => 'http://svideo.egeyed.com/aboutegeyed-480p.mp4'
			)
		);
		$this->setExpires(86400);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function bannerMain(){
		$data = array(
			array(
				'method' => APP_VIEW_METHOD_WEBVIEW,
				'img' => 'http://img.egeyed.com/banner/a201612281818.png',
				'url' => 'http://wx.egeyed.com/events/autodl'
			),
		);
		$this->setExpires(3600);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function bannerObligation(){
		$data = array(
			array(
				'method' => APP_VIEW_METHOD_WEBVIEW,
				'img' => 'http://img.egeyed.com/banner/a201612281818.png',
				'url' => 'http://wx.egeyed.com/events/autodl'
			),
		);
		$this->setExpires(3600);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function bannerMainH(){
		$md_banners = & load_model('banners');
		$banners = $md_banners->getBannersByPosition(BANNER_POSITION_APP_HOME);
		$this->setExpires(180);
		$this->setCodeSuccess();
		$this->setResult($banners);
	}

	public function bannerObligationH(){
		$md_banners = & load_model('banners');
		$banners = $md_banners->getBannersByPosition(BANNER_POSITION_APP_OBLIGATION);
		$this->setExpires(180);
		$this->setCodeSuccess();
		$this->setResult($banners);
	}

	public function carMaker(){
		$data = array(
			'ABARTH' => array('name' => '阿巴斯', 'icon' => 'http://img.eagleeyedfinance.com/maker/abarth.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/abarth.png'),
			'ACURA' => array('name' => '讴歌', 'icon' => 'http://img.eagleeyedfinance.com/maker/acura.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/acura.png'),
			'ALFAROMEO' => array('name' => '阿尔法罗密欧', 'icon' => 'http://img.eagleeyedfinance.com/maker/alfaromeo.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/alfaromeo.png'),
			'ASTONMARTIN' => array('name' => '阿斯顿马丁', 'icon' => 'http://img.eagleeyedfinance.com/maker/astonmartin.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/astonmartin.png'),
			'AUDI' => array('name' => '奥迪', 'icon' => 'http://img.eagleeyedfinance.com/maker/audi.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/audi.png'),
			'BAIC' => array('name' => '北汽', 'icon' => 'http://img.eagleeyedfinance.com/maker/baic.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/baic.png'),
			'BENTLEY' => array('name' => '宾利', 'icon' => 'http://img.eagleeyedfinance.com/maker/bentley.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/bentley.png'),
			'BENZ' => array('name' => '奔驰', 'icon' => 'http://img.eagleeyedfinance.com/maker/benz.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/benz.png'),
			'BMW' => array('name' => '宝马', 'icon' => 'http://img.eagleeyedfinance.com/maker/bmw.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/bmw.png'),
			'BUGATTI' => array('name' => '布加迪', 'icon' => 'http://img.eagleeyedfinance.com/maker/bugatti.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/bugatti.png'),
			'BUICK' => array('name' => '别克', 'icon' => 'http://img.eagleeyedfinance.com/maker/buick.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/buick.png'),
			'BYD' => array('name' => '比亚迪', 'icon' => 'http://img.eagleeyedfinance.com/maker/byd.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/byd.png'),
			'CADILLAC' => array('name' => '凯迪拉克', 'icon' => 'http://img.eagleeyedfinance.com/maker/cadillac.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/cadillac.png'),
			'CHEVROLET' => array('name' => '雪弗兰', 'icon' => 'http://img.eagleeyedfinance.com/maker/chevrolet.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/chevrolet.png'),
			'CITROEN' => array('name' => '雪铁龙', 'icon' => 'http://img.eagleeyedfinance.com/maker/citroen.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/citroen.png'),
			'DODGE' => array('name' => '道奇', 'icon' => 'http://img.eagleeyedfinance.com/maker/dodge.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/dodge.png'),
			'FERRARI' => array('name' => '法拉利', 'icon' => 'http://img.eagleeyedfinance.com/maker/ferrari.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/ferrari.png'),
			'FORD' => array('name' => '福特', 'icon' => 'http://img.eagleeyedfinance.com/maker/ford.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/ford.png'),
			'GMC' => array('name' => 'GMC', 'icon' => 'http://img.eagleeyedfinance.com/maker/gmc.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/gmc.png'),
			'HONDA' => array('name' => '本田', 'icon' => 'http://img.eagleeyedfinance.com/maker/honda.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/honda.png'),
			'HYUNDAI' => array('name' => '现代', 'icon' => 'http://img.eagleeyedfinance.com/maker/hyundai.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/hyundai.png'),
			'INFINITI' => array('name' => '英菲尼迪', 'icon' => 'http://img.eagleeyedfinance.com/maker/infiniti.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/infiniti.png'),
			'JAGUAR' => array('name' => '捷豹', 'icon' => 'http://img.eagleeyedfinance.com/maker/jaguar.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/jaguar.png'),
			'JEEP' => array('name' => '吉普', 'icon' => 'http://img.eagleeyedfinance.com/maker/jeep.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/jeep.png'),
			'KOENIGSEGG' => array('name' => '科尼塞格', 'icon' => 'http://img.eagleeyedfinance.com/maker/koenigsegg.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/koenigsegg.png'),
			'LAMBORGHINI' => array('name' => '兰博基尼', 'icon' => 'http://img.eagleeyedfinance.com/maker/lamborghini.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/lamborghini.png'),
			'LANDROVER' => array('name' => '陆虎', 'icon' => 'http://img.eagleeyedfinance.com/maker/landrover.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/landrover.png'),
			'LEXUS' => array('name' => '雷克萨斯', 'icon' => 'http://img.eagleeyedfinance.com/maker/lexus.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/lexus.png'),
			'LOTUS' => array('name' => '莲花', 'icon' => 'http://img.eagleeyedfinance.com/maker/lotus.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/lotus.png'),
			'MASERATI' => array('name' => '玛莎拉蒂', 'icon' => 'http://img.eagleeyedfinance.com/maker/maserati.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/maserati.png'),
			'MAYBACH' => array('name' => '玛莎拉蒂', 'icon' => 'http://img.eagleeyedfinance.com/maker/maybach.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/maybach.png'),
			'MAZDA' => array('name' => '马自达', 'icon' => 'http://img.eagleeyedfinance.com/maker/mazda.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/mazda.png'),
			'MCLAREN' => array('name' => '迈凯伦', 'icon' => 'http://img.eagleeyedfinance.com/maker/mclaren.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/mclaren.png'),
			'MINI' => array('name' => 'MINI', 'icon' => 'http://img.eagleeyedfinance.com/maker/mini.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/mini.png'),
			'MITSUBISHI' => array('name' => '三菱', 'icon' => 'http://img.eagleeyedfinance.com/maker/mitsubishi.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/mitsubishi.png'),
			'MUSTANG' => array('name' => '野马', 'icon' => 'http://img.eagleeyedfinance.com/maker/mustang.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/mustang.png'),
			'NISSAN' => array('name' => '日产', 'icon' => 'http://img.eagleeyedfinance.com/maker/nissan.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/nissan.png'),
			'OPEL' => array('name' => '欧宝', 'icon' => 'http://img.eagleeyedfinance.com/maker/opel.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/opel.png'),
			'PAGANI' => array('name' => '帕加尼', 'icon' => 'http://img.eagleeyedfinance.com/maker/pagani.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/pagani.png'),
			'PEUGEOT' => array('name' => '标志', 'icon' => 'http://img.eagleeyedfinance.com/maker/peugeot.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/peugeot.png'),
			'PORSCHE' => array('name' => '保时捷', 'icon' => 'http://img.eagleeyedfinance.com/maker/porsche.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/porsche.png'),
			'RENAULT' => array('name' => '雷诺', 'icon' => 'http://img.eagleeyedfinance.com/maker/renault.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/renault.png'),
			'ROEWE' => array('name' => '荣威', 'icon' => 'http://img.eagleeyedfinance.com/maker/roewe.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/roewe.png'),
			'ROLLSROYCE' => array('name' => '劳斯莱斯', 'icon' => 'http://img.eagleeyedfinance.com/maker/rollsroyce.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/rollsroyce.png'),
			'SAAB' => array('name' => '萨博', 'icon' => 'http://img.eagleeyedfinance.com/maker/saab.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/saab.png'),
			'SKODA' => array('name' => '斯柯达', 'icon' => 'http://img.eagleeyedfinance.com/maker/skoda.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/skoda.png'),
			'SPYKER' => array('name' => '世爵', 'icon' => 'http://img.eagleeyedfinance.com/maker/spyker.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/spyker.png'),
			'SUBARU' => array('name' => '斯巴鲁', 'icon' => 'http://img.eagleeyedfinance.com/maker/subaru.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/subaru.png'),
			'SUZUKI' => array('name' => '铃木', 'icon' => 'http://img.eagleeyedfinance.com/maker/suzuki.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/suzuki.png'),
			'TESLA' => array('name' => '特斯拉', 'icon' => 'http://img.eagleeyedfinance.com/maker/tesla.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/tesla.png'),
			'TOYOTA' => array('name' => '丰田', 'icon' => 'http://img.eagleeyedfinance.com/maker/toyota.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/toyota.png'),
			'VOLKSWAGEN' => array('name' => '大众', 'icon' => 'http://img.eagleeyedfinance.com/maker/volkswagen.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/volkswagen.png'),
			'VOLVO' => array('name' => '沃尔沃', 'icon' => 'http://img.eagleeyedfinance.com/maker/volvo.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/volvo.png'),
			'SAIC' => array('name' => '上汽', 'icon' => 'http://img.eagleeyedfinance.com/maker/saic.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/saic.png'),	
			'TRUMPCHI' => array('name' => '广汽传祺', 'icon' => 'http://img.eagleeyedfinance.com/maker/trumpchi.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/trumpchi.png'),	
			'SMART' => array('name' => 'SMART', 'icon' => 'http://img.eagleeyedfinance.com/maker/smart.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/smart.png'),
            'NIO' => array('name' => '蔚来', 'icon' => 'http://img.eagleeyedfinance.com/maker/nio.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/nio.png'),
            'HARLEYDAVIDSON' =>array('name' => '哈雷', 'icon' => 'http://img.eagleeyedfinance.com/maker/harleydavidson.jpg', 'png' => 'http://img.eagleeyedfinance.com/maker/harleydavidson.png'),
		);
		$this->setExpires(3600);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

	public function bankInfo(){
		$data = array(
			'CEB' => array(
				'name' => '中国光大银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/ceb.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),
			'CNCB' => array(
				'name' => '中信银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/cncb.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),
			'PSBC' => array(
				'name' => '中国邮政储蓄银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/psbc.jpg',
				'paylimit' => 5000,
				'daylimit' => 5000,
				'monthlimit' => 150000
			),
			'BOC' => array(
				'name' => '中国银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/boc.jpg',
				'paylimit' => 10000,
				'daylimit' => 10000,
				'monthlimit' => 1000000
			),
			'ABC' => array(
				'name' => '中国农业银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/abc.jpg',
				'paylimit' => 5000,
				'daylimit' => 5000,
				'monthlimit' => 150000
			),
			'CCB' => array(
				'name' => '中国建设银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/ccb.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),
			'ICBC' => array(
				'name' => '中国工商银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/icbc.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),
			'CMB' => array(
				'name' => '招商银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/cmb.jpg',
				'paylimit' => 5000,
				'daylimit' => 5000,
				'monthlimit' => 150000
			),
			'CIB' => array(
				'name' => '兴业银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/cib.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),
			'SPDB' => array(
				'name' => '浦发银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/spdb.jpg',
				'paylimit' => 100000,
				'daylimit' => 200000,
				'monthlimit' => 1000000
			),
			'PAB' => array(
				'name' => '平安银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/pab.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),
			'BCM' => array(
				'name' => '交通银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/bcm.jpg',
				'paylimit' => 10000,
				'daylimit' => 10000,
				'monthlimit' => 300000
			),
			'HXB' => array(
				'name' => '华夏银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/hxb.jpg',
				'paylimit' => 10000,
				'daylimit' => 10000,
				'monthlimit' => 300000
			),
			'CGB' => array(
				'name' => '广发银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/cgb.jpg',
				'paylimit' => 100000,
				'daylimit' => 200000,
				'monthlimit' => 1000000
			),	
			'SHB' => array(
				'name' => '上海银行',
				'icon' => 'http://img.eagleeyedfinance.com/bank/shb.jpg',
				'paylimit' => 50000,
				'daylimit' => 50000,
				'monthlimit' => 1000000
			),	
		);
		
		$this->setExpires(86400);
		$this->setCodeSuccess();
		$this->setResult($data);
	}

}