<?php
require_once PATH_BASE_CONTROLLER;

class Tester extends Controller{

	public function __construct(){
		//header("Location: http://taochengzhou.com", true, 302);exit();
		parent::__construct();
	}

	public function getApiParams(){
		$api = postval('api');
		$map = array
			(

				'account' => array
					(
						'bindCard' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '银行卡预留手机号', 'desc' => '', 'default' => ''),
								array('name' => 'realname', 'type' => 'string', 'title' => '姓名', 'desc' => '', 'default' => ''),
								array('name' => 'idtype', 'type' => 'int', 'title' => '证件类型', 'desc' => '0: 身份证', 'default' => '0'),
								array('name' => 'idno', 'type' => 'string', 'title' => '证件号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
								
							),
						'verifyCard' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'realname', 'type' => 'string', 'title' => '姓名', 'desc' => '', 'default' => ''),
								array('name' => 'idno', 'type' => 'string', 'title' => '证件号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),								
							),
						'dataEncrypt' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'uid', 'type' => 'int', 'title' => '用户ID', 'desc' => '', 'default' => '0'),
								array('name' => 'data', 'type' => 'string', 'title' => '要加密的数据', 'desc' => '', 'default' => ''),
							),							
						'dataDecrypt' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'uid', 'type' => 'int', 'title' => '用户ID', 'desc' => '', 'default' => '0'),
								array('name' => 'data', 'type' => 'string', 'title' => '要解密的数据', 'desc' => '', 'default' => ''),
							),							
						'changeBoundCardMobile' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '银行卡预留手机号', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
							),
						'changeBoundCard' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'user', 'type' => 'int', 'title' => '用户（手机号）', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '银行卡预留手机号', 'desc' => '', 'default' => ''),
								array('name' => 'realname', 'type' => 'string', 'title' => '姓名', 'desc' => '', 'default' => ''),
								array('name' => 'idtype', 'type' => 'int', 'title' => '证件类型', 'desc' => '0: 身份证', 'default' => '0'),
								array('name' => 'idno', 'type' => 'string', 'title' => '证件号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
								
							),
						'bindOfflineCard' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'user', 'type' => 'int', 'title' => '用户（手机号）', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '银行卡预留手机号', 'desc' => '', 'default' => ''),
								array('name' => 'realname', 'type' => 'string', 'title' => '姓名', 'desc' => '', 'default' => ''),
								array('name' => 'idtype', 'type' => 'int', 'title' => '证件类型', 'desc' => '0: 身份证', 'default' => '0'),
								array('name' => 'idno', 'type' => 'string', 'title' => '证件号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
							),
						'accVerifyUserInfo' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'user', 'type' => 'int', 'title' => '用户（手机号）', 'desc' => '', 'default' => ''),
								array('name' => 'uid', 'type' => 'int', 'title' => '用户ID', 'desc' => '', 'default' => ''),
								
							),
						'accWithdrawTP' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'orderno', 'type' => 'string', 'title' => '交易流水号', 'desc' => '', 'default' => ''),
								array('name' => 'rollback', 'type' => 'int', 'title' => '是否现在退还', 'desc' => '0|1', 'default' => '0'),
								
							),
						'switchAmountShift' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'onoff', 'type' => 'string', 'title' => '开启关闭余额转投', 'desc' => 'on: 开启; off: 关闭', 'default' => ''),
								
							),
						'getCardInfo' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
							),
						'getInfo' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
							),
						'getHistory' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'type', 'type' => 'int', 'title' => '是否完成', 'desc' => '1: 购买; 2: 出售; 9: 充值提现', 'default' => '1'),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'getOfflineAccountInfo' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '充值金额', 'desc' => '单位分', 'default' => ''),
							),
						'myOfflineRecharged' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '充值转账ID', 'desc' => '', 'default' => ''),
							),
						'getCompanyAccountInfo' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
							),
						'notifyOfflineRecharged' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '充值金额', 'desc' => '单位分', 'default' => ''),
							),
						'recharge' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'via', 'type' => 'int', 'title' => '通过什么途径', 'desc' => '0: 绑定的银行卡', 'default' => '0'),
								array('name' => 'money', 'type' => 'int', 'title' => '充值金额', 'desc' => '单位分', 'default' => ''),
							),
						'rechargeCheck' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '充值ID', 'desc' => '', 'default' => ''),
							),
						'withdrawCheck' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '提现ID', 'desc' => '', 'default' => ''),
							),
						'withdraw' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'via', 'type' => 'int', 'title' => '通过什么途径', 'desc' => '0: 绑定的银行卡', 'default' => '0'),
								array('name' => 'money', 'type' => 'int', 'title' => '提现金额', 'desc' => '单位分', 'default' => ''),
								array('name' => 'bank', 'type' => 'string', 'title' => '银行名称', 'desc' => 'getCardInfo中bank_name字段', 'default' => ''),
								array('name' => 'bank_sub', 'type' => 'string', 'title' => '支行名称', 'desc' => 'getCardInfo中bank_sub字段，中行、建行、广发必填', 'default' => ''),
								array('name' => 'city', 'type' => 'string', 'title' => '城市名称', 'desc' => 'getCardInfo中city字段', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '支付密码', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
							),
						'offlineWithdrawCheck' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '提现ID', 'desc' => '', 'default' => ''),
							),
						'offlineWithdraw' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'via', 'type' => 'int', 'title' => '通过什么途径', 'desc' => '0: 绑定的银行卡', 'default' => '0'),
								array('name' => 'money', 'type' => 'int', 'title' => '提现金额', 'desc' => '单位分', 'default' => ''),
								array('name' => 'bank', 'type' => 'string', 'title' => '银行名称', 'desc' => 'getCardInfo中bank_name字段', 'default' => ''),
								array('name' => 'bank_sub', 'type' => 'string', 'title' => '支行名称', 'desc' => 'getCardInfo中bank_sub字段，中行、建行、广发必填', 'default' => ''),
								array('name' => 'city', 'type' => 'string', 'title' => '城市名称', 'desc' => 'getCardInfo中city字段', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '支付密码', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
							),
					),
				'user' => array
					(
						'uploadImage' => array
							(
								array('name' => 'img', 'type' => 'file', 'title' => '文件', 'desc' => '', 'default' => '')
							),
						'checkPhoneExists' => array
							(
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => '')
							),
						'getPhoneSMSCode' => array
							(
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'type', 'type' => 'string', 'title' => '验证码类型', 'desc' => '现有4种类型： reg / reset_loginpw / reset_paypw / withdraw (提现）', 'default' => '')
							),
						'getPhoneSMSCodeLogged' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'type', 'type' => 'string', 'title' => '验证码类型', 'desc' => '现有4种类型： cardmobichange (换银行卡预留手机号) / reset_paypw / withdraw (提现） / offline_recharge (转账充值)', 'default' => '')
							),
						'regPhone' => array
							(
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '密码', 'desc' => '', 'default' => ''),
								array('name' => 'inviter', 'type' => 'string', 'title' => '邀请人', 'desc' => '', 'default' => '')
							),
						'loginPhoneWithPassword' => array
							(
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '密码', 'desc' => '', 'default' => '')
							),
						'setUserPassword' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '密码', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => '')
							),
						'setUserPayPassword' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'int', 'title' => '支付密码', 'desc' => '', 'default' => '')
							),
						'smsCodeCheck' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'type', 'type' => 'string', 'title' => '验证码类型', 'desc' => '现有4种类型： reg / reset_loginpw / reset_paypw / withdraw (提现）', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => '')
							),
						'verifyIdentity' => array
							(
								array('name' => 'idtype', 'type' => 'int', 'title' => '认证类别', 'desc' => '', 'default' => '0'),
								array('name' => 'realname', 'type' => 'string', 'title' => '用户名', 'desc' => '', 'default' => ''),
								array('name' => 'identcode', 'type' => 'string', 'title' => '身份证ID', 'desc' => '', 'default' => '')
							),
						'resetUserPasswordByCode' => array
							(
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '密码', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => '')
							),
						'resetUserPayPasswordByCode' => array
							(
								array('name' => 'phone', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'int', 'title' => '支付密码', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => '')
							),
						'getUserInfo' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
							),
						'editPassword' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'passwd_old', 'type' => 'string', 'title' => '原密码', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '新密码', 'desc' => '', 'default' => '')
							),
						'getInviteLink' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'getInviteCode' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'logout' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							)
					),
				
				'configuration' => array
					(
						'staticDomains' => array(),
						'bannerMain' => array(),
						'bannerObligation' => array()
					),
				
				'version' => array
					(
						'android' => array
							(
								array('name' => 'device_id', 'type' => 'string', 'title' => '设备号', 'desc' => '', 'default' => ''),
								array('name' => 'pkg', 'type' => 'string', 'title' => '当前包名', 'desc' => '', 'default' => ''),
								array('name' => 'version', 'type' => 'string', 'title' => '当前版本号', 'desc' => '', 'default' => ''),
								array('name' => 'md5', 'type' => 'string', 'title' => '当前版本安装包的MD5值', 'desc' => '', 'default' => ''),
							),
						'iphone' => array
							(
							),
						'server' => array
							(
							)
					),
				
				'xtrans' => array
					(
						'rechargeSmsCodeRequest' => array
							(
								array('name' => 'type', 'type' => 'int', 'title' => '类型', 'desc' => '（60:转账充值,6:线下充值,22:退保证金;）', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '列表ID', 'desc' => 'RechargeList ID', 'default' => ''),
								array('name' => 'role', 'type' => 'string', 'title' => '角色', 'desc' => '（acc:会计 / fin:财务 / mng:经理）', 'default' => ''),
							),
						'withdrawSmsCodeRequest' => array
							(
								array('name' => 'order_id', 'type' => 'int', 'title' => '列表ID', 'desc' => 'Order ID', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '列表ID', 'desc' => 'Withdraw List ID', 'default' => ''),
								array('name' => 'role', 'type' => 'string', 'title' => '角色', 'desc' => '（acc:会计 / fin:财务 / mng:经理）', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
								array('name' => 'username', 'type' => 'string', 'title' => '用户名', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '金额（分）', 'desc' => '', 'default' => ''),
							),
						'rechargeSmsCodeVerify' => array
							(
								array('name' => 'type', 'type' => 'int', 'title' => '类型', 'desc' => '（60:转账充值,6:线下充值,22:退保证金;）', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '列表ID', 'desc' => 'RechargeList ID', 'default' => ''),
								array('name' => 'code_id', 'type' => 'int', 'title' => '验证码ID', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
								array('name' => 'role', 'type' => 'string', 'title' => '角色', 'desc' => '（acc:会计 / fin:财务 / mng:经理）', 'default' => ''),
							),
						'withDrawSmsCodeVerify' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => '列表ID', 'desc' => 'RechargeList ID', 'default' => ''),
								array('name' => 'code_id', 'type' => 'int', 'title' => '验证码ID', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
								array('name' => 'role', 'type' => 'string', 'title' => '角色', 'desc' => '（acc:会计 / fin:财务 / mng:经理）', 'default' => ''),
							),
						'verifyUser' => array
							(
								array('name' => 'mobile', 'type' => 'int', 'title' => '手机号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
							),
						'setProjcarOnline' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => 'ID', 'desc' => '借款合同ID', 'default' => ''),
								array('name' => 'up_time', 'type' => 'string', 'title' => '上线时间', 'desc' => '2017-02-14 14:02:00', 'default' => ''),
								array('name' => 'show_time', 'type' => 'string', 'title' => 'APP显示时间', 'desc' => '需要比上线时间早', 'default' => ''),
								array('name' => 'rate', 'type' => 'string', 'title' => '利率', 'desc' => '应该为0.01-0.12之间的小数', 'default' => '0.081'),
								array('name' => 'all_period_rate', 'type' => 'string', 'title' => '买断利率', 'desc' => '比利率值大，但是小于0.12之间的小数，如果没有，系统自动计算', 'default' => ''),								
								array('name' => 'closed_period', 'type' => 'int', 'title' => '封闭期', 'desc' => '应该为1-36的整数', 'default' => '1'),
							),
						'bindProjcarPayer' => array
							(
								array('name' => 'pid', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '', 'default' => ''),
								array('name' => 'uid', 'type' => 'int', 'title' => '借款用户ID', 'desc' => '', 'default' => ''),
								array('name' => 'skiprate', 'type' => 'int', 'title' => '跳过利率检查', 'desc' => '', 'default' => '0')
							),
						'getLoanDetail' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '借款合同ID', 'default' => ''),
								array('name' => 'uid', 'type' => 'int', 'title' => '借款用户ID', 'desc' => '借款用户ID', 'default' => ''),
							),
						'finishLoanEarly' => array
							(
								array('name' => 'pid', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '', 'default' => '')
							),
						'cardRelSmsCodeRequest' => array
							(
								array('name' => 'type', 'type' => 'int', 'title' => '类型', 'desc' => '1:换卡；2:线下绑卡。', 'default' => '')
							),
						'changeBoundCard' => array
							(
								array('name' => 'mobile', 'type' => 'int', 'title' => '用户（手机号）', 'desc' => '', 'default' => ''),
								array('name' => 'bank_phone', 'type' => 'int', 'title' => '银行卡预留手机号', 'desc' => '', 'default' => ''),
								array('name' => 'realname', 'type' => 'string', 'title' => '姓名', 'desc' => '', 'default' => ''),
								array('name' => 'idtype', 'type' => 'int', 'title' => '证件类型', 'desc' => '0: 身份证; 1: 台胞证; 2: 护照', 'default' => '0'),
								array('name' => 'idno', 'type' => 'string', 'title' => '证件号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
								array('name' => 'old_cardno', 'type' => 'int', 'title' => '原银行卡号', 'desc' => '', 'default' => ''),
								array('name' => 'code_id', 'type' => 'int', 'title' => '验证码ID', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),																
							),
						'bindOfflineCard' => array
							(
								array('name' => 'mobile', 'type' => 'int', 'title' => '用户（手机号）', 'desc' => '', 'default' => ''),
								array('name' => 'bank_phone', 'type' => 'int', 'title' => '银行卡预留手机号', 'desc' => '', 'default' => ''),
								array('name' => 'realname', 'type' => 'string', 'title' => '姓名', 'desc' => '', 'default' => ''),
								array('name' => 'idtype', 'type' => 'int', 'title' => '证件类型', 'desc' => '0: 身份证; 1: 台胞证; 2: 护照', 'default' => '0'),
								array('name' => 'idno', 'type' => 'string', 'title' => '证件号', 'desc' => '', 'default' => ''),
								array('name' => 'cardno', 'type' => 'int', 'title' => '银行卡号', 'desc' => '', 'default' => ''),
								array('name' => 'code_id', 'type' => 'int', 'title' => '验证码ID', 'desc' => '', 'default' => ''),
								array('name' => 'code', 'type' => 'int', 'title' => '验证码', 'desc' => '', 'default' => ''),
								
							),
						'getComprehensiveProjcars' => array
							(
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => ''),
								array('name' => 'pagesize', 'type' => 'int', 'title' => '每页条数，默认30', 'desc' => '', 'default' => ''),
								array('name' => 'status', 'type' => 'int', 'title' => '状态', 'desc' => '0: 全部, 0x01:未绑定还款人的债权,0x02:未上线的债权,0x04:未上线中债权', 'default' => '0'),
								array('name' => 'filter_id', 'type' => 'int', 'title' => '过滤合同ID', 'desc' => '查询符合ID的记录', 'default' => '')
							),
						'getUserWithdrawTPs' => array
							(
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => ''),
								array('name' => 'pagesize', 'type' => 'int', 'title' => '每页条数，默认30', 'desc' => '', 'default' => ''),
								array('name' => 'status', 'type' => 'int', 'title' => '状态', 'desc' => '空:全部,0:创建,-1:非法,1:确认,2:完成', 'default' => ''),
								array('name' => 'filter_orderno', 'type' => 'int', 'title' => '过滤交易流水号', 'desc' => '查询符合交易流水号记录', 'default' => '')
							),
						'accWithdrawTP' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'orderno', 'type' => 'string', 'title' => '交易流水号', 'desc' => '', 'default' => ''),
							),
                        'setUserContact' => array
                            (
                                array('name' => 'mobile', 'type' => 'int', 'title' => '用户手机号码', 'desc' => '', 'default' => ''),
                                array('name' => 'contact', 'type' => 'int', 'title' => '其他联系手机号码', 'desc' => '', 'default' => ''),
                            ),

					),
				
				'device' => array
					(
						'regPublicKey' => array
							(
								array('name' => 'device', 'type' => 'string', 'title' => '设备号', 'desc' => '', 'default' => ''),
								array('name' => 'darr', 'type' => 'string', 'title' => '需要加密上传的数据', 'desc' => '{platform:"android", ts: "1458132366", udid: "", dev:"29bc48c0474eb3c9ceb08d35cc87a4ca", key:""}', 'default' => '')
							),
						'iOSToken' => array
							(
								array('name' => 'logintoken', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'devicetoken', 'type' => 'string', 'title' => '设备通知用TOKEN', 'desc' => '', 'default' => ''),
							)
					),

				'loan' => array
					(
						'getStatus' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'getList' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'getDetail' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '', 'default' => '')
							),
						'setAutoReturn' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '', 'default' => ''),
								array('name' => 'agree', 'type' => 'int', 'title' => '是否同意', 'desc' => '0:不同意；1:同意', 'default' => '0')
							),
						'addProjcarLoanRel' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'pid', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '', 'default' => ''),
								array('name' => 'uid', 'type' => 'int', 'title' => '借款用户ID', 'desc' => '', 'default' => ''),
								array('name' => 'skiprate', 'type' => 'int', 'title' => '跳过利率检查', 'desc' => '', 'default' => '0')
							),
						'addProjcarLoanRel2' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => 'TOKEN', 'desc' => '超级管理员TOKEN', 'default' => ''),
								array('name' => 'phone', 'type' => 'string', 'title' => '手机号码', 'desc' => '还款用户手机号码', 'default' => ''),
								array('name' => 'name', 'type' => 'string', 'title' => '用户姓名', 'desc' => '可选，用于验证输入值是否同平台匹配', 'default' => ''),
								array('name' => 'pid', 'type' => 'int', 'title' => '合同ID', 'desc' => '借款合同ID，需要21开头', 'default' => ''),
								array('name' => 'first_repayment_date', 'type' => 'string', 'title' => '首次还款日期', 'desc' => '可选，用于验证输入值是否同平台匹配', 'default' => ''),
								array('name' => 'repayment_day', 'type' => 'int', 'title' => '每月还款日', 'desc' => '可选，用于验证输入值是否同平台匹配', 'default' => ''),
								array('name' => 'skiprate', 'type' => 'int', 'title' => '跳过利率检查', 'desc' => '', 'default' => '0')
							),
						'finishLoan' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'pid', 'type' => 'int', 'title' => '借款合同ID', 'desc' => '', 'default' => '')
							),
						'finishExtraObligation' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '债权ID', 'desc' => '', 'default' => '')
							),
					),

				'obligation' => array
					(
						'getStatus' => array
							(
								array('name' => 'device', 'type' => 'string', 'title' => '设备号', 'desc' => '', 'default' => ''),
							),
						'getPlanList' => array(),
						'getList' => array
							(
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => ''),
								array('name' => 'pagesize', 'type' => 'int', 'title' => '每页条数，默认30', 'desc' => '', 'default' => ''),
								array('name' => 'status', 'type' => 'int', 'title' => '状态', 'desc' => '空: 全部,	0:开放,	-1:售空,	-2:关闭,	1:完成', 'default' => '')
							),
						'getSellList' => array
							(
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'getDetail' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => '债权号', 'desc' => '', 'default' => '')
							),
						'getProjectDetail' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => '项目号', 'desc' => '债权内的extid', 'default' => ''),
								array('name' => 'extype', 'type' => 'int', 'title' => '项目类型', 'desc' => '债权内的ext_tbl', 'default' => '')
							),
						'getHoldingList' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => '债权号', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'getUserHoldingList' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => ''),
								array('name' => 'type', 'type' => 'string', 'title' => '类型', 'desc' => '( direct \ eagleeyed \ fast_entry \ other )', 'default' => '')
							),
						'getUserHoldingAssort' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'getUserObligationDetail' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '所持债权ID', 'desc' => '', 'default' => '')
							),
						'getUserBoughtHistory' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'getUserObligationHistory' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => ''),
								array('name' => 'type', 'type' => 'string', 'title' => '类型', 'desc' => '2种类型： 1 (购买) / 2 (出售)', 'default' => '1'),
							),
						'getUserInqueueList' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'getUserPendingInterests' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '0'),
								array('name' => 'pagesize', 'type' => 'int', 'title' => '每页条数', 'desc' => '', 'default' => '30'),
							),
						'getUserPaidInterests' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'computer' => array
							(
								array('name' => 'mode', 'type' => 'string', 'title' => '类型（getEagleEyedList、getFastEntryList、getRookieList）', 'desc' => '', 'default' => 'getEagleEyedList'),
								array('name' => 'amount', 'type' => 'int', 'title' => '金额（分）', 'desc' => '', 'default' => ''),
								array('name' => 'rate', 'type' => 'float', 'title' => '年利率', 'desc' => '', 'default' => ''),
								array('name' => 'monthes', 'type' => 'int', 'title' => '期数', 'desc' => '当type为getRookieList时，monthes请传封闭天数', 'default' => ''),
								array('name' => 'repayment_day', 'type' => 'int', 'title' => '还款日', 'desc' => '', 'default' => ''),
								array('name' => 'day', 'type' => 'int', 'title' => '日', 'desc' => '', 'default' => ''),
								array('name' => 'month', 'type' => 'int', 'title' => '月', 'desc' => '', 'default' => ''),
								array('name' => 'year', 'type' => 'int', 'title' => '年', 'desc' => '', 'default' => '2016'),
							),
					),
				
				'refer' => array
					(
						'myInviteeInterest' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'is_done', 'type' => 'int', 'title' => '是否完成', 'desc' => '0: 未完成; 1: 已完成;', 'default' => '0'),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'myInviteeInterestTotal' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'myInvite2Pages' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'myInvite2Summary' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => '')
							),
						'myInvite2Detail' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
						'myInvite2L2Detail' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'invitee', 'type' => 'int', 'title' => '被邀请者ID', 'desc' => '', 'default' => ''),
								array('name' => 'page', 'type' => 'int', 'title' => '页码（从0计数）', 'desc' => '', 'default' => '')
							),
					),
				
				'qa' => array
					(
						'riskAssessmentAnswer' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'answer', 'type' => 'string', 'title' => '答案（json）', 'desc' => '', 'default' => '')
							),
					),
				
				'msg' => array
					(
						'fetch' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'old', 'type' => 'int', 'title' => '是否查询更老信息', 'desc' => '0: 否; 1: 是', 'default' => '0'),
								array('name' => 'last_id', 'type' => 'int', 'title' => '最后一条消息的ID', 'desc' => '查询新消息则用最大ID号，查询老消息就用最小ID号', 'default' => ''),
								array('name' => 'limit', 'type' => 'int', 'title' => '返回条数', 'desc' => '最小20条，最大200条', 'default' => '20')
							),
					),
				'notice' => array
					(
						'getCurrentNoticeList' => array
							(
								array('name' => 'current_time', 'type' => 'string', 'title' => '当前时间', 'desc' => '一般为空', 'default' => ''),
							),
						'getNoticeList' => array
							(
								array('name' => 'page', 'type' => 'int', 'title' => '第几页', 'desc' => '默认从0开始', 'default' => '0'),
								array('name' => 'page_size', 'type' => 'int', 'title' => '每页显示条数', 'desc' => '默认30', 'default' => '30'),
							),
						'getNotice' => array
							(
								array('name' => 'id', 'type' => 'int', 'title' => '公告ID', 'desc' => '', 'default' => '0'),
							),
					),
				
				'sign' => array
					(
						'day' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'channel', 'type' => 'int', 'title' => '通道', 'desc' => '请求通道，2是IOS，3是安卓', 'default' => '2'),
								array('name' => 'app_version', 'type' => 'string', 'title' => 'APP版本号', 'desc' => '', 'default' => ''),
								array('name' => 'system_version', 'type' => 'string', 'title' => '系统版本号', 'desc' => '', 'default' => ''),
								array('name' => 'device_model', 'type' => 'string', 'title' => '设备型号', 'desc' => '', 'default' => ''),
							),
					),
				
				'transaction' => array
					(
						'obligation' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'oid', 'type' => 'int', 'title' => '债权号', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '金额(分)', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '支付密码', 'desc' => '', 'default' => ''),
								array('name' => 'buy_all_period', 'type' => 'int', 'title' => '是否买断', 'desc' => '1或0', 'default' => '0'),
								array('name' => 'auto_shift', 'type' => 'int', 'title' => '是否自动转投', 'desc' => '1或0', 'default' => ''),
								array('name' => 'shift_to', 'type' => 'int', 'title' => '制动转投至', 'desc' => "2: 鹰眼宝 3: 易购宝", 'default' => '0'),
								
							),
						'fastEntry' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '金额(分)', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '支付密码', 'desc' => '', 'default' => ''),
								array('name' => 'auto_shift', 'type' => 'int', 'title' => '是否自动转投', 'desc' => '1或0', 'default' => ''),
								array('name' => 'shift_to', 'type' => 'int', 'title' => '制动转投至', 'desc' => "2: 鹰眼宝 3: 易购宝", 'default' => '0'),
								
							),
						'eagleeyed' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '金额(分)', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '支付密码', 'desc' => '', 'default' => ''),
								array('name' => 'auto_shift', 'type' => 'int', 'title' => '是否自动转投', 'desc' => '1或0', 'default' => ''),
								array('name' => 'shift_to', 'type' => 'int', 'title' => '制动转投至', 'desc' => "2: 鹰眼宝", 'default' => '0'),
								
							),
						'rookie' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'money', 'type' => 'int', 'title' => '金额(分)', 'desc' => '', 'default' => ''),
								array('name' => 'passwd', 'type' => 'string', 'title' => '支付密码', 'desc' => '', 'default' => ''),
							),
						'switchAutoShift' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '用户债权ID', 'desc' => '', 'default' => ''),
								array('name' => 'auto_shift', 'type' => 'int', 'title' => '是否自动转投', 'desc' => '1或0', 'default' => ''),
								array('name' => 'shift_to', 'type' => 'int', 'title' => '制动转投至', 'desc' => "2: 鹰眼宝 3: 易购宝", 'default' => '0'),
							),
						'dequeue' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '用户债权ID', 'desc' => '', 'default' => '')
							),
						'redeemObligationArray' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'idstr', 'type' => 'string', 'title' => '用户债权IDstr', 'desc' => '例如: 1,2,3,5', 'default' => '')
							),
						'redeemObligation' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '用户债权ID', 'desc' => '', 'default' => '')
							),
						'sellObligation' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '用户债权ID', 'desc' => '', 'default' => '')
							),
						'getTradeStatus' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '队列ID(trade_id)', 'desc' => '', 'default' => '')
							),
						'getProcessStatus' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '队列ID(process_id)', 'desc' => '', 'default' => '')
							),
						'getSellStatus' => array
							(
								array('name' => 'token', 'type' => 'string', 'title' => '用户TOKEN', 'desc' => '', 'default' => ''),
								array('name' => 'id', 'type' => 'int', 'title' => '队列ID(sell_id)', 'desc' => '', 'default' => '')
							)
					)

			);
		list($class, $method) = explode('/', $api);
		@$res = $map[$class][$method];
		$this->setData(array('params' => $res));
		$this->setCodeSuccess();
	}

	public function index(){
		$api_select = array();
		$selection = array();
		$eliminate_arr = array_merge(get_class_methods('Controller'), array('index'));
		$dir = dirname(__FILE__);
		$d = dir($dir);
		while (false !== ($entry = $d->read())) {
			$filename = $dir . '/' . $entry;
			$name = substr($entry, 0, -4);
			if(	file_exists($filename) 
				&& is_file($filename) 
				&& substr($entry, -4) == '.php' 
				&& substr($name, 0, 3) != 'cb_' 
				&& !in_array($name, array('callback_controller', 'controller', 'tester', 'task')) 
				){
				$class = ucfirst($name);
				require_once $filename;
				if(class_exists($class)){
					$selection[strtolower($class)] = array_diff(get_class_methods($class), $eliminate_arr);
				}
			}
		}
		$d->close();
		foreach($selection as $class_label => $class_methods){
			$api_group = array();
			$api_group[] = sprintf('<optgroup label="%s">', $class_label);
			foreach ($class_methods as $method) {
				$api_group[] = sprintf('<option value="%s">%s</option>', $class_label . '/' . $method, $class_label . '/' .$method);
			}
			$api_group[] = '</optgroup>';
			$api_select[$class_label] = implode('', $api_group);
		}
		ksort($api_select, SORT_STRING);
		$api_select = '<select id="apiname">' . implode('', $api_select) . '</select>';
		echo <<<eot
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Tester</title>
	<style>
		body{
			margin: 0px;
		}
		body.dark{
			background: #000;
		}
		img{
			display: block;
			border: 0;
			margin: 0px auto;
		}
		table.hovertable {
			font-family: verdana,arial,sans-serif;
			font-size:11px;
			color:#333333;
			border-width: 1px;
			border-color: #999999;
			border-collapse: collapse;
		}
		table.hovertable th {
			background-color:#c3dde0;
			border-width: 1px;
			padding: 8px;
			border-style: solid;
			border-color: #a9c6c9;
		}
		table.hovertable tr {
			background-color:#d4e3e5;
		}
		table.hovertable td {
			border-width: 1px;
			padding: 8px;
			border-style: solid;
			border-color: #a9c6c9;
		}
		#api_request_table{
			margin: 8% auto 0%;
			width: 84%;
		}
		#api_request_table th{
			width: 18%;
		}
		#api_request_table input[type=text],
		#api_request_table textarea{
			width: 300px;
			padding: 3px;
		}
	</style>
</head>
<body>
	<table id="api_request_table" class="hovertable">
		<tr>
			<th>接口</th>
			<td>$api_select</td>
		</tr>
		<tr style="height: 300px;">
			<th>参数</th>
			<td id="apiparams"></td>
		</tr>
		<tr>
			<th></th>
			<td>
				<input id="submit" type="button" value="提交"/>
				<input id="clear" type="button" value="清空数据"/>
			</td>
		</tr>
		<tr>
			<th>结果</th>
			<td id="result"></td>
		</tr>
	</table>
	<script src="http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript">
	!window.jQuery && document.write('<script src=/testeres/jquery.min.js><\/script>');
	window.jQuery && document.write('<script src=/testeres/jquery-ui.min.js><\/script>');
	window.jQuery && document.write('<script src=/testeres/jquery.fileupload.js><\/script>');
	$(function(){
		if(!String.prototype.repeat){
			String.prototype.repeat = function(count){
				if (this == null) {
					throw new TypeError('can\'t convert ' + this + ' to object');
				}
				var str = '' + this;
				count = +count;
				if (count != count) {
					count = 0;
				}
				if (count < 0) {
					throw new RangeError('repeat count must be non-negative');
				}
				if (count == Infinity) {
					throw new RangeError('repeat count must be less than infinity');
				}
				count = Math.floor(count);
				if (str.length == 0 || count == 0) {
					return '';
				}
				if (str.length * count >= 1 << 28) {
					throw new RangeError('repeat count must not overflow maximum string size');
				}
				var rpt = '';
				for (;;) {
					if ((count & 1) == 1) {
						rpt += str;
					}
					count >>>= 1;
					if (count == 0) {
						break;
					}
					str += str;
				}
				return rpt;
			}
		}
		var is_file_upload = 0, renderAPIParams = function(p){
			var str = '';
			is_file_upload = 0;
			for(var i=0,l=p.length; i<l; ++i){
				var id = 'input_' + i, x = p[i];
				str += '<div class="block"><label for="'+id+'">'+ x.title +'('+ x.type +')</label>';
				switch(x.type){
					case 'text':
						str += '<textarea id="'+ id +'" type="text" name="'+ x.name +'">' + x.default + '</textarea>';
						break;
					case 'file':
						str += '<input id="'+ id +'" type="file" name="'+ x.name +'" />';
						str += '<div id="'+ id +'_show"></div>';
						is_file_upload = 1;
						break;
					case 'int':
					case 'float':
					case 'double':
					case 'string':
					default:
						if(x.name == 'token'){
							var last_token = window.localStorage.getItem('_apitester_last_token');
							if(last_token){
								x.default = last_token;
							}
						}
						str += '<input id="'+ id +'" type="text" name="'+ x.name +'" value="'+ x.default +'" />';
						break;
				}
				str += '<span class="tips">字段名( '+ x.name +' )' + x.desc + '</span>';
				str += '</div>';
			}
			$('#apiparams').html(str);
		},
		removeAPIParams = function(){
			$('#apiparams').empty();
		},
		emptyAPIParams = function(){
			var block = $('#apiparams');
			$('input,textarea', block).each(function(){
				$(this).val('');
			});
		},
		last_request = null,
		getApiInfo = function(){
			if(last_request){
				last_request.abort();
			}
			removeAPIParams();
			var api = $('#apiname').val();
			window.localStorage.setItem('_apitester_last_apiname', api);
			last_request = $.ajax({
				async: true,
				type: "POST",
				url: '?c=tester&m=getApiParams',
				dataType: 'json',
				data: {
					api: api
				},
				timeout: 300000,
				success: function(json){
					if(json && json.code == 0){
						renderAPIParams(json.data.params);
						last_request = null;
						if(is_file_upload){
							$('input[type=file]', '#apiparams').each(function(){
								var obj = $(this);
								obj.attr('data-url', '/'+api);
								obj.fileupload({
									dataType: 'json',
									done: function (e, data) {
										if(data && data.data){
											renderAPIResult(data.data);
										}
									}
								});
							});
						}
					}else{
						$('#result').html('<span style="color: red">获取API信息出错了：' + (json.data.msg?json.data.msg:api) + '</span>');
					}
				},
				error: function(){
					$('#result').html('<span style="color: red">获取API信息网络出错</span>');
				}
			});
		},
		last_api_check,
		unpackJSON = function(json, deep){
			if(typeof deep == 'undefined' || !deep ){
				deep = 0;
			}
			var str = '';
			for(var p in json){
				str += "\\t".repeat(deep+1);
				if(typeof json[p] == 'object'){
					str += p + ' : ' + unpackJSON(json[p], deep+1) + "\\n";
				}else{
					str += p + ' : ' + json[p] + "\\n";
				}
			}
			return '{\\n' + str + "\\t".repeat(deep) + '}\\n';
		},
		renderAPIResult = function(json){
			var str = unpackJSON(json);
			$('#result').html('<pre>'+ str +'</pre>');
		},
		testAPI = function(){
			if(last_api_check){
				last_api_check.abort();
			}
			var data = {};
			$('input,textarea', '#apiparams').each(function(){
				var obj = $(this), val = obj.val();
				if(val.length){
					data[obj.attr('name')] = val;
				}
			});
			if(data && typeof data.token != 'undefined' && data.token){
				window.localStorage.setItem('_apitester_last_token', data.token);
			}
			var api = $('#apiname').val().split('/');

			if(is_file_upload){
				return;
			}
			/*
			var s = '';
			for(var i in data){
				s += i + ':' + data[i] + '\\n';
			}
			//alert(s);
			*/
			last_api_check = $.ajax({
				async: true,
				type: "POST",
				url: '/'+api.join('/'),
				dataType: 'json',
				data: data,
				timeout: 30000,
				success: function(json){
					if(json && json.code == 0){
						last_api_check = null;
						renderAPIResult(json);
					}else{
						$('#result').html('<span style="color: blue">出错了：'+(json.data.msg?json.data.msg:api.join('/'))+'</span>');
					}
				},
				error: function(){
					$('#result').html('<span style="color: red">测试API网络出错</span>');
				}
			});
		};
		$('#apiname').change(getApiInfo);
		$('#clear').click(emptyAPIParams);
		$('#submit').click(testAPI);

		var last_apiname = window.localStorage.getItem('_apitester_last_apiname');
		if(last_apiname){
			$('#apiname').val(last_apiname);
		}
		getApiInfo();
		var hour = (new Date()).getHours();
		if(hour>=21||hour<=5){
			$('body').addClass('dark');
		}
	});
	</script>
</body>
</html>
eot;
		exit();
	}

}