<?php
require_once PATH_BASE_CONTROLLER;

class Msg extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function fetch(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$md_msg = & load_model('msg');

		$start_id = $end_id = $last_id = intval($this->postval('last_id'));
		$old = intval($this->postval('old'));
		$limit = intval($this->postval('limit'));
		$limit = max(20, $limit);
		$limit = min(200, $limit);
		$data = $md_msg->getMsgList($uid, $limit, $last_id, $old);
		if(!empty($data)){
			$start_id = $data[0]['id'];
			$end_id = $data[count($data) - 1]['id'];
			foreach ($data as &$row) {
				$str = $row['content'];
				$firstchar = $str[0];
				$endchar = $str[strlen($str) - 1];
				if(( $firstchar == '{' && $endchar == '}' ) || ( $firstchar == '[' && $endchar == ']' )){
					$d = json_decode($str, true);
					$tpl = $d['tpl'];
					$param = $d['param'];
					$amt = 0;
					if(isset($param['amount'])){
						$amt = floor($param['amount'])/100;
						$param['amount'] = $amt;
					}
					if(isset($param['fee'])){
						$fee = floor($param['fee'])/100;
						$param['fee'] = $fee;
					}
					$str = getLang("msgtpl.{$tpl}", $param);
				}
				list($title, $cnt) = explode('[|||]', $str);
				$row['title'] = $title;
				$row['content'] = $cnt;
			}
		}
		$this->setData( array(
			'start_id' => $start_id,
			'end_id' => $end_id,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	public function pushClicked(){
		$id = intval($this->postval('id'));
		$device = $this->getDeviceID();
		$md_msg = & load_model('msg');
		$bool = $md_msg->setPushClicked($id, $device);
		if($bool){
			$this->setCodeSuccess();
		}
	}
}