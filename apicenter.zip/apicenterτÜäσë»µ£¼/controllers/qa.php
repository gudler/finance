<?php
require_once PATH_BASE_CONTROLLER;

class Qa extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function riskAssessmentQuestions( $return = false ){
		$data = array(
			array(
				'question' => array(
					'text' => '您的年龄是？',
					'name' => 'q1'
					),
				'options' => array(
					'a' => '18-30',
					'b' => '31-50',
					'c' => '51-65',
					'd' => '高于65',
					),
				),

			array(
				'question' => array(
					'text' => '您的家庭年收入为（折合人民币）？',
					'name' => 'q2'
					),
				'options' => array(
					'a' => '5万元以下',
					'b' => '5-20万元',
					'c' => '21-50万元',
					'd' => '51-100万元',
					'e' => '100万元以上',
					),
				),

			array(
				'question' => array(
					'text' => '在您每年的家庭收入中，可用于投资（储蓄存款除外）的比例为？',
					'name' => 'q3'
					),
				'options' => array(
					'a' => '小于10％',
					'b' => '10%－25%',
					'c' => '26%－50%',
					'd' => '大于50%',
					),
				),

			array(
				'question' => array(
					'text' => '您年总投资金额为？',
					'name' => 'q4'
					),
				'options' => array(
					'a' => '0-5万',
					'b' => '6-20万',
					'c' => '21-50万',
					'd' => '51-200万',
					'e' => '200万以上',
					),
				),

			array(
				'question' => array(
					'text' => '以下哪项最能说明您的投资经验？',
					'name' => 'q5'
					),
				'options' => array(
					'a' => '除存款、国债外，我几乎不投资其他金融产品',
					'b' => '大部分投资于存款、国债等，较少投资于股票、基金等风险产品',
					'c' => '资产均衡地分布于存款、国债、银行理财、信托、股票、基金等',
					'd' => '大部分投资于股票、基金、外汇、金融衍生品、海外投资产品等高风险产品，较少投资于存款、国债',
					),
				),

			array(
				'question' => array(
					'text' => '您投多少年投资股票、基金、外汇、金融衍生品、海外投资产品等风险投资品的经验？',
					'name' => 'q6'
					),
				'options' => array(
					'a' => '没有经验',
					'b' => '少于2年',
					'c' => '2-5年',
					'd' => '6-8年',
					'e' => '8年以上',
					),
				),

			array(
				'question' => array(
					'text' => '在您以往的投资经验中，是否发生过本金损失？',
					'name' => 'q7'
					),
				'options' => array(
					'a' => '是',
					'b' => '不是',
					),
				),

			array(
				'question' => array(
					'text' => '您是否已成为其他金融机构的vip客户',
					'name' => 'q8'
					),
				'options' => array(
					'a' => '是',
					'b' => '不是',
					),
				),

			array(
				'question' => array(
					'text' => '您计划的投资期限是多久？',
					'name' => 'q9'
					),
				'options' => array(
					'a' => '一年以下',
					'b' => '1-3年',
					'c' => '3-5年',
					'd' => '5年以上',
					),
				),

			array(
				'question' => array(
					'text' => '您的投资目的是？',
					'name' => 'q10'
					),
				'options' => array(
					'a' => '资产保值，同时获得固定收益',
					'b' => '资产稳健增长，同时获得波动适度的年回报',
					'c' => '资产高回报，能接受短期的资产价值波动',
					),
				),

			array(
				'question' => array(
					'text' => '您期望的投资年收益率？',
					'name' => 'q11'
					),
				'options' => array(
					'a' => '高于同期定期存款',
					'b' => '5%左右，要求相对低风险',
					'c' => '5%－15%，可承受中等风险',
					'd' => '15%以上，可承受较高风险',
					),
				),

			array(
				'question' => array(
					'text' => '以下哪项描述最符合您的投资态度？',
					'name' => 'q12'
					),
				'options' => array(
					'a' => '厌恶风险，不希望本金损失，希望获得稳定的回报',
					'b' => '保守投资，不希望本金损失，愿意承担一定幅度的收益波动',
					'c' => '寻求资金的高收益和成长性，愿意为此承担有限的本金损失',
					'd' => '希望赚取高回报，愿意为此承担较大的本金损失',
					),
				),

			array(
				'question' => array(
					'text' => '您的投资出现何种程度的波动时，您会呈现明显的焦虑？',
					'name' => 'q13'
					),
				'options' => array(
					'a' => '本金无损失，但收益未达到预期',
					'b' => '出现轻微本金损失',
					'c' => '本金10%以内的损失',
					'd' => '本金20％－50%的损失',
					'e' => '本金50%以上的损失',
					),
				),

		);
		if($return){
			return $data;
		}
		$this->setExpires( 86400*7 );
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	public function riskAssessmentAnswer(){
		if(!$this->checkUserLogin()){
			return;
		}
		$question = $this->riskAssessmentQuestions( true );
		$answer = trim($this->postval('answer'));
		if(empty($answer)){
			$this->setMsg( getLang('qa.answer_empty') );
			return;
		}
		$answer_map = json_decode($answer, true);
		$errmsg = array();
		foreach ($question as $row) {
			$name = $row['question']['name'];
			if(!isset($answer_map[$name])){
				$errmsg[] = getLang('qa.not_answer_question', array(
					'question' => $row['question']['text']
					));
			}elseif(!isset($row['options'][$answer_map[$name]])){
				$errmsg[] = getLang('qa.answer_not_in_question', array(
					'question' => $row['question']['text']
					));
			}
		}
		if(!empty($errmsg)){
			$this->setMsg(implode("\n", $errmsg));
			return;
		}
		$uid = $this->uid;
		$md_qa = & load_model('qa');
		$md_qa->addRiskAssessment($uid, json_encode($question), $answer);
		$this->setCodeSuccess();
	}
}