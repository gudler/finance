<?php
require_once PATH_BASE_CONTROLLER;

class Refer extends Controller{

	public function __construct(){
		parent::__construct();
	}
	/**
	 * 分页获取我的邀请好友 
	 * 这个是老版本的APP接口，只能获取一级好友的数据
	 * 2017-11-22 VERIFIED
	 * 
	 * @post_param $is_done 已支付还是未支付
	 */
	public function myInviteeInterest(){
		if(!$this->checkUserLogin()){
			return;
		}
		$md_user = & load_model('user');

		$is_done = intval($this->postval('is_done'));
		// 2017-11-15 新邀请 DONE
		// is_done目前缺省是0，只有1的时候是true
		if( 1==$is_done){
			$is_done = true;
		}else{
			$is_done = false;
		}
		$index = intval($this->postval('page'));
		$pagesize = 30;
		$index = max($index, 0);//对外接口，page从0开始

		$total = $md_user->countUsersRelInterest($this->uid, $is_done);
		$data = $md_user->getUsersRelInterest($this->uid, $is_done, $index, $pagesize);
		if(!empty($data)){
			$helper = load_helper('codemap');
			foreach ($data as &$row) {
				$len = strlen($row['mobile']);
				$row['mobile'] = substr($row['mobile'], 0, 3) . str_pad('', $len - 7, '*') . substr($row['mobile'], -4);
				$row['status_name'] = $helper::inviteStatusCodeName2($is_done);
				$row['interest'] = $this->convHaoToFen( $row['interest'] );					
				if ($is_done==false) {
					// 2017-11-15 新邀请 DONE
					// 兼容老的接口，$is_done为false的时候，返回未支付的利息
					$row['interest'] = $this->convHaoToFen( $row['unpaid_interest'] );					
				}
			}
		}
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	/**
	 * 获取我的邀请好友合计信息
	 * 这个是老版本的APP接口，只能获取一级好友的数据
	 * 2017-11-22 VERIFIED
	 * 
	 */
	public function myInviteeInterestTotal(){
		if(!$this->checkUserLogin()){
			return;
		}
		$md_user = & load_model('user');
		$data = $md_user->sumUsersRelInterest($this->uid);
		$total_number = $total_paid = $total_pending = 0;
		if (!empty($data)) {
			$total_number = $data['number'];
			$total_paid = $data['interest'];
			$total_pending = $data['unpaid_interest'];
		}
		$this->setData( array(
			'total_number' => $total_number,
			'total_paid' => $this->convHaoToFen( $total_paid ),
			'total_pending' => $this->convHaoToFen( $total_pending ),
			) );
		$this->setCodeSuccess();
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取当前邀请入口活动的页面
	 * APP获取两个页面的URL，其中第二个页面，显示了统计数据，需要带参数显示
	 * 2017-11-22 VERIFIED
	 */
	public function myInvite2Pages() {
		if(!$this->checkUserLogin()){
			return;
		}
		// 获取统计信息
		$md_user = & load_model('user');
		$data = $md_user->sumUsersRelInterest2($this->uid);
		// 每个小时生成新的参数，刷新页面
		$param_t = '?t='.date('YmdH', time());
		$invitee_number = $invitee_bonus = $invitee_unpaid_bonus = $invitee_l2_number = 0;
		if (!empty($data)) {
			$invitee_number = $data['number'];
			$invitee_bonus = $this->convHaoToFen( intval($data['interest']) + intval($data['l2_interest']))/100.0;
			$invitee_unpaid_bonus = $this->convHaoToFen( intval($data['unpaid_interest']) + intval($data['l2_unpaid_interest']))/100.0;
			$invitee_l2_number = $data['l2_number'];
		}
		// 第二个页面的参数
		$param = "&invitee_number={$invitee_number}&invitee_bonus={$invitee_bonus}&invitee_unpaid_bonus={$invitee_unpaid_bonus}&invitee_l2_number={$invitee_l2_number}";
		// 默认的邀请活动页面
		$normal_item = array (
			'page1_url' => 'http://image.egeyed.com/static/web/events/appinvite2/page_1.html'.$param_t,
			'page2_url' => 'http://image.egeyed.com/static/web/events/appinvite2/page_2.html'.$param_t.$param,
		);
		// 特别时间段的邀请活动页面
		$config_items = [
			[
				'start_time' => EVENT_NEW_INVITE_START_TIME,
				'end_time' => EVENT_NEW_INVITE_END_TIME,
				'page1_url' => 'http://image.egeyed.com/static/web/events/appinvite2/page_1.html'.$param_t,
				'page2_url' => 'http://image.egeyed.com/static/web/events/appinvite2/page_2.html'.$param_t.$param,
			]
		];
		$items = array();
		$now = time();        
		foreach($config_items as $item) {
			if (isset($item['start_time']) && !empty($item['start_time'])){
				$start = strtotime($item['start_time']);
				if ( $now<$start) {
					continue;
				}
			}
			if (isset($item['end_time']) && !empty($item['end_time'])){
				$end = strtotime($item['end_time']);
				if ( $now>$end) {
					continue;
				}            
			}
			unset($item['start_time']);
			unset($item['end_time']);
			$normal_item = $item;
			break;
		}
		$this->setExpires(180);
		$this->setCodeSuccess();
		$this->setResult($normal_item);		

	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取我的邀请的合计信息
	 * 2017-11-22 VERIFIED
	 */
	public function myInvite2Summary() {
		if(!$this->checkUserLogin()){
			return;
		}
		$md_user = & load_model('user');
		$data = $md_user->sumUsersRelInterest2($this->uid);
		$this->setData( array(
			'invite_number' => intval($data['number']),
			'invite_interest' => $this->convHaoToFen( intval($data['interest']) ),
			'invite_unpaid_interest' => $this->convHaoToFen( intval($data['unpaid_interest']) ),
			'l2_invite_number' => intval($data['l2_number']),
			'l2_invite_interest' => $this->convHaoToFen( intval($data['l2_interest']) ),
			'l2_invite_unpaid_interest' => $this->convHaoToFen( intval($data['l2_unpaid_interest']) ),
			) );
		$this->setCodeSuccess();
	}
	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取用户一级邀请的详细列表
	 * 2017-11-22 VERIFIED
	 */
	public function myInvite2Detail(){
		if(!$this->checkUserLogin()){
			return;
		}
		$md_user = & load_model('user');
		$index = intval($this->postval('page'));
		$pagesize = 12;
		$index = max($index, 0);//对外接口，page从0开始

		$total = $md_user->countUsersRelInterest2($this->uid);
		$data = $md_user->getUsersRelInterest2($this->uid, $index, $pagesize);
		if(!empty($data)){
			foreach ($data as &$row) {
				$len = strlen($row['mobile']);
				$row['mobile'] = substr($row['mobile'], 0, 3) . str_pad('', $len - 7, '*') . substr($row['mobile'], -4);
				$row['interest'] = $this->convHaoToFen( $row['interest'] );
				$row['unpaid_interest'] = $this->convHaoToFen( $row['unpaid_interest'] );
				$row['l2_number'] = intval( $row['l2_number'] );
				$row['l2_interest'] = $this->convHaoToFen( $row['l2_interest'] );
				$row['l2_unpaid_interest'] = $this->convHaoToFen( $row['l2_unpaid_interest'] );
			}
		}
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取用户二级级邀请的详细列表
	 * 2017-11-22 VERIFIED
	 */
	public function myInvite2L2Detail(){
		if(!$this->checkUserLogin()){
			return;
		}
		$md_user = & load_model('user');
		// 一级被邀请者ID
		$invitee= $this->postval('invitee');
		$index = intval($this->postval('page'));
		$pagesize = 12;
		$index = max($index, 0);//对外接口，page从0开始

		$total = $md_user->countUsersRelL2Interest2($this->uid,$invitee);
		$data = $md_user->getUsersRelL2Interest2($this->uid,$invitee, $index, $pagesize);
		if(!empty($data)){
			foreach ($data as &$row) {
				$len = strlen($row['mobile']);
				$row['mobile'] = substr($row['mobile'], 0, 3) . str_pad('', $len - 3, '*');
				$row['l2_interest'] = $this->convHaoToFen( $row['l2_interest'] );
				$row['l2_unpaid_interest'] = $this->convHaoToFen( $row['l2_unpaid_interest'] );
			}
		}
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}
}