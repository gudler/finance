<?php
require_once PATH_BASE_CONTROLLER;

class Obligation extends Controller{

	protected function getAssortViaGroup(){
		return array(
			KEY_VIA_TYPE_DIRECT => array( TRADE_VIA_DIRECT_BUY_OBLIGATION ),
			KEY_VIA_TYPE_EAGLEEYED => array( TRADE_VIA_EAGLEEYED, TRADE_VIA_AUTOSHIFT_EAGLEEYED ),
			KEY_VIA_TYPE_FAST_ENTRY => array( TRADE_VIA_FAST_ENTRY, TRADE_VIA_AUTOSHIFT_FAST_ENTRY, TRADE_VIA_AMOUNT_SHIFT ),
			KEY_VIA_TYPE_OTHER => array( TRADE_VIA_ROOKIE )
		);
	}

	public function __construct(){
		parent::__construct();
	}

	public function getProductList(){
		$md_obligation = & load_model('obligation');
		$md_rate = & load_model('rate');
		$res = $md_obligation->getObligationTotalAmount(array(OBL_STATUS_OPEN, OBL_STATUS_SOLDOUT));
		if(empty($res) || empty($res['total_amount'])){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$total_amount = $res['total_amount'];
		$left_amount = $res['left_amount'];

		$total_amount = $this->convHaoToFen( $total_amount );
		$left_amount = $this->convHaoToFen( $left_amount );
		$res = $md_obligation->getInvestableObligationTotalAmount();
		$investable_amount = 0;
		if(!empty($res) && isset($res['left_amount'])){
			$investable_amount = $this->convHaoToFen( $res['left_amount'] );
		}

		$cmp_amt = $this->convFenToHao($investable_amount);
		if($cmp_amt < AUTO_UP_OBL_MIN_LEFT_AMT){
			$opr = $md_obligation->getObligationPlanRecently();
			if(empty($opr)){
				$robl = $md_obligation->getReadyObligationInDH();
				$diffamt = AUTO_UP_OBL_MIN_LEFT_AMT - $cmp_amt;
				foreach ($robl as $row) {
					$diffamt -= $row['left_loan'];
					$rate = $md_rate->getCurrentRate();
					$all_period_rate = $md_rate->getAllClosedRate($rate, $row['left_period']);
					$closed_period = $md_rate->getClosedPeriodOfObligation();
					$up_time = date('Y-m-d H:i:00', time()+60);
					$md_obligation->addObligationPlan($row['id'], $rate, $all_period_rate, $closed_period, $up_time);
					if($diffamt <= 0){
						break;
					}
				}
			}
		}

		$rate = ($total_amount - $left_amount) / $total_amount;
		$rate2 = ($total_amount - $investable_amount) / $total_amount;

		$rookie_invested = $md_obligation->getRookieTodayTotalAmount();
		$rookie_left_amount = TRADE_QUEUE_ROOKIE_AMOUNT_TOTAL_CAP - $rookie_invested;
		$rate_rookie = $rookie_invested/TRADE_QUEUE_ROOKIE_AMOUNT_TOTAL_CAP;

		$data = array(
			array(
				'label' => 'rookie',
				'name' => getlang('product.rookie'),
				'closed_period' => $md_rate->getClosedPeriodOfRookie(),
				'repayment_method' => getlang('repayment.repayment_principal_and_interest_at_maturity'),
				'total_amount' => $this->convHaoToFen( TRADE_QUEUE_ROOKIE_AMOUNT_TOTAL_CAP ),
				'left_amount' => $this->convHaoToFen( $rookie_left_amount ) ,
				'complete_rate' => $rate_rookie,
				'rate' => $md_rate->getRateOfRookie(),
				'inqueue_amount' => $this->convHaoToFen( $md_obligation->getAPInQueueAmount( TRADE_VIA_ROOKIE ) ),
				'buy_min' => $this->convHaoToFen( TRADE_ROOKIE_AMOUNT_LIMIT_MIN ),
				'buy_max' => $this->convHaoToFen( TRADE_ROOKIE_AMOUNT_LIMIT_MAX ),
				'tips' => getLang('product.rookie_tips'),
			),
			array(
				'label' => 'eagleeyed',
				'name' => getlang('product.eagleeyed'),
				'closed_period' => $md_rate->getClosedPeriodOfEagleeyed(),
				'repayment_method' => getlang('repayment.principal_and_interest_equal'),
				'total_amount' => $total_amount,
				'left_amount' => $investable_amount,//鹰眼宝可以直接投资到用户出售债权
				'complete_rate' => $rate2,
				'rate' => $md_rate->getRateOfEagleeyed(),
				'inqueue_amount' => $this->convHaoToFen( $md_obligation->getAPInQueueAmount( TRADE_VIA_EAGLEEYED ) ),
				'buy_min' => $this->convHaoToFen( TRADE_EAGLEEYED_AMOUNT_LIMIT_MIN ),
				'buy_max' => $this->convHaoToFen( TRADE_QUEUE_EAGLEEYED_AMOUNT_USER_CAP ),//分为单位
				'tips' => getLang('product.eagleeyed_tips'),
			),
			array(
				'label' => 'fastentry',
				'name' => getlang('product.fastentry'),
				'closed_period' => $md_rate->getClosedPeriodOfFastEntry(),
				'repayment_method' => getlang('repayment.principal_and_interest_equal'),
				'total_amount' => $total_amount,
				'left_amount' => $investable_amount,
				'complete_rate' => $rate2,
				'rate' => $md_rate->getRateOfFastEntry().'000',
				'inqueue_amount' => $this->convHaoToFen( $md_obligation->getAPInQueueAmount( TRADE_VIA_FAST_ENTRY ) ),
				'buy_min' => $this->convHaoToFen( TRADE_FAST_ENTRY_AMOUNT_LIMIT_MIN ),
				'buy_max' => $this->convHaoToFen( TRADE_QUEUE_FAST_ENTRY_AMOUNT_USER_CAP ),
				'tips' => getLang('product.fastentry_tips'),
			)
		);
		
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	public function getPlanList(){
		
		$md_obligation = & load_model('obligation');
		$total = 0;

		$data = $md_obligation->getObligationsPlan();
		if(!empty($data)){
			$total = count($data);
			$ids = array();
			$now = time();
			foreach ($data as &$row) {
				$row['seconds'] = strtotime($row['up_time']) - $now;
			}
		}
		$this->setData( array(
			'total' => $total,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	public function getList(){
		$page = intval($this->postval('page'));
		$pagesize = intval($this->postval('pagesize'));
		$status = $this->postval('status');
		if($pagesize<1 || $pagesize > 200){
			$pagesize = 30;
		}
		$index = max($page, 0);//对外接口，page从0开始

		$md_obligation = & load_model('obligation');
		$md_rate = & load_model('rate');
		$helper = load_helper('codemap');
		if(in_array($status, array(OBL_STATUS_OPEN, OBL_STATUS_SOLDOUT, OBL_STATUS_CLOSED, OBL_STATUS_DONE))){
			$total = $md_obligation->getObligationCount($status);
			$data = $md_obligation->getObligationList( $index, $pagesize, $status );
		}else{
			$total = $md_obligation->getObligationCount();
			$data = $md_obligation->getObligationList( $index, $pagesize );
		}
		if(!empty($data)){
			$ids = array();
			foreach ($data as $row) {
				$ids[] = $row['extid'];
			}
			$arr_make = $md_obligation->getObligationExt($ids, array('id','make'));
			$make_map = array();
			foreach ($arr_make as $row) {
				$make_map[$row['id']] = $row['make'];
			}
			foreach ($data as &$row) {
				$row['total_amount'] = $this->convHaoToFen( $row['total_amount'] );
				$row['left_amount'] = $this->convHaoToFen( $row['left_amount'] );
				//$row['rate'] = $md_rate->getCurrentRate();
				$row['make'] = $make_map[$row['extid']];
				// $row['closed_period'] = $md_rate->getClosedPeriodOfObligation( $row['id'] );
				$row['repayment_date'] = $helper::obligationRepaymentDate($row['repayment_date'], $row['repayment_day'], $row['repayment_method']);
				$row['labels'] = array();
				if($row['rate'] < $row['all_period_rate']){
					$row['labels'][] = OBL_LABLE_BUY_ALL_PERIOD;
				}
			}
		}
		$this->logExtraColumns('page', $page);
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	public function getSellList(){
		$page = intval($this->postval('page'));
		$pagesize = 100;
		$index = max($page, 0);//对外接口，page从0开始

		$md_obligation = & load_model('obligation');
		$md_rate = & load_model('rate');
		$helper = load_helper('codemap');
		$res = $md_obligation->getObligationSellCount();
		$numb = isset($res['numb']) ? $res['numb'] : 0;
		$total = isset($res['total']) ? $res['total']/10000 : 0;

		$data = $md_obligation->getObligationSellList( $index, $pagesize );
		if(!empty($data)){
			foreach ($data as &$row) {
				$row['total_amount'] = $this->convHaoToFen( $row['total_amount'] );
				$row['left_amount'] = $this->convHaoToFen( $row['left_amount'] );
			}
		}
		$this->logExtraColumns('page', $page);
		$this->setData( array(
			'total' => $numb,
			'total_money' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	public function getDetail(){
		$id = intval($this->postval('id'));
		$this->logExtraColumns('id', $id);
		if(empty($id)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_obligation = & load_model('obligation');
		$md_rate = & load_model('rate');
		$helper = load_helper('codemap');
		$data = $md_obligation->getObligationDetail( $id );
		if(empty($data)) {
			$this->setMsg( getLang('obligation.not_exists') );
			return;
		}
		$data['total_amount'] = $this->convHaoToFen( $data['total_amount'] );
		$data['left_amount'] = $this->convHaoToFen( $data['left_amount'] );
		// $data['closed_period'] = $md_rate->getClosedPeriodOfObligation( $data['id'] );
		switch ($data['ext_tbl']) {
			case 'projcar':
				$xdata = $md_obligation->getProjcarDetail( $data['extid'] );
				if(!empty($xdata)){
					$xdata['total_loan'] = $this->convHaoToFen( $xdata['total_loan'] );
					$xdata['price'] = $this->convHaoToFen( $xdata['price'] );
					// $xdata['left_loan'] = $this->convHaoToFen( $xdata['left_loan'] );
					unset($xdata['left_loan']);
					$xdata['repayment_date'] = $helper::obligationRepaymentDate($xdata['repayment_date'], $xdata['repayment_day'], $xdata['repayment_method']);
					$data['project'] = $xdata;
				}
				break;
			default:
				break;
		}
			
		$data['repayment_date'] = $helper::obligationRepaymentDate($data['repayment_date'], $data['repayment_day'], $data['repayment_method']);
		$data['inqueue_amount'] = $md_obligation->getObligationInQueueAmount( $id );
			// $data['rate'] = $md_rate->getCurrentRate();
		$data['buy_min'] = min($this->convHaoToFen( TRADE_OBL_AMOUNT_LIMIT_MIN ), $data['left_amount']);
		$data['buy_max'] = $data['left_amount'];
		$data['labels'] = array();
		if($data['rate'] < $data['all_period_rate']){
			$data['labels'][] = OBL_LABLE_BUY_ALL_PERIOD;
		}
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	public function getProjectDetail(){
		$id = $this->postval('id');
		$this->logExtraColumns('id', $id);
		$id = intval($id);
		if(empty($id)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_obligation = & load_model('obligation');
		$helper = load_helper('codemap');
		$data = $md_obligation->getProjcarDetail( $id );
		if(empty($data)) {
			$this->setMsg( getLang('obligation.projcar_not_exists') );
			return;
		}		
		$data['total_loan'] = $this->convHaoToFen( $data['total_loan'] );
		$data['price'] = $this->convHaoToFen( $data['price'] );
		// $data['left_loan'] = $this->convHaoToFen( $data['left_loan'] );
		unset($data['left_loan']);
		$data['repayment_date'] = $helper::obligationRepaymentDate($data['repayment_date'], $data['repayment_day'], $data['repayment_method']);
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	/**
	 *	获取债权当前持有用户列表
	 */
	public function getHoldingList(){
		$id = $this->postval('id');
		$index = intval($this->postval('page'));
		$this->logExtraColumns(array('id' => $id, 'index' => $index));
		$id = intval($id);
		if(empty($id)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$index = max(0, $index);
		$pagesize = 30;

		$md_obligation = & load_model('obligation');
		$total = $md_obligation->countObligationHoldingUsersByOid( $id );
		if($index > ceil($total/$pagesize) - 1){
			$data = array();
		}else{
			$data = $md_obligation->getObligationHoldingUsersByOid( $id, $index, $pagesize );
		}
		if(!empty($data)){
			$helper = load_helper('codemap');
			foreach ($data as &$row) {
				$len = strlen($row['mobile']);
				$row['mobile'] = substr($row['mobile'], 0, 3) . str_pad('', $len - 7, '*') . substr($row['mobile'], -4);
				$row['total_amount'] = $this->convHaoToFen( $row['total_amount'] );
				$row['via'] = $helper::viaCodes($row['via']);
				$row['status'] = $helper::holdingStatusCodeName($row['status'], $row['selling']);
				unset($row['uid']);
			}
		}
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	public function getUserHoldingAssort(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		$res = $md_obligation->getHoldingObligationAssort($uid);
		$empty_arr = array(
			'amount' => 0,
			'interest' => 0,
			'rate' => 0,
		);

		$data = array();
		$assort = $this->getAssortViaGroup();
		foreach ($assort as $key => $value) {
			$data[$key] = $empty_arr;
		}
		if(!empty($res)){
			$total = 0;
			$interests = $md_obligation->getHoldingObligationAssortInterests( $uid );
			foreach ($interests as $row) {
				foreach ($assort as $key => $arr) {
					if(in_array($row['via'], $arr)){
						$data[$key]['interest'] += $row['interest'];
						break;
					}
				}
			}
			foreach ($res as $row) {
				foreach ($assort as $key => $arr) {
					if(in_array($row['via'], $arr)){
						$total += $row['amount'];
						$data[$key]['amount'] += $row['amount'];
						break;
					}
				}
			}
			foreach ($data as &$arr) {
				$arr['rate'] = $arr['amount']/$total;
				$arr['amount'] = $this->convHaoToFen( $arr['amount'] );
				$arr['interest'] = $this->convHaoToFen( $arr['interest'] );
			}
		}
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	/**
	 *	获取用户当前持有债权列表
	 */
	public function getUserHoldingList(){
		if(!$this->checkUserLogin()){
			return;
		}
		$index = intval($this->postval('page'));
		$type = trim($this->postval('type'));
		$type = strtolower($type);
		$index = max(0, $index);
		$pagesize = 30;

		$assort = $this->getAssortViaGroup();
		if(isset($assort[$type])){
			$via = $assort[$type];
		}else{
			$via = array();
		}

		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		$total = $md_obligation->countObligationByUid( $uid, $via );
		if($index > ceil($total/$pagesize) - 1){
			$data = array();
		}else{
			$data = $md_obligation->getObligationByUid( $uid, $index, $pagesize, $via );
		}
		if(!empty($data)){
			$idarr = array();
			foreach ($data as $row) {
				$idarr[] = $row['oid'];
			}
			$makemap = $md_obligation->getObligationInfoByOid($idarr);
			$helper = load_helper('codemap');
			$helper_datetime = load_helper('datetime');
			$now = time();
			foreach ($data as &$row) {
				$key = $md_obligation->getMapKey($row['oid']);
				$row['make'] = isset($makemap[$key]) ? $makemap[$key]['make'] : substr($row['name'], 0, strpos($row['name'], ' '));
				$row['total_amount'] = $this->convHaoToFen( $row['total_amount'] );
				$row['left_amount'] = $this->convHaoToFen( $row['left_amount'] );
				$row['paid_amount'] = $row['total_amount'] - $row['left_amount'];

				$days = $helper_datetime::diffDays(strtotime($row['created_time']), $now);
				// $days = floor(($now - strtotime($row['created_time']))/86400);
				$left_closed_period = $row['closed_period'] - $days;
				if($left_closed_period <= 0){
					$left_closed_period = 0;
					$row['is_closed'] = false;
				}else{
					$row['is_closed'] = true;
				}
				$row['left_closed_period'] = $left_closed_period;

				$repayment_method = REPAYMENT_PRINCIPAL_AND_INTEREST_EQUAL;
				if($row['via'] == TRADE_VIA_EAGLEEYED){
					$row['change_autoshift'] = false;
				}elseif($row['via'] == TRADE_VIA_ROOKIE){
					$row['change_autoshift'] = false;
					$repayment_method = REPAYMENT_PRINCIPAL_AND_INTEREST_AT_MATURITY;
				}else{
					$row['change_autoshift'] = true;
				}
				$row['repayment_date'] = $helper::obligationRepaymentDate($row['repayment_date'], $row['repayment_day'], $repayment_method, $row['closed_period'], $row['created_time']);
				$row['via_code'] = $row['via'];
				$row['via'] = $helper::viaCodes($row['via'], $row['closed_period']);
				$row['status_name'] = $helper::holdingStatusCodeName($row['status'], $row['selling']);
				$row['generated_interest'] = $this->convHaoToFen( $row['generated_interest'] );
				$row['rate'] = substr($row['rate'], 0, 8);
			}
		}
		$this->logExtraColumns('index', $index);
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'type' => $type,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	public function getUserObligationDetail(){
		if(!$this->checkUserLogin()){
			return;
		}
		$id = intval($this->postval('id'));
		$this->logExtraColumns('id', $id);
		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getObligationHolding( $id );
		if(!empty($data)){
			if($uid != $data['uid']){
				$this->setMsg( getLang('obligation.not_exists') );
				return;
			}
			$obligation = $md_obligation->getObligationDetail( $data['oid'] );
			$data['extid'] = $obligation['extid'];
			$data['ext_tbl'] = $obligation['ext_tbl'];
			$data['repayment_method'] = $obligation['repayment_method'];

			$now = time();
			$helper = load_helper('codemap');
			$data['total_amount'] = $this->convHaoToFen( $data['total_amount'] );
			$data['left_amount'] = $this->convHaoToFen( $data['left_amount'] );
			$data['paid_amount'] = $data['total_amount'] - $data['left_amount'];

			$helper_datetime = load_helper('datetime');
			$days = $helper_datetime::diffDays(strtotime($data['created_time']), $now);
			// $days = floor(($now - strtotime($data['created_time']))/86400);
			$left_closed_period = $data['closed_period'] - $days;
			if($left_closed_period <= 0){
				$left_closed_period = 0;
				$data['is_closed'] = false;
			}else{
				$data['is_closed'] = true;
			}
			$data['left_closed_period'] = $left_closed_period;
			$repayment_method = $data['repayment_method'];
			if($data['via'] == TRADE_VIA_EAGLEEYED){
				$data['change_autoshift'] = false;
			}elseif($data['via'] == TRADE_VIA_ROOKIE){
				$data['repayment_method'] = $repayment_method = REPAYMENT_PRINCIPAL_AND_INTEREST_AT_MATURITY;
				$data['change_autoshift'] = false;
			}else{
				$data['change_autoshift'] = true;
			}
			$data['repayment_date'] = $helper::obligationRepaymentDate($data['repayment_date'], $data['repayment_day'], $repayment_method, $data['closed_period'], $data['created_time']);
			$data['via_code'] = $data['via'];
			$data['via'] = $helper::viaCodes($data['via'], $data['closed_period']);
			$data['status_name'] = $helper::holdingStatusCodeName($data['status'], $data['selling']);
			$data['generated_interest'] = $this->convHaoToFen( $data['generated_interest'] );

			$data['rate'] = substr($data['rate'], 0, 8);
			$monthes = $data['total_period'];
			switch ($data['via_code']) {
				case TRADE_VIA_DIRECT_BUY_OBLIGATION:
				case TRADE_VIA_FAST_ENTRY:
				case TRADE_VIA_AUTOSHIFT_FAST_ENTRY:
				case TRADE_VIA_AMOUNT_SHIFT:
					$mode = 'getFastEntryList';
					break;
				case TRADE_VIA_ROOKIE:
					$mode = 'getRookieList';
					$monthes = $data['closed_period'];
					break;
				default:
					$mode = 'getEagleEyedList';
					break;
			}
			$helper_in = load_helper('interest');
			$ts = strtotime($data['created_time']);
			/* 计算已付收益 START */
			$arpay = $helper_in::$mode($data['total_amount']/100, $data['rate']/12, $monthes, $data['repayment_day'], date('j', $ts), date('n', $ts), date('Y', $ts));
			$arpay = $arpay['list'];
			if($data['via_code'] == TRADE_VIA_ROOKIE){
				$not_paid = $md_obligation->getRepaymentInterestByUoid( $id );
				if(empty($not_paid) || empty($not_paid['uid'])){
					$is_paid = 1;
				}else{
					$is_paid = 0;
				}
				$l = count($arpay);
				for($i=1;$i<$l;$i++){
					$arpay[$i]['is_paid'] = $is_paid;
				}
			}else{
				$tmp = $md_obligation->getUserObligationRepaymentByUoid( $id );
				if($data['status'] != USROBL_STATUS_IN_HELD){
					$not_paid = $md_obligation->getRepaymentInterestByUoid( $id );
					do{
						if(empty($not_paid) || empty($not_paid['today_interest'])){
							if($data['status'] != USROBL_STATUS_DONE){
								$pos = count($tmp) + 1;
								break;
							}
						}
						$pos = count($tmp) + 2;
						if(!isset($arpay[$pos - 1])){
							$pos -= 1;
							break;
						}
						$target = &$arpay[$pos - 1];
						$target['capital'] = floor($target['last'] * 100) / 100;
						$target['pay_sum'] = $target['capital'] + floor($not_paid['today_interest']/100)/100;
						if($mode == 'getFastEntryList' && $data['status'] != USROBL_STATUS_SOLD){
							$bonus_interest = $md_obligation->getRepaymentBonusInterestByUoidAndPeriod( $id, $not_paid['period_id']+1 ) + $not_paid['today_interest'];
							$target['pay_sum'] += ( floor($bonus_interest/100)/100 );
						}
						$target['is_paid'] = 0;
						if($data['status'] == USROBL_STATUS_DONE){
							$target['is_paid'] = 1;
						}
					}while(0);
					$arpay = array_slice($arpay, 0, $pos);

				}
				$i = 1;
				$l = count($arpay);
				foreach ($tmp as $idx => $row) {
					$target = &$arpay[$idx + 1];
					$target['capital'] = $this->convHaoToFen( $row['principal'] )/100;
					$target['pay_interest'] = $this->convHaoToFen( $row['interest'] )/100;
					$target['pay_bonus'] = $this->convHaoToFen( $row['bonus_interest'] )/100;
					$target['pay_sum'] = $target['capital'] + $target['pay_interest'] + $target['pay_bonus'];
					$target['is_paid'] = ($row['status'] == OBL_REPAYEMNT_STATUS_PAID ? 1 : 0);
					$i++;
				}
			}
			/* 计算已付收益 END */
			$data['already_repayment'] = $arpay;
			// $data['already_repayment'] = $md_obligation->getUserObligationRepaymentByUoid( $id );
		
		}
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	/**
	 *	获取用户购买记录列表
	 */
	public function getUserBoughtHistory(){
		if(!$this->checkUserLogin()){
			return;
		}
		$index = intval($this->postval('page'));
		$index = max(0, $index);
		$pagesize = 30;

		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		$total = $md_obligation->countBoughtHistoryList( $uid );
		if($index > ceil($total/$pagesize) - 1){
			$data = array();
		}else{
			$data = $md_obligation->getBoughtHistoryList($uid, $index, $pagesize);
		}
		if(!empty($data)){
			$helper = load_helper('codemap');
			$helper_datetime = load_helper('datetime');
			$now = time();
			foreach ($data as &$row) {
				$row['total_amount'] = $this->convHaoToFen( $row['total_amount'] );
				$row['left_amount'] = $this->convHaoToFen( $row['left_amount'] );
				$row['paid_amount'] = $row['total_amount'] - $row['left_amount'];

				$days = $helper_datetime::diffDays(strtotime($row['created_time']), $now);
				// $days = floor(($now - strtotime($row['created_time']))/86400);
				$left_closed_period = $row['closed_period'] - $days;
				if($left_closed_period <= 0){
					$left_closed_period = 0;
					$row['is_closed'] = false;
				}else{
					$row['is_closed'] = true;
				}
				$row['left_closed_period'] = $left_closed_period;
				

				$row['via'] = $helper::viaCodes($row['via'], $row['closed_period']);
				$row['status_name'] = $helper::holdingStatusCodeName($row['status'], $row['selling']);
				$row['generated_interest'] = $this->convHaoToFen( $row['generated_interest'] );
			}
		}
		$this->logExtraColumns('index', $index);
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	/**
	 *	获取用户购买出售历史纪录
	 */
	public function getUserObligationHistory(){
		if(!$this->checkUserLogin()){
			return;
		}
		$index = intval($this->postval('page'));
		$type = intval($this->postval('type'));
		$index = max(0, $index);
		$pagesize = 30;

		switch ($type) {
			case USRHIST_TYPE_SELL://出售
				$status = array(USROBL_STATUS_SOLD);
				$datekey = 'sold_time';
				break;
			case USRHIST_TYPE_BUY://购买
			default:
				$status = NULL;
				$datekey = 'created_time';
				break;
		}
		

		$uid = $this->uid;
		$md_obligation = & load_model('obligation');

		$total = $md_obligation->getUserObligationHistoryList( $uid, $status, true );
		if($index > ceil($total/$pagesize) - 1){
			$data = array();
		}else{
			$data = $md_obligation->getUserObligationHistoryList($uid, $status, false, $index, $pagesize);
		}
		$resarr = array();
		if(!empty($data)){
			$helper = load_helper('codemap');
			foreach ($data as &$row) {
				$arr = array(
					'id' => $row['id'],
					'oid' => $row['oid'],
					'name' => $row['name'],
					'amount' => $this->convHaoToFen( $row['total_amount'] ),
					'via' => $helper::viaCodes($row['via']),
					'date' => $row[$datekey],
				);
				$resarr[] = $arr;
			}
		}
		$this->logExtraColumns(array('index' => $index, 'type' => $type));
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $resarr
			) );
		$this->setCodeSuccess();
	}

	/**
	 *	获取用户当前排队中列表
	 */
	public function getUserInqueueList(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getUserInQueueList($uid);
		if(!empty($data)){
			$helper = load_helper('codemap');
			$helper_datetime = load_helper('datetime');
			$now = time();
			foreach ($data as &$row) {
				$row['total_amount'] = $this->convHaoToFen( $row['total_amount'] );
				$row['amount'] = $this->convHaoToFen( $row['amount'] );
				$row['name'] = $helper::viaCodeName($row['via'], $row['closed_period']);
				$row['via'] = $helper::viaCodes($row['via'], $row['closed_period']);
				$time = strtotime($row['created_time']);
				$row['inqueue_time'] = $helper_datetime::runTime( $now - $time, 2 );
				
			}
		}
		$this->setData( array(
			'total' => count($data),
			'page' => 0,
			'pagesize' => 1000,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	/* //用户代付款利息列表
	public function getUserPendingInterests(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getUserPendingInterests($uid);
		$res = array();
		if(!empty($data)){
			$helper = load_helper('codemap');
			$helper_in = load_helper('interest');
			foreach ($data as $row) {
				$bonus_interest = 0;
				if(!$row['selling']){
					$bonus_interest = $md_obligation->getRepaymentBonusInterestByUoidAndPeriod( $row['id'], $row['period_id'] + 1 );
				}
				$repayment_day = $row['repayment_day'];
				if($repayment_day < date('j')){
					$year = date('Y');
					$month = date('m') + 1;
					if($month > 12){
						$month = 1;
						$year += 1;
					}
					$repayment_ts = strtotime($helper_in::getRepaymentDate($repayment_day, $month, $year));
				}else{
					$repayment_ts = strtotime(date('Y-m-'.$repayment_day));
				}
				$pay_date = date('Y-m-d', $repayment_ts + 86400 );
				$res[] = array(
					'id' => $row['id'],
					'name' => $row['name'],
					'pending_interest' => $this->convHaoToFen( $row['curr_interest'] ),
					'bonus_interest' => $this->convHaoToFen( $bonus_interest ),
					'next_bonus_interest' => $this->convHaoToFen( $row['bonus_interest'] ),
					'pay_date' => $pay_date,
					'rate' => $row['rate'],
					'period_id' => $row['period_id'],
					'principal' => $this->convHaoToFen( $row['principal'] ),
					'status' => $helper::holdingStatusCodeName($row['status'], $row['selling'], true),
					'via_code' => $row['via'],
					'via' => $helper::viaCodes($row['via']),
					'created_time' => $row['created_time']
					);
			}
		}
		$this->setData( array(
			'total' => count($res),
			'page' => 0,
			'pagesize' => 1000,
			'list' => $res
			) );
		$this->setCodeSuccess();
	}
	*/

	//用户代付款利息列表2
	public function getUserPendingInterests(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		// check and update request parameters
		$page = intval($this->postval('page'));
		if ($page<=0) {
			$page = 0;
		}
		$page_size = intval($this->postval('pagesize'));
		if( $page_size<=0 ) {
			$page_size = 30;
		} else if( $page_size<=10 ) {
			$page_size = 10;
		}
		$md_obligation = & load_model('obligation');
		$total = $md_obligation->countUserPendingInterests($uid);
		$data = $md_obligation->getUserPendingInterests2($uid,$page,$page_size);
		$res = array();
		if(!empty($data)){
			$helper = load_helper('codemap');
			$helper_in = load_helper('interest');
			foreach ($data as $row) {
				$bonus_interest = 0;
				$repayment_day = $row['repayment_day'];
				if($repayment_day < date('j')){
					$year = date('Y');
					$month = date('m') + 1;
					if($month > 12){
						$month = 1;
						$year += 1;
					}
					$repayment_ts = strtotime($helper_in::getRepaymentDate($repayment_day, $month, $year));
				}else{
					$repayment_ts = strtotime(date('Y-m-'.$repayment_day));
				}
				$pay_date = date('Y-m-d', $repayment_ts + 86400 );
				$res[] = array(
					'id' => $row['id'],
					'name' => $row['name'],
					'pending_interest' => $this->convHaoToFen( $row['curr_interest'] ),
					'bonus_interest' => $this->convHaoToFen( $bonus_interest ),
					'next_bonus_interest' => $this->convHaoToFen( $row['bonus_interest'] ),
					'pay_date' => $pay_date,
					'rate' => $row['rate'],
					'period_id' => $row['period_id'],
					'principal' => $this->convHaoToFen( $row['principal'] ),
					'status' => $helper::holdingStatusCodeName($row['status'], $row['selling'], true),
					'via_code' => $row['via'],
					'via' => $helper::viaCodes($row['via']),
					'created_time' => $row['created_time']
					);
			}
		}
		$this->setData( array(
			'total' => $total,
			'page' => $page,
			'pagesize' => $page_size,
			'list' => $res
			) );
		$this->setCodeSuccess();
	}


	public function getUserPaidInterests(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$page = $this->postval('page');

		$md_obligation = & load_model('obligation');
		$limit = 30;
		$start = $page * $limit;
		$data = $md_obligation->getUserObligationRepayments($uid, $start, $limit);
		$res = array();
		if(!empty($data)){
			$helper = load_helper('codemap');
			$helper_in = load_helper('interest');
			foreach ($data as $row) {
				
				$res[] = array(
					'id' => $row['uoid'],
					// 'uoid' => $row['uoid'],
					'name' => $row['name'],
					'paid_interest' => $this->convHaoToFen( $row['interest'] + $row['bonus_interest'] ),
					'period_id' => $row['period_id'],
					'principal' => $this->convHaoToFen( $row['principal'] ),
					'via_code' => $row['via'],
					'via' => $helper::viaCodes($row['via']),
					'paid_time' => $row['finish_time'],
					'created_time' => $row['created_time']
					);
			}
		}
		$this->setData( array(
			'total' => $md_obligation->getUserObligationRepaymentsCount( $uid ),
			'page' => 0,
			'pagesize' => $limit,
			'list' => $res
			) );
		$this->setCodeSuccess();
	}

	public function computer(){
		$mode = $this->postval('mode');
		$this->logExtraColumns('mode', $mode);
		if(!in_array($mode, array('getEagleEyedList', 'getFastEntryList', 'getRookieList'))){
			return;
		}
		$amount = intval($this->postval('amount'));
		$rate = $this->postval('rate');
		$monthes = intval($this->postval('monthes'));
		$repayment_day = intval($this->postval('repayment_day'));
		$day = intval($this->postval('day'));
		$month = intval($this->postval('month'));
		$year = intval($this->postval('year'));
		$month_rate = $rate/12;
		$money = $amount/100;

		$errmsg = array();
		if($rate<=0){
			$errmsg[] = getLang('obligation.cmpt_param_err_rate');
		}
		if($monthes<=0){
			$errmsg[] = getLang('obligation.cmpt_param_err_amount');
		}
		if($amount<=0){
			$errmsg[] = getLang('obligation.cmpt_param_err_monthes');
		}
		if($repayment_day<=0 || $repayment_day > 31){
			$errmsg[] = getLang('obligation.cmpt_param_err_repayment_day');
		}
		if($day<=0 || $day > 31){
			$errmsg[] = getLang('obligation.cmpt_param_err_day');
		}
		if($month<=0 || $month > 31){
			$errmsg[] = getLang('obligation.cmpt_param_err_month');
		}
		if($year<=2012 || $year > 2100){
			$errmsg[] = getLang('obligation.cmpt_param_err_year');
		}
		if(!empty($errmsg)){
			$this->setMsg(implode("\n", $errmsg));
			return;
		}
		$helper_in = load_helper('interest');
		$data = $helper_in::$mode($money, $month_rate, $monthes, $repayment_day, $day, $month, $year);

		$this->setData( $data );
		$this->setCodeSuccess();
	}
}