<?php
require_once PATH_BASE_CONTROLLER;
require_once DIR_CORE . 'cipher.php';

class Task extends Controller{

	protected function checkIfRunnerExists( $runner_name ){
		$pid_file = sys_get_temp_dir() . '/' . $runner_name . '.run.pid';
		if(file_exists($pid_file)){
			$pid = file_get_contents($pid_file);
			if(file_exists('/proc/')){
				if(file_exists('/proc/'.$pid)){
					return true;
				}
			}else{
				@$r = pcntl_getpriority($pid);
				if($r>0){
					return true;
				}
			}
		}
		if(function_exists('posix_getpid')){
			$pid = posix_getpid();
		}else{
			return null;
		}
		file_put_contents($pid_file, $pid);
		return false;
	}

	protected function runnerClean( $runner_name ){
		$pid_file = sys_get_temp_dir() . '/' . $runner_name . '.run.pid';
		if(file_exists($pid_file)){
			unlink($pid_file);
		}
	}

	protected function runnerWait($start_ts, $microsec, $busy_stop = 1000000){
		$end_ts = microtime(true);
		$cost = ($end_ts - $start_ts) * 1000000;
		if($cost > $microsec){
			usleep( $busy_stop );
		}else{
			usleep( $microsec - $cost );
		}
	}

	protected function logResult($func, $result){
		$filename = DIR_LOG . 'taskresult_' . date('Y-m') . '.log';
		$data = sprintf("%s\t%s\t%s\n", date('Y-m-d H:i:s'), $func, json_encode($result));
		file_put_contents($filename, $data, FILE_APPEND);
	}

	/**
	 *	获取债权文件存放路径，不存在则创建。
	 */
	protected function getDesProjcarDir($ext_id){
		$date = date('Ymd');
		$dir = DIR_DATAHOUSE . $date;
		// 2017-09-22 UPDATE
		// 增加mkdir的返回值判断
		if(!is_dir($dir)){
			if(!mkdir($dir)){
				return false;
			}
		}
		$des_path = $dir . DS . $ext_id;
		if(!is_dir($des_path)){
			if(!mkdir($des_path)){
				return false;
			}
		}
		return $des_path;
	}

	/**
	 *	利息计算与录入v2
	 */
	protected function computeInterestV2( &$statistics ){
		$md_obligation = & load_model('obligation');
		$helper_interest = load_helper('interest');
		$ts = strtotime('-23 hours');//计算前一天
		$curr_day = date('j', $ts);//今日
		$curr_month = date('n', $ts);//今月
		$curr_year = date('Y', $ts);//今年
		$date = date('Y-m-d', $ts);
		$start_ts = microtime(true);
		/**
		 *	根据所持本金、利率、剩余期数计算用户所持债权本金与利息，按当期天数计算每日利息。
		 *	如果债权到账日为X的，则计算当期总利息，并将当期本金与利息发给用户，更新债权信息。
		 *	当X>28时，判断当月最大日期以提前结算。
		 *
		 *	从obligation_holding_list获取status>=0的债权
		 *		检查obligation_interest内是否已有uoid的当日利息，若有，则跳过.
		 *		如果via为直接购买或通过易购宝或鹰眼宝购买
		 *			根据left_amount和rate和当期天数period_days计算当期利息 day_interest = left_amount*rate/12/period_days
		 *			today_interest = day_interest;
		 *			bonus_interest = 0;
		 *		如果via不为以上
		 *			根据left_amount和rate和当期天数period_days计算当期利息 day_interest = left_amount*rate/365
		 *			today_interest = day_interest;
		 *			bonus_interest = 0;
		 *
		 *		将数据录入obligation_interest
		 */
		$count = $md_obligation->countObligationHolding(true);
		$count_success = 0;
		$count_change = 0;
		$pagesize = 100;
		$page = ceil($count/$pagesize);
		for($i=0;$i<$page;$i++){
			$oblarr = $md_obligation->getObligationHoldingListByPage($i, $pagesize);
			foreach ($oblarr as $hobl) {
				if($hobl['uid'] == OBL_SYSTEM_UID){//系统持有债权不计算利息
					$count_success ++;
					continue;
				}
				$is_exists = $md_obligation->isObligationInterestExists($hobl['id'], $date);
				if($is_exists){//已计算利息的跳过
					$count_success ++;
					continue;
				}
				$start_date = date('Y-m-d', strtotime($hobl['created_time']));
				$ts_diff = strtotime($date) - strtotime($start_date);
				if($ts_diff<0){//超出开始时间的不计算
					$count_success ++;
					continue;
				}
				if($hobl['via'] == TRADE_VIA_ROOKIE){
					$days = floor($ts_diff/86400) + 1;
					if($days > $hobl['closed_period']){//新人专享的为到期还本付息，过期后不计算利息
						$count_success ++;
						continue;
					}
				}
				if($hobl['left_amount'] == 0 || $hobl['rate'] < 0.00000001){//当余额为0或利率为0，则跳过
					$count_success ++;
					continue;
				}

				if($hobl['via'] == TRADE_VIA_ROOKIE){
					$day_interest = $hobl['left_amount'] * $hobl['rate'] / 365;
				}else{
					$period_days = $helper_interest::getRepaymentMonthDays($hobl['repayment_day'], $curr_day, $curr_month, $curr_year);
					$day_interest = $hobl['left_amount'] * $hobl['rate'] / 12 / $period_days;
				}
				$today_interest = floor($day_interest);
				$bonus_interest = 0;

				$addid = $md_obligation->addObligationInterest(
					$hobl['id'],
					$hobl['uid'],
					$hobl['oid'],
					$hobl['name'],
					$hobl['left_amount'],
					$today_interest,
					$bonus_interest,
					$hobl['rate'],
					$hobl['left_period'],
					$date );
				if($addid){
					$count_success ++;
					$count_change ++;
				}
			}
		}
		$statistics = array(
			'cost_ts' => microtime( true ) - $start_ts,
			'total' => $count,
			// 2017-10-10
			// 修正返回统计信息
			'success' => $count_success,
			'change' => $count_change
		);
		return $count == $count_success;
	}

	protected function isObligationRepayDatesExistsOrInserts($oid, $created_time, $repayment_day, $last_peroid_id, $total_period = null, $first_repayment_date = null){
		$md_obligation = & load_model('obligation');
		if($md_obligation->isObligationRepayPlanExists($oid)){
			return true;
		}
		$helper_interest = load_helper('interest');
		if(empty($first_repayment_date)){//债权插入时未生成还款计划表
			$ts = strtotime('-23 hours');//计算前一天
			$curr_month = intval(date('n', $ts));//今月
			$curr_year = date('Y', $ts);//今年
			$curr_day = date('j', $ts);//今日
			$ts_created_date = strtotime(date('Y-m-d', strtotime($created_time)));
			$ts_curr_date = strtotime(date('Y-m-d', $ts));
			if( $ts_curr_date <= $ts_created_date ){
				$curr_month ++;
				if($curr_month>12){
					$curr_year ++;
					$curr_month = 1;
				}
			}
		}else{//债权插入时生成还款计划表
			$ts = strtotime($created_time);
			$curr_month = intval(date('n', $ts));//今月
			$curr_year = date('Y', $ts);//今年
			$curr_day = date('j', $ts);//今日
			$ts_first_date = strtotime($first_repayment_date);
			$first_year = date('Y', $ts_first_date);
			$first_month = date('n', $ts_first_date);
			$repaid_period = ($curr_year - $first_year) * 12 + $curr_month - $first_month;
			if($last_peroid_id < $total_period - $repaid_period){
				//当剩余期数小于当前月时
				$curr_month = $curr_month + $total_period - $repaid_period - $last_peroid_id;
				if($curr_month>12){
					$curr_year = $curr_year + intval($curr_month/12);
					$curr_month = $curr_month%12;
				}
			}

		}
		for($i=$last_peroid_id; $i>0; $i--){
			$date = $helper_interest::getRepaymentDate($repayment_day, $curr_month, $curr_year);
			$md_obligation->addObligationRepayPlan( $oid, $date, $i );
			$curr_month ++;
			if($curr_month>12){
				$curr_year ++;
				$curr_month = 1;
			}
		}
	}

	/**
	 *	是否返还交易手续费
	 */
	protected function isPaybackTradeFee( $data, $period_id ){
		$md_obligation = & load_model('obligation');
		if(empty($data)){
			return false;
		}
		//是否出售中，或者售完
		if($data['selling'] != UOB_SELLING_YES && $data['status'] != USROBL_STATUS_SOLD){
			return false;
		}
		//交易手续费返还时间限定。
		$ts = strtotime($data['created_time']);
		$start = strtotime('2016-07-01 00:00:00');
		$end = strtotime('2016-10-01 00:00:00');
		if($ts<$start || $ts>=$end){
			return false;
		}
		$uoid = $data['id'];
		if(!in_array($data['via'], array( TRADE_VIA_FAST_ENTRY, TRADE_VIA_DIRECT_BUY_OBLIGATION ))){
			return false;
		}
		$bonus_interest = $md_obligation->getNotPaidBonusInterestByUoid( $uoid, $period_id );
		if($bonus_interest>0){
			return $md_obligation->addTradeFeePaybackLog($uoid, $data['uid'], $data['oid'], $bonus_interest, $period_id);
		}
		return false;
	}

	/**
	 *	返还交易手续费
	 */
	protected function paybackTradeFee( &$statistics ){
		$start_ts = microtime(true);
		$md_obligation = & load_model('obligation');
		$md_msg = & load_model('msg');
		$i = 1000;
		$limit = 100;
		$total = 0;
		$success = 0;
		$failed = 0;
		do{
			$data = $md_obligation->getTradeFeePaybackNormal( $limit );
			if(empty($data)){
				break;
			}
			foreach ($data as $row) {
				$total ++;
				$bool = $md_obligation->paybackTradeFee($row['id'], $row['uid'], $row['fee'], $row['uoid']);
				if($bool){
					$success ++;
					$content = json_encode(array(
						'tpl' => MSGTPL_PAYBACK_TRADEFEE_OK,
						'param' => array(
							'id' => $row['uoid'],
							'amount' => floor($row['fee']/100)
							),
						));
					$md_msg->addMsg($row['uid'], $content);
				}else{
					$failed ++;
				}
			}
			if(count($data) < $limit){
				break;
			}
			sleep(1);
		}while ( $i--);

		$statistics = array(
			'cost_ts' => microtime( true ) - $start_ts,
			'total' => $total,
			'failed' => $failed,
			'success' => $success
		);
		return !$failed;
	}

	/**
	 *	汇总还本付息v2
	 */
	protected function computePrincipalWithInterestV2( &$statistics ){
		$md_obligation = & load_model('obligation');
		$helper_interest = load_helper('interest');
		$ts = strtotime('-23 hours');//计算前一天
		$curr_day = date('j', $ts);//今日
		$date = date('Y-m-d', $ts);
		$month_lastday = $helper_interest::getMonthDays(date('n', $ts), date('Y', $ts));//当月最后日
		$is_lastday = false;
		if($curr_day == $month_lastday){//若今日为当月最后日
			$is_lastday = true;
		}
		$start_ts = microtime(true);
		/**
		 *	如果债权到账日为X的，则计算当期总利息，并将当期本金与利息发给用户，更新债权信息。
		 *	当X>28时，判断当月最大日期以提前结算。
		 *
		 *	从obligation获取repayment_day＝curr_day(或$is_lastday and repayment_day>＝curr_day)的债权数组oblarr
		 *	对oblarr中的每一个债权obl进行分别操作：
		 *		从obligation_holding_list获取obl对应用户持有债权，计算出用户应还本金后将其录入obligation_repayment
		 *		从obligation_interest获取status=0且oid=obl.id的利息表
		 *		分类统计后将当期利息录入obligation_repayment, 将status(obligation_holding_list)置为1
		 *		根据holding_obl是否在售判断是否给bouns，若有，则录入obligation_repayment, 将status置为2，若无，则置为3.
		 *
		 *	处理偿还后债权信息
		 *		projcar
		 *			left_loan - 应还本金
		 *			left_period - 1
		 *			modified_time = NOW()
		 *		obligation
		 *			left_period - 1
		 *			modified_time = NOW()
		 */
		$count = $md_obligation->countRepaymentObligation( $curr_day, $is_lastday, true);
		$count_success = 0;
		$count_failed = 0;
		$pagesize = 10;
		$page = ceil($count/$pagesize);
		for($i=0;$i<$page;$i++){
			$oblarr = $md_obligation->getRepaymentObligationListByPage($curr_day, $is_lastday, $i, $pagesize);
			foreach ($oblarr as $obl) {
				// 2018-06-21
				// 由于下面的“updateObligationRepayPlanOblFinished”调用会更新left_period，所有查询的结果里面包含了=0的记录
				// 这里需要过滤掉；否则由于本次left_period更新为0，下一次按页查询会漏掉记录
				if ($obl['left_period']==0) {
					continue;
				}
				$oid = $obl['id'];
				// 从obligation_repay_dates中获取债权还款日期的记录，如果不存在，那么就创建
				// obligation_reapy_dates主要用于标记债权、合同等是否已经更新过，这里面的记录同loan_repayment里面有差异
				// 因为上债权的时间比那个还款生成的时间可能晚
				$retry = 1;
				do{
					$repaid_info = $md_obligation->getObligationRepayPlan($oid, $date);
					if(!empty($repaid_info)){
						break;
					}
					if( $this->isObligationRepayDatesExistsOrInserts($oid, $obl['created_time'], $obl['repayment_day'], $obl['left_period']) ){
						break;
					}
				}while($retry--);
				$period_id = null;
				if(!empty($repaid_info) && isset($repaid_info['period_id'])){
					$period_id = $repaid_info['period_id'];
					// 债权信息未更新，则进行债权信息更新。
					if($repaid_info['status'] == REPAY_DATES_STATUS_NORMAL){
						$rate = $md_obligation->getObligationSYSRate( $oid );
						$pjcar = $md_obligation->getProjcarDetail( $obl['extid'] );
						$in_total = intval( $helper_interest::principalAndInterestEqual($pjcar['left_loan'], $rate, $pjcar['left_period']) );
						$in_interest = intval($pjcar['left_loan'] * $rate/12);
						$in_principal = $in_total - $in_interest;
						$proj_principal = $in_principal;
						// 获取系统(uid=1)持有该债权的列表，实际数据只有一条
						$syshoblarr = $md_obligation->getObligationSYSHolding( $oid );
						if(!empty($syshoblarr)){
							foreach ($syshoblarr as $syshobl) {
								$sys_total = intval( $helper_interest::principalAndInterestEqual($syshobl['left_amount'], $syshobl['rate'], $syshobl['left_period']) );
								$sys_interest = intval($syshobl['left_amount'] * $syshobl['rate']/12);
								$sys_principal = $sys_total - $sys_interest;
								// 更新系统持有债权的剩余本金和期数，函数中期数会减去1
								$md_obligation->updateSYSObligationHoldingLeftAmount( $sys_principal, $syshobl['left_period'], $syshobl['id'] );
							}
						}
						// 更新obliation和projcar剩余本金和期数，函数中期数会减去1；更新obligation_repay_dates的状态为已经更新
						$md_obligation->updateObligationRepayPlanOblFinished( $oid, $obl['extid'], $date, $period_id, $in_principal, $proj_principal, $in_interest );
					}
				}
				if(empty($period_id)){
					continue;
				}
				// 从obligation_interest中，获取债权当期的应付总利息（每天的利息求和）列表
				// deep_night_computer中computeInterestV2函数中先计算了每个用户持有某个债权每天的利息，一天一条
				$interestarr = $md_obligation->getRepaymentInterestByOid( $oid, $period_id );
				foreach ($interestarr as $row) {
					//today_interest	name	period_id	uoid	uid
					$today_interest = $row['today_interest'];
					$name = $row['name'];
					$period_id = $row['period_id'];
					$uoid = $row['uoid'];
					$uid = $row['uid'];
					// obligation_reapyment 中用户持有债权的当期记录已经存在的话，继续
					if($md_obligation->isObligationRepaymentExists($uoid, $period_id)){
						continue;
					}
					// 从obligation_holding_list中获取持有债权记录信息，并计算
					$hobl = $md_obligation->getObligationHolding( $uoid );
					do{
						$interest = $today_interest;
						$principal = 0;
						$bonus_interest = 0;
						$auto_shift = 0;
						$via = $hobl['via'];
						$total_period = 0;
						$no_bonus = true;
						$shift_to = TRADE_AUTOSHIFT_NONE;
						if ($via == TRADE_VIA_ROOKIE) {
							break;
						}
						$left_amount = $hobl['left_amount'];
						$rate = $hobl['rate'];
						$total_period = $hobl['total_period'];
						$left_period = $hobl['left_period'];
						$each_month = $helper_interest::principalAndInterestEqual($left_amount, $rate, $left_period);
						$def_interest = $left_amount * $rate / 12;
						$principal = floor($each_month - $def_interest);
						if($hobl['selling']){
							break;
						}
						if($hobl['auto_shift']){
							$auto_shift = 1;
							$shift_to = $hobl['shift_to'];
						}
					}while (false);
					$skip_repayment = false;
					if($principal + $interest <= 0){
						$skip_repayment = true;
					}
					// 在表obligation_repayment中添加用户持有债权应该支付的相关信息
					$bool = $md_obligation->addObligationRepayment($uoid, $uid, $oid, $name, $principal, $interest, $bonus_interest, $period_id, $via, $auto_shift, $shift_to, $total_period, $no_bonus, $skip_repayment);
					if(!$bool){
						$count_failed++;
					}else{
						$count_success++;
					}
				}

			}
		}
		$statistics = array(
			'cost_ts' => microtime( true ) - $start_ts,
			'total' => $count_failed + $count_success,
			'failed' => $count_failed,
			'success' => $count_success
		);
		return !$count_failed;
	}

	/**
	 *	进行还本付息
	 */
	protected function repaymentPrincipalAndInterest( &$statistics ){
		$md_obligation = & load_model('obligation');
		$md_msg = & load_model('msg');
		$helper_interest = load_helper('interest');
		$ts = strtotime('-23 hours');//计算前一天
		$curr_day = date('j', $ts);//今日
		$date = date('Y-m-d', $ts);
		$month_lastday = $helper_interest::getMonthDays(date('n', $ts), date('Y', $ts));//当月最后日
		$is_lastday = false;
		if($curr_day == $month_lastday){//若今日为当月最后日
			$is_lastday = true;
		}
		$start_ts = microtime(true);
		/**
		 *	从obligation_repayment获取obl对应的偿还表
		 *		将所有本金和利息支付给用户（update user_accounts 中的 amount / total_amount / total_interest ）
		 *		obligation_holding_list
		 *			left_amount - 还给用户的本金
		 *			left_period - 1
		 *			generated_interest + 付给用户的利息
		 *			modified_time = NOW()
		 *		obligation_repayment
		 *			status = 1
		 *			finish_time = NOW()
		 *		根据hoid查询是否自动转投，如果非，则break
		 *		如果自动转投，则 autoshift_pool 内对应uid的amount增加相应本金与利息
		 *
		 */
		$count = $md_obligation->countObligationRepaymentNormal();
		$count_success = 0;
		$count_failed = 0;
		$pagesize = 10;
		$page = ceil($count/$pagesize);
		for($i=0;$i<$page;$i++){
			$rparr = $md_obligation->getObligationRepaymentNormalListByPage($pagesize);
			foreach ($rparr as $rp) {
				$uid = $rp['uid'];
				$rpid = $rp['id'];
				$interest_amount = intval($rp['interest']) + intval($rp['bonus_interest']);
				$sum_amount = $rp['principal'] + $interest_amount;
				$bool = $md_obligation->repaymentToUser( $rpid, $rp['period_id'], $sum_amount, $rp['principal'], $rp['uoid'], $interest_amount, $uid );
				if ($bool) {
					$count_success ++;
					if($rp['auto_shift']){
						$md_obligation->addAutoShiftPool($uid, $sum_amount, $rp['shift_to']);
					}

					$content = json_encode(array(
						'tpl' => MSGTPL_REPAYMENT_OK,
						'param' => array(
							'id' => $rp['uoid'],
							'amount' => floor($sum_amount/100),
							'interest' => floor($interest_amount/100),
							),
						));
					$md_msg->addMsg($uid, $content);
				}else{
					$count_failed ++;
				}
			}
		}
		$md_obligation->updateObligationWhichIsClosed();
		$statistics = array(
			'cost_ts' => microtime( true ) - $start_ts,
			'total' => $count,
			'success' => $count_success,
			'failed' => $count_failed
		);
		return !$count_failed;
	}

	/**
	 *	返还新人专享本金
	 */
	protected function returnRookiePrincipal( &$statistics ){
		$start_ts = microtime(true);

		$md_obligation = & load_model('obligation');
		$md_accounts = & load_model('accounts');
		$md_rate = & load_model('rate');
		$md_msg = & load_model('msg');

		$closed_period = $md_rate->getClosedPeriodOfRookie();
		$date = date('Y-m-d', time()- 86400*($closed_period - 1));
		$rookie_arr = $md_obligation->getExpireRookieObligations( $date );
		$count = count($rookie_arr);
		$count_success = 0;
		if(!empty($rookie_arr)){
			foreach ($rookie_arr as $row) {
				$uid = $row['uid'];
				$oid = $row['oid'];
				$amount = $row['left_amount'];
				$uoid = $row['id'];
				$bool = $md_obligation->returnRookieObligation($uid, $uoid, $oid, $amount);
				if($bool){
					$count_success ++;

					$content = json_encode(array(
						'tpl' => MSGTPL_ROOKPRIN_OK,
						'param' => array(
							'id' => $uoid,
							'amount' => floor($amount/100)
							),
						));
					$md_msg->addMsg($uid, $content);
				}
			}
		}
		$statistics = array(
			'cost_ts' => microtime( true ) - $start_ts,
			'total' => $count,
			'success' => $count_success
		);
		// print_r($statistics);
		return true;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 这个是老的计算邀请者收入的函数，已经废弃，参考函数 computeInviterIncome2
	 * @deprecated
	 */
	protected function computeInviterIncome( &$statistics_inviter ){
		$start_ts = microtime(true);
		$md_accounts = & load_model('accounts');
		$md_user = & load_model('user');
		$md_obligation = & load_model('obligation');
		$total = $md_user->countUsersRelInPaperInterest();
		$pgsize = 100;
		$pages = ceil($total/$pgsize);
		$early = time() - 100*86400;//100天内的进行状态更新，到100天的进行最终计算并支付金额
		$update_count = 0;
		$success_count = 0;
		for($i=0;$i<$pages;$i++){
			$data = $md_user->getUsersRelInPaperInterest($i, $pgsize);
			$update_rows = array();
			foreach ($data as $row) {
				$uid = $row['invitee'];
				$status = $row['invite_interest_status'];
				$ts = strtotime( $row['created_time'] );
				if($ts < $early){
					if($status == INVITE_STATUS_PENDING){
						continue;//状态已是待付息，不处理，直接跳过
					}
					$status = INVITE_STATUS_PENDING;
				}
				$all_interest = $md_obligation->getUserRepaymentAllInterest($uid);
				$interest = abs(intval($all_interest * 0.1));
				$holding_exsits = $md_obligation->isUserObligationHolding($uid);
				if($status == INVITE_STATUS_NORMAL && $holding_exsits){
					$status = INVITE_STATUS_INVESTED;
				}
				if($status >= 0 && $interest>0){
					$status = INVITE_STATUS_GENERATED;
				}
				$update_rows[] = array(
					'status' => $status,
					'interest' => $interest,
					'id' => $row['id']
				);
			}
			$failed_idarr = array();
			$update_count += count($update_rows);
			$bool = $md_user->updateUsersRelInPaperInterest($update_rows, $failed_idarr);
			if(!$bool){
				$this->logResult(__FUNCTION__, 'Failed: ' . implode(',', $failed_idarr));
			}
			$success_count += ($update_count - count($failed_idarr));
		}
		unset($update_rows);
		unset($data);

		$statistics_inviter = array(
			'cost_ts' => microtime( true ) - $start_ts,
			'total' => $total,
			'update_count' => $update_count,
			'success_count' => $success_count,
		);
		return true;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 这个是老的邀请的支付邀请者的函数，已经废弃，参考函数payInviterIncome2
	 * @deprecated
	 */
	public function payInviterIncome(){
		$md_accounts = & load_model('accounts');
		$md_user = & load_model('user');
		$md_msg = & load_model('msg');
		$total = $md_user->countUsersRelPendingInterest();
		$pgsize = 100;
		$pages = ceil($total/$pgsize);
		$early = time() - 100*86400;//100天内的进行状态更新，到100天的进行最终计算并支付金额
		$failed = array();

		$success_count = 0;
		for($i=0;$i<$pages;$i++){
			$data = $md_user->getUsersRelPendingInterest($i, $pgsize);
			foreach ($data as $row) {
				$ts = strtotime( $row['created_time'] );
				if($row['invite_interest_status'] != INVITE_STATUS_PENDING){
					continue;//状态非待付息，不处理，直接跳过
				}
				$bool = $md_accounts->payUsersRelInterest( $row['id'], $row['inviter'], $row['invite_interest'] );
				if($bool){
					$success_count ++;
					if( $row['invite_interest'] > 0 ){

						$uinfo = $md_user->getUserById($row['invitee']);
						$phone_txt = '';
						if(!empty($uinfo) && isset($uinfo['mobile'])){
							$mobile = $uinfo['mobile'];
							$len = strlen($mobile);
							$phone_txt = substr($mobile, 0, 3) . str_pad('', $len - 7, '*') . substr($mobile, -4);
						}
						$content = json_encode(array(
							'tpl' => MSGTPL_PAYINVITER_OK,
							'param' => array(
								'phone' => $phone_txt,
								'amount' => floor($row['invite_interest']/100)
								),
							));
						$md_msg->addMsg($row['inviter'], $content);
					}
				}else{
					$failed[] = $row['id'];
				}
			}
		}
		unset($data);
		$this->logResult(__FUNCTION__, array(
			'total' => $total,
			'success_count' => $success_count,
			'failed' => implode(',', $failed)
		));
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 计算邀请者的奖励
	 * 根据被邀请者产生的利息收益，按一定的比例进行奖励
	 * 统计被邀请者的利益收益的时候，本次奖励的利息收益=当前计算时间点的所有利息收益-上次计算时间点的所有利息收益
	 */
	protected function computeInviterIncome2( &$statistics){
		$start_ts = microtime(true);
		// 通用邀请的规则：被邀请人100天内利息收益的10%给到一级邀请者，二级邀请者没有奖励
		$invite_normal_event = array(
			'title' => 'normal invite',
			'start_time' => '',
			'end_time' => '',
			'interest_days' => 100,
			'early'=> time() - 100*86400,
			'invite_ratio' => 0.1,
			'l2_invite_ratio' => 0.0,
		);
		$invite_special_events = array (
			// 新邀请的规则：从2017-12-09日开始，一年内被邀请注册的人，这个人一年内（365天）的利息的15%作为奖励给到一级邀请者，5%给到二级邀请者
			array(
				'title' => '2017 new invite',
				'start_time' => EVENT_NEW_INVITE_START_TIME,
				'ts_start' => strtotime(EVENT_NEW_INVITE_START_TIME),
				'end_time' => EVENT_NEW_INVITE_END_TIME,
				'ts_end' => strtotime(EVENT_NEW_INVITE_END_TIME),
				'interest_days' => 365,
				'early'=> time() - 365*86400,
				'invite_ratio' => 0.15,
				'l2_invite_ratio' => 0.05,
			),

		);
		$md_accounts = & load_model('accounts');
		$md_user = & load_model('user');
		$md_obligation = & load_model('obligation');
		$total = $md_user->countUsersRelInPaperInterest();
		$pgsize = 100;
		$pages = ceil($total/$pgsize);
		$insert_succeeded_count = $insert_failed_count = 0;
		$f_insert_succeeded_count = $f_insert_failed_count = 0;
		for($i=0;$i<$pages;$i++){
			$data = $md_user->getUsersRelInPaperInterest($i, $pgsize);
			$failed_insert = array();
			foreach ($data as $row) {
				// 根据被邀请者的创建时间，判断记录属于哪一个邀请活动范围
				$invite_event = $invite_normal_event;
				$ts_invitee_created = strtotime( $row['created_time'] );
				foreach($invite_special_events as $special_event) {
					if ($ts_invitee_created>=$special_event['ts_start'] && $ts_invitee_created<=$special_event['ts_end']) {
						$invite_event = $special_event;
						break;
					}
				}

				$invitee = $row['invitee'];
				// 获取被邀请者当前已支付的利息
				$invitee_total_paid_interest = $md_obligation->getUserRepaymentAllInterest($invitee);
				// 获取被邀请者当前未支付的利息
				$pending_interest_pair = $md_obligation->getUserPendingInterestAmount($invitee);
				$invitee_total_unpaid_interest = $pending_interest_pair['max'];
				// 判断被邀请者从创建到现在是否超过了邀请活动的奖励天数
				// now()-$ts_invitee_created <= 365*86400
				// $ts_invitee_created >= now()-365*86400(early)
				if ($ts_invitee_created >= $invite_event['early']) {
					// 本次计算要支付奖励的利息
					$invitee_this_paid_interest = abs($invitee_total_paid_interest-$row['invitee_paid_interest']);
					// 2017-12-13
					// 老版本升级已经完成，用户的支付和未支付都没有变化，不需要再去更新相关记录
					if ($invitee_this_paid_interest==0 && $invitee_total_unpaid_interest==$row['invitee_unpaid_interest']) {
						continue;
					}
					// 按照邀请活动奖励利率计算邀请者的奖励
					$inviter = $row['inviter'];
					$inviter_day_bonus = abs(intval($invitee_this_paid_interest * $invite_event['invite_ratio']));
					$inviter_unpaid_bonus = abs(intval($invitee_total_unpaid_interest * $invite_event['invite_ratio']));
					// 按照邀请活动奖励利率计算二级邀请者的奖励
					$l2_inviter = $row['l2_inviter'];
					$l2_inviter_day_bonus = $l2_inviter_unpaid_bonus = 0;
					// 只有在二级邀请者不为空的时候，才去计算他们的收益
					if (!empty($l2_inviter)) {
						$l2_inviter_day_bonus = abs(intval($invitee_this_paid_interest * $invite_event['l2_invite_ratio']));
						$l2_inviter_unpaid_bonus = abs(intval($invitee_total_unpaid_interest * $invite_event['l2_invite_ratio']));
					}
					$insert_row = array(
						'invitee' => $invitee,
						'invitee_interest' => $invitee_this_paid_interest,
						'invitee_unpaid_interest' => $invitee_total_unpaid_interest,
						'inviter' => $inviter,
						'inviter_bonus' => $inviter_day_bonus,
						'inviter_unpaid_bonus' => $inviter_unpaid_bonus,
						'l2_inviter' => $l2_inviter,
						'l2_inviter_bonus' => $l2_inviter_day_bonus,
						'l2_inviter_unpaid_bonus' => $l2_inviter_unpaid_bonus,
					);
					$bool = $md_user->addInviterBonusRepayment($insert_row,0);
					if (!$bool) {
						$this->logResult(__FUNCTION__, 'addInviterBonusRepayment failed, id='.$row['id']);
						$insert_failed_count ++;
					} else {
						$insert_succeeded_count ++;
					}
				} else {
					// 邀请奖励到期了，把被邀请者未支付的利息全部奖励给邀请者，未支付全部清0,因为不再计算了
					// 本次计算要支付奖励的利息
					$invitee_this_paid_interest = abs($invitee_total_paid_interest-$row['invitee_paid_interest'])+
							$invitee_total_unpaid_interest;
					// 按照邀请活动奖励利率计算邀请者的奖励
					$inviter = $row['inviter'];
					$inviter_day_bonus = abs(intval($invitee_this_paid_interest * $invite_event['invite_ratio']));
					// 按照邀请活动奖励利率计算二级邀请者的奖励
					$l2_inviter = $row['l2_inviter'];
					$l2_inviter_day_bonus = abs(intval($invitee_this_paid_interest * $invite_event['l2_invite_ratio']));

					$insert_row = array(
						'invitee' => $invitee,
						'invitee_interest' => $invitee_this_paid_interest,
						'invitee_unpaid_interest' => 0,
						'inviter' => $inviter,
						'inviter_bonus' => $inviter_day_bonus,
						'inviter_unpaid_bonus' => 0,
						'l2_inviter' => $l2_inviter,
						'l2_inviter_bonus' => $l2_inviter_day_bonus,
						'l2_inviter_unpaid_bonus' => 0,
					);
					// 同时邀请奖励支付状态更新为结束
					$bool = $md_user->addInviterBonusRepayment($insert_row,2);
					if (!$bool) {
						$this->logResult(__FUNCTION__, 'addInviterBonusRepayment with finish failed, id='.$row['id']);
						$f_insert_failed_count ++;
					} else {
						$f_insert_succeeded_count ++;
					}
				}
			}
			unset($data);
		}
		$statistics = array(
			'total' => $total,
			'insert_failed_count' => $insert_failed_count,
			'insert_succeeded_count' => $insert_succeeded_count,
			'f_insert_failed_count' => $f_insert_failed_count,
			'f_insert_succeeded_count' => $f_insert_succeeded_count,
			'cost_ts' => microtime( true ) - $start_ts,
		);
		return true;
	}
	/**
	 * 2017-11-15 新邀请 DONE
	 * 支付邀请者奖励
	 * 由于计算方式是按两次差值计算的本次支付奖励，原则上一天一次
	 *
	 */
	public function payInviterIncome2(&$statistics){
		$start_ts = microtime(true);
		$md_accounts = & load_model('accounts');
		$md_user = & load_model('user');
		$md_msg = & load_model('msg');
		$total = $md_user->countInviterPendingBonus();
		$pgsize = 100;
		$success_count = 0;
		$failed_count = 0;
		$total_count = 0;
		while ($total_count<$total) {
			$data = $md_user->getInviterPendingBonus(0, $pgsize);
			if (empty($data)) {
				break;
			}
			$failed = array();
			foreach ($data as $row) {
				$total_count ++;
				$bool = $md_accounts->payInviterBonus( $row['id'], $row['invitee'], $row['invitee_interest'],
						$row['inviter'], $row['inviter_bonus'], $row['l2_inviter'], $row['l2_inviter_bonus']);
				if($bool){
					$success_count ++;
					$invitee_mobile = '';
					// 给邀请者发送邀请奖励信息
					$amount = floor($row['inviter_bonus']/100);
					if( $amount > 0 ){
						$invitee_info = $md_user->getUserById($row['invitee']);
						$phone_txt = '';
						if(!empty($invitee_info) && isset($invitee_info['mobile'])){
							$invitee_mobile = $invitee_info['mobile'];
							$len = strlen($invitee_mobile);
							// 一级邀请手机号码只显示前面3位和后四位
							$phone_txt = substr($invitee_mobile, 0, 3) . str_pad('', $len - 7, '*') . substr($invitee_mobile, -4);
						}
						$content = json_encode(array(
							'tpl' => MSGTPL_PAYINVITER_OK,
							'param' => array(
								'phone' => $phone_txt,
								'amount' => $amount
								),
							));
						$md_msg->addMsg($row['inviter'], $content);
					}
					// 给二级邀请者发送邀请奖励信息
					$amount = floor($row['l2_inviter_bonus']/100);
					if ( $amount >0 ) {
						$l2_phone_txt = '';
						if (empty($invitee_mobile)) {
							$invitee_info = $md_user->getUserById($row['invitee']);
							if(!empty($invitee_info) && isset($invitee_info['mobile'])){
								$invitee_mobile = $invitee_info['mobile'];
							}
						}
						// 二级邀请手机号码只显示前面3位
						$l2_phone_txt = substr($invitee_mobile, 0, 3) . str_pad('', $len - 3, '*');
						$content = json_encode(array(
							'tpl' => MSGTPL_PAYINVITER_OK,
							'param' => array(
								'phone' => $l2_phone_txt,
								'amount' => $amount
								),
							));
						$md_msg->addMsg($row['l2_inviter'], $content);
					}
				}else{
					$failed_count++;
					$failed[] = $row['id'];
				}
			}
			if (count($failed)>0) {
				$this->logResult(__FUNCTION__, array(
					'failed' => implode(',', $failed),
				));
				$md_accounts->setPayInviterBonusFailed($failed);
			}
			unset($data);
		}
		$statistics = array(
			'total' => $total,
			'total_count' => $total_count,
			'success_count' => $success_count,
			'failed_count' => $failed_count,
			'cost_ts' => microtime( true ) - $start_ts,
		);
		return $failed_count>0?false:true;
	}

	/**
	 *	处理自动转投
	 */
	protected function processAutoShift( &$statistics ){
		/**
		 *	从 autoshift_pool 获取自动转投信息，加入自动处理队列。TRADE_AUTOSHIFT_AMOUNT_LIMIT_MIN
		 *
		 */
		$md_obligation = & load_model('obligation');
		$md_rate = & load_model('rate');

		$count = $md_obligation->getAutoShiftCount();
		$pagesize = 100;
		$page = ceil($count/$pagesize);

		$eg_rate = $md_rate->getRateOfEagleeyed();
		$eg_via = TRADE_VIA_EAGLEEYED;
		$eg_closed_period = $md_rate->getClosedPeriodOfEagleeyed();

		$fe_rate = $md_rate->getRateOfFastEntry();
		$fe_via = TRADE_VIA_FAST_ENTRY;
		$fe_closed_period = $md_rate->getClosedPeriodOfFastEntry();

		for($i=0; $i<$page; $i++){
			$pool_arr = $md_obligation->getAutoShiftList($pagesize);
			foreach ($pool_arr as $row) {
				$uid = $row['uid'];
				$amount = $row['amount'];
				$shift_to = $row['shift_to'];

				switch ($shift_to) {
					case TRADE_AUTOSHIFT_EAGLEEYED:
						$rate = $eg_rate;
						$via = $eg_via;
						$closed_period = $eg_closed_period;
						break;
					case TRADE_AUTOSHIFT_FAST_ENTRY:
					default:
						$rate = $fe_rate;
						$via = $fe_via;
						$closed_period = $fe_closed_period;

				}
				$process_id = $md_obligation->addAutoProcessQueue($uid, $amount, $rate, $closed_period, $via, 1, $shift_to);
				if($process_id){
					$md_obligation->resetAutoShiftPool($uid, $shift_to);
				}
			}
		}
	}


	protected function bindProjcarToObligation($extid, $rate_sell, $all_period_rate, $closed_period = 30){
		$md_obligation = & load_model('obligation');
		$info = $md_obligation->getProjcarDetail($extid);
		$total_amount = $info['total_loan'];
		$total_period = $info['total_period'];
		$repayment_day = $info['repayment_day'];
		$make = $info['make'];
		$model = $info['model'];
		$rate = $info['rate'];
		$first_repayment_date = $info['first_repayment_date'];
		$helper_interest = load_helper('interest');
		$left = $helper_interest::getLeftAmountAndPeriod($total_amount, $rate, $total_period, $first_repayment_date);
		if(empty($left)){
			return "compute left amount and period failed,$total_period,$first_repayment_date";
		}
		$left_amount = intval($left['left_amount']);
		$left_period = intval($left['left_period']);

		if($left_amount != $info['left_loan'] || $left_period != $info['left_period']){//当projcar内数据与计算数据不一致时，更新projcar数据
			$md_obligation->updateProjcarLeft($extid, $left_amount, $left_period);
		}
		if($all_period_rate < $rate_sell || $all_period_rate > 0.2){//当买断利率小于销售利率、或当买断利率>20%，则设为销售利率
			$all_period_rate = $rate_sell;
		}
		// TODO, 检查extid是否已经存在于obligation中，否则有漏洞
		$oid = $md_obligation->bindProjcarObligation($extid, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $rate, $rate_sell, $all_period_rate, $closed_period);
		if(!$oid){
			return 'bind failed';
		}
		$this->isObligationRepayDatesExistsOrInserts($oid, date('Y-m-d H:i:s'), $repayment_day, $left_period, $total_period, $first_repayment_date);
		return true;
	}

	public function __construct(){

		if(!defined('IN_TASK') || !IN_TASK){
			exit('Not allowed');
		}
		get_config();
	}

	/**
	 * 对于中转账户持有的小金额的单笔债权，更新为不再进行售卖，放入深夜计算最后
	 */
	protected function cancelSysBuyerSmallSelling() {
		$md_obligation = & load_model('obligation');
		return $md_obligation->cancelSysBuyerSmallSelling();
	}

	/**
	 *	深夜计算
	 *	利息计算
	 *	付本还息
	 */
	public function deep_night_computer(){
		// $is_exists = $this->checkIfRunnerExists( __METHOD__ );
		// if($is_exists){
		// 	return;
		// }
		$start_ts = microtime(true);

		$bool_cint = $this->computeInterestV2( $statistics_cmp_int );
		$bool_cpi = $this->computePrincipalWithInterestV2( $statistics_cmp_pi );
		$bool_rp = $this->repaymentPrincipalAndInterest( $statistics_rp );
		$bool_rrp = $this->returnRookiePrincipal( $statistics_rookie );
		$bool_as = $this->processAutoShift( $statistics_auto );
		$bool_ptf = $this->paybackTradeFee( $statistics_payback );
		// 2017-11-15 新邀请 DONE
		$bool_cii = $bool_pii = false;
		$statistics_inviter = $statistics_pay_inviter = array();
		$bool_cii = $this->computeInviterIncome2( $statistics_inviter );
		$bool_pii = $this->payInviterIncome2( $statistics_pay_inviter );
		$bool_cancel = $this->cancelSysBuyerSmallSelling();

		$res = array(
			'interest' => array(
				'success' => $bool_cint,
				'statistics' => $statistics_cmp_int
				),
			'principal' => array(
				'success' => $bool_cpi,
				'statistics' => $statistics_cmp_pi
				),
			'repayment' => array(
				'success' => $bool_rp,
				'statistics' => $statistics_rp
				),
			'rookie' => array(
				'success' => $bool_rrp,
				'statistics' => $statistics_rookie
				),
			'computeInviterIncome2' => array(
				'success' => $bool_cii,
				'statistics' => $statistics_inviter
				),
			'payInviterIncome2' => array(
				'success' => $bool_pii,
				'statistics' => $statistics_pay_inviter
				),
			'payback' => array(
				'success' => $bool_ptf,
				'statistics' => $statistics_payback
				),
			'bool_cancel' => array(
				'success' => $bool_cancel,
				),
			'cost' => microtime(true) - $start_ts
			);
		$this->logResult(__FUNCTION__, $res);
		// $this->runnerClean( __METHOD__ );
	}

	protected function updateProjcarLeft( $pid ){
		$md_loan = & load_model('loan');
		$pinfo = $md_loan->getProjcarDetail($pid);
		if(!empty($pinfo)){
			$helper_interest = load_helper('interest');
			$md_obligation = & load_model('obligation');
			$left = $helper_interest::getLeftAmountAndPeriod($pinfo['total_loan'], $pinfo['rate'], $pinfo['total_period'], $pinfo['first_repayment_date']);
			$left_amount = intval($left['left_amount']);
			$left_period = intval($left['left_period']);
			$md_obligation->updateProjcarLeft($pid, $left_amount, $left_period);
		}
	}
	/**
	 *	使用专有账户购买用户债权
	 *	使用方式： 29,59 7-22 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task auto_buyer
	 */
	public function auto_buyer(){
		$start_ts = microtime(true);
		$buyer = 100006;
		$md_obligation = & load_model('obligation');
		$md_accounts = & load_model('accounts');
		$md_email_notify = & load_model('email_notify');
		$obligations = $md_obligation->getSellingObligationHoldingExcept( $buyer );
		$count_bought = 0;
		if(!empty($obligations)){
			$accinfo = $md_accounts->getUserCurrentAccount(	$buyer );
			$accamt = $accinfo['amount'];
			$auto_shift = 0;
			$shift_to = TRADE_AUTOSHIFT_NONE;
			$via = TRADE_VIA_EAGLEEYED;
			$md_rate = & load_model('rate');
			$rate = $md_rate->getRateOfEagleeyed();
			$closed_period = 0;
			$count_amount = 0;
			foreach ($obligations as $row) {
				$oblid = $row['oid'];
				$hoid = $row['id'];
				$money = $row['left_amount'];
				//购买用户售出的债权
				$count_bought ++;
				$count_amount += $money;
				$md_obligation->buyObligationQueue($buyer, $oblid, $hoid, $money, $rate, $closed_period, $via, $auto_shift, $shift_to);
			}
			// 2018-04-27
			// 中转账户余额不足通知
			if ($count_amount>$accamt) {
				$content = json_encode(array(
					'tpl' => MSGTPL_BUYER_NO_ENOUGH_MONEY,
					'param' => array(
						'datetime' => date('Y-m-d H:i:s'),
						'o_count' => $count_bought,
						'o_amount' => floor($count_amount/100),
						'amount' => floor($accamt/100),
					),
				));
				$md_email_notify->addNotify(MSGTPL_BUYER_NO_ENOUGH_MONEY,$content);
			}
		}

		$count_selling = 0;
		//将已购入的债权自动售出
		$curr_hour = date('G');
		if($curr_hour < TRANSACTION_OPEN_HOUR || $curr_hour >= TRANSACTION_CLOSE_HOUR){
			return false;
		}
		$total = $md_obligation->countHoldingObligationByUid( $buyer );
		$pagesize = 20;
		$pages = ceil($total/$pagesize);
		for($page = 0; $page < $pages; $page ++ ){
			$data = $md_obligation->getHoldingObligationByUid( $buyer, $page, $pagesize );
			foreach ($data as $hobl) {
				if($hobl['selling'] == UOB_SELLING_YES){
					continue;
				}
				if($hobl['via'] == TRADE_VIA_ROOKIE){
					continue;
				}
				$closed_period = intval($hobl['closed_period']);
				if($closed_period != 0){
					$ct = strtotime($hobl['created_time']);
					$now = time();
					$days = floor(($now - $ct)/86400);
					if($days < $closed_period){
						continue;
					}
				}
				$count_selling ++;
				$md_obligation->sellObligation( $buyer, $hobl['id'], $hobl['oid'], $hobl['left_amount'] );
			}
		}

		$res = array(
			'count_bought' => $count_bought,
			'count_selling' => $count_selling,
			'cost' => microtime(true) - $start_ts
			);
		$this->logResult(__FUNCTION__, $res);
	}

	/**
	 *	处理余额转投
	 *	使用方式： 25 8 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task amount_shift
	 */
	public function amount_shift(){
		$start_ts = microtime(true);
		$md_obligation = & load_model('obligation');
		$md_accounts = & load_model('accounts');
		$md_rate = & load_model('rate');
		$md_user = & load_model('user');
		$md_loan = & load_model('loan');

		$rate = $md_rate->getRateOfFastEntry();
		$via = TRADE_VIA_AMOUNT_SHIFT;
		$closed_period = $md_rate->getClosedPeriodOfFastEntry();

		$count = $md_accounts->getAmountShiftCount();
		// var_dump($count);
		$pagesize = 100;
		$page = ceil($count/$pagesize);
		$min_uid = 0;
		$obligate_date = date('Y-m-d', strtotime('+31 days'));
		$counter = 0;
		for($i=0; $i<$page; $i++){
			$pool_arr = $md_accounts->getAmountShiftList($pagesize, $min_uid);
			foreach ($pool_arr as $row) {
				$uid = $row['uid'];
				$amount = $row['amount'];
				$uinfo = $md_user->getUserById( $uid );
				if(empty($uinfo)){//获取用户信息，如果信息为空，则跳过
					continue;
				}
				if($uinfo['have_loan']){
					//获取用户31天内应还贷款金额
					$obligate_amt = $md_loan->getObligateAmount($uid, $obligate_date);
					// var_dump($obligate_amt);
					if(null === $obligate_amt){//如果为null则表示数据获取失败，跳过
						continue;
					}
					$amount -= $obligate_amt;//获取用户预留31天内还款金额后，可投资金额。
				}
				if( $amount < TRADE_FAST_ENTRY_AMOUNT_LIMIT_MIN || $amount < $row['shift_amount_min'] ){
					//如果用户可投资金额小于系统限值或小于用户自设限值，则跳过
					continue;
				}

				$auto_shift = 0;
				$shift_to = TRADE_AUTOSHIFT_NONE;
				$process_id = $md_obligation->addAutoProcessQueue($uid, $amount, $rate, $closed_period, $via, $auto_shift, $shift_to);
				if($process_id){
					$counter ++;
				}
				$min_uid = $uid;
			}
		}
		$res = array(
			'count_all' => $count,
			'count_inqueue' => $counter,
			'cost' => microtime(true) - $start_ts
			);
		$this->logResult(__FUNCTION__, $res);
	}

	/**
	 *	自动还款扣款程序
	 *	使用方式： 25,55 10-23 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task auto_return_loan
	 */
	public function auto_return_loan(){
		$start_ts = microtime(true);
		$date = date('Y-m-d');
		$md_loan = & load_model('loan');
		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');
		$list = $md_loan->getLoanRepaymentListByDate($date, false, true);
		$count_success = 0;
		$count_total = 0;
		if(!empty($list)){
			foreach ($list as $row) {
				if($row['status'] == LOAN_REPAYMENT_STATUS_RETURNED || $row['status'] == LOAN_REPAYMENT_STATUS_PAYEARLY){
					continue;
				}
				$count_total ++;
				$left_principal = $row['principal'] - $row['paid_principal'];
				$left_interest = $row['interest'] - $row['paid_interest'];
				$left_overdue_fee = $row['overdue_fee'] - $row['paid_overdue_fee'];
				$amount = $left_principal + $left_interest + $left_overdue_fee;
				$id = $row['id'];
				$pid = $row['pid'];
				$uid = $row['uid'];
				$period_id = $row['period_id'];
				$accinfo = $md_accounts->getUserCurrentAccount(	$uid );
				$accamt = floor($accinfo['amount']/100)*100;
				if($accamt >= $amount){
					if($period_id > 1){
						$next_date = $md_loan->getLoanDateByPidAndPeriod($pid, $period_id - 1);
						$status = LOAN_INFO_STATUS_NORMAL;
					}else{
						$next_date = null;
						$status = LOAN_INFO_STATUS_RETURNED;
					}
					$bool = $md_loan->loanRepayment( $id, $pid, $uid, $amount, $left_principal, $left_interest, $left_overdue_fee, $period_id, $next_date );
					if($bool){
						$md_loan->updateLoanInfoReturned($pid, $left_principal, $left_interest, $left_overdue_fee, $status);
						$count_success ++;
						$msg_tpl = 	MSGTPL_LOAN_REPAYMENT_OK;
						$overdue_fee = floor($left_overdue_fee/10000);
						if ($overdue_fee>0) {
							$msg_tpl = 	MSGTPL_LOAN_REPAYMENT_OK2;
						}
						$content = json_encode(array(
							'tpl' => $msg_tpl,
							'param' => array(
								'id' => $id,
								'pid' => $pid,
								'amount' => floor($amount/100),
								'fee' => $overdue_fee
								),
							));
						$md_msg->addMsg($uid, $content);
						$this->updateProjcarLeft( $pid );
					}

				}elseif($accamt >= 100){
					$paid_principal = 0;
					$paid_interest = 0;
					$paid_overdue_fee = 0;
					//当余额不足时，先行偿付罚金，然后是利息，最后是本金
					if($accamt < $left_overdue_fee){//只够还部分罚金
						$paid_overdue_fee = $accamt;
					}elseif ($accamt < ($left_overdue_fee + $left_interest)) {//只够还全部罚金和部分利息
						$paid_overdue_fee = $left_overdue_fee;
						$paid_interest = $accamt - $left_overdue_fee;
					}else{//只够还全部罚金、利息和部分本金
						$paid_overdue_fee = $left_overdue_fee;
						$paid_interest = $left_interest;
						$paid_principal = $accamt - $left_overdue_fee - $left_interest;
					}
					$amount = $paid_principal + $paid_interest + $paid_overdue_fee;
					$bool = $md_loan->repaymentPiece( $id, $pid, $uid, $amount, $paid_principal, $paid_interest, $paid_overdue_fee );

					if($bool){
						$msg_tpl = 	MSGTPL_LOAN_REPAYMENT_OK;
						$overdue_fee = floor($paid_overdue_fee/10000);
						if ($overdue_fee>0) {
							$msg_tpl = 	MSGTPL_LOAN_REPAYMENT_OK2;
						}
						$content = json_encode(array(
							'tpl' => $msg_tpl,
							'param' => array(
								'id' => $id,
								'pid' => $pid,
								'amount' => floor($amount/100),
								'fee' => $overdue_fee,
								),
							));
						$md_msg->addMsg($uid, $content);
					}
				}
			}
		}
		$res = array(
			'count_total' => $count_total,
			'count_success' => $count_success,
			'cost' => microtime(true) - $start_ts
			);
		$this->logResult(__FUNCTION__, $res);
	}

	/**
	 *	自动还款逾期处理程序
	 *	使用方式： 30 0 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task overdue_loan_process
	 */
	public function overdue_loan_process(){
		$start_ts = microtime(true);
		$date = date('Y-m-d');
		$md_loan = & load_model('loan');
		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');
		$list = $md_loan->getLoanRepaymentListByDate($date, true, true);
		$count_success = 0;
		$count_total = 0;
		if(!empty($list)){
			foreach ($list as $row) {
				if($row['status'] == LOAN_REPAYMENT_STATUS_RETURNED || $row['status'] == LOAN_REPAYMENT_STATUS_PAYEARLY){
					continue;
				}
				$count_total ++;
				$left_principal = $row['principal'] - $row['paid_principal'];
				$left_interest = $row['interest'] - $row['paid_interest'];
				$left_overdue_fee = $row['overdue_fee'] - $row['paid_overdue_fee'];
				$amount =  $left_principal + $left_interest;
				$repayment_date = $row['repayment_date'];
				$overdue_days = ceil( (strtotime($date) - strtotime($repayment_date))/86400 );
				$day_overdue_fee = floor($amount * RATE_OF_OVERDUE / 100) * 100;//当前日罚金

				$id = $row['id'];
				$pid = $row['pid'];
				$uid = $row['uid'];
				$bool = $md_loan->updateLoanRepaymentOverdues($id, $overdue_days, $day_overdue_fee, $uid, $left_principal, $left_interest, $date);
				if($bool){
					$md_loan->updateLoanInfoOverdued($pid, $overdue_days);
					$count_success ++;

					$content = json_encode(array(
						'tpl' => MSGTPL_LOAN_REPAYMENT_TIME_OVERDUE,
						'param' => array(
							'id' => $id,
							'pid' => $pid,
							'amount' => floor(($amount + $left_overdue_fee + $day_overdue_fee)/100)
							),
						));
					$md_msg->addMsg($uid, $content);
				}
			}
		}
		$res = array(
			'count_total' => $count_total,
			'count_success' => $count_success,
			'cost' => microtime(true) - $start_ts
			);
		$this->logResult(__FUNCTION__, $res);
	}

	/**
	 *	自动还款3日内处理程序
	 *	使用方式： 1 11 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task recent_loan_process
	 */
	public function recent_loan_process(){
		$start_ts = microtime(true);
		$date = date('Y-m-d');
		$md_loan = & load_model('loan');
		$md_msg = & load_model('msg');
		$list = $md_loan->getLoanRecentListByDate($date, 3, false);
		$count_success = 0;
		$count_total = 0;
		if(!empty($list)){
			foreach ($list as $row) {
				$count_total ++;
				$amount =  $row['principal'] + $row['interest'];
				$repayment_date = $row['repayment_date'];
				$overdue_days = ceil( (strtotime($repayment_date) - strtotime($date))/86400 );

				$id = $row['id'];
				$pid = $row['pid'];
				$uid = $row['uid'];

				$content = json_encode(array(
					'tpl' => MSGTPL_LOAN_REPAYMENT_TIME_LESS_AMOUNT,
					'param' => array(
						'id' => $id,
						'pid' => $pid,
						'date' => $repayment_date,
						'amount' => floor($amount/100)
						),
					));
				$md_msg->addMsg($uid, $content);
			}
		}
		$res = array(
			'count_total' => $count_total,
			'cost' => microtime(true) - $start_ts
			);
		$this->logResult(__FUNCTION__, $res);
	}

	/**
	 *	自动上线程序
	 *	使用方式： * 6-23 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task online_obligations
	 */
	public function online_obligations(){
		$start_ts = microtime(true);
		$result = array(
			'total' => 0,
			'success' => 0,
			);
		$md_obligation = & load_model('obligation');
		$arr = $md_obligation->getObligationsReady();
		if(!empty($arr)){
			foreach ($arr as $row) {
				$extid = $row['id'];
				$result['total'] ++;
				if($extid){
					$bool = $this->bindProjcarToObligation( $extid, $row['rate'], $row['all_period_rate'], $row['closed_period'] );
					if(true === $bool){
						$result['success'] ++;
						$md_obligation->setObligationOnline( $extid );
					} else {
						// 2018/01/12 FIX BUG
						// 如果bindProjcarToObligation函数执行失败，那么需要标记obligation_plan记录为失败
						// 然后获取上线债权的时候不再获取这条记录；否则，系统任务每次执行都会失败，而自动上线债权的逻辑
						// 是如果有要上线的债权，那么就不再添加，这样由于这条失败的记录，导致永远也上不了债权
						$this->logResult(__FUNCTION__, "bind failed:{$extid},{$bool}");
						$md_obligation->setObligationOnlineFailed( $extid );
					}
				}
			}
			$result['cost'] = microtime(true) - $start_ts;
			$this->logResult(__FUNCTION__, $result);
		}
	}

	/**
	 *	自动上线程序
	 *	使用方式： * 7-23 * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task export_msg_to_push
	 */
	public function export_msg_to_push(){

		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		$init_ts = microtime(true);
		if(false === $is_exists){
			$loop = 10;
		}
		$limit = 100;
		$last_id = null;
		$md_msg = & load_model('msg');
		$md_user = & load_model('user');
		$last_row = $md_msg->getPushLastRow();
		$count_total = 0;
		if(!empty($last_row)){
			$last_id = $last_row['mid'];
		}
		do{
			$start_ts = microtime(true);
			$data = $md_msg->getMsgBatch($limit, $last_id);
			if(!empty($data)){
				// 2017-11-23 BUG FIX
				// 原来getMsgBatch获取的数据是倒序排，现在修改为正序排
				$max_id_row = end($data);
				$last_id = $max_id_row['id'];
				foreach ($data as &$row) {
					$str = $row['content'];
					$firstchar = $str[0];
					$endchar = $str[strlen($str) - 1];
					if(( $firstchar == '{' && $endchar == '}' ) || ( $firstchar == '[' && $endchar == ']' )){
						$d = json_decode($str, true);
						$tpl = $d['tpl'];
						$param = $d['param'];
						$amt = 0;
						if(isset($param['amount'])){
							$amt = floor($param['amount'])/100;
							$param['amount'] = $amt;
						}
						$str = getLang("msgtpl.{$tpl}", $param);
					}
					list($title, $content) = explode('[|||]', $str);
					$mid = $row['id'];
					$uid = $row['uid'];

					$info = $md_user->getDeviceInfoByUid($uid);
					// 2018-08-23 69豪车整合
					$app = APP_DEFAULT;
					$tag = null;
					if(!empty($info)){
						$devtoken = $info['token'];
						$device = $info['device'];
						$plantform = $info['plantform'];
						$app = $info['app'];
					}else{
						$devtoken = null;
						$device = null;
						$plantform = null;
					}
					$bool = $md_msg->addPush($title, $content, $devtoken, $device, $plantform, $uid, $mid, $tag, $app);
					if($bool){
						$count_total ++;
					}
				}
			}
			$this->runnerWait($start_ts, 5000000);

		}while(--$loop);
		$this->runnerClean( __METHOD__ );

		$res = array(
			'count_total' => $count_total,
			'cost' => microtime(true) - $init_ts
			);
		$this->logResult(__FUNCTION__, $res);
	}

	/**
	 * 2018-08-23 69豪车整合
	 * 根据app处理消息推送
	 */
	protected function process_msg_push($app = APP_DEFAULT) {
		$loop = 1;
		$method = __METHOD__.$app;
		$is_exists = $this->checkIfRunnerExists( $method );
		if($is_exists){
			return;
		}
		$init_ts = microtime(true);
		if(false === $is_exists){
			$loop = 36000;
		}
		$limit = 10;
		$md_msg = & load_model('msg');
		$lib_msgpush = & load_library('msgpush');
		$count_total = 0;
		do{
			$start_ts = microtime(true);
			$arr = $md_msg->getPushList($limit,$app);
			$id_arr = array();
			$failed_ids = array();
			$lib_msgpush->iOSOpen($app);
			foreach ($arr as $row) {
				if($row['plantform'] == 'iOS' && !empty($row['token'])){

					$props = $md_msg->getiOSPushPropByTag( $row['tag'] );
					$body = $lib_msgpush->getIOSBody($row['content'], $row['title'], $row['title'] . ':' . $row['content']
						,	$props['url']
						,	$props['badge']
						,	$props['method']
						,	$props['sound']
						,	$props['type']
						);
					$res = $lib_msgpush->iOSPush( $row['token'], $body, $app);

				}elseif($row['plantform'] == 'Android'){
					$res = false;
				}else{
					$res = false;
				}
				if($res){
					$id_arr[] = $row['id'];
					$count_total ++;
				}else{
					$failed_ids[] = $row['id'];
				}
			}
			$lib_msgpush->iOSClose();
			if(!empty($id_arr)){
				$md_msg->setPushSentArr($id_arr);
			}
			if(!empty($failed_ids)){
				$md_msg->setPushFailedArr($failed_ids);
			}
			$this->runnerWait($start_ts, 1500000);

		}while(--$loop);
		$this->runnerClean( $method );

		$res = array(
			'count_total' => $count_total,
			'cost' => microtime(true) - $init_ts
			);
		$this->logResult($method, $res);
	}
	/**
	 *	push消息程序
	 *	使用方式： * * * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task push_msg
	 */
	public function push_msg(){
		$this->process_msg_push(APP_DEFAULT);
	}
	/**
	 *	2018-08-23 69豪车整合
	 *  push消息程序,69豪车
	 *	使用方式： * * * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task push_msg_69hc
	 */
	public function push_msg_69hc(){
		$this->process_msg_push(APP_69HC);
	}

	/**
	 *	活动奖励发放
	 *	使用方式： * * * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task award_dispatch >> /tmp/award_dispatch.txt &
	 */
	public function award_dispatch(){

		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}

		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');

		$start_time = '2017-01-01 00:00:00';
		$end_time = '2017-03-31 23:59:59';
		$limit_amount = 300000*10000;
		do{
			$start_ts = microtime(true);
			$total_amount = $md_accounts->getInviteAwardTotal($start_time);
			// echo $total_amount;exit();
			if($total_amount>=$limit_amount){
				break;
			}
			$arr = $md_accounts->getInviteeBindCard($start_time, $end_time);

			$bonus = 20*10000;//20元
			$action = USRACCOUNT_ACTION_AWARD;
			foreach ($arr as $row) {
				//id, inviter, invitee, invite_interest, invite_interest_status, bind_card_time, bind_card_award_invitee, bind_card_award_inviter, buy_long_time, buy_long_award_invitee, buy_long_award_inviter, created_time, modified_time
				$type = 'bind_card_award_invitee';
				$bool = $md_accounts->addUserAmountByRelAward($row['id'], $row['invitee'], $bonus, $action, $type);
				if($bool){
					$content = json_encode(array(
						'tpl' => MSGTPL_PAY_BINDCARDINVITEE_OK,
						'param' => array(
							'amount' => floor($bonus/100)
							),
						));
					$md_msg->addMsg($row['invitee'], $content);
				}
			}

			$arr = $md_accounts->getInviterBuyLong($start_time, $end_time);

			$bonus = 50*10000;//50元
			$action = USRACCOUNT_ACTION_AWARD;
			foreach ($arr as $row) {
				//id, inviter, invitee, invite_interest, invite_interest_status, bind_card_time, bind_card_award_invitee, bind_card_award_inviter, buy_long_time, buy_long_award_invitee, buy_long_award_inviter, created_time, modified_time
				$uid = $row['inviter'];
				$info = $md_accounts->getUserAccountInfo($uid);
				if(null === $info){
					continue;
				}
				$type = 'buy_long_award_inviter';
				$bool = $md_accounts->addUserAmountByRelAward($row['id'], $uid, $bonus, $action, $type);
				if($bool){
					$content = json_encode(array(
						'tpl' => MSGTPL_PAY_BUYLONGINVITER_OK,
						'param' => array(
							'amount' => floor($bonus/100)
							),
						));
					$md_msg->addMsg($uid, $content);
				}
			}
			$this->runnerWait($start_ts, 3000000);

		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 *	签到奖励发放
	 *	使用方式： * * * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task sign_bonus_dispatch >> /tmp/sign_bonus_dispatch.txt &
	 */
	public function sign_bonus_dispatch(){

		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}

		$md_sign = & load_model('sign');
		$md_msg = & load_model('msg');

		do{
			$limit = 100;
			$start_ts = microtime(true);
			$arr = $md_sign->getUnpaidList($limit);
			if(!empty($arr)){
				$total = 0;
				$success = 0;
				$failed_ids = array();
				foreach ($arr as $row) {
					$total ++;
					$bool = $md_sign->paySignBonusToUser( $row['id'] );
					if($bool){
						$content = json_encode(array(
							'tpl' => MSGTPL_PAYSIGNBONUS_OK,
							'param' => array(
								'date' => date('Y-m-d'),
								'amount' => $row['amount']/100
								),
							));
						$md_msg->addMsg($row['uid'], $content);
						$success ++;
					}else{
						$failed_ids[] = $row['id'];
					}
				}
				$failed_count = count($failed_ids);
				if ($failed_count>0) {
					$md_sign->updateSignBonusFailed($failed_ids);
				}
				$this->logResult(__FUNCTION__, array(
					'total' => $total,
					'success' => $success,
					'failed' => $failed_count,
					));
			}
			$this->runnerWait($start_ts, 3000000);

		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 * 2018-08-23,69豪车整合
	 * 处理发送验证码短信
	 */
	protected function process_sms_send($app){
		$loop = 1;
		$method = __METHOD__ . $app;
		$is_exists = $this->checkIfRunnerExists( $method );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}

		$cipher = Cipher::getInstance();
		$lib_sms = & load_library('mdsms');
		$cnf = config_item('mdsms');
		if ($app==APP_69HC && isset($cnf[1])) {
			$cnf = $cnf[1];
		} elseif (isset($cnf[0])){
			$cnf = $cnf[0];
		}
		$lib_sms->init($cnf);
		$md_sms = & load_model('sms');
		$md_accounts = & load_model('accounts');
		$md_user = & load_model('user');
		$sent_count = 0;
		$failed_count = 0;
		do{
			$start_ts = microtime(true);
			$arr = $md_sms->getSendList($app);
			$id_arr = array();
			$failed_ids = array();
			foreach ($arr as $row) {
				//id,mobile,code,ext_id,template,failed_times,created_time
				$ext_id = $row['ext_id'];
				if(strlen($row['mobile']) != 11){
					continue;
				}
				if(empty($row['code'])){
					continue;
				}
				$template = $row['template'];
				if(empty($template)){
					$template = 'SMS_5580193';
				}
				$lib_sms->setTemplate( $template );

				$lib_sms->setMobile( $row['mobile'] );

				switch ($template) {
					case 'SMS_66755307':
					case 'SMS_66770507':
					case 'SMS_70410276':
						$orinfo = $md_accounts->getOfflineRechargeByRLID( $ext_id );
						$uid = $orinfo['uid'];
						$money = $orinfo['money']/100;
						$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
						$userinfo = $md_user->getUserById($uid);

						$key = $cipher->getMDHashKey( $uid );
						$str = base64_decode($accinfo['identcode']);
						$raw = $cipher->aesDecode( $key, $str );
						$identcode = trim($raw);
						$str = base64_decode($accinfo['realname']);
						$raw = $cipher->aesDecode( $key, $str );
						$username = trim($raw);

						$params = array(
							'phone' => $userinfo['mobile'] . "",
							'name' => $username . "",
							'idno' => substr($identcode, -6) . "",
							'money' => $money . "",
							'code' => $row['code'] . ""
							);
						break;

					case 'SMS_70535272':
						$owinfo = $md_accounts->getOfflineWithdrawByWLID( $ext_id );
						$uid = $owinfo['uid'];
						$money = ($owinfo['money'] - $owinfo['fee'])/100;
						$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
						$userinfo = $md_user->getUserById($uid);

						$key = $cipher->getMDHashKey( $uid );
						$str = base64_decode($accinfo['identcode']);
						$raw = $cipher->aesDecode( $key, $str );
						$identcode = trim($raw);
						$str = base64_decode($accinfo['realname']);
						$raw = $cipher->aesDecode( $key, $str );
						$username = trim($raw);
						$params = array(
							'tid' => $ext_id . "",
							'phone' => $userinfo['mobile'] . "",
							'name' => $username . "",
							'idno' => substr($identcode, -6) . "",
							'money' => $money . "",
							'code' => $row['code'] . ""
							);
						break;

					case 'SMS_74545032':
					case 'SMS_74675022':
						$params = array(
							'code' => $row['code'],
							);
						break;

					default:
						$params = array(
							'code' => $row['code'],
							'product' => $cnf['sign']
							);
						break;
				}
				$lib_sms->setParams( $params );
				$res = $lib_sms->send();
				if(true === $res){
					$id_arr[] = $row['id'];
					$sent_count ++;
				}else{
					log_error( $method . $res . print_r($params, 1));
					$failed_ids[] = $row['id'];
					$failed_count ++;
				}
			}
			if(!empty($id_arr)){
				$md_sms->setSent($id_arr);
			}
			if(!empty($failed_ids)){
				$md_sms->setFailed($failed_ids);
			}

			$this->runnerWait($start_ts, 1500000);

		}while(--$loop);
		$this->logResult($method, array(
			'sent_count' => $sent_count,
			'failed_count' => $failed_count,
			));
		$this->runnerClean( $method );
	}

	/**
	 * 2018-08-23,69豪车整合
	 * 发送验证码短信,鹰眼理财
	 * 使用方式： * * * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task sms_send_code &
	 */
	public function sms_send_code(){
		$this->process_sms_send(APP_DEFAULT);
	}
	/**
	 * 2018-08-23,69豪车整合
	 * 发送验证码短信,69豪车
	 * 使用方式： * * * * * /usr/local/bin/php ROOT/apicenter/tasks/task.php task sms_send_code_69hc &
	 */
	public function sms_send_code_69hc(){
		$this->process_sms_send(APP_69HC);
	}

	/**
	 *	充值处理
	 */
	public function recharge_in_account(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}
		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');

		do{
			$start_ts = microtime(true);

			$status = RECHARGE_STATUS_PAID;
			$limit = 20;
			$list = $md_accounts->getRechargeOrderList( $status, $limit );
			if(!empty($list)) foreach ($list as $row) {
				$id = $row['id'];
				$uid = $row['uid'];
				$money = $row['money'];
				$bool = $md_accounts->rechargeOrderDoneAndToAccount( $id );
				if($bool){
					$content = json_encode(array(
						'tpl' => MSGTPL_RECHARGE_OK,
						'param' => array(
							'id' => $id,
							'amount' => $money
							),
						));
					$md_msg->addMsg($uid, $content);
				}
			}
			$this->runnerWait($start_ts, 1000000, 1500000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 *	提现处理
	 */
	public function withdraw_out_account(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 4900;
		}
		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');

		$cipher = Cipher::getInstance();

		require_once PATH_PAYMENT_FUIOU;
		$prepay = new FuiouPerPayment();
		$fp = new FPCommon_util_pub();

		do{
			$start_ts = microtime(true);

			$status = WITHDRAW_STATUS_ORDER_CREATED;
			$batch = str_pad(mt_rand(10000, 99999) . microtime(true), 20, '0', STR_PAD_RIGHT);
			$limit = 20;
			$up = $md_accounts->setWithdrawOrderBatch( $batch, $status, $limit );
			if(!$up){
				$this->runnerWait($start_ts, 1000000, 1500000);
				continue;
			}
			$list = $md_accounts->getWithdrawOrderList( $status, $batch );
			if(!empty($list)) foreach ($list as $row) {
				$uid = $row['uid'];
				$key = $cipher->getMDHashKey( $uid );
				$str = base64_decode($row['cardno']);
				$raw = $cipher->aesDecode( $key, $str );
				$accntno = trim($raw);
				$str = base64_decode($row['username']);
				$raw = $cipher->aesDecode( $key, $str );
				$accntnm = trim($raw);

				$orderno = $row['order_id'];
				$bankno = $fp->bankNameCode( $row['bank_name'] );
				$cityno = $fp->cityNameCode( $row['city'] );
				$branchnm = $row['bank_sub'];
				$amt = $row['money'];
				$amt_fee = $row['fee'];
				$entseq = $row['id'];
				$memo = '';
				$mobile = '';
				$res = $prepay->userPerpay($orderno, $bankno, $cityno, $branchnm, $accntno, $accntnm, $amt - $amt_fee, $entseq, $memo, $mobile);
				if(true === $res){
					$md_accounts->withdrawOrderResponsed( $row['id'], WITHDRAW_STATUS_DONE );
					$md_accounts->updateBankAccountCityInfoByWithdraw( $row['id'] );

					$content = json_encode(array(
						'tpl' => MSGTPL_WITHDRAW_OK,
						'param' => array(
							'id' => $entseq,
							'amount' => $amt - $amt_fee
							),
						));
					$md_msg->addMsg($uid, $content);

				}else{
					$md_accounts->withdrawOrderResponsed( $row['id'], WITHDRAW_STATUS_FAILED, $res);
					$bool = $md_accounts->withdrawOrderRollbacked( $row['id'], $uid, $amt, $row['baid'] );

					if($bool){
						$content = json_encode(array(
							'tpl' => MSGTPL_WITHDRAW_FAILED,
							'param' => array(
								'id' => $entseq,
								'amount' => $amt
								),
							));
						$md_msg->addMsg($uid, $content);
					}
				}
			}
			$this->runnerWait($start_ts, 1000000, 1500000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}


	/**
	 *	转账充值通知内部服务器
	 */
	public function offline_recharge_notice(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}
		$md_user = & load_model('user');
		$md_accounts = & load_model('accounts');
		$lib_xtransfer = & load_library('xtransfer');

		$cipher = Cipher::getInstance();

		do{
			$start_ts = microtime(true);
			$list = $md_accounts->getOfflineRechargeWaitingNoticeLocalSRV();
			if(!empty($list)) foreach ($list as $row) {

				foreach ($list as $row) {
					$id = $row['id'];
					$uid = $row['uid'];
					$bank = $row['bank'];
					$userinfo = $md_user->getUserById($uid);
					$account_mobile = $userinfo['mobile'];
					$key = $this->getMDHashKey( $uid );
					$realname = $this->mdataDecrypt($key, $row['realname']);
					$cardno = $this->mdataDecrypt($key, $row['cardno']);
					$money = $row['money'];
					$rl_id = $lib_xtransfer->largeAmountRecharge($id, $bank, $cardno, $realname, $money, $account_mobile);
					if($rl_id){
						$md_accounts->offlineRechargeNoticedLocalSRV( $uid, $id, $rl_id );
					}
				}
			}
			$this->runnerWait($start_ts, 1000000, 1500000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 *	线下、退保证金充值从内部服务器获取
	 */
	public function fetch_offline_recharge_info(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}
		$md_accounts = & load_model('accounts');
		$md_user = & load_model('user');
		$lib_xtransfer = & load_library('xtransfer');

		$cipher = Cipher::getInstance();

		do{
			$start_ts = microtime(true);
			$list = $lib_xtransfer->fetchNewRechargeInfoList();
			if(!empty($list)) foreach ($list as $row) {
				foreach ($list as $row) {
					$rl_id = intval($row['id']);
					$mobile = $row['mobile'];
					$money = $row['money'];
					$type = $row['type'];
					if(!in_array($type, array(_IN_XTRANS_TYPE_OFFLINE_RECHARGE, _IN_XTRANS_TYPE_PAYBACK_DEPOSIT))){
						$lib_xtransfer->noticeRechargeListStatus($rl_id, OFFLINE_RECHARGE_COMM_STATUS_MOBILE_NOT_REGISTER);
						continue;
					}
					if(!preg_match('/^[0-9]{1,10}$/', $money)){
						$lib_xtransfer->noticeRechargeListStatus($rl_id, OFFLINE_RECHARGE_COMM_STATUS_MONEY_ERROR);
						continue;
					}
					$info = $md_user->getUserByPhone( $mobile );
					if(empty($info)){
						$lib_xtransfer->noticeRechargeListStatus($rl_id, OFFLINE_RECHARGE_COMM_STATUS_MOBILE_NOT_REGISTER);
					}else{
						$uid = $info['id'];
						$orinfo = $md_accounts->getOfflineRechargeByRLID($rl_id);
						$uor_id = null;
						if (!$orinfo) {
							$uor_id = $md_accounts->addLocalOfflineRechargeOrder($uid, $mobile, $money, $rl_id, $type);
						}else{
							$uor_id = $orinfo['id'];
						}
						if($uor_id){
							$lib_xtransfer->noticeRechargeListUorID($rl_id, $uor_id);
						}
					}
				}
			}
			$this->runnerWait($start_ts, 1000000, 1500000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}


	/**
	 *	线下充值处理
	 */
	public function offline_recharge_in_account(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}
		$md_accounts = & load_model('accounts');
		$md_sms = & load_model('sms');
		$md_msg = & load_model('msg');
		$lib_xtransfer = & load_library('xtransfer');

		$cipher = Cipher::getInstance();

		do{
			$start_ts = microtime(true);

			$list = $lib_xtransfer->fetchRechargeList();
			if(!empty($list)) foreach ($list as $row) {
				$id = $row['id'];
				$mobile = $row['mobile'];
				$money = $row['money'];
				$acc_code = $row['acc_code'];
				$acc_code_id = $row['acc_code_id'];
				$fin_code = $row['fin_code'];
				$fin_code_id = $row['fin_code_id'];
				$mng_code = $row['mng_code'];
				$mng_code_id = $row['mng_code_id'];
				$trans_id = $row['trans_id'];
				$uor_id = $row['uor_id'];
				$status = $row['status'];
				$type = $row['type'];
				$rdesc = $row['rdesc'];
				$created_time = $row['created_time'];

				$info = $md_accounts->getOfflineRechargeByRLID($id);
				if(empty($info)){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_NOT_EXISTS);
					continue;
				}
				if($info['money'] != $money || $info['mobile']!= $mobile || $info['id'] != $uor_id){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_VERIFY_FAILED);
					continue;
				}
				if($info['status'] == OFFLINE_RECHARGE_STATUS_DONE){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_FINISHED);
					continue;
				}
				if($info['status'] == OFFLINE_RECHARGE_STATUS_FAILD){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_FAILED);
					continue;
				}
				if($info['status'] != OFFLINE_RECHARGE_STATUS_NOTICED_LOCAL_SRV){
					continue;
				}
				$uid = $info['uid'];
				$acc_code_info = $md_sms->getPhoneCodeById($acc_code_id);
				if(empty($acc_code_info) || $acc_code_info['code'] != $acc_code || $acc_code_info['ext_id'] != $id){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_VERIFY_FAILED);
					continue;
				}
				$fin_code_info = $md_sms->getPhoneCodeById($fin_code_id);
				if(empty($fin_code_info) || $fin_code_info['code'] != $fin_code || $fin_code_info['ext_id'] != $id){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_VERIFY_FAILED);
					continue;
				}
				/*经理验证现阶段关闭
				$mng_code_info = $md_sms->getPhoneCodeById($mng_code_id);
				if(empty($mng_code_info) || $mng_code_info['code'] != $mng_code || $mng_code_info['ext_id'] != $id){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_VERIFY_FAILED);
					continue;
				}
				*/

				$bool = $md_accounts->offlineRechargeOrderDoneAndToAccount( $info['id'], $info['type'] );
				if($bool){
					$lib_xtransfer->noticeRechargeListStatus($id, OFFLINE_RECHARGE_COMM_STATUS_FINISHED);
					$md_sms->useCodeByID($mobile, $acc_code, $acc_code_id);
					$md_sms->useCodeByID($mobile, $fin_code, $fin_code_id);
					$content = json_encode(array(
						'tpl' => MSGTPL_RECHARGE_OK . '_' . $info['type'],
						'param' => array(
							'id' => $id,
							'amount' => $money
							),
						));
					$md_msg->addMsg($uid, $content);
				}
			}
			$this->runnerWait($start_ts, 1000000, 1500000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 *	线下提现处理
	 */
	public function offline_withdraw_out_account(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 4900;
		}
		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');
		$md_user = & load_model('user');
		$lib_xtransfer = & load_library('xtransfer');

		$cipher = Cipher::getInstance();

		do{
			$start_ts = microtime(true);

			$status = WITHDRAW_STATUS_ORDER_CREATED;
			$batch = str_pad(mt_rand(10000, 99999) . microtime(true), 20, '0', STR_PAD_RIGHT);
			$limit = 20;
			$up = $md_accounts->setOfflineWithdrawOrderBatch( $batch, $status, $limit );
			if(!$up){
				$this->runnerWait($start_ts, 1000000, 1500000);
				continue;
			}
			$list = $md_accounts->getOfflineWithdrawOrderList( $status, $batch );

			if(!empty($list)) foreach ($list as $row) {
				$uid = $row['uid'];
				$key = $cipher->getMDHashKey( $uid );
				$str = base64_decode($row['cardno']);
				$raw = $cipher->aesDecode( $key, $str );
				$cardno = trim($raw);
				$str = base64_decode($row['username']);
				$raw = $cipher->aesDecode( $key, $str );
				$username = trim($raw);

				$orderno = $row['order_id'];
				$bank_name = $row['bank_name'];
				$city = $row['city'];
				$bank_sub = $row['bank_sub'];
				$amt = $row['money'];
				$amt_fee = $row['fee'];
				$entseq = $row['id'];

				$userinfo = $md_user->getUserById($uid);
				$account_mobile = $userinfo['mobile'];

				$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
				$bank_mobile = trim($cipher->aesDecode($key, base64_decode(($accinfo['mobile']))));
				$wl_id = $lib_xtransfer->withdraw($orderno, $bank_name, $city, $bank_sub, $cardno, $username, $amt - $amt_fee, $account_mobile, $bank_mobile);
				if($wl_id){
					$md_accounts->offlineWithdrawOrderResponsedDone( $row['id'], $wl_id );

					$content = json_encode(array(
						'tpl' => MSGTPL_WITHDRAW_OK,
						'param' => array(
							'id' => $entseq,
							'amount' => $amt - $amt_fee
							),
						));
					$md_msg->addMsg($uid, $content);

				}
				/* 只许成功不许失败。。。
				else{
					$md_accounts->offlineWithdrawOrderResponsedFailed( $row['id'] );
					$bool = $md_accounts->offlineWithdrawOrderRollbacked( $row['id'], $uid, $amt, $row['baid'] );

					if($bool){
						$content = json_encode(array(
							'tpl' => MSGTPL_WITHDRAW_FAILED,
							'param' => array(
								'id' => $entseq,
								'amount' => $amt
								),
							));
						$md_msg->addMsg($uid, $content);
					}
				}
				*/
			}
			$this->runnerWait($start_ts, 1000000, 1500000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 *	交易处理
	 */
	public function trade_operator(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}
		$md_obligation = & load_model('obligation');
		$md_accounts = & load_model('accounts');
		$md_msg = & load_model('msg');
		do{
			$start_ts = microtime(true);

			$status = TRADE_STATUS_NORMAL;
			$limit = 20;
			$queues = $md_obligation->getOblQueueAll( $status, $limit );
			if(!empty($queues)) foreach ($queues as $row) {
				//id, uid, oid, amount, rate, closed_period, via, auto_shift, shift_to, status, created_time, process_time, modified_time;
				$qid = $row['id'];
				$hoid = $row['hoid'];
				$oid = $row['oid'];
				$uid = $row['uid'];
				$amount = $row['amount'];
				//获取用户账户信息
				$buy_accinfo = $md_accounts->getUserCurrentAccount( $uid );
				if(!$buy_accinfo){
					log_error( __METHOD__ . " buy_accinfo[$uid] not fetch");
					continue;
				}
				if($buy_accinfo['amount'] < $amount){
					log_warning( __METHOD__ . " buy_accinfo[$uid] amount not enough {$buy_accinfo['amount']} < $amount");
					$md_obligation->queueAmountNotEnough( $qid );
					continue;
				}
				$hold_obl = $md_obligation->getObligationHolding( $hoid, true );
				if(empty($hold_obl) || !isset($hold_obl['id'])){
					log_error( __METHOD__ . " obligation_holding_list[$hoid] not fetch");
					continue;
				}
				if(!$hold_obl['selling']){
					log_warning( __METHOD__ . " obligation_holding_list[$hoid] is not selling");
					$md_obligation->oblHoldingFlushQueue( $hoid );
					//重置队列后跳出循环，重新获取队列信息
					break;
				}

				$obl = $md_obligation->getObligationDetail( $oid, true );
				if(empty($obl) || !isset($obl['id'])){
					log_error( __METHOD__ . " obligation[$oid] not fetch");
					continue;
				}
				//$queue, $buy_accinfo, $sell_accinfo, $obl, $holding_obl
				$res = $md_obligation->oblTradeProcess( $row, $obl, $hold_obl );
				if(is_array($res)){
					list($buy_uoid, $buy_uid, $sell_uoid, $sell_uid) = $res;

					$content = json_encode(array(
						'tpl' => MSGTPL_OBLBUY_OK,
						'param' => array(
							'id' => $buy_uoid
							),
						));
					$md_msg->addMsg($buy_uid, $content);
					if($sell_uid != OBL_SYSTEM_UID){
						$content = json_encode(array(
							'tpl' => MSGTPL_OBLSELL_OK,
							'param' => array(
								'id' => $sell_uoid
								),
							));
						$md_msg->addMsg($sell_uid, $content);
					}

					if($buy_uid != 100006 && in_array($row['via'], array( TRADE_VIA_DIRECT_BUY_OBLIGATION, TRADE_VIA_FAST_ENTRY, TRADE_VIA_AMOUNT_SHIFT ))){
						$rel = $md_accounts->getUserRel( $buy_uid );
						if( !empty($rel) && empty($rel['buy_long_time']) ){
							$md_accounts->setUserRelBuyLongTime( $buy_uid );
						}
					}
				}
			}
			// 2018-05-28
			// 需要尽快处理而不是等待更多时间，busy_stop从1500秒修改为200毫秒
			$this->runnerWait($start_ts, 1000000, 200000);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}

	/**
	 * 内部处理一次交易队列
	 */
	protected function process_auto_queue($limit) {
		$md_obligation = & load_model('obligation');
		// 获取购买队列
		$buy_queue = $md_obligation->getAutoProcessQueueAll(AUTO_PROCESS_STATUS_NORMAL,$limit);
		if (empty($buy_queue)) {
			return -1;
		}
		// 获取未处理的交易队列
		$trade_queue = $md_obligation->getTradeQueueHoidAmount();
		// 获取售卖队列
		$sell_queue = $md_obligation->getSellingObligationHoldingLite( true );
		if (empty($sell_queue)) {
			return -2;
		}
		// 构建map，加快处理
		$trade_queue_map = array();
		foreach($trade_queue as $trader) {
			$trade_queue_map[$trader['hoid']] = $trader['amount'];
		}
		// 售卖对了进行排序，用户卖出优先，系统卖出最后
		$sys_arr = array();
		$user_arr = array();
		foreach ($sell_queue as &$seller) {
			// 卖出队列中的金额减去未处理的金额，减少重复购买，即购买失败概率
			if (isset($trade_queue_map[$seller['id']])) {
				$amount = $trade_queue_map[$seller['id']];
				$seller['left_amount'] -= $amount;
			}
			// 过滤掉小于等于0的售卖记录
			if ($seller['left_amount']<=0) {
				continue;
			}
			if($seller['uid'] == OBL_SYSTEM_UID){
				array_push($sys_arr, $seller);
			}else{
				array_push($user_arr, $seller);
			}
		}
		$sell_queue = array_merge($user_arr, $sys_arr);
		if (empty($sell_queue)) {
			return -2;
		}
		$buyer_count = count($buy_queue);
		$processed_count = 0;
		// 遍历购买队列，进行购买处理
		foreach($buy_queue as $buyer) {
			$qid = $buyer['id'];
			$uid = $buyer['uid'];
			$amount = $buyer['amount'];
			if($amount <=0 ){
				// 购买金额小于等于0，直接设置为购买结束
				$processed_count ++;
				$md_obligation->updateAutoProcessStatusById($qid, AUTO_PROCESS_STATUS_DONE, AUTO_PROCESS_STATUS_NORMAL);
				continue;
			}
			$via = $buyer['via'];
			// 遍历售卖，进行匹配购买
			foreach ($sell_queue as $key => &$seller) {
				if($seller['left_amount'] <= 0){
					//当债权余额小于等于0，跳出此债权，同时从队列中去除掉
					$sell_queue = array_slice($sell_queue, $key+1);
					continue;
				}
				if($via == TRADE_VIA_ROOKIE){
					$md_rate = & load_model('rate');
					$rookie_closed_period = $md_rate->getClosedPeriodOfRookie();
					$mindiff = $rookie_closed_period + 3;
					// 从源头限制新人专享所购债权无夸还款日问题，同时只购买一条记录（即出售的债权金额要大等于购买的金额）
					if( $amount > $seller['left_amount'] || ($seller['repayment_day'] - date('j') + 30)%30 < $mindiff ){
						continue;
					}
					// TODO,从obligation_holiding_list中查询是否更好
					$rookie_obl = $md_obligation->getRookieTradeQueue($uid);
					if(!empty($rookie_obl)){
						// 如果用户已经购买了新人专享，直接取消交易
						$processed_count ++;
						$md_obligation->updateAutoProcessStatusById( $qid, AUTO_PROCESS_STATUS_CANCEL, AUTO_PROCESS_STATUS_NORMAL );
						continue;
					}
				}
				$hoid = $seller['id'];
				$oid = $seller['oid'];
				if($amount <= $seller['left_amount']){
					//当债权余额大于等于购买金额，处理完此购买请求，跳出债权循环，换下一个购买请求
					$bool = $md_obligation->processQueueToTradeQueue( $uid, $oid, $hoid, $buyer, $amount );
					if($bool){
						$seller['left_amount'] -= $amount;
						$processed_count ++;
						break;
					}else{
						log_error(__METHOD__, "[error]process queue to trade queue failed 1,buyer id:{$buyer['id']},seller id:{$hoid}");
					}
				}else{
					//当前债权余额小于需求额，债权应清理，继续购买下一个售出的债权
					$bool = $md_obligation->processQueueToTradeQueue( $uid, $oid, $hoid, $buyer, $seller['left_amount'] );
					if($bool){
						$amount -= $seller['left_amount'];
						$seller['left_amount'] = 0;
						$sell_queue = array_slice($sell_queue,$key + 1);
					}else{
						log_error(__METHOD__, "[error]process queue to trade queue failed 2,buyer id:{$buyer['id']},seller id:{$hoid}");
					}
				}
			}
			if(empty($sell_queue)) {
				// 本次售卖完没有了
				return -2;
			}
		}
		return 	$buyer_count-$processed_count;
	}

	/**
	 * 自动购买交易队列处理
	 * 使用方式： * * * * *
	 */
	public function auto_process_operator(){
		$loop = 1;
		$is_exists = $this->checkIfRunnerExists( __METHOD__ );
		if($is_exists){
			return;
		}
		if(false === $is_exists){
			$loop = 36000;
		}

		$limit =100;
		// 交易队列为空的情况下，等待2秒后处理
		$queue_empty_sleep = 2*1000000;
		// 还可能有交易的情况下，等待0.3秒后处理
		$has_more_sleep = 0.3*1000000;
		do{
			$start_ts = microtime(true);
			$left_count = $this->process_auto_queue($limit);
			usleep($left_count>=0?$has_more_sleep:$queue_empty_sleep);
		}while(--$loop);
		$this->runnerClean( __METHOD__ );
	}
}