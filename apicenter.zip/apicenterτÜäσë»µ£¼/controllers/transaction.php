<?php
require_once PATH_BASE_CONTROLLER;

class Transaction extends Controller{

	/**
	 *	检查用户余额是否足够
	 */
	protected function checkUserAmountIsEnough($uid, $money){
		$md_accounts = & load_model('accounts');

		$accinfo = $md_accounts->getUserCurrentAccount(	$uid );
		if(!$accinfo){
			$this->setCode( CODES_ACCOUNT_INFO_GETS_FAILED );
			$this->setMsg( getLang('account.infogetsfailed') );
			return false;
		}
		if( $accinfo['amount'] < $money){
			$this->setCode( CODES_ACCOUNT_AMOUNT_NOT_ENOUGH );
			$this->setMsg( getLang('account.amountnotenough') );
			return false;
		}
		$md_obligation = & load_model('obligation');
		$oblqueues = $md_obligation->getOblQueue( $uid );
		if(!empty($oblqueues)){
			$count = count($oblqueues);
			if($count > TRADE_INQUEUE_COUNT_LIMIT){
				$this->setCode( CODES_TRADE_INQUEUE_COUNT_LIMIT );
				$this->setMsg( getLang('trade.inqueue_count_limit', array('count' => $count)) );
				return false;
			}
			$sum = 0;
			foreach ($oblqueues as $oblqueue) {
				$sum += intval($oblqueue['amount']);
			}
			$autoqueues = $md_obligation->getAutoProcessQueue( $uid );
			if(!empty($autoqueues)){
				foreach ($autoqueues as $autoqueue) {
					$sum += intval($autoqueue['amount']);
				}
			}
			if($sum > TRADE_INQUEUE_AMOUNT_RATE_LIMIT * $accinfo['amount']){
				$this->setCode( CODES_TRADE_INQUEUE_AMOUNT_RATE_LIMIT );
				$sum = $this->convHaoToFen( $sum );
				$this->setMsg( getLang('trade.inqueue_amount_limit', array('amount' => floor($sum/100) . '.' . ($sum%100) )) );
				return false;
			}
		}
		return true;
	}
	
	/**
	 *	修正自动转投项目
	 */
	protected function fixShiftTo(&$auto_shift, &$shift_to){
		//关闭自动转投功能，使用余额转投。
		$auto_shift = 0;
		$shift_to = TRADE_AUTOSHIFT_NONE;
		return;
		$auto_shift = intval($auto_shift);
		if($auto_shift){
			$auto_shift = 1;
			$shift_to = intval($shift_to);
			if($shift_to != TRADE_AUTOSHIFT_FAST_ENTRY){
				$shift_to = TRADE_AUTOSHIFT_EAGLEEYED;
			}
		}else{
			$auto_shift = 0;
			$shift_to = TRADE_AUTOSHIFT_NONE;
		}
	}

	public function __construct(){
		parent::__construct();
	}

	/**
	 *	调整自动转投
	 */
	public function switchAutoShift(){
		//关闭自动转投，仅开放余额转投功能
		return;
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkTranscationAvailable()) {
			return;
		}
		$id = $this->postval('id');
		$id = intval($id);
		$this->logExtraColumns('id', $id);
		$auto_shift = $this->postval('auto_shift');
		$shift_to = $this->postval('shift_to');
		if(empty($id)){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}

		$this->fixShiftTo($auto_shift, $shift_to);
		
		$uid = $this->uid;
 
		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserAccountInfo($uid);
		if(!$accinfo['auto_shift']){
			$this->setMsg( getLang('trade.no_permission_of_auto_shift') );
			return;
		}
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getObligationHolding($id);
		if(false === $data){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		if(empty($data)){
			$this->setMsg( getLang('trade.user_obligation_not_exists') );
			return;
		}
		if( $data['uid'] != $uid){
			$this->setMsg( getLang('trade.no_permission') );
			return;
		}
		if($data['via'] == TRADE_VIA_EAGLEEYED){
			$this->setMsg( getLang('trade.eagleeyed_cannot_change_autoshift') );
			return;
		}elseif($data['via'] == TRADE_VIA_ROOKIE){
			$this->setMsg( getLang('trade.rookie_cannot_change_autoshift') );
			return;
		}
		$bool = $md_obligation->updateObligationHoldingAutoShift( $id, $uid, $auto_shift, $shift_to );
		$res = array( 'auto_shift' => $auto_shift );
		if($bool){
			$res['success'] = true;
		}else{
			$res['success'] = false;
		}
		if($auto_shift){
			$res['shift_to'] = $shift_to;
		}else{
			$res['shift_to'] = null;
		}
		$this->setData( $res );
		$this->setCodeSuccess();
	}

	/**
	 *	取消排队
	 */
	public function dequeue(){
		if(!$this->checkUserLogin()){
			return;
		}
		$id = $this->postval('id');
		$this->logExtraColumns('id', $id);
		$id = intval($id);
		if(empty($id)){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$uid = $this->uid;

		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getUserAPQueueById($id);
		if(false === $data){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		if(empty($data)){
			$this->setMsg( getLang('trade.user_apqueue_not_exists') );
			return;
		}
		if( $data['uid'] != $uid){
			$this->setMsg( getLang('trade.no_permission') );
			return;
		}
		$bool = $md_obligation->updateAutoProcessStatusById($id, AUTO_PROCESS_STATUS_CANCEL, AUTO_PROCESS_STATUS_NORMAL);
		$this->setData( array('success' => $bool) );
		$this->setCodeSuccess();
	}

	/**
	 *	购买债权
	 *	检查用户余额
	 *	检查债权余额（扣除队列资金）
	 *	检查债权期限
	 *	
	 */
	public function obligation(){
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkTranscationAvailable()) {
			return;
		}
		$oblid = $this->postval('oid');

		$money = $this->postval('money');
		$password = $this->postval('passwd');

		$auto_shift = $this->postval('auto_shift');

		$shift_to = $this->postval('shift_to');

		$buy_all_period = intval($this->postval('buy_all_period'));
		
		$this->fixShiftTo($auto_shift, $shift_to);

		$money = $this->convFenToHao( $money );//系统内最小计数单位为万分之一元，上传的money单位为分，故需要转换

		$uid = $this->uid;
		
		$this->logExtraColumns(array(
			'oblid' => $oblid,
			'money' => $money
			));
		$md_accounts = & load_model('accounts');
		if($auto_shift){
			$accinfo = $md_accounts->getUserAccountInfo($uid);
			if(!$accinfo['auto_shift']){
				$this->setMsg( getLang('trade.no_permission_of_auto_shift') );
				return;
			}
		}

		$md_obligation = & load_model('obligation');

		$obl = $md_obligation->getObligationDetail( $oblid );
		$min = min($obl['left_amount'], TRADE_OBL_AMOUNT_LIMIT_MIN);
		if(floor($money/100) < floor($min/100)){
			$this->setMsg( getLang('trade.obligationamountlimitmin', array('amount' => floor($min/100)/100)) );
			return;
		}
		if(empty($obl) || !isset($obl['id'])){
			$this->setCode( CODES_OBLIGATION_NOT_EXISTS );
			$this->setMsg( getLang('obligation.not_exists') );
			return;
		}
		
		if($obl['left_amount']<$money){
			$this->setCode( CODES_OBLIGATION_LEFT_AMOUNT_NOT_ENOUGH );
			$this->setMsg( getLang('obligation.left_amount_not_enough') );
			return;
		}
		
		if( !$this->checkUserAmountIsEnough($uid, $money) ){
			return;
		}

		if( !$this->checkUserPaymentPassword($uid, $password) ){
			return;
		}

		$md_rate = & load_model('rate');
		// $rate = $md_rate->getRateOfObligation();
		$rate = $obl['rate'];
		$via = TRADE_VIA_DIRECT_BUY_OBLIGATION;
		
		$sysholding = $md_obligation->getSYSHoldingObligationByOid($oblid, true);
		if(empty($sysholding) || empty($sysholding[0])){
			$this->setMsg( getLang('obligation.left_amount_not_enough') );
			return;
		}
		$sysholding = $sysholding[0];
		if($sysholding['left_amount']<$money){
			$this->setCode( CODES_OBLIGATION_LEFT_AMOUNT_NOT_ENOUGH );
			$this->setMsg( getLang('obligation.left_amount_not_enough') );
			return;
		}
		
		$hoid = $sysholding['id'];

		$closed_period = $obl['closed_period'];
		// $closed_period = $md_rate->getClosedPeriodOfObligation( $oblid );

		$all_period_holding = 0;
		if($buy_all_period){
			$rate = $obl['all_period_rate'];
			$closed_period = $obl['left_period'] * 30 + 6 * ceil($obl['left_period']/12);
			$all_period_holding = 1;
		}

		$trade_id = $md_obligation->buyObligationQueue($uid, $oblid, $hoid, $money, $rate, $closed_period, $via, $auto_shift, $shift_to, $all_period_holding);

		if(!$trade_id){
			$this->setCode( CODES_TRADE_ADD_QUEUE_FAILED );
			$this->setMsg( getLang('trade.add_queue_failed') );
			return;
		}
		$this->setCodeSuccess();
		$this->setData( array(
			'trade_id' => $trade_id,
			'msg' => getLang('trade.into_trade_queue_success')
			)
		);
	}

	public function rookie(){
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkTranscationAvailable()) {
			return;
		}
		$money = $this->postval('money');
		$password = $this->postval('passwd');
		$money = $this->convFenToHao( $money );//系统内最小计数单位为万分之一元，上传的money单位为分，故需要转换

		$this->logExtraColumns('money', $money );
		if($money < TRADE_ROOKIE_AMOUNT_LIMIT_MIN){
			$this->setMsg( getLang('trade.rookie_amount_limit_min', array('amount' => TRADE_ROOKIE_AMOUNT_LIMIT_MIN/10000)) );
			return;
		}
		if($money > TRADE_ROOKIE_AMOUNT_LIMIT_MAX){
			$this->setMsg( getLang('trade.rookie_amount_limit_max', array('amount' => TRADE_ROOKIE_AMOUNT_LIMIT_MAX/10000)) );
			return;
		}
		$uid = $this->uid;

		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserAccountInfo( $uid );
		if(!$accinfo){
			$this->setCode( CODES_ACCOUNT_INFO_GETS_FAILED );
			$this->setMsg( getLang('account.infogetsfailed') );
			return false;
		}
		$ts = strtotime($accinfo['created_time']);
		if(time() - $ts > 180*86400){//超过180天
			$this->setMsg( getLang('account.not_rookie') );
			return false;
		}
		$md_obligation = & load_model('obligation');
		$info = $md_obligation->getRookieObligation( $uid, true );
		if(!empty($info)){
			$this->setMsg( getLang('trade.rookie_bought_already') );
			return false;
		}
		$info = $md_obligation->getRookieAutoQueue( $uid );
		if(!empty($info)){
			$this->setMsg( getLang('trade.rookie_inqueue_already') );
			return false;
		}
		$inqueue_amount = $md_obligation->getAPInQueueAmount(TRADE_VIA_ROOKIE);
		if($inqueue_amount >= TRADE_QUEUE_ROOKIE_AMOUNT_INQUEUE_CAP){//排队金额超限
			$this->setMsg( getLang('trade.rookie_user_cap_limited') );
			return false;
		}
		$today_total_amount = $md_obligation->getRookieTodayTotalAmount();
		if($today_total_amount >= TRADE_QUEUE_ROOKIE_AMOUNT_TOTAL_CAP){//当日金额超限
			$this->setMsg( getLang('trade.rookie_total_cap_limited') );
			return false;
		}

		if( !$this->checkUserAmountIsEnough($uid, $money) ){
			return;
		}

		if( !$this->checkUserPaymentPassword($uid, $password) ){
			return;
		}

		$md_rate = & load_model('rate');
		$rate = $md_rate->getRateOfRookie();
		$via = TRADE_VIA_ROOKIE;
		$closed_period = $md_rate->getClosedPeriodOfRookie();
		$auto_shift = 0;
		$shift_to = TRADE_AUTOSHIFT_NONE;

		$process_id = $md_obligation->addAutoProcessQueue($uid, $money, $rate, $closed_period, $via, $auto_shift, $shift_to);
		if(!$process_id){
			$this->setMsg( getLang('trade.add_rookie_queue_failed') );
			return;
		}
		$this->setCodeSuccess();
		$this->setData( array(
			'process_id' => $process_id,
			'msg' => getLang('trade.into_rookie_queue_success')
			)
		);

		//检查当前用户是否符合要求
		//检查当前系统排队额度是否超限
		//检查当日购买金额是否超限
		//进入自动购买队列

	}

	/**
	 *	鹰眼宝-默认自动转投鹰眼宝
	 *	检查用户余额
	 *	检查鹰眼宝队列资金
	 *	检查债权余额（扣除队列资金）
	 *	检查债权期限
	 */
	public function eagleeyed(){
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkTranscationAvailable()) {
			return;
		}
		$money = $this->postval('money');
		$password = $this->postval('passwd');

		$money = $this->convFenToHao( $money );//系统内最小计数单位为万分之一元，上传的money单位为分，故需要转换
		$this->logExtraColumns('money', $money );
		if($money < TRADE_EAGLEEYED_AMOUNT_LIMIT_MIN){
			$this->setMsg( getLang('trade.eagleeyed_amount_limit_min', array('amount' => TRADE_EAGLEEYED_AMOUNT_LIMIT_MIN/10000)) );
			return;
		}

		$md_obligation = & load_model('obligation');
		//检查当前鹰眼宝自动队列金额总计
		$apq_ee_amount = $md_obligation->getAPInQueueAmount( TRADE_VIA_EAGLEEYED );
		//检查当前自动队列金额总计
		$apq_amount = $md_obligation->getAPInQueueAmount();
		//检查当前所售债权金额总计
		$oblitotal_amount = $md_obligation->getObligationLeftAmount();

		$cap_amount = $oblitotal_amount - $apq_amount;

		do{
			//余额足够，跳出
			if($cap_amount >= $money){
				break;
			}
			//队列余额已满，跳出
			if($apq_ee_amount >= TRADE_QUEUE_EAGLEEYED_AMOUNT_TOTAL_CAP){
				$this->setMsg( getlang('trade.eagleeyed_total_cap_limited') );
				return;
			}
			//单次进入队列金额过大，跳出
			if($money >= TRADE_QUEUE_EAGLEEYED_AMOUNT_USER_CAP){
				//用户的当日排队总额先不做限制，用以筛选多次购买用户
				$this->setMsg( getlang('trade.eagleeyed_user_cap_limited', array('amount' => TRADE_QUEUE_EAGLEEYED_AMOUNT_USER_CAP/10000)) );
				return;
			}

		}while(false);


		$uid = $this->uid;

		if( !$this->checkUserAmountIsEnough($uid, $money) ){
			return;
		}

		if( !$this->checkUserPaymentPassword($uid, $password) ){
			return;
		}

		$md_rate = & load_model('rate');
		$rate = $md_rate->getRateOfEagleeyed();
		$via = TRADE_VIA_EAGLEEYED;
		$closed_period = $md_rate->getClosedPeriodOfEagleeyed();

		$auto_shift = 0;
		$shift_to = TRADE_AUTOSHIFT_NONE;

		$process_id = $md_obligation->addAutoProcessQueue($uid, $money, $rate, $closed_period, $via, $auto_shift, $shift_to);
		if(!$process_id){
			$this->setCode( CODES_AUTO_PROCESS_ADD_QUEUE_FAILED );
			$this->setMsg( getLang('trade.add_auto_queue_failed') );
			return;
		}
		$this->setCodeSuccess();
		$this->setData( array(
			'process_id' => $process_id,
			'msg' => getLang('trade.into_eagleeyed_queue_success')
			)
		);
	}

	/**
	 *	月宝产品，快速购买渠道
	 */
	public function fastEntry(){
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkTranscationAvailable()) {
			return;
		}
		$money = $this->postval('money');
		$password = $this->postval('passwd');
		$auto_shift = $this->postval('auto_shift');
		$shift_to = $this->postval('shift_to');

		$md_rate = & load_model('rate');
		
		$this->fixShiftTo($auto_shift, $shift_to);

		$money = $this->convFenToHao( $money );//系统内最小计数单位为万分之一元，上传的money单位为分，故需要转换
		$this->logExtraColumns('money', $money );
		if($money < TRADE_FAST_ENTRY_AMOUNT_LIMIT_MIN){
			$this->setMsg( getLang('trade.fastentry_amount_limit_min', array('amount' => TRADE_FAST_ENTRY_AMOUNT_LIMIT_MIN/10000)) );
			return;
		}

		$md_obligation = & load_model('obligation');
		//检查当前易购宝自动队列金额
		$apq_fe_amount = $md_obligation->getAPInQueueAmount( TRADE_VIA_FAST_ENTRY );
		//检查当前自动队列金额
		$apq_amount = $md_obligation->getAPInQueueAmount();
		//检查当前所有系统所售债权金额
		$oblitotal_amount = $md_obligation->getObligationLeftAmount();

		$cap_amount = $oblitotal_amount - $apq_amount;

		do{
			//余额足够，跳出
			if($cap_amount >= $money){
				break;
			}
			//队列余额已满，跳出
			if($apq_fe_amount >= TRADE_QUEUE_FAST_ENTRY_AMOUNT_TOTAL_CAP){
				$this->setMsg( getlang('trade.fastentry_total_cap_limited') );
				return;
			}
			//单次进入队列金额过大，跳出
			if($money >= TRADE_QUEUE_FAST_ENTRY_AMOUNT_USER_CAP){
				//用户的当日排队总额先不做限制，用以筛选多次购买用户
				$this->setMsg( getlang('trade.fastentry_user_cap_limited', array('amount' => TRADE_QUEUE_FAST_ENTRY_AMOUNT_USER_CAP/10000)) );
				return;
			}

		}while(false);

		$uid = $this->uid;

		
		if($auto_shift){
			$md_accounts = & load_model('accounts');
			$accinfo = $md_accounts->getUserAccountInfo($uid);
			if(!$accinfo['auto_shift']){
				$this->setMsg( getLang('trade.no_permission_of_auto_shift') );
				return;
			}
		}
		
		if( !$this->checkUserAmountIsEnough($uid, $money) ){
			return;
		}

		if( !$this->checkUserPaymentPassword($uid, $password) ){
			return;
		}

		$rate = $md_rate->getRateOfFastEntry();
		$via = TRADE_VIA_FAST_ENTRY;
		$closed_period = $md_rate->getClosedPeriodOfFastEntry();

		$md_obligation = & load_model('obligation');

		$process_id = $md_obligation->addAutoProcessQueue($uid, $money, $rate, $closed_period, $via, $auto_shift, $shift_to);
		if(!$process_id){
			$this->setCode( CODES_AUTO_PROCESS_ADD_QUEUE_FAILED );
			$this->setMsg( getLang('trade.add_auto_queue_failed') );
			return;
		}
		$this->setCodeSuccess();
		$this->setData( array(
			'process_id' => $process_id,
			'msg' => getLang('trade.into_fastentry_queue_success')
			)
		);
	}

	public function redeemObligation(){
		$this->sellObligation();
	}

	public function sellObligation(){
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkSellTranscationAvailable()) {
			return;
		}
		$hoid = $this->postval('id');
		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		
		$this->logExtraColumns('id', $hoid);
		$hobl = $md_obligation->getObligationHolding($hoid);
		if (empty($hobl)) {
			$this->setMsg( getLang('trade.user_obligation_not_exists') );
			return;
		}
		if($hobl['via'] == TRADE_VIA_ROOKIE){
			$this->setMsg( getLang('trade.rookie_cannot_sell') );
			return;
		}
		$closed_period = intval($hobl['closed_period']);
		if($closed_period != 0){
			$ct = strtotime( date('Y-m-d', strtotime($hobl['created_time'])) );
			$now = strtotime( date('Y-m-d', time()) );
			$days = floor(($now - $ct)/86400);
			if($days < $closed_period){
				$this->setMsg( getLang('trade.in_closed_period') );
				return;
			}
		}

		$inselling = $md_obligation->sellObligation( $uid, $hoid, $hobl['oid'], $hobl['left_amount'] );
		$sell_id = $md_obligation->getUserSellQueue($uid, $hoid);
		if(empty($sell_id)){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}

		$this->setCodeSuccess();
		$this->setData( array(
			'sell_id' => $sell_id,
			'msg' => getLang('trade.into_sell_queue_success')
			) 
		);
	}

	public function redeemObligationArray(){
		if(!$this->checkUserLogin()){
			return;
		}
		if (!$this->checkSellTranscationAvailable()) {
			return;
		}
		$idstr = $this->postval('idstr');
		$uid = $this->uid;
		$md_obligation = & load_model('obligation');
		
		$this->logExtraColumns('idstr', $idstr);
		$idarr = explode(',', $idstr);
		foreach ($idarr as &$id) {
			$id = intval($id);
		}
		$idarr = array_unique($idarr);
		if(empty($idarr)){
			$this->setMsg( getLang('trade.empty_idstr') );
			return;
		}
		foreach ($idarr as $hoid) {
			$hobl = $md_obligation->getObligationHolding($hoid);
			if (empty($hobl)) {
				$this->setMsg( getLang('trade.user_hoid_not_exists', array('uoid' => $hoid)) );
				return;
			}
			if($hobl['via'] == TRADE_VIA_ROOKIE){
				$this->setMsg( getLang('trade.rookie_cannot_sell') );
				return;
			}
			$closed_period = intval($hobl['closed_period']);
			if($closed_period != 0){
				$ct = strtotime( date('Y-m-d', strtotime($hobl['created_time'])) );
				$now = strtotime( date('Y-m-d', time()) );
				$days = floor(($now - $ct)/86400);
				if($days < $closed_period){
					$this->setMsg( getLang('trade.uoid_in_closed_period', array('uoid' => $hoid)) );
					return;
				}
			}
		}
		
		$failed_idarr = array();
		$sell_idarr = array();
		foreach ($idarr as $hoid) {
			$inselling = $md_obligation->sellObligation( $uid, $hoid, $hobl['oid'], $hobl['left_amount'] );
			$sell_id = $md_obligation->getUserSellQueue($uid, $hoid);
			if(empty($sell_id)){
				$failed_idarr[] = $hoid;
			}else{
				$sell_idarr[] = $hoid;
			}
		}
		
		$this->setCodeSuccess();
		$this->setData( array(
			'sell_idarr' => $sell_idarr,
			'failed_idarr' => $failed_idarr,
			'msg' => getLang('trade.into_sell_queue_success')
			) 
		);
	}

	public function getTradeStatus(){
		if(!$this->checkUserLogin()){
			return;
		}
		$id = $this->postval('id');

		$this->logExtraColumns('id', $id);
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getTradeStatus( $id );
		if(!empty($data)){
			$this->setCodeSuccess();
			$this->setData( $data );
		}elseif(null === $data){
			$this->setCode( CODES_TRADE_QUEUE_NOT_EXISTS );
			$this->setMsg( getLang('trade.trade_queue_not_exists') );
		}else{
			$this->setMsg( getLang('sys.serverunavailable') );
		}
	}

	public function getProcessStatus(){
		if(!$this->checkUserLogin()){
			return;
		}
		$id = $this->postval('id');

		$this->logExtraColumns('id', $id);
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getProcessStatus( $id );
		if(!empty($data)){
			$this->setCodeSuccess();
			$this->setData( $data );
		}elseif(null === $data){
			$this->setCode( CODES_AUTO_PROCESS_QUEUE_NOT_EXISTS );
			$this->setMsg( getLang('trade.auto_queue_not_exists') );
		}else{
			$this->setMsg( getLang('sys.serverunavailable') );
		}
	}

	public function getSellStatus(){
		if(!$this->checkUserLogin()){
			return;
		}
		$id = $this->postval('id');
		
		$this->logExtraColumns('id', $id);
		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getSellStatus( $id );
		if(!empty($data)){
			$this->setCodeSuccess();
			$this->setData( $data );
		}elseif(null === $data){
			$this->setCode( CODES_SELL_QUEUE_NOT_EXISTS );
			$this->setMsg( getLang('trade.sell_queue_not_exists') );
		}else{
			$this->setMsg( getLang('sys.serverunavailable') );
		}
	}

}