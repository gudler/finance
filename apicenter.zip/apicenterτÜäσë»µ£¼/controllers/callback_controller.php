<?php

class Callback_controller{
	
	private static $instance;

	protected $cipher = null;

	protected $tpl = null;

	protected $tplkv = array();

	private function _initCipher(){
		if(null === $this->cipher){
			$this->cipher = Cipher::getInstance();
		}
	}

	protected function & getCipher(){
		$this->_initCipher();
		return $this->cipher;
	}

	protected function getMDHashKey( $uid ){
		$this->_initCipher();
		return $this->cipher->getMDHashKey( $uid );
	}

	protected function mdataEncrypt($key, $str){
		$this->_initCipher();
		return $this->cipher->aesEncode( $key, $str );
	}

	protected function mdataDecrypt($key, $str){
		$this->_initCipher();
		return $this->cipher->aesDecode( $key, $str );
	}

	protected function setExpires($ts){
		if($ts){
			header('Expires: '. gmdate('r', time()+$ts));
		}
	}

	protected function setTemplate( $tpl_name ){
		$this->tpl = $tpl_name;
	}

	protected function setValue( $key, $value ){
		$_key = strtolower($key);
		$code = ord($_key[0]);
		if($_key == '_post' || $_key == '_get' || $_key == '_request' || $code > 122 || $code < 95 || $code == 96 ){
			exit("Error! Key [$key] is not allowed");
		}
		$this->tplkv[$key] = $value;
	}

	protected function setCodeSuccess(){
		$this->setValue('code', CODES_OK);
	}

	protected function setCodeFailed(){
		$this->setValue('code', CODES_FAILED);
	}

	protected function setMsg($msg){
		$this->setValue('msg', $msg);
	}


	protected function getViewFilePath(){
		$view_file = DIR_VIEW . $this->tpl . '.html';
		if(!file_exists($view_file)){
			exit("Template [{$this->tpl}] not exists.");
		}
		return $view_file;
	}

	public function __construct(){
		self::$instance = & $this;
	}

	public static function &getInstance(){
		return self::$instance;
	}

	public function notExists(){
		exit(sprintf('NOT EXISTS: Controller: %s, Method: %s'
			, (isset($_GET['c'])?$_GET['c']:'NOT PASS')
			, (isset($_GET['m'])?$_GET['m']:'NOT PASS')
			));
	}

	public function output(){
		$_error_info = ob_get_clean();
		if(!empty($this->tplkv)){
			extract($this->tplkv);
		}
		include( $this->getViewFilePath() );
		ob_end_flush();
	}
}