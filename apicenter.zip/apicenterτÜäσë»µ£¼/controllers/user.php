<?php
require_once PATH_BASE_CONTROLLER;

class User extends Controller{

	public function __construct(){
		parent::__construct();
	}

	protected function passwordStrengthCheck($passwd){
		if(strlen($passwd)<6){
			return getlang('user.passwordlengthlimits');
		}
		return true;
	}

	protected function getSalt($length){
		$map = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_';
		$max = strlen($map) - 1;
		$str = '';
		do{
			$str .= $map[mt_rand(0, $max)];
		}while(--$length);
		return $str;
	}

	protected function checkMobileSMSLimited($mobile){
		$md_sms = & load_model('sms');
		$date = date('Y-m-d');
		$arr = $md_sms->getByDate($mobile, $date, 50);
		if(empty($arr)){
			return false;
		}
		$len = count($arr);
		if($len >= 50){
			$this->setMsg( getlang('user.sms_day_limited') );
			return true;
		}
		$row = $arr[0];
		if(time() - strtotime($row['created_time']) < 60){
			$this->setMsg( getlang('user.sms_minute_limited') );
			return true;
		}
		if($len >= 7){
			$row = $arr[6];
			if(time() - strtotime($row['created_time']) < 3600){
				$this->setMsg( getlang('user.sms_hour_limited') );
				return true;
			}
		}
		return false;
	}

	public function uploadImage(){
		$field_name = 'img';
		if(isset($_FILES[$field_name]) && isset($_FILES[$field_name]['error']) && $_FILES[$field_name]['error'] == UPLOAD_ERR_OK){
			$name = $_FILES[$field_name]['name'];
			$tmp_name = $_FILES[$field_name]['tmp_name'];
			$type = strtolower($_FILES[$field_name]['type']);
			$size = $_FILES[$field_name]['size'];
			$cnfs = config_item('upload');
			if(in_array($type, array(
				'image/jpeg', 'image/png', 'image/gif'
				))){
				$dir = $cnfs['image_folder'];
				if(strrpos($dir, '/') != strlen($dir) - 1){
					$dir .= '/';
				}
				$ddir = date('Ymd');
				if(!file_exists($dir . $ddir)){
					mkdir($dir . $ddir);
				}
				$filename = $ddir . '/' . md5(time().$tmp_name) . '.' . pathinfo($name, PATHINFO_EXTENSION);
				if(move_uploaded_file($tmp_name, $dir . $filename)){
					$this->setCodeSuccess();
					$web_dir = $cnfs['image_web_entry'];
					if(strrpos($web_dir, '/') != strlen($web_dir) - 1){
						$web_dir .= '/';
					}
					$this->setData(array('url' => $web_dir . $filename));
				}else{
					$this->setMsg( getlang('user.uploadeimageerror') );
				}
			}else{
				$this->setMsg( getlang('user.uploadeimagelimits') );
			}
		}
	}

	public function checkPhoneExists(){
		$phone = trim($this->postval('phone'));
		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}
		$md_user = & load_model('user');
		$user = $md_user->getUserByPhone($phone);
		$this->setCodeSuccess();
		$this->setData(array('exists' => $user ? 1 : 0));
	}

	protected function processSmsCodeRequest($phone,$type,$logged=false) {
		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}
		if( $this->checkMobileSMSLimited($phone) ){
			return;
		}
		$md_sms = & load_model('sms');
		$code = mt_rand(10000, 99999);

		$type = strtolower($type);
		$md_user = & load_model('user');
		$user = $md_user->getUserByPhone($phone);
		//2019-03-06 修复更换银行卡预留手机号时，检查用户不存在BUG
		if (($logged || $type!=SMS_CODE_TYPE_REG) && $type!=SMS_CODE_TYPE_CARDMOBICHG) {
			if (empty($user)) {
				$this->setMsg( getlang('user.notexists') );
				return;
			}
		}
		if ($type==SMS_CODE_TYPE_REG && !empty($user)) {
			$this->setMsg( getlang('user.phoneexists') );
			return;
		}
		switch ($type) {
			case SMS_CODE_TYPE_REG:
				$template = 'SMS_5580193';
				break;
			case SMS_CODE_TYPE_RESET_LOGINPW:
				$template = 'SMS_5580191';
				break;
			case SMS_CODE_TYPE_RESET_PAYPW:
				$template = 'SMS_7261548';
				break;
			case SMS_CODE_TYPE_WITHDRAW:
				$template = 'SMS_7585087';
				break;
			case SMS_CODE_TYPE_CARDMOBICHG:
				$template = 'SMS_26335244';
				break;
			case SMS_CODE_TYPE_OFFLINE_RECHARGE:
				$template = 'SMS_33850096';
				break;
			default:
				$type = SMS_CODE_TYPE_INFOCHG;
				$template = 'SMS_5580190';
				break;
		}
		// 2018-08-23,69豪车整合
		// 短信验证码数据记录添加$app，用于区分是鹰眼理财还是69豪车，然后发送的验证码带不同的app签名
		$app = $this->getApp();
		$res = $md_sms->addPhoneCode($phone, $code, $type, $template, $app);
		if($res){
			$success = true;
			$this->setCodeSuccess();
		}else{
			$success = false;
			$this->setMsg( getlang('sys.serverunavailable') );
		}
		$this->setData(array('success' => $success));		
	}

	public function getPhoneSMSCode(){
		$phone = trim($this->postval('phone'));
		$type = trim($this->postval('type'));
		$this->processSmsCodeRequest($phone,$type,false);
	}

	public function getPhoneSMSCodeLogged(){
		if(!$this->checkUserLogin()){
			return;
		}
		$phone = trim($this->postval('phone'));
		$type = trim($this->postval('type'));
		$this->processSmsCodeRequest($phone,$type,true);
	}

	public function regPhone(){
		$phone = trim($this->postval('phone'));
		$code = trim($this->postval('code'));
		$passwd = trim($this->postval('passwd'));
		$inviter = trim($this->postval('inviter'));
		$this->logExtraColumns('inviter', $inviter);		
		// 2018-02-26
		// 新增邀请码解码。由于编码是服务器提供的，同样的解码也是服务器来做。
		// 目前的网页邀请码解码的相关逻辑需要去掉。
		if (!empty($inviter)) {
			$inviter = base_convert($inviter, 16, 10);
		}

		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_REG);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$md_user = & load_model('user');
		$user = $md_user->getUserByPhone($phone);
		if(empty($user)){
			$check_res = $this->passwordStrengthCheck($passwd);
			if(true !== $check_res){
				$this->setMsg($check_res);
				return;
			}
			$salt = $this->getSalt(8);
			$pwd = $this->encryptPasswd($passwd, $salt);
			$id = $md_user->createUserWithPasswd($phone, $pwd, $salt);
			if(!$id){
				$this->setMsg( getlang('sys.serverunavailable') );
				return;
			}
			// 只有等iOS都升级到最新版才能开放
			$md_accounts = & load_model('accounts');
			$md_accounts->regAccountEgg( $id );
			
			if(!empty($inviter)){
				// 2018-02-26 
				// 判断邀请用户是否存在
				$inviter_user = $md_user->getUserById($inviter);
				if ($inviter_user!=false && !empty($inviter_user)) {
					$md_user->createUsersRel($inviter, $id);
			    }
			}
		}else{
			$id = $user['id'];
		}
		$token = $md_user->getUserTokenById($id, $this->getDeviceID(), $this->getIP(), $this->getUserTokenChannel());
		if(empty($token)){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$invite_code = base_convert($id, 10, 16);		
		$this->setData(array('token' => $token,'invite_code' => $invite_code));
		$md_sms->useCode($phone, $code);
		$this->setCodeSuccess();
	}

	public function loginPhoneWithPassword(){
		$phone = trim($this->postval('phone'));
		$passwd = trim($this->postval('passwd'));
		$md_user = & load_model('user');
		$user = $md_user->getUserByPhone($phone);
		if(empty($user)){
			$this->setMsg( getlang('user.notexists') );
			return;
		}
		if($user['passwd'] != $this->encryptPasswd($passwd, $user['salt'])){
			$this->setMsg( getlang('user.passworderror') );
			return;
		}
		$token = $md_user->getUserTokenById($user['id'], $this->getDeviceID(), $this->getIP(), $this->getUserTokenChannel());
		if(empty($token)){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$invite_code = base_convert($user['id'], 10, 16);		
		$this->setData(array('token' => $token,'invite_code' => $invite_code));
		$this->setCodeSuccess();
	}

	public function setUserPassword(){
		$phone = trim($this->postval('phone'));
		$passwd = trim($this->postval('passwd'));
		$code = trim($this->postval('code'));
		
		if(!$this->checkUserLogin()){
			return;
		}
		$check_res = $this->passwordStrengthCheck($passwd);
		if(true !== $check_res){
			$this->setMsg($check_res);
			return;
		}
		$id = $this->uid;

		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_RESET_LOGINPW);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$md_user = & load_model('user');
		$user = $md_user->getUserById($id);
		if(empty($user)){
			$this->setMsg( getlang('user.tokenexpired') );
			return;
		}
		$phoneuser = $md_user->getUserByPhone($phone);
		$salt = $this->getSalt(8);
		$pwd = $this->encryptPasswd($passwd, $salt);
		if(empty($phoneuser)){
			$md_user->setUserPassword($id, $pwd, $salt, $phone);
		}else{
			$md_user->setUserPassword($id, $pwd, $salt);
		}
		$this->setCodeSuccess();
		$md_sms->useCode($phone, $code);
	}

	public function setUserPayPassword(){
		$passwd = trim($this->postval('passwd'));
		if(!$this->checkUserLogin()){
			return;
		}
		if(!preg_match('/^[0-9]{6}$/', $passwd)){
			$this->setMsg( getlang('user.pay_password_invalid') );
			return;
		}
		$id = $this->uid;
		
		$md_user = & load_model('user');
		$user = $md_user->getUserById($id);
		if(empty($user)){
			$this->setMsg( getlang('user.tokenexpired') );
			return;
		}

		$salt = $user['salt'];
		$pwd = $this->encryptPasswd($passwd, $salt);
		$md_user->setUserPayPassword($id, $pwd, $salt);
		$this->setCodeSuccess();
	}

	public function resetUserPasswordByCode(){
		$phone = trim($this->postval('phone'));
		$passwd = trim($this->postval('passwd'));
		$code = trim($this->postval('code'));
		
		$check_res = $this->passwordStrengthCheck($passwd);
		if(true !== $check_res){
			$this->setMsg($check_res);
			return;
		}
		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_RESET_LOGINPW);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$md_user = & load_model('user');
		$phoneuser = $md_user->getUserByPhone($phone);
		$id = $phoneuser['id'];
		$salt = $this->getSalt(8);
		$pwd = $this->encryptPasswd($passwd, $salt);		
		$md_user->setUserPassword($id, $pwd, $salt);
		$this->setCodeSuccess();
		$md_sms->useCode($phone, $code);
		// 2018-05-23
		// 重置密码后原来用户登录的token都标记为失效
		$md_user->setUserLogoutByID($phoneuser['id']);
		// 重新获取新token
		$token = $md_user->getUserTokenById($phoneuser['id'], $this->getDeviceID(), $this->getIP(), $this->getUserTokenChannel());
		if(empty($token)){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$this->setData(array('token' => $token));
	}

	public function resetUserPayPasswordByCode(){
		$phone = trim($this->postval('phone'));
		$passwd = trim($this->postval('passwd'));
		$code = trim($this->postval('code'));
		
		if(!preg_match('/^[0-9]{6}$/', $passwd)){
			$this->setMsg( getlang('user.pay_password_invalid') );
			return;
		}
		
		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_RESET_PAYPW);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$md_user = & load_model('user');
		$phoneuser = $md_user->getUserByPhone($phone);
		$id = $phoneuser['id'];
		$salt = $phoneuser['salt'];
		$pwd = $this->encryptPasswd($passwd, $salt);
		$md_user->setUserPayPassword($id, $pwd);
		$this->setCodeSuccess();
		$md_sms->useCode($phone, $code);
	}
	
	public function getUserInfo(){

		if(!$this->checkUserLogin()){
			return;
		}
		$id = $this->uid;
		
		$md_user = & load_model('user');
		$info = $md_user->getUserById($id);
		if(isset($info['passwd'])){
			unset($info['passwd']);
		}
		if(!empty($info['pay_passwd'])){
			$info['pay_passwd'] = true;
		}else{
			$info['pay_passwd'] = false;
		}
		if(isset($info['salt'])){
			unset($info['salt']);
		}
		if(isset($info['id'])){
			$tmp = $md_user->getUserInfoById($id);
			if(!empty($tmp)){
				$info = array_merge($info, $tmp);
			}
		}
		$this->setCodeSuccess();
		$this->setResult($info);
	}
	
	
	public function editPassword(){
		$passwd_old = trim($this->postval('passwd_old'));
		$passwd = trim($this->postval('passwd'));

		if(!$this->checkUserLogin()){
			return;
		}
		$check_res = $this->passwordStrengthCheck($passwd);
		if(true !== $check_res){
			$this->setMsg($check_res);
			return;
		}
		$id = $this->uid;
		
		$md_user = & load_model('user');

		$user = $md_user->getUserById($id);
		if(empty($user)){
			$this->setMsg( getlang('user.tokenexpired') );
			return;
		}
		
		if( $user['passwd'] != $this->encryptPasswd($passwd_old, $user['salt']) ){
			$this->setMsg( getlang('user.oldpassworderror') );
			return;
		}

		$salt = $this->getSalt(8);
		$pwd = $this->encryptPasswd($passwd, $salt);
		$md_user->setUserPassword($id, $pwd, $salt);
		$this->setCodeSuccess();
	}

	public function verifyIdentity(){
		return;
		if(!$this->checkUserLogin()){
			return;
		}
		$idtype = $this->postval('idtype');
		$realname = $this->postval('realname');
		$identcode = $this->postval('identcode');

		$id = $this->uid;
		
		$md_user = & load_model('user');
		$data = $md_user->getUserInfoById($id);
		if(isset($data['idverified']) && $data['idverified'] == 1){
			$this->setMsg( getlang('user.idverifiedcannotbemodified') );
			return;
		}
		if(null === $idtype){
			$idtype = $data['idtype'];
		}
		if(null === $realname){
			$realname = $data['realname'];
		}
		if(null === $identcode){
			$identcode = $data['identcode'];
		}
		$user = $md_user->setUserIdentityById($id, $idtype, $realname, $identcode);
		if(empty($user)){
			$this->setMsg( getlang('user.tokenexpired') );
			return;
		}

		$this->setCodeSuccess();
	}
	
	public function setUserinfo(){
		if(!$this->checkUserLogin()){
			return;
		}
		$sex = $this->postval('sex');
		$birthday = $this->postval('birthday');
		$himg = $this->postval('himg');

		$id = $this->uid;
		
		$md_user = & load_model('user');
		$data = $md_user->getUserInfoById($id);
		if(null === $sex){
			$sex = $data['sex'];
		}
		if(null === $birthday){
			$birthday = $data['birthday'];
		}
		if(null === $himg){
			$himg = $data['himg'];
		}
		$user = $md_user->setUserInfoById($id, $sex, $birthday, $himg);
		if(empty($user)){
			$this->setMsg( getlang('user.tokenexpired') );
			return;
		}

		$this->setCodeSuccess();
	}
	
	public function smsCodeCheck(){
		if(!$this->checkUserLogin()){
			return;
		}
		
		$phone = trim($this->postval('phone'));
		$code = trim($this->postval('code'));
		$type = trim($this->postval('type'));
		$md_sms = & load_model('sms');
		
		$arr = $md_sms->getPhoneCode($phone, $type);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		$this->setResult(array('matched' => $matched));
		
		$this->setCodeSuccess();
	}

	public function getInviteLink(){

		$ts = time();
		$ts_start = strtotime('2017-01-01 00:00:00');
		$ts_end = strtotime('2017-01-03 18:30:00');
		$in_event = false;
		if ($ts + 1*3600 >= $ts_start && $ts <= $ts_end) {
			$in_event = true;
		}
		if($in_event){
			$url = 'http://www.eagleeyedfinance.com/events/appinvite/doubleRewards3.html';
		}else{
			$url = 'http://www.eagleeyedfinance.com/events/appinvite/innercontent.html';
		}
		$data =  array(
			'is_closed' => false,
			'info_url' => $url,
			'msg' => ''
		);

		$share_url = 'http://www.egeyed.com/events/appinvite/';
		$share_title = '超级新人专享年利率（预期）28.88%！';
		$share_content = '所有债权均为豪车按揭且真实可查，年利率（预期）高达8.25%，稳健又高收益！想了解详情吗？';
		$share_url_items = [
			// 新邀请的规则：从2017-12-09日开始，一年内被邀请注册的人，这个人一年内（365天）的利息的15%作为奖励给到一级邀请者，5%给到二级邀请者			
			[
				'start_time' => EVENT_NEW_INVITE_START_TIME,
				'end_time' => EVENT_NEW_INVITE_END_TIME,        
				'url' => 'http://www.egeyed.com/events/appinvite201712/',
				'title' => '邀请好友，轻松拿万元奖励！',
				'content' => '所有债权均为豪车按揭且真实可查，年利率（预期）高达8.25%，稳健又高收益！想了解详情吗？',				
				'description' => '201712新邀请',
			]
		];
		$now = time();        
		foreach($share_url_items as $item) {
			if (isset($item['start_time']) && !empty($item['start_time'])){
				$start = strtotime($item['start_time']);
				if ( $now<$start) {
					continue;
				}
			}
			if (isset($item['end_time']) && !empty($item['end_time'])){
				$end = strtotime($item['end_time']);
				if ( $now>$end) {
					continue;
				}            
			}
			$share_url = $item['url'];
			$share_title = $item['title'];
			$share_content = $item['content'];
			break;
		} 		
		
		if($this->checkUserLogin()){
			// $key = '6C1EB094877D1D8AC339D5F6A9F5C39E';
			// $x = 100699;
			// $invite_str = urlencode( $this->mdataEncrypt($key, intval($this->uid) + $x) );
			$invite_str = base_convert($this->uid, 10, 16);
			$data['login_expired'] = false;
			$data['share_url'] = $share_url.$invite_str;
		}else{
			$data['login_expired'] = true;
			$data['share_url'] = $share_url;
			$data['nologin_confirm'] = '登录后邀请才能参加活动，您确定不登录直接分享吗？';
		}

		if($in_event){
			$data['share_title'] = '现金大放送！只要您注册，即可领取20元现金！';
			$data['share_content'] = '与其花钱做广告，不如现金送给您！邀请好友现金50元，好友现金20元，多邀多得！只要您注册并邀请108个好友成功，即可获得5420元（一台iPhone7）！';
			$data['share_image'] = 'http://img.egeyed.com/static/web/img/hongbao.png';
		}else{
			$data['share_title'] = $share_title;
			$data['share_content'] = $share_content;
			$data['share_image'] = 'http://img.egeyed.com/static/web/img/whyus4.png';
		}
		
		$this->setResult($data);
		$this->setCodeSuccess();
	}

	public function getInviteCode(){
		if(!$this->checkUserLogin()){
			return;
		}
		$id = $this->uid;
		$data =  array(
			'code' => base_convert($this->uid, 10, 16),
		);
		$this->setResult($data);
		$this->setCodeSuccess();
	}


	public function logout(){
		$token = trim($this->postval('token'));
		$md_user = & load_model('user');
		$user = $md_user->getUserIdByToken($token);
		$uid = 0;
		if(!empty($user)){
			$uid = $user['id'];
		}
		$md_user->setUserLogout($token);
		// 2018-03-15
		// 用户登出后，增加删除device token逻辑，防止用户再收到相关的推送消息
		$removed = $md_user->removeDeviceToken($uid);
		$this->setCodeSuccess();		
	}

}