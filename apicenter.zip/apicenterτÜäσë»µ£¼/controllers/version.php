<?php
require_once PATH_BASE_CONTROLLER;

class Version extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function android(){
		$pkg = $this->postval('pkg');
		$old_version = $this->postval('version');
		$old_md5 = $this->postval('md5');
		$device_id = $this->getDeviceID();
		$current_version = '1.7.3';
		$current_md5 = '524c47400105e51f5d329c6d6c9c8e4e';
		$data = array('version' => $current_version, 'md5' => $current_md5, 'need_update' => false);
		if($pkg == 'com.egeyed.yylc' && version_compare($current_version, $old_version)>0){
			$data['need_update'] = true;
			$data['url'] = 'http://s1.egeyed.com/apk/egeyed-20180930-1.7.3.apk';//升级包全包
			$data['message'] = <<<eot
1、优化APP体验
2、修复已知问题
eot;
		}
		$this->logExtraColumns('pkg', $pkg);
		$this->logExtraColumns('version', $old_version);
		$this->logExtraColumns('md5', $old_md5);
		$this->setCodeSuccess();
		$this->setData($data);
	}

	public function iphone(){
		$this->setCodeSuccess();
		$data = '请到AppStore下载最新版本';
		$this->setData($data);
	}

	public function server() {
		$data = array(
			'version' => '1.6.1', 
			'update_date' => '2017-11-25 18:00:00');
			$data['message'] = <<<eot
1. 新的邀请功能
2. 修复已知问题
eot;
		$this->setCodeSuccess();
		$this->setData($data);
	}
}