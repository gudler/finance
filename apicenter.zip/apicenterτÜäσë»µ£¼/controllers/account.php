<?php
require_once PATH_BASE_CONTROLLER;
require_once PATH_PAYMENT_FUIOU;

class Account extends Controller{

	/**
	 *	检查用户余额是否足够
	 */
	protected function checkWithdrawAmountIsEnough($uid, $money){
		$md_accounts = & load_model('accounts');

		$accinfo = $md_accounts->getUserCurrentAccount(	$uid );
		if(!$accinfo){
			$this->setCode( CODES_ACCOUNT_INFO_GETS_FAILED );
			$this->setMsg( getLang('account.infogetsfailed') );
			return false;
		}
		if( $accinfo['amount'] < $money){
			$this->setCode( CODES_ACCOUNT_AMOUNT_NOT_ENOUGH );
			$this->setMsg( getLang('account.amountnotenough') );
			return false;
		}
		$md_obligation = & load_model('obligation');
		$oblqueues = $md_obligation->getOblQueue( $uid );
		if(!empty($oblqueues)){
			$sum = 0;
			foreach ($oblqueues as $oblqueue) {
				$sum += intval($oblqueue['amount']);
			}
			$autoqueues = $md_obligation->getAutoProcessQueue( $uid );
			if(!empty($autoqueues)){
				foreach ($autoqueues as $autoqueue) {
					$sum += intval($autoqueue['amount']);
				}
			}
			$left_amount = $accinfo['amount'] - $sum;
			if( $left_amount < $money ){
				$left_amount = $this->convHaoToFen( $left_amount );
				$this->setMsg( getLang('account.withdraw_amount_not_enough', array('amount' => floor($left_amount/100) . '.' . ($left_amount%100), 'inqueue_amount' => floor($sum/100) . '.' . ($sum%100) )) );
				return false;
			}
		}
		return true;
	}

	public function __construct(){
		parent::__construct();
	}

	/**
	 *	绑定银行卡，如果支付方不验证手机，我方需要验证用户手机，以证明是用户本人在进行绑定操作。
	 */
	public function bindCard(){
		if(!$this->checkUserLogin()){
			return;
		}
		//$idtype = $this->postval('idtype');
		$idtype = 0;//默认身份证
		$idno = $this->postval('idno');
		$phone = $this->postval('phone');
		$realname = $this->postval('realname');
		$cardno = $this->postval('cardno');

		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}

		//校验身份证是否合法
		$helper = load_helper('certcardrpc');
		if(!$helper::check_id($idno)){
			$this->setMsg( getlang('account.cert_card_rpc_invalid') );
			return;
		}

		$uid = $this->uid;

		$md_accounts = & load_model('accounts');

		$info = $md_accounts->getUserAccountInfo($uid);
		if(!empty($info)){
			if($info['status'] == USRACCOUNT_STATUS_OFFLINE){
				//线下用户不可绑卡，但返回为服务不可用
				$this->setMsg( getlang('sys.serverunavailable') );
				return;
			}elseif($info['status'] == USRACCOUNT_STATUS_NORMAL){
				$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
				if (!empty($accinfo)) {
					//用户已绑卡
					$this->setMsg( getlang('account.bankcardexists') );
					return;
				}
			}
		}

		//检查银行卡是否支持
		$bkq = new BankcardQuery_pub;
		$bkq->setBankcardno( $cardno );
		$res = $bkq->getUseful();
		if(false === $res){
			$this->setMsg( getlang('account.card_verify_service_down') );
			return;
		}
		if($res['code'] != BANK_CARD_OK){
			$error = '';
			if(!empty($res['msg'])){
				$error = $res['msg'];
			}else{
				$error = getlang('account.card_verify_service_down');
			}
			$this->setMsg( $error );
			return;
		}
		if($res['cardtype'] != BANK_CARD_TYPE_DEBIT_CARD){
			$this->setMsg( getlang('account.card_type_only_debit_card') );
			return;
		}
		$bank = $res['bankname'];


		$key = $this->getMDHashKey( $uid );
		$_cardno = $this->mdataEncrypt($key, $cardno);
		$_idno = $this->mdataEncrypt($key, $idno);
		$_phone = $this->mdataEncrypt($key, $phone);
		$_realname = $this->mdataEncrypt($key, $realname);

		$key_identcode = $this->getUniqKey( $idno );

		$numb = $md_accounts->countAccByIdentID($key_identcode);

		if($numb && $numb >= LIMIT_ACC_SAME_USER){
			$this->setMsg( getlang('account.same_user_accounts_limit') );
			return;
		}


		$seqid = $md_accounts->regBankAccountVerify($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone);
		if(empty($seqid)){
			$this->setMsg( getlang('account.get_bankacc_verify_id_failed') );
			return false;
		}
		//四要素验证
		$vci = new VerifyCardInfo_pub;
		$vci->setSequnceID( $seqid );
		$vci->setBankcardno( $cardno );
		$vci->setUsername( $realname );
		$vci->setIDNumber( $idno );
		$res = $vci->getResponse();

		if(true !== $res){
			if(empty($res)){
				$res = getLang('account.card_verify_service_down');
			}
			$this->setMsg( $res );
			return;
		}
		$key_mobile = $this->getUniqKey( $phone );
		$key_cardno = $this->getUniqKey( $cardno );
		$key_identcode = $this->getUniqKey( $idno );
		$bool = $md_accounts->regBankAccount($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone, $key_mobile, $key_cardno, $key_identcode);
		if(!$bool){
			$msg = stored_messages();
			if(empty($msg)){
				$msg = getlang('sys.serverunavailable');
			}
			$this->setMsg( $msg );
			return;
		}
		if(null === $info){
			$md_accounts->regAccount( $uid );
			$rel = $md_accounts->getUserRel( $uid );
			if( !empty($rel) ){
				$md_accounts->setUserRelBindCardTime( $uid );
			}
		}elseif($info && $info['status'] == USRACCOUNT_STATUS_EGG){
			$md_accounts->updateAccountNormal( $uid );
		}
		$this->setData('success', true);
		$this->setCodeSuccess();
	}

	public function dataEncrypt() {
		if(!$this->checkUserLogin()){
			return;
		}
		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}

		$uid = $this->postval('uid');
		$data = $this->postval('data');
		$key = $this->getMDHashKey( $uid );
		$data2  = $this->mdataEncrypt($key, $data);
		$udata = $this->getUniqKey($data);
		$result = array (
			'data' => $data2,
			'ukey' => $udata,
		);
		$this->setData('data', $result);
		$this->setCodeSuccess();
	}

	public function dataDecrypt() {
		if(!$this->checkUserLogin()){
			return;
		}
		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}

		$uid = $this->postval('uid');
		$data = $this->postval('data');
		$key = $this->getMDHashKey( $uid );
		$data2  = $this->mdataDecrypt($key, $data);
		$this->setData('data', $data2);
		$this->setCodeSuccess();
	}

	/**
	 *	绑定银行卡验证，做测试用
	 */
	public function verifyCard(){
		if(!$this->checkUserLogin()){
			return;
		}
		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		//$idtype = $this->postval('idtype');
		$idtype = 0;//默认身份证
		$idno = $this->postval('idno');
		$realname = $this->postval('realname');
		$cardno = $this->postval('cardno');
		$phone = $this->postval('phone');

		//校验身份证是否合法
		$helper = load_helper('certcardrpc');
		if(!$helper::check_id($idno)){
			$this->setMsg( getlang('account.cert_card_rpc_invalid') );
			return;
		}

		//检查银行卡是否支持
		$bkq = new BankcardQuery_pub;
		$bkq->setBankcardno( $cardno );
		$res = $bkq->getUseful();
		if(false === $res){
			$this->setMsg( getlang('account.card_verify_service_down') );
			return;
		}
		if($res['code'] != BANK_CARD_OK){
			$error = '';
			if(!empty($res['msg'])){
				$error = $res['msg'];
			}else{
				$error = getlang('account.card_verify_service_down');
			}
			$this->setMsg( $error );
			return;
		}
		if($res['cardtype'] != BANK_CARD_TYPE_DEBIT_CARD){
			$this->setMsg( getlang('account.card_type_only_debit_card') );
			return;
		}
		$bank = $res['bankname'];

		$uid = 1; // system account
		$key = $this->getMDHashKey( $uid );
		$_cardno = $this->mdataEncrypt($key, $cardno);
		$_idno = $this->mdataEncrypt($key, $idno);
		$_phone = $this->mdataEncrypt($key, $phone);
		$_realname = $this->mdataEncrypt($key, $realname);

		$md_accounts = & load_model('accounts');

		$seqid = $md_accounts->regBankAccountVerify($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone);
		if(empty($seqid)){
			$this->setMsg( getlang('account.get_bankacc_verify_id_failed') );
			return false;
		}
		//四要素验证
		$vci = new VerifyCardInfo_pub;
		$vci->setSequnceID( $seqid );
		$vci->setBankcardno( $cardno );
		$vci->setUsername( $realname );
		$vci->setIDNumber( $idno );
		$res = $vci->getResponse();

		if(true !== $res){
			if(empty($res)){
				$res = getLang('account.card_verify_service_down');
			}
			$this->setMsg( $res );
			return;
		}
		$this->setData('success', true);
		$this->setCodeSuccess();
	}

	public function switchAmountShift(){
		if(!$this->checkUserLogin()){
			return;
		}
		$onoff = $this->postval('onoff');//on: 开启; off: 关闭
		$onoff = trim($onoff);
		$onoff = strtolower($onoff);
		if($onoff == 'on'){
			$amount_shift = 1;
		}elseif($onoff == 'off'){
			$amount_shift = 0;
		}else{
			$this->setMsg( getlang('account.amount_shift_onoff_invalid') );
			return;
		}
		$uid = $this->uid;
		$md_accounts = & load_model('accounts');
		$info = $md_accounts->getUserAccountInfo( $uid );
		if(false === $info){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}elseif(null === $info){
			$bankacc = $md_accounts->getUserCurrentBankAccount( $uid );
			if(!empty($bankacc)){
				$md_accounts->regAccount( $uid );
				$info = $md_accounts->getUserAccountInfo( $uid );
			}else{
				$this->setMsg( getlang('account.need_bind_one_card') );
				return;
			}
		}
		$current_shift = $info['amount_shift'];
		$bool = true;
		if($current_shift != $amount_shift){
			if($amount_shift){
				$bool = $md_accounts->setAmountShiftOn( $uid );
			}else{
				$bool = $md_accounts->setAmountShiftOff( $uid );
			}
		}
		if($bool){
			if($amount_shift){
				$msg = getlang('account.amount_shift_on_ok');
			}else{
				$msg = getlang('account.amount_shift_off_ok');
			}
			$this->setCodeSuccess();
		}else{
			if($amount_shift){
				$msg = getlang('account.amount_shift_on_failed');
			}else{
				$msg = getlang('account.amount_shift_off_failed');
			}
		}
		$this->setMsg( $msg );
	}

	public function changeBoundCardMobile(){
		if(!$this->checkUserLogin()){
			return;
		}
		$phone = $this->postval('phone');
		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}
		$md_sms = & load_model('sms');
		$code = trim($this->postval('code'));
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_CARDMOBICHG);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$uid = $this->uid;
		$key = $this->getMDHashKey( $uid );
		$_phone = $this->mdataEncrypt($key, $phone);
		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );

		$_cardno = $accinfo['cardno'];
		$_idno = $accinfo['identcode'];
		$_realname = $accinfo['realname'];
		$key_mobile = $this->getUniqKey( $phone );
		$key_cardno = $accinfo['key_cardno'];
		$key_identcode = $accinfo['key_identcode'];
		$idtype = $accinfo['idtype'];
		$bank = $accinfo['bank'];

		if(!empty($accinfo) && isset($accinfo['id'])){
			$bool = $md_accounts->removeBankAccount($uid, $accinfo['id']);
		}

		$bool = $md_accounts->regBankAccount($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone, $key_mobile, $key_cardno, $key_identcode);
		if(!$bool){
			$msg = stored_messages();
			if(empty($msg)){
				$msg = getlang('sys.serverunavailable');
			}
			$this->setMsg( $msg );
			return;
		}
		$info = $md_accounts->getUserAccountInfo($uid);
		if(null === $info){
			$md_accounts->regAccount( $uid );
		}
		$this->setData('success', true);
		$this->setCodeSuccess();

	}

	/**
	 *	换绑定银行卡。
	 */
	public function changeBoundCard(){
		if(!$this->checkUserLogin()){
			return;
		}
		$idtype = 0;//默认身份证
		$idno = $this->postval('idno');
		$user = $this->postval('user');
		$phone = $this->postval('phone');
		$realname = $this->postval('realname');
		$cardno = $this->postval('cardno');

		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}

		//校验身份证是否合法
		$helper = load_helper('certcardrpc');
		if(!$helper::check_id($idno)){
			$this->setMsg( getlang('account.cert_card_rpc_invalid') );
			return;
		}

		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$md_user = & load_model('user');
		$info = $md_user->getUserByPhone($user);
		if(empty($info) || !isset($info['id']) || empty($info['id'])){
			$this->setMsg( getlang('user.notexists') );
			return;
		}
		$uid = $info['id'];

		//检查银行卡是否支持
		$bkq = new BankcardQuery_pub;
		$bkq->setBankcardno( $cardno );
		$res = $bkq->getUseful();
		// 2017-11-29
		// 修改返回错误提示信息
		if(false === $res){
			$this->setMsg( getlang('account.card_verify_service_down') );
			return;
		}
		if($res['code'] != BANK_CARD_OK){
			$error = '';
			if(!empty($res['msg'])){
				$error = $res['msg'];
			}else{
				$error = getlang('account.card_verify_service_down');
			}
			$this->setMsg( $error );
			return;
		}
		if($res['cardtype'] != BANK_CARD_TYPE_DEBIT_CARD){
			$this->setMsg( getlang('account.card_type_only_debit_card') );
			return;
		}
		$bank = $res['bankname'];


		$key = $this->getMDHashKey( $uid );
		$_cardno = $this->mdataEncrypt($key, $cardno);
		$_idno = $this->mdataEncrypt($key, $idno);
		$_phone = $this->mdataEncrypt($key, $phone);
		$_realname = $this->mdataEncrypt($key, $realname);

		$md_accounts = & load_model('accounts');

		$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
		if(!empty($accinfo) && isset($accinfo['id'])){
			$bool = $md_accounts->removeBankAccount($uid, $accinfo['id']);
		}
		$seqid = $md_accounts->regBankAccountVerify($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone);
		if(empty($seqid)){
			$this->setMsg( getlang('account.get_bankacc_verify_id_failed') );
			return false;
		}
		//四要素验证
		$vci = new VerifyCardInfo_pub;
		$vci->setSequnceID( $seqid );
		$vci->setBankcardno( $cardno );
		$vci->setUsername( $realname );
		$vci->setIDNumber( $idno );
		$res = $vci->getResponse();

		if(true !== $res){
			if(empty($res)){
				$res = getLang('account.card_verify_service_down');
			}
			$this->setMsg( $res );
			return;
		}

		$key_mobile = $this->getUniqKey( $phone );
		$key_cardno = $this->getUniqKey( $cardno );
		$key_identcode = $this->getUniqKey( $idno );
		$bool = $md_accounts->regBankAccount($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone, $key_mobile, $key_cardno, $key_identcode);
		if(!$bool){
			$msg = stored_messages();
			if(empty($msg)){
				$msg = getlang('sys.serverunavailable');
			}
			$this->setMsg( $msg );
			return;
		}
		$info = $md_accounts->getUserAccountInfo($uid);
		if(null === $info){
			$md_accounts->regAccount( $uid );
		}
		$this->setData('success', true);
		$this->setCodeSuccess();
	}

	/**
	 *	绑定OFFLINE银行卡。线下绑卡使用
	 */
	public function bindOfflineCard(){
		if(!$this->checkUserLogin()){
			return;
		}
		$idtype = $this->postval('idtype');//默认身份证: 0，身份证；1，台胞证； 2，护照
		$idno = $this->postval('idno');
		$user = $this->postval('user');
		$phone = $this->postval('phone');
		$realname = $this->postval('realname');
		$cardno = $this->postval('cardno');

		$phone = $this->checkMobileNumber($phone);
		if($phone==false){
			return;
		}

		//人工校验身份证是否合法

		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$md_user = & load_model('user');
		$userinfo = $md_user->getUserByPhone($user);
		if(empty($userinfo) || !isset($userinfo['id']) || empty($userinfo['id'])){
			$this->setMsg( getlang('user.notexists') );
			return;
		}
		$uid = $userinfo['id'];

		$md_accounts = & load_model('accounts');

		$info = $md_accounts->getUserAccountInfo($uid);
		if(!empty($info)){
			if($info['status'] == USRACCOUNT_STATUS_NORMAL){
				//线下用户不可绑卡，但返回为服务不可用
				$this->setMsg( getlang('account.its_an_online_account') );
				return;
			}elseif($info['status'] == USRACCOUNT_STATUS_OFFLINE){
				$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
				if (!empty($accinfo)) {
					//用户已绑卡
					$this->setMsg( getlang('account.bankcardexists') );
					return;
				}
			}
		}

		//检查银行卡是否支持
		$bkq = new BankcardQuery_pub;
		$bkq->setBankcardno( $cardno );
		$res = $bkq->getUseful();
		// 2017-11-29
		// 修改返回错误提示信息
		if(false === $res){
			$this->setMsg( getlang('account.card_verify_service_down') );
			return;
		}
		if($res['code'] != BANK_CARD_OK){
			$error = '';
			if(!empty($res['msg'])){
				$error = $res['msg'];
			}else{
				$error = getlang('account.card_verify_service_down');
			}
			$this->setMsg( $error );
			return;
		}
		if($res['cardtype'] != BANK_CARD_TYPE_DEBIT_CARD){
			$this->setMsg( getlang('account.card_type_only_debit_card') );
			return;
		}
		$bank = $res['bankname'];


		$key = $this->getMDHashKey( $uid );
		$_cardno = $this->mdataEncrypt($key, $cardno);
		$_idno = $this->mdataEncrypt($key, $idno);
		$_phone = $this->mdataEncrypt($key, $phone);
		$_realname = $this->mdataEncrypt($key, $realname);

		$seqid = $md_accounts->regBankAccountVerify($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone);
		if(empty($seqid)){
			$this->setMsg( getlang('account.get_bankacc_verify_id_failed') );
			return false;
		}

		$key_mobile = $this->getUniqKey( $phone );
		$key_cardno = $this->getUniqKey( $cardno );
		$key_identcode = $this->getUniqKey( $idno );
		// 2018-05-18 线下绑卡加上证件个数限制
		$numb = $md_accounts->countAccByIdentID($key_identcode);
		if($numb && $numb >= LIMIT_ACC_SAME_USER){
			$this->setMsg( getlang('account.same_user_accounts_limit') );
			return;
		}

		$bool = $md_accounts->regBankAccount($uid, $idtype, $bank, $_cardno, $_realname, $_idno, $_phone, $key_mobile, $key_cardno, $key_identcode);
		if(!$bool){
			$msg = stored_messages();
			if(empty($msg)){
				$msg = getlang('sys.serverunavailable');
			}
			$this->setMsg( $msg );
			return;
		}

		if(null === $info){
			$md_accounts->regAccountOffline( $uid );
		}elseif($info && $info['status'] == USRACCOUNT_STATUS_EGG){
			$md_accounts->updateAccountOffline( $uid );
		}
		$this->setData('success', true);
		$this->setCodeSuccess();
	}

	/**
	 *	确认用户信息
	 */
	public function accVerifyUserInfo(){
		if(!$this->checkUserLogin()){
			return;
		}
		$user = $this->postval('user');
		$uid = $this->postval('uid');
		if(!empty($user)){
			$user = $this->checkMobileNumber($user);
			if($user==false){
				return;
			}
		}elseif(empty($uid)){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}

		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$md_user = & load_model('user');
		if(!empty($user)){
			$info = $md_user->getUserByPhone($user);
		}else{
			$info = $md_user->getUserById($uid);
		}
		if(empty($info) || !isset($info['id']) || empty($info['id'])){
			$this->setMsg( getlang('user.notexists') );
			return;
		}
		$uid = $info['id'];

		//获取银行卡信息

		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
		$info = $md_accounts->getUserAccountInfo($uid);
		if(!empty($accinfo) && isset($accinfo['id'])){
			$key = $this->getMDHashKey( $uid );
			$bank = $accinfo['bank'];
			$phone = $this->mdataDecrypt($key, $accinfo['mobile']);
			$identcode = $this->mdataDecrypt($key, $accinfo['identcode']);
			$cardno = $this->mdataDecrypt($key, $accinfo['cardno']);
			$realname = $this->mdataDecrypt($key, $accinfo['realname']);
			// 2018-04-10
			// 可以看到用户充值、提现相关的所有记录
			$logs = $md_accounts->getUserAccountLogs($uid, array(
				USRACCOUNT_ACTION_RECHARGE,USRACCOUNT_ACTION_OFFLINE_RECHARGE,
				USRACCOUNT_ACTION_WITHDRAW_ROLLBACK,USRACCOUNT_ACTION_LARGE_AMT_RECHARGE,
				USRACCOUNT_ACTION_PAYBACK_TRADEFEE,USRACCOUNT_ACTION_PAYBACK_DEPOSIT,
				USRACCOUNT_ACTION_WITHDRAW,USRACCOUNT_ACTION_OFFLINE_WITHDRAW,
				USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK,USRACCOUNT_ACTION_RETURN_LOAN,
				USRACCOUNT_ACTION_RETURN_LOAN_PIECE));
		}else{
			$bank = '';
			$phone = '';
			$identcode = '';
			$cardno = '';
			$realname = '';
			$logs = getLang('account.need_bind_one_card');
		}
		if(!is_array($info)){
			$info = array();
		}
		$this->setData('info', array_merge($info, array(
			'bank' => $bank,
			'phone' => $phone,
			'identcode' => $identcode,
			'cardno' => $cardno,
			'realname' => $realname,
			'logs' => $logs,
			)));
		$this->setCodeSuccess();
	}

	/**
	 *	用户退票返还
	 */
	public function accWithdrawTP(){
		if(!$this->checkUserLogin()){
			return;
		}
		$orderno = $this->postval('orderno');
		$rollback = $this->postval('rollback');

		if($this->uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}

		$md_accounts = & load_model('accounts');
		$info = $md_accounts->getWithdrawTuipiao($orderno);
		if(empty($info)){
			$this->setMsg( getLang('account.order_not_exists') );
			return;
		}
		$order = $md_accounts->getWithdrawOrderByOrderId( $orderno );
		if(empty($order)){
			$this->setMsg( getLang('account.withdraw_order_not_exists') );
			return;
		}
		// 判断退票订单状态
		if ($info['status']!=WITHDRAW_TUIPIAO_CONFIRMED){
			$this->setMsg( getLang('account.withdraw_tp_status_not_confirmed') );
			return;
		}
		// 判断用户ID是否正确
		if ($info['uid']!=$order['uid']){
			$this->setMsg( getLang('account.withdraw_tp_user_not_match') );
			return;
		}
		// 判断卡号是否正确
		$key = $this->getMDHashKey( $order['uid'] );
		$raw_cardno = $this->mdataDecrypt($key, $order['cardno']);
		if ($info['accntno']!=$raw_cardno) {
			$this->setMsg( getLang('account.withdraw_tp_cardno_not_match') );
			return;
		}
		// 判断金额是否正确
		if ($info['amt']+$info['fee']!=$order['money']) {
			$this->setMsg( getLang('account.withdraw_tp_money_not_match') );
			return;
		}
		// 判断提现记录状态是否正确
		if ($order['status']!=WITHDRAW_STATUS_DONE){
			$this->setMsg( getLang('account.withdraw_tp_withdraw_status_not_done') );
			return;
		}
		$bool = false;
		if($rollback == '1'){
			$amt = floor($info['amt']);//分，不作处理
			$fee = floor($info['fee']);//分，不作处理
			$amount = $amt + $fee;
			$uid = $info['uid'];
			$tpid = $info['id'];
			$id = $order['id'];
			$baid = $order['baid'];
			//print_r(array($amt, $fee, $amount, $uid, $tpid, $id, $baid));exit();
			$bool = $md_accounts->withdrawOrderTuipiaoRollbacked( $id, $tpid, $uid, $amount, $baid );
		}
		$key = $this->getMDHashKey( $order['uid'] );
		$order['cardno'] = $this->mdataDecrypt($key, $order['cardno']);
		$order['username'] = $this->mdataDecrypt($key, $order['username']);

		$this->setData('info', array(
			'result' => $bool,
			'order' => $order,
			'tuipiao' => $info,
		));
		$this->setCodeSuccess();
	}

	/**
	 * 给身份证打掩码，考虑18、15位身份证已经8位台胞证的问题
	 */
	protected function maskIdentCode($identCode) {
		$len = strlen($identCode);
		$masked = '';
		if ($len>=18) { //18位身份证
			$masked = substr($identCode, 0, 2) . '**' . substr($identCode, 4, 4) . str_pad('', $len - 11, '*') . substr($identCode, -3);
		}else if ($len>=15) { //15位身份证
			$masked = substr($identCode, 0, 2) . '**' . substr($identCode, 4, 2) . str_pad('', $len - 9, '*') . substr($identCode, -3);
        } else if ($len>=9){ //9位护照
            $masked = substr($identCode, 0, 2) . str_pad('', $len - 5, '*') . substr($identCode, -3);
        } else if ($len>=8){ //8位台胞证
            $masked = substr($identCode, 0, 2) . str_pad('', $len - 5, '*') . substr($identCode, -3);
        } else if ($len>=7){ //7位护照
            $masked = substr($identCode, 0, 2) . str_pad('', $len - 4, '*') . substr($identCode, -2);
		} else if ($len>=5){ // 5位
			$masked = str_pad('', $len - 2, '*') . substr($identCode, -2);
		} else if ($len>=2){ // 3位
			$masked = str_pad('', $len - 1, '*') . substr($identCode, -1);
		} else { //小于3位
			$masked = str_pad('', $len , '*');
		}
		return $masked;
	}

	public function getCardInfo(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;

		$md_accounts = & load_model('accounts');
		$bankacc = $md_accounts->getUserCurrentBankAccount( $uid );
		if(false === $bankacc){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		if(null === $bankacc){
			$this->setCode( CODES_ACCOUNT_BANKACC_NOT_EXISTS );
			$this->setMsg( getlang('account.bankacc_not_exists') );
			return;
		}
		$key = $this->getMDHashKey( $uid );
		$bankacc['cardno'] = $this->mdataDecrypt($key, $bankacc['cardno']);
		$len = strlen($bankacc['cardno']);
		$bankacc['cardno'] = substr($bankacc['cardno'], 0, 6) . str_pad('', $len - 10, '*') . substr($bankacc['cardno'], -4);

		$bankacc['idno'] = $this->mdataDecrypt($key, $bankacc['identcode']);
		unset($bankacc['identcode']);
		$len = strlen($bankacc['idno']);
		// 2018-02-05 BUG FIX
		// 修复台胞证8位多显示一位的问题，同时美化身份证的掩码显示
		$bankacc['idno'] = $this->maskIdentCode($bankacc['idno']);

		/*
		$bankacc['phone'] = $this->mdataDecrypt($key, $bankacc['mobile']);
		unset($bankacc['mobile']);
		$len = strlen($bankacc['phone']);
		$bankacc['phone'] = substr($bankacc['phone'], 0, 3) . str_pad('', $len - 7, '*') . substr($bankacc['phone'], -4);
		*/
		$bankacc['phone'] = $this->mdataDecrypt($key, $bankacc['mobile']);
		$bankacc['nowts'] = time() * 1000;
		unset($bankacc['mobile']);

		$bankacc['realname'] = $this->mdataDecrypt($key, $bankacc['realname']);
		$bankacc['bankabbr'] = $md_accounts->getBankAbbr($bankacc['bank']);
		$this->setData($bankacc);
		$this->setCodeSuccess();
	}

	/**
	 *	获取当前用户账户信息
	 */
	public function getInfo(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$md_accounts = & load_model('accounts');
		$info = $md_accounts->getUserAccountInfo($uid);
		if(false === $info){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}elseif(null === $info){
			$bankacc = $md_accounts->getUserCurrentBankAccount( $uid );
			if(!empty($bankacc)){
				$md_accounts->regAccount( $uid );
				$info = $md_accounts->getUserAccountInfo($uid);
			}else{
				$this->setMsg( getlang('account.need_bind_one_card') );
				return;
			}
		}
		$info['amount'] = $this->convHaoToFen( $info['amount'] );
		$info['total_amount'] = $this->convHaoToFen( $info['total_amount'] );
		$info['total_interest'] = $this->convHaoToFen( $info['total_interest'] );
		// 2018-03-07
		// total_interest 字段，APP用来显示“已到帐收益”，除了利息，还应该有用户在平台的其他的收益：签到、活动等等
		$other = $md_accounts->getUserOtherAmount($uid);
		$info['total_invite'] = $this->convHaoToFen( $other['total_invite'] );
		$info['total_award'] = $this->convHaoToFen( $other['total_award'] );
		$info['total_sign'] = $this->convHaoToFen( $other['total_sign'] );
		$info['total_other'] = $this->convHaoToFen( $other['total_other'] );

		$info['shift_amount_min'] = $this->convHaoToFen( $info['shift_amount_min'] );

		$md_obligation = & load_model('obligation');
		$held_amount = $md_obligation->getObligationHoldingAmount($uid);
		$inqueue_amount = $md_obligation->getUserInQueueAmount($uid);
		$pending_interest_pair = $md_obligation->getUserPendingInterestAmount($uid);
		if(!empty($pending_interest_pair)){
			$pimin = $pending_interest_pair['min'];
			$pimax = $pending_interest_pair['max'];
		}else{
			$pimin = $pimax = 0;
		}

		$info['held_amount'] = $this->convHaoToFen( $held_amount );
		$info['inqueue_amount'] = $this->convHaoToFen( $inqueue_amount );
		$info['pending_interest_min'] = $this->convHaoToFen( $pimin );
		$info['pending_interest_max'] = $this->convHaoToFen( $pimax );

		$this->setData($info);
		$this->setCodeSuccess();
	}

	/**
	 *	获取当前用户账户历史记录
	 */
	public function getHistory(){
		if(!$this->checkUserLogin()){
			return;
		}
		$index = intval($this->postval('page'));
		$type = intval($this->postval('type'));
		$index = max(0, $index);
		$pagesize = 30;

		$uid = $this->uid;
		$md_accounts = & load_model('accounts');

		//getUserAccountLogs($uid, $action = null, $get_total = false, $limit = 50, $start = 0)
		switch ($type) {
			case USRHIST_TYPE_RECHARGE_AND_WITHDRAW://充值提现还款
				// 2017-09-20 FIX BUG
				// 有4个状态漏掉了(最后4个状态)，导致客户端显示的时候一些账户变更记录没有
				$action = array(USRACCOUNT_ACTION_RECHARGE,
					USRACCOUNT_ACTION_WITHDRAW,
					USRACCOUNT_ACTION_WITHDRAW_ROLLBACK,
					USRACCOUNT_ACTION_RETURN_LOAN,
					USRACCOUNT_ACTION_PAYBACK_LOAN,
					USRACCOUNT_ACTION_RETURN_LOAN_PIECE,
					USRACCOUNT_ACTION_PAYBACK_TRADEFEE,
					USRACCOUNT_ACTION_INVITE_INTEREST,
					USRACCOUNT_ACTION_OFFLINE_RECHARGE,
					USRACCOUNT_ACTION_AWARD,
					USRACCOUNT_ACTION_PAY_INTEREST_IMMEDIATELY,
					USRACCOUNT_ACTION_PAY_EARLY,
					USRACCOUNT_ACTION_REPAYMENT,
					USRACCOUNT_ACTION_WITHDRAW_TUIPIAO_ROLLBACK,
					USRACCOUNT_ACTION_PAYBACK_DEPOSIT,
					USRACCOUNT_ACTION_SIGN_BONUS,
					USRACCOUNT_ACTION_ADD_LEFT_DMAMOUNT,
					USRACCOUNT_ACTION_LARGE_AMT_RECHARGE,
					USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK,
					USRACCOUNT_ACTION_OFFLINE_WITHDRAW);
				$getname = false;
				break;
			case USRHIST_TYPE_SELL://出售
				$action = USRACCOUNT_ACTION_OBSELL;
				$getname = true;
				break;
			case USRHIST_TYPE_BUY://购买
			default:
				$action = USRACCOUNT_ACTION_OBBUY;
				$getname = true;
				break;
		}


		$uid = $this->uid;

		$total = $md_accounts->getUserAccountLogs( $uid, $action, true );
		if($index > ceil($total/$pagesize) - 1){
			$data = array();
		}else{
			$data = $md_accounts->getUserAccountLogs( $uid, $action, false, $pagesize, $index * $pagesize );
		}
		$resarr = array();
		if(!empty($data)){
			$helper = load_helper('codemap');

			if($getname){
				$md_obligation = & load_model('obligation');
				$idarr = array();
				foreach ($data as $row) {
					$idarr[] = $row['act_id'];
				}
				$namemap = $md_obligation->getObligationNameByUoid($idarr);
				foreach ($data as $row) {
					$key = $md_obligation->getMapKey($row['act_id']);
					$arr = array(
						'id' => $row['id'],
						'name' => isset($namemap[$key]) ? $namemap[$key] : $row['act_id'],
						'amount' => $this->convHaoToFen( $row['amount_change'] ),
						'action' => $helper::accountActionName($row['action']),
						'action_code' => $row['action'],
						'date' => $row['created_time'],
					);
					$resarr[] = $arr;
				}

			}else{
				foreach ($data as $row) {
					$arr = array(
						'id' => $row['id'],
						'amount' => $this->convHaoToFen( $row['amount_change'] ),
						'action' => $helper::accountActionName($row['action']),
						'action_code' => $row['action'],
						'out' => $row['action'] == USRACCOUNT_ACTION_WITHDRAW,
						'date' => $row['created_time'],
					);
					$resarr[] = $arr;
				}
			}
		}
		$this->setData( array(
			'total' => $total,
			'page' => $index,
			'pagesize' => $pagesize,
			'list' => $resarr
			) );
		$this->setCodeSuccess();
	}

	/**
	 *	线下充值、转账充值
	 */
	public function getOfflineAccountInfo(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$money = $this->postval('money');
		$code = $this->postval('code');
		$money = intval($money);//当前单位为分
		if ($money < RECHARGE_LIMIT_MIN) {
			$this->setMsg( getlang('account.recharge_limit_min') );
			return;
		}
		if ($money > OFFLINE_RECHARGE_LIMIT_MAX) {
			$this->setMsg( getlang('account.offline_recharge_limit_max') );
			return;
		}

		$md_user = & load_model('user');

		$user = $md_user->getUserById($uid);
		$phone = $user['mobile'];

		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_OFFLINE_RECHARGE);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;

		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		//户名：御果金融信息服务（上海）有限公司，账号：4351-7217-5322，开户行：中国银行上海宝山支行。
		// 2018-06-22 修改账户为：开户行：工商银行黄浦南京东路第一支行 账号：1001234619300012869
		$data = array(
			'name' => '御果金融信息服务（上海）有限公司',
			'account' => '1001234619300012869',
			'bank' => '工商银行黄浦南京东路第一支行',
		);
		$md_accounts = & load_model('accounts');
		$id = $md_accounts->addOfflineRechargeOrder( $uid, $phone, $money );
		if($id){
			$md_sms->useCode($phone, $code);
			$data['tid'] = $id;
			$this->setCodeSuccess();
			$this->setData( $data );
		}
	}
	/**
	 * 获取公司账户信息，用于转账
	 */
	public function getCompanyAccountInfo(){
		if(!$this->checkUserLogin()){
			return;
		}
		//户名：御果金融信息服务（上海）有限公司，账号：4351-7217-5322，开户行：中国银行上海宝山支行。
		// 2018-06-22 修改账户为：开户行：工商银行黄浦南京东路第一支行 账号：1001234619300012869
		$data = array(
			'name' => '御果金融信息服务（上海）有限公司',
			'account' => '1001234619300012869',
			'bank' => '工商银行黄浦南京东路第一支行',
		);
		$this->setCodeSuccess();
		$this->setData( $data );
	}
	/**
	 * 用户转账后，通知平台
	 */
	public function notifyOfflineRecharged(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$money = $this->postval('money');
		$code = $this->postval('code');
		$money = intval($money);//当前单位为分
		if ($money < OFFLINE_RECHARGE_LIMIT_MIN ) {
			$this->setMsg( getlang('account.offline_recharge_limit_min') );
			return;
		}
		if ($money > OFFLINE_RECHARGE_LIMIT_MAX) {
			$this->setMsg( getlang('account.offline_recharge_limit_max') );
			return;
		}

		$md_user = & load_model('user');

		$user = $md_user->getUserById($uid);
		$phone = $user['mobile'];

		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_OFFLINE_RECHARGE);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;

		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}
		$md_accounts = & load_model('accounts');
		$id = $md_accounts->addOfflineRechargePaidOrder( $uid, $phone, $money );
		$msg = getLang('account.offline_recharge_notice_ok');
		if($id==false){
			$msg = getLang('account.offline_recharge_notice_failed');
		}else{
			$this->setCodeSuccess();
			$this->setData(array('id' => $id));
			$md_sms->useCode($phone, $code);
		}
		$this->setData( array('msg' => $msg) );
	}


	/**
	 *	通知系统已充值，待检验
	 */
	public function myOfflineRecharged(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$id = $this->postval('id');
		$md_accounts = & load_model('accounts');
		$info = $md_accounts->getOfflineRechargeOrderById( $id );
		do{
			if($info['uid'] != $uid){
				$msg = getLang('account.offline_recharge_notice_failed');
				break;
			}
			if($info['status'] != OFFLINE_RECHARGE_STATUS_ORDER_CREATED){
				$this->setCodeSuccess();
				$msg = getLang('account.offline_recharge_notice_already');
				break;
			}
			$bool = $md_accounts->noticeOfflineRecharged( $uid, $id );
			if($bool){
				$this->setCodeSuccess();
				$msg = getLang('account.offline_recharge_notice_ok');
			}else{
				$msg = getLang('account.offline_recharge_notice_failed');
			}
		}while (false);
		$this->setData( array('msg' => $msg) );
	}

	/**
	 *	充值
	 */
	public function recharge(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$money = $this->postval('money');
		$money = intval($money);//当前单位为分
		if ($money < RECHARGE_LIMIT_MIN) {
			$this->setMsg( getlang('account.recharge_limit_min') );
			return;
		}
		if ($money > RECHARGE_LIMIT_MAX) {
			$this->setMsg( getlang('account.recharge_limit_max') );
			return;
		}

		$md_accounts = & load_model('accounts');

		$bankacc = $md_accounts->getUserCurrentBankAccount( $uid );
		if(false === $bankacc){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		if(null === $bankacc){
			$this->setCode( CODES_ACCOUNT_BANKACC_NOT_EXISTS );
			$this->setMsg( getlang('account.bankacc_not_exists') );
			return;
		}
		$key = $this->getMDHashKey( $uid );
		$cardno = $this->mdataDecrypt($key, $bankacc['cardno']);
		$idno = $this->mdataDecrypt($key, $bankacc['identcode']);
		$phone = $this->mdataDecrypt($key, $bankacc['mobile']);
		$realname = $this->mdataDecrypt($key, $bankacc['realname']);
		// 2018/01/04 TODO
		// 创建充值订单的时候，需要带上下面的order_id，否则同步数据会有不一致
		$payid = $md_accounts->addRechargeOrder( $uid, $bankacc['id'], $money );

		$co = new CreateOrder_pub;
		$co->setPayId( $payid );
		$co->setAmount( $money );
		$order_id = $co->getOrderId();
		if(false === $order_id){
			$this->setMsg( getlang('account.recharge_create_order_failed') );
			return;
		}
		$res = $md_accounts->rechargeOrderUpdateTransId( $payid, $order_id );
		if(false === $res){
			$this->setMsg( getlang('account.recharge_update_trans_id_failed') );
			return;
		}
		$op = new OrderPayinfo_pub;
		$op->setOrderId( $order_id );
		$op->setBankcardno( $cardno );
		$op->setUsername( $realname );
		// 2018/01/04， 富友修改了充值通道，对接的用户信息部分是旧的（虽热用户在银行更新了预留信息，但是不知道是吗时候同步）
		// 把18位身份证换成15位，需要匹配卡号，因为每个银行都不一样
		$card_id_map = array(
			'6230580000074209540,370902197505251233' => '370902750525123', //测试用户
			'6222081001014472942,310225198401315028' => '310225840131502', //真实用户
			'9558801001128304455,31023019701230724X' => '310230701230724', //真实用户
			'6212261001030940107,31010719911120342x' => '31010719911120342X', //真实用户，身份证最后x换成大写的X
			'6222081001006824902,31011219871017521x' => '31011219871017521X', //真实用户，身份证最后x换成大写的X
			'6228481059141212170,32082219650710003x' => '32082219650710003X', //真实用户，身份证最后x换成大写的X
			'622908213018600711,33032419850706002x' => '33032419850706002X', //真实用户，身份证最后x换成大写的X
		);
		$card_id = "$cardno,$idno";
		if (isset($card_id_map[$card_id])) {
			$idno = $card_id_map[$card_id];
		}
		$op->setIDNumber( $idno );
		$data = $op->getPackData();
		$this->setCodeSuccess();
		$this->setData( $data );
	}

	/**
	 *	充值检查
	 */
	public function rechargeCheck(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$id = $this->postval('id');

		$md_accounts = & load_model('accounts');

		$payinfo = $md_accounts->getRechargeOrderById( $id );
		if(false === $payinfo){
			$this->setMsg( getlang('account.recharge_order_query_failed') );
			return;
		}
		$status = $payinfo['status'];
		if($status == RECHARGE_STATUS_ORDER_CREATED){
			$oq = new OrderQuery_pub;
			$oq->setOrderId( $id );
			$res = $oq->getStatus();
			if(false === $res){
				$this->setMsg( getlang('account.recharge_order_query_failed') );
				return;
			}
			switch ($res['code']) {
				case RECHARGE_ORDER_NOT_EXISTS:
					$status = RECHARGE_STATUS_NOT_EXISTS;
					break;
				case RECHARGE_ORDER_EXPIRED:
					$status = RECHARGE_STATUS_EXPIRED;
					break;
				case RECHARGE_ORDER_PAY_FAILED:
					$status = RECHARGE_STATUS_PAY_FAILED;
					break;
				case RECHARGE_ORDER_OK:
					$status = RECHARGE_STATUS_PAID;
					break;
			}
			$md_accounts->rechargeOrderResponsed( $id, $status );
		}
		switch ($status) {
			case RECHARGE_STATUS_NOT_EXISTS:
				$msg = getlang('account.recharge_order_not_exists');
				break;
			case RECHARGE_STATUS_EXPIRED:
				$msg = getlang('account.recharge_order_expired');
				break;
			case RECHARGE_STATUS_FAILED:
				$msg = getlang('account.recharge_order_failed');
				break;
			case RECHARGE_STATUS_PAY_FAILED:
				$msg = getlang('account.recharge_order_pay_failed');
				break;
			case RECHARGE_STATUS_PAID:
				$msg = getlang('account.recharge_order_paid');
				break;
			case RECHARGE_STATUS_ORDER_CREATED:
				$msg = getlang('account.recharge_order_created');
				break;
			case RECHARGE_STATUS_DONE:
				$msg = getlang('account.recharge_order_done');
				break;
			default:
				$this->setMsg( getlang('account.recharge_status_error') );
				return;
		}

		$this->setCodeSuccess();
		$this->setData( array('status' => $status, 'msg' => $msg) );
	}

	/**
	 *	提现
	 */
	public function withdraw(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$money = $this->postval('money');
		$passwd = $this->postval('passwd');
		$code = $this->postval('code');
		$bank = $this->postval('bank');
		$city = $this->postval('city');
		$bank_sub = $this->postval('bank_sub');
		$money = intval($money);//当前单位为分
		$md_accounts = & load_model('accounts');

		$info = $md_accounts->getUserAccountInfo($uid);
		if(empty($info)){
			$this->setMsg( getlang('account.bind_card_first') );
			return;
		}
		if($info['status'] != USRACCOUNT_STATUS_NORMAL){
			if($info['status'] == USRACCOUNT_STATUS_OFFLINE){
				$msg = getlang('account.not_allowed');
			}elseif($info['status'] == USRACCOUNT_STATUS_EGG){
				$msg = getlang('account.bind_card_first');
			}else{
				$msg = getlang('account.not_allowed');
			}
			$this->setMsg( $msg );
			return;
		}

		if ($money < WITHDRAW_LIMIT_MIN) {
			$this->setMsg( getlang('account.withdraw_limit_min') );
			return;
		}
		// 2018-03-30
		// 对中转账户(100006)提现金额上线放开
		$buyer_admin = 100006;
		// 2019-04-16
		// 对特殊账号限制提现
		$special_account = 112746;
		if ($uid == $special_account) {
			$this->setMsg( getlang('account.withdraw_limit_max') );
			return;
		}

		if ($uid != $buyer_admin && $money > WITHDRAW_LIMIT_MAX ) {
			$this->setMsg( getlang('account.withdraw_limit_max') );
			return;
		}

		if( !$this->checkWithdrawAmountIsEnough($uid, $this->convFenToHao($money)) ){//对比金额为毫
			return;
		}

		if( !$this->checkUserPaymentPassword($uid, $passwd) ){
			return;
		}
		$md_user = & load_model('user');
		$info = $md_user->getUserById($uid);
		if(empty($info)){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$phone = $info['mobile'];

		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_WITHDRAW);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$md_accounts = & load_model('accounts');

		$bankacc = $md_accounts->getUserCurrentBankAccount( $uid );
		if(false === $bankacc){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		if(null === $bankacc){
			$this->setCode( CODES_ACCOUNT_BANKACC_NOT_EXISTS );
			$this->setMsg( getlang('account.bankacc_not_exists') );
			return;
		}
		// 2018-03-30
		// 对中转账户(100006)提现金额上线放开
		if ($uid != $buyer_admin) {
			$info = $md_accounts->getWithdrawTodayTotalByUid( $uid );
			if(false === $info){
				$this->setMsg( getlang('sys.serverunavailable') );
				return;
			}
			if($info['total'] + $money > WITHDRAW_LIMIT_TODAY_TOTAL_MAX){
				$amount = WITHDRAW_LIMIT_TODAY_TOTAL_MAX - $info['total'];
				$amount = substr($amount, 0, -2) . '.' . substr($amount, -2);
				$this->setMsg( getlang('account.withdraw_limit_total_max', array('date' => $info['date'], 'amount' => $amount)) );
				return;
			}
			$info = $md_accounts->getWithdrawMonthTotalByUid( $uid );
			if(false === $info){
				$this->setMsg( getlang('sys.serverunavailable') );
				return;
			}
			if($info['total'] + $money > WITHDRAW_LIMIT_MONTH_TOTAL_MAX){
				$amount = WITHDRAW_LIMIT_MONTH_TOTAL_MAX - $info['total'];
				$amount = substr($amount, 0, -2) . '.' . substr($amount, -2);
				$this->setMsg( getlang('account.withdraw_limit_month_total_max', array('date' => $info['date'], 'amount' => $amount)) );
				return;
			}
		}
		$mtimes = $md_accounts->getWithdrawMonthTimesByUid( $uid );
		if(false === $mtimes){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$fee = 0;
		if($mtimes['times'] >= WITHDRAW_LIMIT_FEE_FREE_TIMES){
			$fee = WITHDRAW_FEE;
		}
		if($money - $fee < 1){
			$this->setMsg( getlang('account.withdraw_amount_not_enough_with_fee', array('amount' => $money/100, 'fee' => $fee/100)) );
			return;
		}
		list($usec, ) = explode(' ', microtime());
		$usec = floor($usec*1000);
		$order_id = date('YmdHis') . str_pad($usec, 3, '0', STR_PAD_LEFT) . str_pad($bankacc['id'], 12, '0', STR_PAD_LEFT);
		$wdid = $md_accounts->addWithdrawOrder( $uid, $bankacc['id'], $money, $bankacc['cardno'], $bankacc['realname'], $bank, $city, $bank_sub, $order_id, $fee );
		if(empty($wdid)){
			$this->setMsg( getlang('account.withdraw_create_order_failed') );
			return;
		}
		$md_sms->useCode($phone, $code);
		$this->setCodeSuccess();
		$this->setData( array('withdraw_id'=>$wdid) );
	}


	/**
	 *	提现检查
	 */
	public function withdrawCheck(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$id = $this->postval('id');

		$md_accounts = & load_model('accounts');

		$info = $md_accounts->getWithdrawOrderById( $id );
		if(false === $info){
			// 2018-03-28
			// Android 版本发起的请求withdrawCheck 和 offlineWithdrawCheck 调换了，这里临时处理一下
			// 等待下一个Android版本更新后去掉
			$info = $md_accounts->getOfflineWithdrawOrderById( $id );
			if(false === $info){
				$this->setMsg( getlang('account.withdraw_order_query_failed') );
				return;
			}
		}
		if(null === $info){
			$status = WITHDRAW_STATUS_NOT_EXISTS;
		}else{
			$status = $info['status'];
		}
		switch ($info['status']) {
			case WITHDRAW_STATUS_NOT_EXISTS:
				$msg = getlang('account.withdraw_order_not_exists');
				break;
			case WITHDRAW_STATUS_CANCELED:
				$msg = getlang('account.withdraw_order_canceled');
				break;
			case WITHDRAW_STATUS_FAILED:
				$msg = getlang('account.withdraw_order_failed');
				break;
			case WITHDRAW_STATUS_ACCOUNT_ROLLBACK:
				$msg = getlang('account.withdraw_order_account_rollback');
				break;
			case WITHDRAW_STATUS_ORDER_CREATED:
				$msg = getlang('account.withdraw_order_created');
				break;
			case WITHDRAW_STATUS_DONE:
				$msg = getlang('account.withdraw_order_done');
				break;
			default:
				$this->setMsg( getlang('account.withdraw_status_error') );
				return;
		}

		$this->setCodeSuccess();
		$this->setData( array('status' => $status, 'msg' => $msg) );
	}

	/**
	 *	提现（转账模式）
	 */
	public function offlineWithdraw(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$money = $this->postval('money');
		$passwd = $this->postval('passwd');
		$code = $this->postval('code');
		$bank = $this->postval('bank');
		$city = $this->postval('city');
		$bank_sub = $this->postval('bank_sub');
		$money = intval($money);//当前单位为分
		$md_accounts = & load_model('accounts');
		$info = $md_accounts->getUserAccountInfo($uid);

		// 2019-04-16
		// 对特殊账号限制提现
		$special_account = 112746;
		if ($uid == $special_account) {
			$this->setMsg( getlang('account.withdraw_limit_max') );
			return;
		}

		if($info['status'] != USRACCOUNT_STATUS_OFFLINE){
			$this->setMsg( getlang('account.withdraw_not_offline_account') );
			return;
		}

		if ($money < WITHDRAW_LIMIT_MIN) {
			$this->setMsg( getlang('account.withdraw_limit_min') );
			return;
		}

		if ($money > WITHDRAW_LIMIT_MAX ) {
			$this->setMsg( getlang('account.withdraw_limit_max') );
			return;
		}

		if( !$this->checkWithdrawAmountIsEnough($uid, $this->convFenToHao($money)) ){//对比金额为毫
			return;
		}

		if( !$this->checkUserPaymentPassword($uid, $passwd) ){
			return;
		}
		$md_user = & load_model('user');
		$info = $md_user->getUserById($uid);
		if(empty($info)){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$phone = $info['mobile'];

		$md_sms = & load_model('sms');
		$arr = $md_sms->getPhoneCode($phone, SMS_CODE_TYPE_WITHDRAW);
		if(!count($arr)){
			$this->setMsg( getlang('user.smscodeexpired') );
			return;
		}
		$matched = false;
		foreach ($arr as $row) {
			if($row['code'] == $code){
				$matched = true;
				break;
			}
		}
		if(!$matched){
			$this->setMsg( getlang('user.smscodenotmatch') );
			return;
		}

		$md_accounts = & load_model('accounts');

		$bankacc = $md_accounts->getUserCurrentBankAccount( $uid );
		if(false === $bankacc){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		if(null === $bankacc){
			$this->setCode( CODES_ACCOUNT_BANKACC_NOT_EXISTS );
			$this->setMsg( getlang('account.bankacc_not_exists') );
			return;
		}

		$info = $md_accounts->getOfflineWithdrawTodayTotalByUid( $uid );
		if(false === $info){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		if($info['total'] + $money > WITHDRAW_LIMIT_TODAY_TOTAL_MAX){
			$amount = WITHDRAW_LIMIT_TODAY_TOTAL_MAX - $info['total'];
			$amount = substr($amount, 0, -2) . '.' . substr($amount, -2);
			$this->setMsg( getlang('account.withdraw_limit_total_max', array('date' => $info['date'], 'amount' => $amount)) );
			return;
		}
		$mtimes = $md_accounts->getOfflineWithdrawMonthTimesByUid( $uid );
		if(false === $mtimes){
			$this->setMsg( getlang('sys.serverunavailable') );
			return;
		}
		$fee = 0;
		if($mtimes['times'] >= WITHDRAW_LIMIT_FEE_FREE_TIMES){
			$fee = WITHDRAW_FEE;
		}
		if($money - $fee < 1){
			$this->setMsg( getlang('account.withdraw_amount_not_enough_with_fee', array('amount' => $money/100, 'fee' => $fee/100)) );
			return;
		}
		list($usec, ) = explode(' ', microtime());
		$usec = floor($usec*1000);
		$order_id = date('YmdHis') . str_pad($usec, 3, '0', STR_PAD_LEFT) . str_pad($bankacc['id'], 12, '0', STR_PAD_LEFT);
		$wdid = $md_accounts->addOfflineWithdrawOrder( $uid, $bankacc['id'], $money, $bankacc['cardno'], $bankacc['realname'], $bank, $city, $bank_sub, $order_id, $fee );
		if(empty($wdid)){
			$this->setMsg( getlang('account.withdraw_create_order_failed') );
			return;
		}
		$md_sms->useCode($phone, $code);
		$this->setCodeSuccess();
		$this->setData( array('withdraw_id'=>$wdid) );
	}

	/**
	 *	提现（转账模式）检查
	 */
	public function offlineWithdrawCheck(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$id = $this->postval('id');

		$md_accounts = & load_model('accounts');

		$info = $md_accounts->getOfflineWithdrawOrderById( $id );
		if(false === $info){
			// 2018-03-28
			// Android 版本发起的请求withdrawCheck 和 offlineWithdrawCheck 调换了，这里临时处理一下
			// 等待下一个Android版本更新后去掉
			$info = $md_accounts->getWithdrawOrderById( $id );
			if(false === $info){
				$this->setMsg( getlang('account.withdraw_order_query_failed') );
				return;
			}
		}
		if(null === $info){
			$status = WITHDRAW_STATUS_NOT_EXISTS;
		}else{
			$status = $info['status'];
		}
		switch ($info['status']) {
			case WITHDRAW_STATUS_NOT_EXISTS:
				$msg = getlang('account.withdraw_order_not_exists');
				break;
			case WITHDRAW_STATUS_CANCELED:
				$msg = getlang('account.withdraw_order_canceled');
				break;
			case WITHDRAW_STATUS_FAILED:
				$msg = getlang('account.withdraw_order_failed');
				break;
			case WITHDRAW_STATUS_ACCOUNT_ROLLBACK:
				$msg = getlang('account.withdraw_order_account_rollback');
				break;
			case WITHDRAW_STATUS_ORDER_CREATED:
				$msg = getlang('account.withdraw_order_created');
				break;
			case WITHDRAW_STATUS_DONE:
				$msg = getlang('account.withdraw_order_done');
				break;
			default:
				$this->setMsg( getlang('account.withdraw_status_error') );
				return;
		}

		$this->setCodeSuccess();
		$this->setData( array('status' => $status, 'msg' => $msg) );
	}

	public function platformStatus(){
		$allowed_ips = config_item('front_ips');
		if( !$this->checkIP( $allowed_ips ) ){
			$this->setMsg('Denied;p');
			return;
		}
		$keep_amount = 0;
		$md_accounts = & load_model('accounts');
		$data = $md_accounts->getTotalBalance();
		if(!array_key_exists('amount', $data)){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$bounds = $md_accounts->getTotalBankBounds();
		$keep_amount += $data['amount'];
		$total_accounts = $data['numb'];
		$total_bounds = $bounds['numb'];
		$keep_amount += ($total_accounts * 2 * 10000);
		$total_amount = $data['total_amount'];

		$md_obligation = & load_model('obligation');
		$data = $md_obligation->getRookieObligationTotalAmount();

		if(!array_key_exists('left_amount', $data)){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$keep_amount += $data['left_amount'];

		$this->setCodeSuccess();
		$this->setData(array(
			'keep_amount' => ceil($keep_amount/100),
			'total_amount' => ceil($total_amount/100),
			'total_accounts' => "$total_bounds / $total_accounts",
			));
	}

	public function getBankMap(){
		$comm = new FPCommon_util_pub;
		$data = $comm::bankCodeName();
		$this->setCodeSuccess();
		$this->setData( $data );
	}

	public function getCityMap(){
		$comm = new FPCommon_util_pub;
		$data = $comm::cityCodeName();
		$this->setCodeSuccess();
		$this->setData( $data );
	}

	public function getCities(){
		$cities = array(
			'北京' => array('北京市'),
			'天津' => array('天津市'),
			'河北省' => array('石家庄市','唐山市','秦皇岛市','邯郸市','邢台市','保定市','张家口市','承德市','沧州市','廊坊市','衡水市'),
			'山西省' => array('太原市','大同市','阳泉市','长治市','晋城市','朔州市','晋中市','运城市','忻州市','临汾市','吕梁市'),
			'内蒙古自治区' => array('呼和浩特市','包头市','乌海市','赤峰市','通辽市','鄂尔多斯市','呼伦贝尔市','兴安盟','锡林郭勒盟','乌兰察布市','巴彦淖尔市','阿拉善盟'),
			'辽宁省' => array('沈阳市','大连市','鞍山市','抚顺市','本溪市','丹东市','锦州市','营口市','阜新市','辽阳市','盘锦市','铁岭市','朝阳市','葫芦岛市'),
			'吉林省' => array('长春市','吉林市','四平市','辽源市','通化市','白山市','松原市','白城市','延边朝鲜族自治州'),
			'黑龙江省' => array('哈尔滨市','齐齐哈尔市','鸡西市','鹤岗市','双鸭山市','大庆市','伊春市','佳木斯市','七台河市','牡丹江市','黑河市','绥化市','大兴安岭地区'),
			'上海市' => array('上海市'),
			'江苏省' => array('南京市','无锡市','徐州市','常州市','苏州市','南通市','连云港市','淮安市','盐城市','扬州市','镇江市','泰州市','宿迁市'),
			'浙江省' => array('杭州市','宁波市','温州市','嘉兴市','湖州市','绍兴市','金华市','衢州市','舟山市','台州市','丽水市'),
			'安徽省' => array('合肥市','芜湖市','蚌埠市','淮南市','马鞍山市','淮北市','铜陵市','安庆市','黄山市','滁州市','阜阳市','宿州市','巢湖市','六安市','亳州市','池州市','宣城市'),
			'福建省' => array('福州市','厦门市','莆田市','三明市','泉州市','漳州市','南平市','龙岩市','宁德市'),
			'江西省' => array('南昌市','景德镇市','萍乡市','九江市','新余市','鹰潭市','赣州市','吉安市','宜春市','抚州市','上饶市'),
			'山东省' => array('济南市','青岛市','淄博市','枣庄市','东营市','烟台市','潍坊市','济宁市','泰安市','威海市','日照市','莱芜市','临沂市','德州市','聊城市','滨州市','菏泽市'),
			'河南省' => array('郑州市','开封市','洛阳市','平顶山市','安阳市','鹤壁市','新乡市','焦作市','济源市','濮阳市','许昌市','漯河市','三门峡市','南阳市','商丘市','信阳市','周口市','驻马店市'),
			'湖北省' => array('武汉市','黄石市','十堰市','宜昌市','襄阳市','鄂州市','荆门市','孝感市','荆州市','黄冈市','咸宁市','随州市','恩施土家族苗族自治州','仙桃市','潜江市','天门市','神农架林区'),
			'湖南省' => array('长沙市','株洲市','湘潭市','衡阳市','邵阳市','岳阳市','常德市','张家界市','益阳市','郴州市','永州市','怀化市','娄底市','湘西土家族苗族自治州'),
			'广东省' => array('广州市','韶关市','深圳市','珠海市','汕头市','佛山市','江门市','湛江市','茂名市','肇庆市','惠州市','梅州市','汕尾市','河源市','阳江市','清远市','东莞市','中山市','潮州市','揭阳市','云浮市'),
			'广西壮族自治区' => array('南宁市','柳州市','桂林市','梧州市','北海市','防城港市','钦州市','贵港市','玉林市','百色市','贺州市','河池市','来宾市','崇左市'),
			'海南省' => array('海口市','三亚市','五指山市','琼海市','儋州市','文昌市','万宁市','东方市','定安县','屯昌县','澄迈县','临高县','白沙黎族自治县','昌江黎族自治县','乐东黎族自治县','陵水黎族自治县','保亭黎族苗族自治县','琼中黎族苗族自治县','西沙群岛','南沙群岛','中沙群岛的岛礁及其海域'),
			'重庆市' => array('重庆市'),
			'四川省' => array('成都市','自贡市','攀枝花市','泸州市','德阳市','绵阳市','广元市','遂宁市','内江市','乐山市','南充市','眉山市','宜宾市','广安市','达州市','雅安市','巴中市','资阳市','阿坝藏族羌族自治州','甘孜藏族自治州','凉山彝族自治州'),
			'贵州省' => array('贵阳市','六盘水市','遵义市','安顺市','铜仁地区','黔西南布依族苗族自治州','毕节地区','黔东南苗族侗族自治州','黔南布依族苗族自治州'),
			'云南省' => array('昆明市','曲靖市','玉溪市','保山市','昭通市','丽江市','楚雄彝族自治州','红河哈尼族彝族自治州','文山壮族苗族自治州','普洱市','西双版纳傣族自治州','大理白族自治州','德宏傣族景颇族自治州','怒江傈僳族自治州','迪庆藏族自治州','临沧市'),
			'西藏自治区' => array('拉萨市','昌都地区','山南地区','日喀则地区','那曲地区','阿里地区','林芝地区'),
			'陕西省' => array('西安市','铜川市','宝鸡市','咸阳市','渭南市','延安市','汉中市','榆林市','安康市','商洛市'),
			'甘肃省' => array('兰州市','嘉峪关市','金昌市','白银市','天水市','武威市','张掖市','平凉市','酒泉市','庆阳市','定西市','陇南市','临夏回族自治州','甘南藏族自治州'),
			'青海省' => array('西宁市','海东地区','海北藏族自治州','黄南藏族自治州','海南藏族自治州','果洛藏族自治州','玉树藏族自治州','海西蒙古族藏族自治州'),
			'宁夏回族自治区' => array('银川市','石嘴山市','吴忠市','固原市','中卫市'),
			'新疆维吾尔自治区' => array('乌鲁木齐市','克拉玛依市','吐鲁番地区','哈密地区','昌吉回族自治州','博尔塔拉蒙古自治州','巴音郭楞蒙古自治州','阿克苏地区','克孜勒苏柯尔克孜自治州','喀什地区','和田地区','伊犁哈萨克自治州','塔城地区','阿勒泰地区','石河子市','阿拉尔市','图木舒克市','五家渠市'),
			// '台湾省' => array('台湾省'),
			// '香港特别行政区' => array('香港特别行政区'),
			// '澳门特别行政区' => array('澳门特别行政区'),
		);
		$this->setCodeSuccess();
		$this->setData( $cities );
	}

}