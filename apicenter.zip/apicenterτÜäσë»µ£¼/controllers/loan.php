<?php
require_once PATH_BASE_CONTROLLER;

class Loan extends Controller{

	public function __construct(){
		parent::__construct();
	}

	public function getSysStatus(){
		$allowed_ips = config_item('front_ips');
		if( !$this->checkIP( $allowed_ips ) ){
			$this->setMsg('Denied;p');
			return;
		}
		$date_from = $this->postval('date_from');
		$date_to = $this->postval('date_to');
		$date_from = date('Y-m-d', strtotime($date_from));
		$date_to = date('Y-m-d', strtotime($date_to));
		$md_loan = & load_model('loan');
		$helper = load_helper('codemap');
		$listA = $md_loan->getLoanRepaymentOverdueListByDate( $date_to );
		if(!empty($listA)){
			foreach ($listA as &$row) {
				$row['amount'] = floor($row['amount']/100)/100;
				$row['each_month'] = ceil($row['each_month']/100)/100;
				$row['status_txt'] = $helper::loanListStatusCodeName( $row['status'] );
				$row['paid'] = ($row['paid_principal'] + $row['paid_interest'])/10000;
				$row['overdue_fee'] = ceil($row['overdue_fee']/100)/100;
				$row['paid_overdue_fee'] = ceil($row['paid_overdue_fee']/100)/100;
			}
		}else{
			$listA = array();
		}
		$list = $md_loan->getLoanRepaymentStatusListByDate( $date_from, $date_to );
		foreach ($list as &$row) {
			$row['amount'] = floor($row['amount']/100)/100;
			$row['each_month'] = ceil($row['each_month']/100)/100;
			$row['status_txt'] = $helper::loanListStatusCodeName( $row['status'] );
			$row['paid'] = ($row['paid_principal'] + $row['paid_interest'])/10000;
			$row['overdue_fee'] = ceil($row['overdue_fee']/100)/100;
			$row['paid_overdue_fee'] = ceil($row['paid_overdue_fee']/100)/100;
		}
		$this->setData( 'list', array_merge($listA, $list) );
		$this->setCodeSuccess();
	}

	/**
	 *	获取贷款状态
	 */
	public function getStatus(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$ts = time() + 14 * 86400;
		$date = date('Y-m-d', $ts);
		$md_loan = & load_model('loan');
		$data = $md_loan->getRecentLoanRepaymentList($uid, $date);
		$count_overdue = 0;
		$count_recent = 0;
		$sum_amount = 0;
		$amount_less = false;
		if(!empty($data)){
			foreach ($data as $row) {
				if($row['overdue_days'] > 0){
					$count_overdue ++;
				}
				if(strtotime($row['repayment_date']) - $ts < 3*86400){
					$count_recent ++;
					$sum_amount += ($row['principal'] + $row['interest']);
				}
			}
		}
		$msg = '';
		if($count_overdue>0){
			$count = $count_overdue;
			$amount_less = true;
			$msg = getLang('loan.has_count_overdued', array('count' => $count));
		}else{
			$md_accounts = & load_model('accounts');
			$accinfo = $md_accounts->getUserCurrentAccount(	$uid );
			$count = $count_recent;
			if($accinfo['amount'] < $sum_amount){
				$amount_less = true;
				$msg = getLang('loan.has_count_recent_less', array( 'count' => $count, 'amount' => ceil($sum_amount/100)/100 ));
			}else{
				$msg = getLang('loan.has_count_recent', array( 'count' => $count, 'amount' => ceil($sum_amount/100)/100 ));
			}
		}
		$this->setData( array(
			'count' => $count,
			'amount_less' => $amount_less,
			'msg' => $msg
			) );
		$this->setCodeSuccess();
	}
	/**
	 *	获取用户贷款列表
	 */
	public function getList(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$page = intval($this->postval('page'));
		$pagesize = 50;
		$page = max($page, 0);//对外接口，page从0开始

		$md_loan = & load_model('loan');
		$helper = load_helper('codemap');
		$total = $md_loan->getLoanInfoCount($uid);

		$data = $md_loan->getLoanInfoList( $uid, $page, $pagesize );
		if(!empty($data)){
			foreach ($data as &$row) {
				$row['name'] = "{$row['make']} {$row['model']}";
				$row['total_loan'] = $this->convHaoToFen( $row['total_loan'] );
				$row['left_loan'] = $this->convHaoToFen( $row['left_loan'] );
				$row['returned_loan'] = $this->convHaoToFen( $row['returned_loan'] );
				$row['paid_interest'] = $this->convHaoToFen( $row['paid_interest'] );
				$row['paid_overdue_fee'] = $this->convHaoToFen( $row['paid_overdue_fee'] );
				$row['repayment_method_txt'] = $helper::repaymentMethod( $row['repayment_method'] );
				$row['status_txt'] = $helper::loanInfoStatusCodeName( $row['status'], $row['curr_overdue_days'] );
			}
		}
		$this->logExtraColumns('page', $page);
		$this->setData( array(
			'total' => $total,
			'page' => $page,
			'pagesize' => $pagesize,
			'list' => $data
			) );
		$this->setCodeSuccess();
	}

	/**
	 *	获取用户某贷款详细数据
	 */
	public function getDetail(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$id = $this->postval('id');
		$this->logExtraColumns('id', $id);
		if(empty($id)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_loan = & load_model('loan');
		$helper = load_helper('codemap');
		$data = $md_loan->getLoanInfo( $id );
		if(!empty($data)){
			if($uid != $data['uid']){
				$this->setMsg( getLang('sys.invalid_params') );
				return;
			}
			$data['name'] = "{$data['make']} {$data['model']}";
			$data['total_loan'] = $this->convHaoToFen( $data['total_loan'] );
			$data['left_loan'] = $this->convHaoToFen( $data['left_loan'] );
			$data['returned_loan'] = $this->convHaoToFen( $data['returned_loan'] );
			$data['paid_interest'] = $this->convHaoToFen( $data['paid_interest'] );
			$data['paid_overdue_fee'] = $this->convHaoToFen( $data['paid_overdue_fee'] );
			$data['repayment_method_txt'] = $helper::repaymentMethod( $data['repayment_method'] );
			$data['status_txt'] = $helper::loanInfoStatusCodeName( $data['status'], $data['curr_overdue_days'] );
			$list = $md_loan->getLoanRepaymentListByPid( $id );
			foreach ($list as &$row) {
				$row['principal'] = $this->convHaoToFen( $row['principal'] );
				$row['paid_principal'] = $this->convHaoToFen( $row['paid_principal'] );
				$row['interest'] = $this->convHaoToFen( $row['interest'] );
				$row['paid_interest'] = $this->convHaoToFen( $row['paid_interest'] );
				$row['day_interest'] = $this->convHaoToFen( $row['day_interest'] );
				$row['overdue_fee'] = $this->convHaoToFen( $row['overdue_fee'] );
				$row['paid_overdue_fee'] = $this->convHaoToFen( $row['paid_overdue_fee'] );
				// $row['left_amount'] = $this->convHaoToFen( $row['left_amount'] );
				$row['status_txt'] = $helper::loanRepaymentStatusCodeName( $row['status'], $row['overdue_days'] );
				$row['index'] = $data['total_period'] - $row['period_id'] + 1;
			}
			$data['list'] = $list;
		}
		$this->setData( $data );
		$this->setCodeSuccess();
	}

	/**
	 *	设置成自动还款
	 */
	public function setAutoReturn(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		$id = $this->postval('id');
		$agree = intval($this->postval('agree'));
		if(!$agree){
			$this->setMsg( getLang('loan.auto_return_not_agreed') );
			return;
		}
		$md_loan = & load_model('loan');
		$res = $md_loan->setLoanRepaymentListAutoPay($uid, $id);
		if(!$res){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$this->setMsg( getLang('loan.successfully_set_auto_return') );
		$this->setCodeSuccess();
	}

	public function addProjcarLoanRel(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		if($uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$uid = $this->postval('uid');
		$pid = $this->postval('pid');
		$skiprate = $this->postval('skiprate');
		if(empty($uid) || empty($pid)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_loan = & load_model('loan');

		$res = $md_loan->getLoanInfo($pid, true);
		if(!empty($res)){
			$this->setMsg( getLang('loan.info_already_exists') );
			return;
		}
		$detail = $md_loan->getProjcarDetail( $pid );
		$repayment_method = $detail['repayment_method'];
		$total_loan = $detail['total_loan'];
		$total_period = $detail['total_period'];
		$left_period = $detail['left_period'];
		$rate = $detail['rate'];
		// 2018-05-08 有的合同利息提前支付，只还本金，利率可以是0		
		if (!$skiprate && $rate < 0){
			$this->setMsg( getLang('loan.rate_not_exists') );
			return;
		}
		$repayment_date = $detail['repayment_date'];
		$first_repayment_date = $detail['first_repayment_date'];
		$repayment_day = $detail['repayment_day'];


		$helper_in = load_helper('interest');
		$each_month = round( $helper_in::principalAndInterestEqual($total_loan, $rate, $total_period)/100 ) * 100;//精确到分

		$ts = time();
		$ts_first_date = strtotime($first_repayment_date);
		$year = date('Y', $ts_first_date);
		$month = date('n', $ts_first_date);
		$total_interest = 0;
		$left_loan = 0;
		$paid_loan = 0;
		$last_loan = $total_loan;
		$recent_repayment_date = null;
		//TODO 需要用事务进行处理
		for($period_id = $total_period; $period_id > 0; $period_id --){
			$date = $helper_in::getRepaymentDate($repayment_day, $month, $year);
			$interest = round($last_loan * $rate/12/100) * 100;//精确到分
			$principal = $each_month - $interest;
			$last_loan -= $principal;
			$interest_days = $helper_in::getRepaymentMonthDays($repayment_day, 1, $month, $year);
			// 2017-09-11 FIX BUG
			// 日利息=月利息／月利息天数
			$day_interest = ceil($interest/$interest_days/100) * 100;//精确到分
			if($period_id > $left_period){
				$status = LOAN_REPAYMENT_STATUS_RETURNED;
				$total_interest += $interest;
				$paid_loan += $principal;
			}else{
				if(empty($recent_repayment_date)){
					$recent_repayment_date = $date;
				}
				$status = LOAN_REPAYMENT_STATUS_NORMAL;
			}
			$md_loan->addLoanRepayment($pid, $uid, $principal, $interest, $each_month, $day_interest, $interest_days, $period_id, $date, $status);
			$month ++;
			if($month>12){
				$year ++;
				$month = 1;
			}
		}
		$left_loan = $total_loan - $paid_loan;
		$bool = $md_loan->addLoanInfo($uid, $pid, $total_loan, $paid_loan, $left_loan, $total_interest, $recent_repayment_date);
		if($bool){
			$md_loan->setUserHaveLoan($uid);
		}
		$this->setData(array('uid' => $uid, 'pid' => $pid));
		$this->setCodeSuccess();
	}

	public function addProjcarLoanRel2(){
		if(!$this->checkUserLogin()){
			return;
		}
		// 检查操作用户是否为超级管理员
		$uid = $this->uid;
		if($uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		// 检查用户手机参数
		$phone = $this->postval('phone');
		$name = $this->postval('name');
		if(empty($phone)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		// 检查用户是否存在
		$md_user = & load_model('user');
		$user = $md_user->getUserByPhone($phone);
		if(empty($user)){
			$this->setMsg( getLang('loan.user_not_exists') );
			return;
		}
		$uid = $user['id'];
		$md_accounts = & load_model('accounts');
		$accinfo = $md_accounts->getUserCurrentBankAccount( $uid );
		if(empty($accinfo)){
			$this->setMsg( getLang('loan.user_not_bind_card') );
			return;
		}
		// 如果有姓名，检查是否匹配
		if (!empty($name)) {
			$key = $this->getMDHashKey( $uid );
			$realname = $this->mdataDecrypt($key, $accinfo['realname']);
			if ($realname!=$name) {
				$this->setMsg( getLang('loan.user_realname_not_matched') );
				return;	
			}
		}
		// 检查合同
		$pid = $this->postval('pid');
		$skiprate = $this->postval('skiprate');
		$first_repayment_date = $this->postval('first_repayment_date');
		$repayment_day = $this->postval('repayment_day');
		
		if(empty($pid)){
			$this->setMsg( getLang('loan.projcar_not_exists'));
			return;
		}
		$md_loan = & load_model('loan');
		// 检查合同是否存在
		$projcar = $md_loan->getProjcarDetail( $pid );
		if(empty($projcar)){
			$this->setMsg( getLang('loan.projcar_not_exists') );
			return;
		}
		// 检查合同利率
		// 2018-05-08 有的合同利息提前支付，只还本金，利率可以是0		
		$rate = $projcar['rate'];		
		if (!$skiprate && $rate < 0){
			$this->setMsg( getLang('loan.rate_not_exists') );
			return;
		}
		// 检查合同首次还款日期
		if (!empty($first_repayment_date) && $first_repayment_date!=$projcar['first_repayment_date']) {
			$this->setMsg( getLang('loan.projcar_frd_not_matched') );
			return;
		}
		// 检查合同每月还款日
		if (!empty($repayment_day) && $repayment_day!=$projcar['repayment_day']) {
			$this->setMsg( getLang('loan.projcar_rd_not_matched') );
			return;
		}
		// 检查还款是否存在
		$loan = $md_loan->getLoanInfo($pid, true);
		if(!empty($loan)){
			$this->setMsg( getLang('loan.info_already_exists') );
			return;
		}
		// 检查还款列表是否存在
		$list = $md_loan->getLoanRepaymentListByPid($pid);
		if(!empty($list)){
			$this->setMsg( getLang('loan.list_already_exists') );
			return;
		}

		// 生成数据
		$repayment_method = $projcar['repayment_method'];
		$total_loan = $projcar['total_loan'];
		$total_period = $projcar['total_period'];
		$left_period = $projcar['left_period'];
		$repayment_date = $projcar['repayment_date'];
		$first_repayment_date = $projcar['first_repayment_date'];
		$repayment_day = $projcar['repayment_day'];
		$helper_in = load_helper('interest');
		$each_month = round( $helper_in::principalAndInterestEqual($total_loan, $rate, $total_period)/100 ) * 100;//精确到分

		$now = time();
		$ts_first_date = strtotime($first_repayment_date);
		$year = date('Y', $ts_first_date);
		$month = date('n', $ts_first_date);

		// 检查当前操作的时间是否在合同的剩余期数允许的时间内
		// 如果不在，需要同财务确认，用户还款到底多少，剩余期数是怎样的，并并手动修改合同的剩余
		$past_period = $total_period - $left_period;
		$past_year = intval($past_period/12);
		$past_month = intval($past_period%12);
		$last_year = $year+$past_year;
		$last_month = $month+$past_month;
		if ($last_month>=12) {
			$last_month -= 12;
			$last_year++;
		}
		// 根据剩余期数算出来的用户最后一次支付的日期
		$last_paid_date = $helper_in::getRepaymentDate($repayment_day, $last_month, $last_year);
		$prev_year = $last_year;
		$prev_month = $last_month-1;
		if ($prev_month<=0) {
			$prev_month = 12;
			$prev_year--;
		}
		// 根据剩余期数算出来的用户最后一次支付的上一个月日期
		$prev_paid_date = $helper_in::getRepaymentDate($repayment_day, $prev_month, $prev_year);
		$last_paid_time = strtotime($last_paid_date.' 22:00:00');//23点系统就停止自动还款了，所以设置成22点
		$prev_paid_time = strtotime($prev_paid_date.' 23:59:59'); 
		if ( ($now>$prev_paid_time && $now<=$last_paid_time) || $prev_paid_time>=$now ) {
			// 正好落在剩余期数所在的时间访问或者剩余期数比现在还提前多还了（提前绑定债权或者用户多还款的情况）。
		} else {
			$this->setMsg( getLang('loan.projcar_left_period_not_matched') );
			return;
		}

		$paid_interest = 0;
		$left_loan = 0;
		$paid_loan = 0;
		$last_loan = $total_loan;
		$recent_repayment_date = null;
		$loan_repayment_list = array();
		for($period_id = $total_period; $period_id > 0; $period_id --){
			$date = $helper_in::getRepaymentDate($repayment_day, $month, $year);
			$interest = round($last_loan * $rate/12/100) * 100;//精确到分
			$principal = $each_month - $interest;
			$last_loan -= $principal;
			$interest_days = $helper_in::getRepaymentMonthDays($repayment_day, 1, $month, $year);
			$day_interest = ceil($interest/$interest_days/100) * 100;//精确到分
			if($period_id > $left_period){
				$status = LOAN_REPAYMENT_STATUS_RETURNED;
				$paid_interest += $interest;
				$paid_loan += $principal;
			}else{
				if(empty($recent_repayment_date)){
					$recent_repayment_date = $date;
				}
				$status = LOAN_REPAYMENT_STATUS_NORMAL;
			}
			$loan_repayment_list[] = array(
				'principal'=>$principal,
				'interest'=>$interest,
				'each_month'=>$each_month,
				'day_interest'=>$day_interest,
				'interest_days'=>$interest_days,
				'period_id' => $period_id,
				'repayment_date' => $date,
				'status' => $status,
			);
			$month ++;
			if($month>12){
				$year ++;
				$month = 1;
			}
		}
		$left_loan = $total_loan - $paid_loan;
		$loan_info = array(
			'total_loan' => $total_loan,
			'paid_loan' => $paid_loan,
			'left_loan' => $left_loan,
			'paid_interest' => $paid_interest,
			'recent_repayment_date' => $recent_repayment_date,
		);
		// 检查还款合同按首次还款日期计算是否已经结束		
		if (empty($recent_repayment_date)||$left_loan<=0) {
			$this->setMsg( getLang('loan.projcar_finished') );
			return;
		}
		// 插入数据库
		$result = $md_loan->addLoan($uid,$pid,$loan_info,$loan_repayment_list);
		if (!$result) {
			$this->setMsg( getLang('sys.database_error'));
			return;
		}
		// 检查是否插入了还款信息
		$loan = $md_loan->getLoanInfo($pid, true);
		if(empty($loan)){
			$this->setMsg( getLang('loan.info_not_exists') );
			return;
		}
		// 检查是否插入了还款列表信息
		$list = $md_loan->getLoanRepaymentListByPid($pid);
		if(empty($list)){
			$this->setMsg( getLang('loan.list_not_exists') );
			return;
		}
		$this->setData(array('uid' => $uid, 'pid' => $pid));
		$this->setCodeSuccess();
	}
	
	public function finishLoan(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		if($uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$pid = $this->postval('pid');
		if(empty($pid)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_loan = & load_model('loan');
		$md_obligation = & load_model('obligation');

		//获取债权信息
		$detail = $md_obligation->getOblDetailByExtid( $pid );
		$loan = $md_loan->getLoanInfo($pid, true);
		if(empty($detail) && empty($loan)){
			$this->setMsg( getLang('obligation.not_exists') );
			return;
		}
		$md_msg = & load_model('msg');
		$codemap = load_helper('codemap');
		$counter = array(
			'total_all' => 0,
			'ok_total' => 0,
			'total_interest' => 0,
			'ok_interest' => 0,
			'total_loan' => 0,
			'ok_loan' => 0,
			);
		if(!empty($detail)){
			//辨别债权状态，若债权不为开放or售空，则跳出
			if($detail['status'] != OBL_STATUS_OPEN && $detail['status'] != OBL_STATUS_SOLDOUT){
				$this->setMsg( getLang('obligation.status', array('status' => $codemap::obligationStatusCodeName($detail['status']))) );
				return;
			}
			//标记债权处理完毕
			$id = $detail['id'];
			$b_obl = $md_obligation->updateObligationDone( $id );
			$list = $md_obligation->getHoldingObligationByOid( $id );
			if(!empty($list)){
				foreach ($list as $row) {
					$counter['total_all']++;
					$uid = $row['uid'];
					$oid = $row['oid'];
					$uoid = $row['id'];
					$amount = $row['left_amount'];
					// 2017-11-15 新邀请 DONE
					// 提前结清债权的时候，添加支付记录到obligation_repayment表中，这些是需要的数据
					// 2017-11-22 VERIFIED
					
					$name = $row['name'];
					$via = $row['via'];
					$auto_shift = $row['auto_shift'];
					$shift_to = $row['shift_to'];					
					//获取未付利息，若利息>0，则进行支付操作
					$interest = $md_obligation->getObligationInterest( $uoid );
					$interest = intval($interest);
					if($interest>0){
						$counter['total_interest']++;
						$bool = $md_obligation->paybackObligationInterestEarly( $uoid, $oid, $uid, $interest );
						if($bool){
							$counter['ok_interest']++;
							$content = json_encode(array(
								'tpl' => MSGTPL_OBL_PAIDEARLY_INTEREST,
								'param' => array(
									'id' => $uoid,
									'amount' => floor($interest/100)
									),
								));
							$md_msg->addMsg($uid, $content);
						}
					}
					// 将剩余本金还给用户
					// 2017-11-15 新邀请 DONE
					// 提前结清债权的时候，添加支付记录到obligation_repayment表中，这些是需要的数据
					$bool = $md_obligation->paybackObligationEarly( $uoid, $oid, $uid, $amount, $interest, $name, $via, $auto_shift, $shift_to );
					if($bool){
						$counter['ok_total']++;
						$content = json_encode(array(
							'tpl' => MSGTPL_OBL_PAIDEARLY,
							'param' => array(
								'id' => $uoid,
								'amount' => floor($amount/100)
								),
							));
						$md_msg->addMsg($uid, $content);
					}
				}
			}
			// 2018-07-06
            // 原来持有的已经转让给其他用户的记录不在列表中，但是这些转让的用户持有的债权利息还未支付
            // 所以这里提前结清的话，那一部分用户持有的利息没有支付，这里调用处理一下
            $unpaid_list = $md_obligation->getUnpaidObligationInterestsForEarly($id);
            if (!empty($unpaid_list)) {
                $name = $detail['name'];
                foreach ($unpaid_list as $row) {
					$counter['total_all']++;
					$uid = $row['uid'];
					$oid = $row['oid'];
					$uoid = $row['uoid'];
					$interest = $row['interest'];
					$interest = intval($interest);
					if($interest>0){
						$counter['total_interest']++;
						$bool = $md_obligation->paybackObligationInterestEarlyWithRepayment( $uoid, $name, $oid, $uid, $interest );
						if($bool){
							$counter['ok_interest']++;
							$content = json_encode(array(
								'tpl' => MSGTPL_OBL_PAIDEARLY_INTEREST,
								'param' => array(
									'id' => $uoid,
									'amount' => floor($interest/100)
								),
							));
							$md_msg->addMsg($uid, $content);
						}
					}
				}
            }
		}
		if(!empty($loan) && in_array($loan['status'], array(LOAN_INFO_STATUS_NORMAL, LOAN_INFO_STATUS_OVERDUED))){
			$counter['total_loan']++;
			$bool = $md_loan->loanPayEarly($pid);
			if($bool){
				$counter['ok_loan']++;
			}
		}
		$this->setData($counter);
		$this->setCodeSuccess();
	}

	public function finishExtraObligation(){
		if(!$this->checkUserLogin()){
			return;
		}
		$uid = $this->uid;
		if($uid !== SUPER_ADMIN){
			$this->setMsg( getLang('sys.serverunavailable') );
			return;
		}
		$id = $this->postval('id');
		if(empty($id)){
			$this->setMsg( getLang('sys.invalid_params') );
			return;
		}
		$md_loan = & load_model('loan');
		$md_obligation = & load_model('obligation');

		//获取债权信息
		$detail = $md_obligation->getOblDetailById( $id );
		if(empty($detail)){
			$this->setMsg( getLang('obligation.not_exists') );
			return;
		}
		$md_msg = & load_model('msg');
		$codemap = load_helper('codemap');
		$counter = array(
			'total_all' => 0,
			'ok_total' => 0,
			'total_interest' => 0,
			'ok_interest' => 0,
			);
		if(!empty($detail)){
			//辨别债权状态，若债权不为开放or售空，则跳出
			if($detail['status'] != OBL_STATUS_OPEN && $detail['status'] != OBL_STATUS_SOLDOUT){
				$this->setMsg( getLang('obligation.status', array('status' => $codemap::obligationStatusCodeName($detail['status']))) );
				return;
			}
			//标记债权处理完毕
			$id = $detail['id'];
			$b_obl = $md_obligation->updateObligationDone( $id );
			$list = $md_obligation->getHoldingObligationByOid( $id );
			if(!empty($list)){
				foreach ($list as $row) {
					$counter['total_all']++;
					$uid = $row['uid'];
					$oid = $row['oid'];
					$uoid = $row['id'];
					$amount = $row['left_amount'];
					// 2017-11-15 新邀请 DONE
					// 提前结清债权的时候，添加支付记录到obligation_repayment表中，这些是需要的数据					
					$name = $row['name'];
					$via = $row['via'];
					$auto_shift = $row['auto_shift'];
					$shift_to = $row['shift_to'];
					//获取未付利息，若利息>0，则进行支付操作
					$interest = $md_obligation->getObligationInterest( $uoid );
					$interest = intval($interest);
					if($interest>0){
						$counter['total_interest']++;
						$bool = $md_obligation->paybackObligationInterestEarly( $uoid, $oid, $uid, $interest );
						if($bool){
							$counter['ok_interest']++;
							$content = json_encode(array(
								'tpl' => MSGTPL_OBL_PAIDEARLY_INTEREST,
								'param' => array(
									'id' => $uoid,
									'amount' => floor($interest/100)
									),
								));
							$md_msg->addMsg($uid, $content);
						}
					}
					// 将剩余本金还给用户 
					// 2017-11-15 新邀请 DONE
					// 提前结清债权的时候，添加支付记录到obligation_repayment表中，这些是需要的数据
					// 2017-11-22 VERIFIED					
					$bool = $md_obligation->paybackObligationEarly( $uoid, $oid, $uid, $amount, $interest, $name, $via, $auto_shift, $shift_to);
					if($bool){
						$counter['ok_total']++;
						$content = json_encode(array(
							'tpl' => MSGTPL_OBL_PAIDEARLY,
							'param' => array(
								'id' => $uoid,
								'amount' => floor($amount/100)
								),
							));
						$md_msg->addMsg($uid, $content);
					}
				}
			}
			// 2018-07-06
            // 原来持有的已经转让给其他用户的记录不在列表中，但是这些转让的用户持有的债权利息还未支付
            // 所以这里提前结清的话，那一部分用户持有的利息没有支付，这里调用处理一下
            $unpaid_list = $md_obligation->getUnpaidObligationInterestsForEarly($id);
            if (!empty($unpaid_list)) {
                $name = $detail['name'];
                foreach ($unpaid_list as $row) {
					$counter['total_all']++;
					$uid = $row['uid'];
					$oid = $row['oid'];
					$uoid = $row['uoid'];
					$interest = $row['interest'];
					$interest = intval($interest);
					if($interest>0){
						$counter['total_interest']++;
						$bool = $md_obligation->paybackObligationInterestEarlyWithRepayment( $uoid, $name, $oid, $uid, $interest );
						if($bool){
							$counter['ok_interest']++;
							$content = json_encode(array(
								'tpl' => MSGTPL_OBL_PAIDEARLY_INTEREST,
								'param' => array(
									'id' => $uoid,
									'amount' => floor($interest/100)
								),
							));
							$md_msg->addMsg($uid, $content);
						}
					}
				}
            }
		}
		$this->setData($counter);
		$this->setCodeSuccess();
	}

}