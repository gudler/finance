<?php
require_once PATH_BASE_CB_CONTROLLER;
require_once PATH_PAYMENT_FUIOU;

class Cb_fuiou extends Callback_controller
{
	public function __construct()
	{
		parent::__construct();
		$this->setTemplate('cb_fuiou');
		$this->setCodeFailed();
	}

	protected function log_request($status)
	{
		$rcd     = requestval('rcd');
		$rdesc   = requestval('rdesc');
		$orderid = requestval('orderid');
		$md5     = requestval('md5');
		$data    = sprintf("status:%s|rcd:%s|rdesc:%s|orderid:%s|md5:%s", $status, $rcd, $rdesc, $orderid, $md5);
		file_put_contents(DIR_LOG . 'fuiou.cb.log', date("Y-m-d H:i:s") . "|" . $data . "\n", FILE_APPEND);
	}

	protected function log_request_tp($status)
	{
		$orderno     = requestval('orderno');     //商户请求流水
		$merdt       = requestval('merdt');       //原请求日期
		$fuorderno   = requestval('fuorderno');   //富友流水
		$tpmerdt     = requestval('tpmerdt');     //退票日期
		$futporderno = requestval('futporderno'); //退票流水
		$accntno     = requestval('accntno');     //账号
		$accntnm     = requestval('accntnm');     //账户名称
		$bankno      = requestval('bankno');      //总行代码
		$amt         = requestval('amt');         //退票金额
		$state       = requestval('state');       //状态
		$result      = requestval('result');      //交易结果
		$reason      = requestval('reason');      //结果原因
		$mac         = requestval('mac');         //校验值
		$data        = sprintf("status:%s|orderno:%s|merdt:%s|fuorderno:%s|tpmerdt:%s|futporderno:%s|accntno:%s|accntnm:%s|bankno:%s|amt:%s|state:%s|result:%s|reason:%s|mac:%s", $status, $orderno, $merdt, $fuorderno, $tpmerdt, $futporderno, $accntno, $accntnm, $bankno, $amt, $state, $result, $reason, $mac);
		file_put_contents(DIR_LOG . 'fuiou.tpcb.log', date("Y-m-d H:i:s") . "|" . $data . "\n", FILE_APPEND);
	}

	//重新支付 URL，重新支付时跳转到的商户页面地址
	public function reurl()
	{
		$this->setMsg(getlang('fuiou.recharge_failed_and_return'));
	}

	//退票通知 URL，商户代付款失败的后台通知地址
	public function tpurl()
	{
		$orderno     = requestval('orderno');     //商户请求流水
		$merdt       = requestval('merdt');       //原请求日期
		$fuorderno   = requestval('fuorderno');   //富友流水
		$tpmerdt     = requestval('tpmerdt');     //退票日期
		$futporderno = requestval('futporderno'); //退票流水
		$accntno     = requestval('accntno');     //账号
		$accntnm     = requestval('accntnm');     //账户名称
		$bankno      = requestval('bankno');      //总行代码
		$amt         = requestval('amt');         //退票金额
		$state       = requestval('state');       //状态
		$result      = requestval('result');      //交易结果
		$reason      = requestval('reason');      //结果原因
		$mac         = requestval('mac');         //校验值

		if (empty($orderno)
			|| empty($merdt)
			|| empty($fuorderno)
			|| empty($tpmerdt)
			|| empty($futporderno)
			|| empty($accntno)
			|| empty($accntnm)
			|| empty($bankno)
			|| empty($amt)
			|| empty($state)
			|| empty($result)
			|| empty($reason)
			|| empty($mac)
		) {
			$this->log_request_tp('var_empty');
			exit('fuiou.var_empty');
		}
		// 2017-09-25 BUF FIX
		// 富友的研发确认，这里的mac MD5验证需要用代付的密钥
		$cnf = config_item('payment_fuiou_perpay');
		//Md5(merid+”|”+key+”|”+orderno+”|”+me rdt+”|”+accntno+”|”+amt)
		$sign        = md5($cnf['mchid'] . '|' . $cnf['mchkey'] . '|' . $orderno . '|' . $merdt . '|' . $accntno . '|' . $amt);
		// 2019-07-02 bug fix
		// 富友的研发确认，加密字符串的时间可能是退票日期
		$signTpmerdt = md5($cnf['mchid'] . '|' . $cnf['mchkey'] . '|' . $orderno . '|' . $tpmerdt . '|' . $accntno . '|' . $amt);
		if ($sign != $mac && $signTpmerdt != $mac) {
			$this->log_request_tp('sign_not_match');
			exit('fuiou.sign_not_match');
		}
		// 2017-09-25 UPDATE
		// 所有退票都写入日志
		$md_accounts = &load_model('accounts');
		$row         = $md_accounts->getWithdrawTuipiao($orderno);
		if (!empty($row)) {
			$this->log_request_tp('orderno_exist');
			// 根据富友文档说明，回复字符串“1”，表示平台处理成功
			exit('1');
		}
		// 退票邮件通知功能
		$content = json_encode([
			'tpl'   => MSGTPL_WITHDRAW_TP,
			'param' => [
				'datetime' => date('Y-m-d H:i:s'),
				'orderno'  => $orderno,
				'amount'   => $amt
			]
		]);
		$md_email_notify = &load_model('email_notify');
		$md_email_notify->addNotify(MSGTPL_WITHDRAW_TP, $content);
		// 插入记录
		$id = $md_accounts->addWithdrawTuipiao($orderno, $merdt, $fuorderno, $tpmerdt, $futporderno, $accntno, $accntnm, $bankno, $amt, $state, $result, $reason, $mac);
		if (false === $id) {
			$this->log_request_tp('insert_record_failed');
			exit('internal.server_error');
		}

		// 判断通知状态是否正确
		/*
			0:交易未发送
			1:交易已发送且成功
			2:交易已发送且失败
			3:交易发送中
			7:交易已发送且超时
			根据富友工程师确认，只有state=1这一种情况回调
		 */
		if (1 != $state) {
			$bool = $md_accounts->updateWithdrawTuipiaoIllegal($id, 'state_invalid');
			$this->log_request_tp('state_invalid:' . $bool);
			exit('1');
		}
		// 根据orderno，获取原来提现记录，是否存在
		$withdraw_order = $md_accounts->getWithdrawOrderByOrderId($orderno);
		if (empty($withdraw_order) || empty($withdraw_order['id'])) {
			$bool = $md_accounts->updateWithdrawTuipiaoIllegal($id, 'withdraw_order_not_found');
			$this->log_request_tp('withdraw_order_not_found:' . $bool);
			exit('1');
		}
		// 判断卡号是否匹配
		$cipher     = Cipher::getInstance();
		$key        = $cipher->getMDHashKey($withdraw_order['uid']);
		$str        = base64_decode($withdraw_order['cardno']);
		$raw_cardno = $cipher->aesDecode($key, $str);
		if ($raw_cardno != $accntno) {
			$bool = $md_accounts->updateWithdrawTuipiaoIllegal($id, 'cardno_not_match');
			$this->log_request_tp('cardno_not_match:' . $bool);
			exit('1');
		}
		// 判断金额是否正确
		if ($withdraw_order['money'] - $withdraw_order['fee'] != $amt) {
			$bool = $md_accounts->updateWithdrawTuipiaoIllegal($id, 'amount_not_match');
			$this->log_request_tp('amount_not_match:' . $bool);
			exit('1');
		}
		// 判断提现记录状态是否正确
		if (WITHDRAW_STATUS_DONE != $withdraw_order['status']) {
			$bool = $md_accounts->updateWithdrawTuipiaoIllegal($id, 'withdraw_status_invalid');
			$this->log_request_tp('withdraw_status_invalid:' . $bool);
			exit('1');
		}
		// 更新退票记录信息
		// 目前需要线下处理退票逻辑：同财务确认退票是否真的发生，然后手动操作，注意需要退回用户提现手续费。
		$bool = $md_accounts->updateWithdrawTuipiaoConfirmed($id, $withdraw_order['id'], $withdraw_order['uid'], $withdraw_order['baid'], $withdraw_order['fee']);
		$this->log_request_tp('internal_update_confirmed' . $bool);
		// 根据富友文档说明，回复字符串“1”，表示平台处理成功
		exit('1');
	}

	//后台通知 URL，商户接收支付结果的后台通知地址
	public function backurl()
	{
		$rcd     = requestval('rcd');
		$rdesc   = requestval('rdesc');
		$orderid = requestval('orderid');
		$md5     = requestval('md5');

		if (empty($rcd) || empty($rdesc) || empty($orderid) || empty($md5)) {
			$this->log_request('var_empty');
			exit('fuiou.var_empty');
		}
		$cnf  = config_item('payment_fuiou');
		$sign = md5($rcd . '|' . $orderid . '|' . $cnf['mchkey']);
		if ($sign != $md5) {
			$this->log_request('sign_not_match');
			exit('fuiou.sign_not_match');
		}
		$md_accounts = &load_model('accounts');
		$payinfo     = $md_accounts->getRechargeOrderByTransId($orderid);
		if (empty($payinfo)) {
			$this->log_request('id not exists');
			exit('id not exists');
		}
		$this->log_request('ok');

		$status = $payinfo['status'];
		if (RECHARGE_STATUS_PAID == $status || RECHARGE_STATUS_DONE == $status) {
			exit('OK');
		}
		if ('0000' == $rcd) {
			$status = RECHARGE_STATUS_PAID;

			$oq = new OrderQuery_pub;
			$oq->setOrderId($orderid);
			$res = $oq->getStatus();
			if (false === $res) {
				$this->log_request('status_query_failed');
				exit('Order status query failed');
			}
			if (RECHARGE_ORDER_OK != $res['code']) {
				$this->log_request('status_check_failed:' . $res['code']);
				exit('Order status check failed');
			}
		} elseif (RECHARGE_STATUS_FAILED == $status) {
			exit('OK');
		} else {
			$status = RECHARGE_STATUS_FAILED;
		}
		$md_accounts->rechargeOrderResponsedByOrderID($orderid, $status, $rdesc);
		exit('OK');
	}

	//页面通知 URL，支付成功后跳转到的商户页面地址
	public function homeurl()
	{
		$rcd     = getval('rcd');
		$rdesc   = getval('rdesc');
		$orderid = getval('orderid');
		$md5     = getval('md5');

		if (empty($rcd) || empty($rdesc) || empty($orderid) || empty($md5)) {
			$this->log_request('var_empty');
			$this->setMsg(getlang('fuiou.var_empty'));
			return;
		}
		$cnf  = config_item('payment_fuiou');
		$sign = md5($rcd . '|' . $orderid . '|' . $cnf['mchkey']);
		if ($sign != $md5) {
			$this->log_request('sign_not_match');
			$this->setMsg(getlang('fuiou.sign_not_match'));
			return;
		}
		$md_accounts = &load_model('accounts');
		$payinfo     = $md_accounts->getRechargeOrderByTransId($orderid);
		if (empty($payinfo)) {
			$this->log_request('id not exists');
			$this->setMsg(getlang('fuiou.id_not_exists'));
			return;
		}
		$this->log_request('ok');
		$status = $payinfo['status'];
		if (RECHARGE_STATUS_PAID == $status || RECHARGE_STATUS_DONE == $status) {
			$this->setMsg(getlang('fuiou.recharge_ok_and_return'));
			$this->setCodeSuccess();
			return;
		}

		if ('0000' == $rcd) {
			$status = RECHARGE_STATUS_PAID;

			$oq = new OrderQuery_pub;
			$oq->setOrderId($orderid);
			$res = $oq->getStatus();
			if (false === $res) {
				$this->log_request('status_query_failed');
				$this->setMsg(getlang('fuiou.status_query_failed'));
				return;
			}
			if (RECHARGE_ORDER_OK != $res['code']) {
				$this->log_request('status_check_failed:' . $res['code']);
				$this->setMsg(getlang('fuiou.status_check_failed'));
				return;
			}
			$this->setMsg(getlang('fuiou.recharge_ok_and_return'));
		} elseif (RECHARGE_STATUS_FAILED == $status) {
			$this->setMsg($rdesc);
			// $this->setMsg( getlang('fuiou.recharge_failed_and_return') );
			return;
		} else {
			$status = RECHARGE_STATUS_FAILED;
			$this->setMsg($rdesc);
			// $this->setMsg( getlang('fuiou.recharge_failed_and_return') );
		}
		$md_accounts->rechargeOrderResponsedByOrderID($orderid, $status, $rdesc);
		$this->setCodeSuccess();
	}

}
