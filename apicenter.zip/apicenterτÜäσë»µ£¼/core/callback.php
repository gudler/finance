<?php

@ob_start();
$controller = isset($_GET['c']) ? trim($_GET['c']) : 'index';
$method = isset($_GET['m']) ? trim($_GET['m']) : 'index';

$controller = 'cb_' . $controller;
$file_path = DIR_CTRL . $controller . '.php';
if (!file_exists($file_path)){
	$controller = 'callback_controller';
	$method = 'notExists';
}else{

}

$ctrl = & load_ctrl($controller);
if(!method_exists($ctrl, $method)){
	$method = 'notExists';
}

//set_status_header(200);
$ctrl->$method();
$ctrl->output();