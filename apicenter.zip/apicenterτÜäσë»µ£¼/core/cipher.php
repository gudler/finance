<?php

class Cipher{
	
	const CIPHER = MCRYPT_RIJNDAEL_128;
	const MODE = MCRYPT_MODE_CBC;

	private static $_instance;
	private static $_device;
	private static $_data;
	
	private function __construct(){

	}

	private function _initInputData(){
		$d = self::decryptData( postval('data') );
		self::$_data = json_decode( $d, true );
	}

	public function __clone(){
		trigger_error('CLONE IS NOT ALLOWED', E_USER_ERROR);
	}

	/**
	 *	获取对象单例
	 */
	public static function getInstance(){
		if(!(self::$_instance instanceof self)){
			self::$_instance = new self;
		}
		return self::$_instance;
	}

	private function getiv(){
		//固定初始向量数值，128位为16字节字符，256位为32位字符
		//$iv = mcrypt_create_iv(mcrypt_get_iv_size(self::CIPHER,self::MODE),MCRYPT_RAND);
    	return 'xumm12x90z578912';
	}

	public function aesEncode( $key, $str, $iv = null ){
		if(null === $iv){
			$iv = $this->getiv();
		}
		return mcrypt_encrypt( self::CIPHER, $key, $str, self::MODE, $iv );
	}

	public function aesDecode( $key, $str, $iv = null ){
		if(null === $iv){
			$iv = $this->getiv();
		}
		$str = mcrypt_decrypt( self::CIPHER, $key, $str, self::MODE, $iv );
		$str = rtrim($str);//解密后不是key的倍数的数据，会自动添加空格，故需做一次trim
		return $str;
	}


	/**
	 *	主要使用方向：使用公钥进行解密
	 */
	public function rsaPuDecode( $key, $data ){
		static $pu_key = null;
		if( null === $pu_key ){
			$pu_key = openssl_pkey_get_public($key);
		}
		$decrypted = null;
		openssl_public_decrypt( $data, $decrypted, $pu_key, OPENSSL_PKCS1_PADDING );//公钥解密
		return $decrypted;
	}

	/**
	 *	主要使用方向：使用公钥进行加密
	 */
	public function rsaPuEncode( $key, $data ){
		static $pu_key = null;
		if( null === $pu_key ){
			$pu_key = openssl_pkey_get_public($key);
		}
		$encrypted = null;
		openssl_public_encrypt( $data, $encrypted, $pu_key, OPENSSL_PKCS1_PADDING );//公钥加密
		return $encrypted;
	}

	/**
	 *	主要使用方向：使用私钥进行解密
	 */
	public function rsaPiDecode( $key, $data, $passwd ){
		static $pi_key = null;
		if(null === $pi_key){
			$pi_key = openssl_pkey_get_private($key, $passwd);
		}
		$decrypted = null;
		$bool = openssl_private_decrypt( $data, $decrypted, $pi_key, OPENSSL_PKCS1_PADDING );//私钥解密

		return $decrypted;
	}

	/**
	 *	主要使用方向：使用私钥进行加密
	 */
	public function rsaPiEncode( $key, $data, $passwd ){
		static $pi_key = null;
		if(null === $pi_key){
			$pi_key = openssl_pkey_get_private($key, $passwd);
		}
		$encrypted = null;
		openssl_private_encrypt( $data, $encrypted, $pi_key, OPENSSL_PKCS1_PADDING );//私钥加密
		return $encrypted;
	}
	
	public function getUserPublicKey(){
		$device = $this->getDeviceID();
		if(null === $device){
			return null;
		}
		$md_cipher = & load_model('cipher');
		$info = $md_cipher->getPublicKeyInfo($device);
		if(!empty($info) && isset($info['pubkey'])){
			$pubkey = $info['pubkey'];
		}else{
			$pubkey = null;
		}
		return $pubkey;
	}

	public function initRSAKey(){
		/**
		 *	device id为串码的md5值，串码生产过程应该加上随机码，每次重装应重新生成。
		 *	上报报备RSA KEY的时候，应将device ID原始信息同步上传，结构如：
		 *	{platform:"android", ts: "1458132366", udid: "", dev:"29bc48c0474eb3c9ceb08d35cc87a4ca", key:""}
		 *	传输过程中应使用服务器RSA公钥进行加密。
		 *	dev值＝md5（platform＋ts＋td）
		 */
		$darr = postval('darr');
		$prikey = SRVRSA_PRIVATE_KEY;
		$passwd = SRVRSA_PASSWD;
		//$darr = str_replace(array("\n", "\r"), '', $darr);
		$darr = json_decode($darr, true);

		$arr = array();
		if(!is_array($darr)){
			stored_messages('darr not exists');
			return CODES_FAILED;
		}
		$pi_key = openssl_pkey_get_private($prikey, $passwd);
		for ($i=0,$l=count($darr); $i<$l; $i++) {
			$row = str_replace(array("\n", "\r"), '', $darr[$i]);
			$row = trim($row);
			$value = base64_decode($row);
			$arr[] = $this->rsaPiDecode($prikey, $value, $passwd);
		}
		$dinfo = implode('', $arr);
		$dinfo = json_decode($dinfo, true);
		if($dinfo){
			$platform = $dinfo['platform'];
			$ts = $dinfo['ts'];
			$udid = $dinfo['udid'];
			//$dev = strtolower($dinfo['dev']);
			$dev = $this->getDeviceID();
			$key = $dinfo['key'];

			$pass = false;
			do{
				if( $ts<100000000 ){
					stored_messages('timestamp error');
					break;
				}
				if(md5($platform.$ts.$udid) != $dev){
					stored_messages('device ID check error');
					break;
				}
				if(empty($key)){
					stored_messages('public key is empty');
					break;
				}
				$key = trim($key);
				if(substr($key, 0, 5) != '-----'){
					$key = "-----BEGIN PUBLIC KEY-----\n".$key."\n-----END PUBLIC KEY-----";
				}
				$resoure = openssl_pkey_get_public($key);
				if(!is_resource($resoure)){
					stored_messages('public key error');
					break;
				}
				$pass = true;

			}while(false);

			if(!$pass){
				return CODES_DATA_ILLEGAL;
			}
			$md_cipher = & load_model('cipher');
			$udid = strtoupper($udid);//将所有udid大写
			$res = $md_cipher->addPublicKey($dev, $udid, $key);
			if(!$res){
				stored_messages('add public key failed');
				return CODES_FAILED;
			}
			$this->initAESKey();
			return CODES_OK;
		}else{
			stored_messages('json decode darr error');
			return CODES_DATA_ILLEGAL;
		}
	}

	/**
	 *	初始化客户端与服务器端的对称加密密码
	 */
	public function initAESKey(){
		$aeskey = md5( mt_rand() . microtime() );
		$md_cipher = & load_model('cipher');
		$device = $this->getDeviceID();
		$bool = $md_cipher->addAESKey($device, $aeskey);
		if(!$bool){
			return false;
		}
		$ts = time();
		$md_cipher->cacheAESKey($device, $aeskey, $ts, $ts);
		return true;
	}

	/**
	 *	获取当前设备ID
	 */
	public function getDeviceID(){
		if(null === self::$_device){
			$id = postval( 'device' );//此device ID为md5值。
			if( preg_match("/^[a-z0-9]{32}$/", $id) ){
				self::$_device = $id;
			}
		}
		return self::$_device;
	}

	/**
	 *	获取当前设备的加解密密码
	 */
	public function getAESKey(){
		static $aeskey;
		if(null === $aeskey){
			$device = $this->getDeviceID();
			$md_cipher = & load_model('cipher');
			$info = $md_cipher->getAESKeyInfo($device);
			if(!empty($info) && isset($info['aeskey'])){
				$aeskey = $info['aeskey'];
			}else{
				$aeskey = null;
			}
		}
		return $aeskey;
	}

	/**
	 *	用AESKEY解密
	 */
	public function decryptData($data, $key = null, $iv = null){
		if(null === $key){
			$key = $this->getAESKey();
		}
		if(empty($key)){
			return null;
		}
		//加密后的data应是先被base64编码的，所以需要先解码
		$bin = base64_decode($data);
		if(strlen($bin)){
			return $this->aesDecode($key, $bin, $iv);
		}else{
			return null;
		}
	}

	/**
	 *	用AESKEY加密
	 */
	public function encryptData($data, $key = null, $iv = null){
		if(null === $key){
			$key = $this->getAESKey();
		}
		if(empty($key)){
			return null;
		}
		$raw = $this->aesEncode($key, $data, $iv);
		//因为raw为二进制，网络传输不便，故改为base64编码数据
		$val = base64_encode($raw);
		return $val;
	}

	/**
	 *	根据KEY获取加密数据
	 */
	public function getValue($key){
		if(null === self::$_data){
			$this->_initInputData();
		}
		$d = self::$_data;
		if(isset($d[$key])){
			return $d[$key];
		}else{
			return null;
		}
	}

	public function getMDHashKey( $uid ){
		return md5(MDHASH_KEY . $uid . MDHASH_KEY . $uid);
	}

}