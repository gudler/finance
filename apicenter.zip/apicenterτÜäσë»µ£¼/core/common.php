<?php

if ( ! function_exists('postval') ){
	function postval($key, $default = null){
		return isset($_POST[$key]) ? $_POST[$key] : $default;
	}
}

if ( ! function_exists('getval') ){
	function getval($key, $default = null){
		return isset($_GET[$key]) ? $_GET[$key] : $default;
	}
}

if ( ! function_exists('requestval') ){
	function requestval($key, $default = null){
		return isset($_REQUEST[$key]) ? $_REQUEST[$key] : $default;
	}
}

if ( ! function_exists('strswap') ){
	function strswap(&$str, $params){
		$search = array();
		$replace = array();
		foreach ($params as $key => $value) {
			$search[] = '{'.strtolower($key).'}';
			$replace[] = $value;
		}
		$str = str_replace($search, $replace, $str);
	}
}

if ( ! function_exists('getlang')){
	function getlang(){
		static $lang = null;
		
		$params = func_get_args();
		$key = strtolower(array_shift($params));
		if (null === $lang){
			if(!defined('USER_LANGUAGE')){
				$userlangage = 'chinese';
			}else{
				$userlangage = USER_LANGUAGE;
			}
			$file_path = DIR_LANG . $userlangage . DS . 'lang.php';
			if (file_exists($file_path)){
				require($file_path);
			}
		}
		list($p1,$p2) = explode('.', $key, 2);
		if(isset($lang[$p1]) && isset($lang[$p1][$p2])){
			$key = $lang[$p1][$p2];
			if(!empty($params)){
				strswap($key, $params[0]);
			}
		}
		return $key;
	}
}

if ( ! function_exists('load_ctrl')){
	function &load_ctrl($class){
		static $_classes = array();
		
		$class = strtolower($class);

		if (isset($_classes[$class])){
			return $_classes[$class];
		}

		$name = false;

		$file_path = DIR_CTRL . $class . '.php';
		if (file_exists($file_path)){
			$name = ucfirst($class);

			if (class_exists($name) === false){
				require($file_path);
			}

		}

		if ($name === false){
			exit('Unable to locate the specified controller: '.$class.'.php');
		}

		$_classes[$class] = new $name();
		return $_classes[$class];
	}
}

if ( ! function_exists('load_model')){
	function &load_model($class){
		static $_classes = array();
		
		$class = strtolower($class);

		if (isset($_classes[$class])){
			return $_classes[$class];
		}

		$name = false;

		$file_path = DIR_MODEL . $class . '.php';
		if (file_exists($file_path)){
			$name = ucfirst($class) . 'Model';

			if (class_exists($name) === false){
				require($file_path);
			}

		}

		if ($name === false){
			exit('Unable to locate the specified model: '.$class.'.php');
		}

		$_classes[$class] = new $name();
		return $_classes[$class];
	}
}

if ( ! function_exists('load_library')){
	function &load_library($class){
		static $_classes = array();
		
		$class = strtolower($class);

		if (isset($_classes[$class])){
			return $_classes[$class];
		}

		$name = false;

		$file_path = DIR_LIB . $class . '.php';
		if (file_exists($file_path)){
			$name = ucfirst($class) . 'Library';

			if (class_exists($name) === false){
				require($file_path);
			}

		}

		if ($name === false){
			exit('Unable to locate the specified library: '.$class.'.php');
		}

		$_classes[$class] = new $name();
		return $_classes[$class];
	}
}

if ( ! function_exists('load_helper')){
	/**
	 * load_helper返回类名，因为helper约定为静态类，调用方式都为静态调用。
	 */
	function load_helper($class){
		static $_classes = array();
		
		$class = strtolower($class);

		if (isset($_classes[$class])){
			return $_classes[$class];
		}

		$name = false;

		$file_path = DIR_HELPER . $class . '.php';
		if (file_exists($file_path)){
			$name = ucfirst($class) . 'Helper';

			if (class_exists($name) === false){
				require($file_path);
			}

		}

		if ($name === false){
			exit('Unable to locate the specified helper: '.$class.'.php');
		}

		$_classes[$class] = $name;
		return $_classes[$class];
	}
}

if ( ! function_exists('load_define')){
	/**
	 * load_define 获取常量文件。
	 */
	function load_define($define){
		static $_defines = array();
		
		$define = strtolower($define);

		if (isset($_defines[$define])){
			return true;
		}

		$name = false;

		$file_path = DIR_ETC . 'def_' . $define . '.php';
		if (file_exists($file_path)){
			require($file_path);
		}
		$_defines[$define] = true;
		return true;
	}
}

if ( ! function_exists('get_config')){
	function &get_config($replace = array()){
		static $_config = null;

		if (!is_null($_config)){
			return $_config;
		}

		do{
			$file_path = DIR_ETC . ENVIRONMENT . '/config.php';
			if(file_exists($file_path)){
				break;
			}
			$file_path = DIR_ETC . 'config.php';
			if(file_exists($file_path)){
				break;
			}

		}while(0);

		require($file_path);

		if ( ! isset($config) OR ! is_array($config)){
			exit('Your config file does not appear to be formatted correctly.');
		}

		if (count($replace) > 0){
			foreach ($replace as $key => $val){
				if (isset($config[$key])){
					$config[$key] = $val;
				}
			}
		}

		$_config =& $config;
		return $_config;
	}
}

if ( ! function_exists('config_item')){
	function config_item($item){
		static $_config_item = array();

		if ( ! isset($_config_item[$item])){
			$config =& get_config();

			if ( ! isset($config[$item])){
				return false;
			}
			$_config_item[$item] = $config[$item];
		}

		return $_config_item[$item];
	}
}

if ( ! function_exists('set_status_header')){
	function set_status_header($code = 200, $text = ''){
		$stati = array(
			200	=> 'OK',
			201	=> 'Created',
			202	=> 'Accepted',
			203	=> 'Non-Authoritative Information',
			204	=> 'No Content',
			205	=> 'Reset Content',
			206	=> 'Partial Content',

			300	=> 'Multiple Choices',
			301	=> 'Moved Permanently',
			302	=> 'Found',
			304	=> 'Not Modified',
			305	=> 'Use Proxy',
			307	=> 'Temporary Redirect',

			400	=> 'Bad Request',
			401	=> 'Unauthorized',
			403	=> 'Forbidden',
			404	=> 'Not Found',
			405	=> 'Method Not Allowed',
			406	=> 'Not Acceptable',
			407	=> 'Proxy Authentication Required',
			408	=> 'Request Timeout',
			409	=> 'Conflict',
			410	=> 'Gone',
			411	=> 'Length Required',
			412	=> 'Precondition Failed',
			413	=> 'Request Entity Too Large',
			414	=> 'Request-URI Too Long',
			415	=> 'Unsupported Media Type',
			416	=> 'Requested Range Not Satisfiable',
			417	=> 'Expectation Failed',

			500	=> 'Internal Server Error',
			501	=> 'Not Implemented',
			502	=> 'Bad Gateway',
			503	=> 'Service Unavailable',
			504	=> 'Gateway Timeout',
			505	=> 'HTTP Version Not Supported'
		);

		if (isset($stati[$code]) && $text == ''){
			$text = $stati[$code];
		}

		$server_protocol = (isset($_SERVER['SERVER_PROTOCOL'])) ? $_SERVER['SERVER_PROTOCOL'] : false;

		if (substr(php_sapi_name(), 0, 3) == 'cgi'){
			header("Status: {$code} {$text}", true);
		}
		elseif ($server_protocol == 'HTTP/1.1' OR $server_protocol == 'HTTP/1.0'){
			header($server_protocol." {$code} {$text}", true, $code);
		}
		else{
			header("HTTP/1.1 {$code} {$text}", true, $code);
		}
	}
}


if ( ! function_exists('stored_messages')){
	function stored_messages($msg = null){
		static $messages = array();

		if(null !== $msg){
			$messages[] = $msg;
			return true;
		}else{
			return $messages;
		}
	}
}

if ( ! function_exists('log_error')){
	function log_error($msg){
		syslog(LOG_ERR, sprintf("[%s]%s", date('Y-m-d H:i:s'), $msg));
	}
}

if ( ! function_exists('log_warning')){
	function log_warning($msg){
		syslog(LOG_WARNING, sprintf("[%s]%s", date('Y-m-d H:i:s'), $msg));
	}
}

if ( !function_exists('fastcgi_finish_request')) {
	function fastcgi_finish_request(){
		
	}
}