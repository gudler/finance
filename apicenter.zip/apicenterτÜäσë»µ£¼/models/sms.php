<?php
require_once PATH_BASE_MODEL;

class SmsModel extends Model{

	protected $tbl_code = 'sms_code_list';

	public function __construct(){
		parent::__construct();
	}

	public function getByDate($mobile, $date, $limit = 50){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT id, mobile, created_time FROM `{$this->tbl_code}` WHERE date(created_time) = '%s' AND mobile = '%d' ORDER BY id DESC LIMIT %d", $date, $mobile, $limit);
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}				
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 * 2018-08-23,69豪车整合
	 * 增加 app 字段，默认是空，表示鹰眼理财，兼容原来的请求
	 */
	public function addPhoneCode($phone, $code, $type, $template = '', $app = APP_DEFAULT){
		$db = & $this->getDB();
		$sql = "insert into `{$this->tbl_code}` set app = ?, mobile = ?, code = ?, type = ?, template = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssiss', $app, $phone, $code, $type, $template);
		$bool = $stmt->execute();
		$id = null;
		if($bool){
			$id = $stmt->insert_id;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $id;
	}	

	public function addXtransVerifyCode($phone, $code, $type, $template, $ext_id){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_code}` SET mobile = ?, code = ?, type = ?, template = ?, ext_id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sissi', $phone, $code, $type, $template, $ext_id);
		$bool = $stmt->execute();
		$id = null;
		if($bool){
			$id = $stmt->insert_id;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $id;
	}

	/**
	 * 2018-08-23,69豪车整合
	 * 获取发送短信列表，增加app过滤，默认是空，表示鹰眼理财，兼容原来请求
	 */
	public function getSendList($app = APP_DEFAULT){
		$db = & $this->getReadonlyDB();
		$datetime = date('Y-m-d H:i:s', time()-60);//60秒前的数据抛弃，因为超过60秒后用户可以设置重发。
		$sql = "select * from `{$this->tbl_code}` where sent = 0 and created_time > '{$datetime}' and used = 0 and failed_times < 3 and app = '{$app}'";
		$result = $db->query($sql);
		$arr = array();
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return $arr;
		}						
		while ($row = $result->fetch_assoc()) {
			$arr[] = $row;
		}
		$result->free();
		return $arr;
	}

	public function getPhoneCodeById($id){
		$db = & $this->getReadonlyDB();
		$sql = "select id,mobile,code,template,type,ext_id, created_time, used, sent from `{$this->tbl_code}` where id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('i', $id);
		$stmt->execute();
		$id = $mobile = $code = $template = $type = $ext_id = $created_time = $used = $sent = null;
		$stmt->bind_result($id, $mobile, $code, $template, $type, $ext_id, $created_time, $used, $sent);
		
		$row = null;
		if ($stmt->fetch()) {
			$row = array(
				'id'=>$id,
				'phone'=>$mobile,
				'code'=>$code,
				'template'=>$template,
				'type'=>$type,
				'ext_id' => $ext_id,
				'created_time' => $created_time,
				'used' => $used,
				'sent' => $sent
				);
		}
		$stmt->close();
		return $row;
	}

	public function getPhoneCode($phone, $type){
		$db = & $this->getReadonlyDB();
		$datetime = date('Y-m-d H:i:s', time()-30*60);//30分钟前的数据抛弃，因为验证码有效期只有30分钟。
		$sql = "select id,mobile,code,template,ext_id from `{$this->tbl_code}` where mobile = ? and used = 0 and created_time > '{$datetime}' and type = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $phone, $type);
		$stmt->execute();
		$id = $mobile = $code = $template = $ext_id = null;
		$stmt->bind_result($id, $mobile, $code, $template, $ext_id);
		
		$arr = array();
		while ($stmt->fetch()) {
			$arr[] = array('id'=>$id, 'phone'=>$mobile, 'code'=>$code, 'template'=>$template, 'ext_id' => $ext_id);
		}
		$stmt->close();
		return $arr;
	}

	public function setSent($id_arr){
		$db = & $this->getDB();
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($id_arr);
		$sql = sprintf("update `{$this->tbl_code}` set sent = 1, sent_time = NOW() where id in (%s)", $id_str);
		return $db->query($sql);
	}

	public function setFailed($id_arr){
		$db = & $this->getDB();
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($id_arr);
		$sql = sprintf("update `{$this->tbl_code}` set failed_times = failed_times + 1 where id in (%s)", $id_str);
		return $db->query($sql);
	}

	/**
	 * @return affected_rows(int)|false
	 */
	public function useCode($phone, $code){
		$db = & $this->getDB();
		$sql = "update `{$this->tbl_code}` set used = 1, used_time = NOW() where mobile = ? and code = ? and used = 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('si', $phone, $code);
		$bool = $stmt->execute();
		$affected_rows = 0;
		if($bool){
			$affected_rows = $stmt->affected_rows;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $affected_rows;
	}

	/**
	 * @return affected_rows(int)|false
	 */
	public function useCodeByID($phone, $code, $code_id){
		$db = & $this->getDB();
		$sql = "update `{$this->tbl_code}` set used = 1, used_time = NOW() where mobile = ? and code = ? and id = ? and used = 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sii', $phone, $code, $code_id);
		$bool = $stmt->execute();
		$affected_rows = 0;
		if($bool){
			$affected_rows = $stmt->affected_rows;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $affected_rows;
	}

}