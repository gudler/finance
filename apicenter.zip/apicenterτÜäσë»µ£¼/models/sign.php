<?php
require_once PATH_BASE_MODEL;

class SignModel extends Model{

	protected $tbl_sign = 'user_sign';

	protected $tbl_account = 'user_accounts';

	protected $tbl_account_log = 'user_accounts_log';

	public function __construct(){
		parent::__construct();
	}

	/**
	 * 签到记录添加
	 * 
	 * @param $uid 用户ID
	 * @param $date 签到日期
	 * @param $amount 签到金额
	 * @param $day_idx 连续签到天数
	 * @param $channel APP通道，2是IOS，3是Android
	 * @param $app_version APP当前版本号
	 * @param $system_version 设备系统当前版本号
	 * @param $device_model 设备型号
	 * 
	 */
	public function dayAdd($uid, $date, $amount, $day_idx, $channel=0, $app_version='',$system_version='',$device_model=''){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_sign}` SET `uid` = ?, `sign_date` = ?, `amount` = ?, `day_idx` = ?, `channel` = ?, `app_version` = ?, `system_version` = ?, `device_model` = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssiiisss', $uid, $date, $amount, $day_idx, $channel, $app_version, $system_version,$device_model);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function dayGet($uid, $date){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_sign}` WHERE `uid` = %d AND `sign_date` = '%s'", $uid, date('Y-m-d', strtotime($date)));
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}		
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getUnpaidList($limit = 30){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_sign}` WHERE status = %d LIMIT %d", USR_SIGN_STATUS_NORMAL, $limit);
		$result = $db->query($sql);		
		$arr = array();
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return $arr;
		}
		
		while($row = $result->fetch_assoc()){
			$arr[] = $row;
		}
		$result->free();
		return $arr;
	}

	public function getById($id){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_sign}` WHERE id = %d", $id);
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}		
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function paySignBonusToUser($sid){
		//标记已兑付
		
		$sql_sign_update = "UPDATE `{$this->tbl_sign}` SET status = ?, done_time = NOW() WHERE id = ? AND status = ?";
		//余额增加，总资产增加，利息增加
		$sql_acc_amt_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? AND ? >= 0";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, uid) SELECT ?, amount, amount + ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$db = & $this->getDB();

		$info = $this->getById($sid);
		if(empty($info)){
			return false;
		}
		if(USR_SIGN_STATUS_NORMAL != $info['status']){
			return null;
		}
		$uid = $info['uid'];
		$amount = $info['amount'];

		$db->autocommit(false);
		$stmt = $db->prepare($sql_sign_update);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_sign_update prepare failed:'.$sid);
			$db->autocommit(true);
			return false;
		}
		$status = USR_SIGN_STATUS_PAID;
		$status_normal = USR_SIGN_STATUS_NORMAL;
		$stmt->bind_param('isi', $status, $sid, $status_normal);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows'."$sid,$uid,$amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_acc_log prepare failed:'."$sid,$uid,$amount");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = USRACCOUNT_ACTION_SIGN_BONUS;
		$stmt->bind_param('ssiss', $amount, $amount, $action, $sid, $uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows:'." $sid,$uid,$amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_acc_amt_add);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_acc_amt_add prepare failed:'." $sid,$uid,$amount");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('iisi', $amount, $amount, $uid, $amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows:' . " $sid,$uid,$amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$db->commit();
		$db->autocommit(true);
		return true;
	}
	/**
	 * 更新签到奖金发放失败
	 * 
	 */
	public function updateSignBonusFailed($ids){
		$db = & $this->getDB();
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($ids);
		$new_status = USR_SIGN_STATUS_FAILED;
		$old_status = USR_SIGN_STATUS_NORMAL;
		$sql = "UPDATE `{$this->tbl_sign}` SET status = {$new_status}, done_time = NOW() WHERE status = {$old_status} AND id IN ($id_str)"; 
		return $db->query($sql);
	}
}