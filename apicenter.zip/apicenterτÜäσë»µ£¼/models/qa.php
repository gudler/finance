<?php
require_once PATH_BASE_MODEL;

class QaModel extends Model{

	protected $tbl_q = 'questions';

	protected $tbl_ra = 'riskassessment';

	public function __construct(){
		parent::__construct();
	}

	public function getQuestionsByMd5($md5){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, question, md5val, created_time FROM `{$this->tbl_q}` WHERE md5val = ? LIMIT 1";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql prepare failed');
			return false;
		}
		$stmt->bind_param('s', $md5);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $question = $md5val = $created_time = null;
		$stmt->bind_result( $id, $question, $md5val, $created_time );
		$bool = $stmt->fetch();
		if(!$bool){
			// 2017-12-15 stmt close
			$stmt->close();			
			return null;
		}
		$stmt->close();
		return array(
			'id' => $id,
			'question' => $question,
			'md5val' => $md5val,
			'created_time' => $created_time
			);
	}

	public function addQuestions($question, $md5val){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_q}` SET question = ?, md5val = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $question, $md5val);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function addRiskAssessment($uid, $question, $answer){
		$md5val = md5($question);
		$arr = $this->getQuestionsByMd5( $md5val );
		$qid = 0;
		if(!empty($arr)){
			$qid = $arr['id'];
		}else{
			$qid = $this->addQuestions( $question, $md5val );
		}
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_ra}` SET uid = ?, qid = ?, answer = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sis', $uid, $qid, $answer);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}
	
}