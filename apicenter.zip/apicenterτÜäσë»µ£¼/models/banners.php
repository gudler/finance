<?php
require_once PATH_BASE_MODEL;

/**
 * 系统Banner数据库操作类
 * 2018-03-13
 */
class BannersModel extends Model{
    // 数据库表名字
	protected $tbl_banners = 'banners';

    public function __construct(){
		parent::__construct();
    }
    /**
     * 根据位置获取缺省配置的Banner
     * 用于数据库链接失败或者其他情况导致查询不到的时候
     * 
     * @param $position banner的显示位置，有app_startup,app_home,app_obligation,web_home等
     * 
     * @return banner数组
     */
    protected function getDefaultBannersByPosition($position) {
        $banners = array();
        if ($position==BANNER_POSITION_APP_STARTUP) {
            $banners[] = [
                'method' => '',
                'img' => 'http://img.egeyed.com/startup/20170714184529.png',
                'description' => '先到先得，高额回报投资',
            ];
        } else if ($position==BANNER_POSITION_APP_HOME) {
            $banners[] = [
				'method' => APP_VIEW_METHOD_WEBVIEW,
				'img' => 'http://img.egeyed.com/banner/a201611232.png',
				'url' => 'http://svideo.egeyed.com/aboutegeyed-480p.mp4',
				'description' => '2分钟解毒',				
            ];
            $banners[] = [
				'method' => APP_VIEW_METHOD_WEBVIEW,
				'img' => 'http://img.egeyed.com/banner/a201611074.png',
				'url' => 'http://www.eagleeyedfinance.com/articles/20160922/index.html',
				'description' => '什么是易购宝',
            ];
            $banners[] = [
				'method' => APP_VIEW_METHOD_WEBVIEW,
				'img' => 'http://img.egeyed.com/banner/a201611231.png',
				'url' => 'http://www.eagleeyedfinance.com/articles/20170714/app_intro_eaglebao/index.html',
				'description' => '什么是鹰眼宝',
            ];
        } else if ($position==BANNER_POSITION_APP_OBLIGATION) {
            $banners[] = [
				'method' => APP_VIEW_METHOD_WEBVIEW,
				'img' => 'http://img.egeyed.com/banner/a20170714184529.png',
				'url' => 'http://www.eagleeyedfinance.com/articles/20170714/high_rate_event/index.html',
				'description' => '先到先得，搞回报投资',				
            ];
            $banners[] = [
				'method' => APP_VIEW_METHOD_WEBVIEW,
                'img' => 'http://img.egeyed.com/banner/a201611232.png',
                'url' => 'http://svideo.egeyed.com/aboutegeyed-480p.mp4',
				'description' => '2分钟解毒',				
            ];
        } else if ($position==BANNER_POSITION_WEB_HOME) {
            //@TODO 2018-03-13，目前展示不支持官网
        }
        return $banners;

    }
    /**
     * 根据位置从数据库中获取配置的Banner
     * 
     * @param $position banner的显示位置，有app_startup,app_home,app_obligation,web_home等
     * 
     * @return banner数组
     * 
     */
    public function getBannersByPosition($position){
        $db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT `img`, `method`, `url`, `description` FROM `{$this->tbl_banners}` 
            WHERE  position = '%s' AND status = %d AND start_time<=NOW() AND end_time>=NOW()
            ORDER BY `order` ASC, `created_time` DESC ", $position, BANNER_STATUS_NORMAL);
        $result = $db->query($sql);
        if (empty($result)) {
            $this->logerror(__METHOD__, "sql query failed: errno:{$db->errno},error:{$db->error}.");
            $banners = $this->getDefaultBannersByPosition($position);
    	    return $banners;
        }
	    $banners = $result->fetch_all(MYSQLI_ASSOC);
        $result->free();
        if (empty($banners)) {
            $banners = $this->getDefaultBannersByPosition($position);
        }
		return $banners;
	}

}