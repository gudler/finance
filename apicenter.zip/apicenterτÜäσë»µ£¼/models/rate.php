<?php
require_once PATH_BASE_MODEL;

class RateModel extends Model{

	protected $tbl_rate = 'rate';

	public function __construct(){
		parent::__construct();
	}

	public function getRateOfObligation($oid = null){
		return $this->getCurrentRate();
	}

	public function getRateOfEagleeyed(){
		$rate = RATE_OF_EAGLEEYED;
		if($rate > 0.12){
			$rate = 0.0666;
		}
		$dt_start = strtotime('2017-07-15 08:00:00');
		$dt_end = strtotime('2077-07-27 23:00:00');
		$now = time();
		if($now >= $dt_start && $now < $dt_end){
			$rate += 0.0187;
		}
		return $rate;
	}

	public function getCurrentRate(){
		$rate = RATE_OF_OBLIGATION;
		if($rate > 0.12){
			$rate = 0.0888;
		}
		return $rate;
	}

	public function getAllClosedRate($rate, $left_period){
		return $rate + $left_period * 0.0005;
	}

	public function getRateOfRookie(){
		return RATE_OF_ROOKIE;
	}

	public function getClosedPeriodOfRookie(){
		return 5;
	}

	public function getClosedPeriodOfObligation( $oid = null ){
		return 30;
	}

	public function getClosedPeriodOfFastEntry(){
		return 30;
	}

	public function getClosedPeriodOfEagleeyed(){
		return 0;
	}

	public function getRateOfFastEntry(){
		$rate = RATE_OF_OBLIGATION;
		if($rate >= 0.12){
			$rate = 0.0888;
		}
		$rate += 0.0015;
		$dt_start = strtotime('2017-04-26 08:00:00');
		$dt_end = strtotime('2017-04-28 23:00:00');
		$now = time();
		if($now >= $dt_start && $now < $dt_end){
			$rate += 0.0055;
		}
		return $rate;
	}

	public function getProductRates(){
		return array(
			'rookie' => $this->getRateOfRookie(),
			'eagleeyed' => $this->getRateOfEagleeyed(),
			'fastentry' => $this->getRateOfFastEntry()
		);
	}

}