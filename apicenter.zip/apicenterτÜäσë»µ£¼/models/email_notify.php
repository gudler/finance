<?php

require_once PATH_BASE_MODEL;

class Email_notifyModel extends Model{

	protected $tbl_enl = 'email_notify_list';
	
	public function __construct(){
		parent::__construct();
	}

	public function addNotify($type,$content){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_enl}` SET type = ?, content = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $type, $content);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function getNotifySendList($limit=10){
		$db = & $this->getReadonlyDB();
		$status = EMAIL_NOTIFY_STATUS_NORMAL;
		$sql = sprintf("SELECT * FROM `{$this->tbl_enl}` WHERE status = %d LIMIT %d", $status, $limit);
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return array();
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function setNotifySent($ids,$succeeded){
		$db = & $this->getDB();
		$status = EMAIL_NOTIFY_STATUS_FAILED;
		if ($succeeded) {
			$status = EMAIL_NOTIFY_STATUS_SENT;
		}
		$helper = load_helper('model');
		$ids_str = $helper::idarr_to_string($ids);
		$sql = sprintf("UPDATE `{$this->tbl_enl}` SET status = %d, modified_time = NOW() WHERE id in (%s)", $status, $ids_str);
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
		}
		return $result;
	}

}