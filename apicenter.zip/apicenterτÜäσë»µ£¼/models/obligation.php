<?php
require_once PATH_BASE_MODEL;

class ObligationModel extends Model{

	protected $tbl_user = 'users';

	protected $tbl_obligation = 'obligation';
	
	protected $tbl_obligation_interest = 'obligation_interest';

	protected $tbl_obligation_repayment = 'obligation_repayment';

	protected $tbl_obligation_repay_dates = 'obligation_repay_dates';

	protected $tbl_loan_info = 'loan_info';
	
	protected $tbl_autoshift_pool = 'autoshift_pool';

	protected $tbl_projcar = 'projcar';
	
	protected $tbl_obligation_plan = 'obligation_plan';

	protected $tbl_obligation_holding_list = 'obligation_holding_list';

	protected $tbl_trade_queue = 'trade_queue';

	protected $tbl_auto_process_queue = 'auto_process_queue';

	protected $tbl_account = 'user_accounts';

	protected $tbl_account_log = 'user_accounts_log';

	protected $tbl_trade_fee_payback_log = 'trade_fee_payback_log';

	public function __construct(){
		parent::__construct();
	}

	/**
	 *	公共缓存：START
	 *	债权剩余可投金额、排队金额
	 *	所有债权剩余可投金额
	 *	待转让债权剩余可投金额
	 *	所有待转让债权剩余可投金额
	 *	自动购买工具（鹰眼宝、易购宝）排队金额
	 *	所有自动购买工具排队金额
	 */
	public function realAmountRebuild(){
		$status = OBL_STATUS_OPEN;
		$obligations = $this->getInvestableObligationGroupAmount( true );
		$inQueueOidAmounts = $this->getOblQueueAmount();
		
		$open_obls = array();

		if(!empty($obligations)){
			$sum = 0;
			foreach ($obligations as $row) {
				$_oid = $row['oid'];
				$amount = intval($row['left_amount']);
				if(array_key_exists($_oid, $inQueueOidAmounts)){
					$amount -= $inQueueOidAmounts[$_oid];
				}
				$open_obls[$_oid] = true;

				$sum += $amount;
				$this->memSet( "Obli_" . $_oid, $amount, TRADE_CACHE_OBLI_TIMEOUT );//债权剩余可投金额

			}
			$this->memSet( "ObliTotal", $sum, TRADE_CACHE_OBLI_TIMEOUT );//所有债权剩余可投金额
		}
		if(!empty($open_obls)){
			foreach ($inQueueOidAmounts as $_oid => $amount) {
				if(!array_key_exists($_oid, $open_obls)){//如果债权不在开放中，则清除此债权队列
					$this->queueOBLSoldout($_oid);
					continue;
				}
				$this->memSet( "ObliInque_" . $_oid, $amount, TRADE_CACHE_OBLI_TIMEOUT );//债权排队金额

			}
		}
		$inAutoProcessQueueAmounts = $this->getAutoProcessQueueAmount();
		if(!empty($inAutoProcessQueueAmounts)){
			$sum = 0;
			foreach ($inAutoProcessQueueAmounts as $via => $amount) {
				
				$sum += $amount;
				$this->memSet( "APQue_" . $via, $amount, TRADE_CACHE_OBLI_TIMEOUT );//自动购买工具（鹰眼宝、易购宝）排队金额

			}
			$this->memSet( "APQueTotal", $sum, TRADE_CACHE_OBLI_TIMEOUT );//所有自动购买工具排队金额
		}
	}

	//债权剩余可投金额－获取
	public function getObligationLeftAmount( $oid = null ){
		if(!empty($oid)){
			$key = "Obli_" . $oid;
		}else{
			$key = "ObliTotal";
		}
		$res = $this->memGet( $key );
		if(false === $res){
			$this->realAmountRebuild();
			$res = $this->memGet( $key );
		}
		if(false === $res){
			$res = 0;
			$this->memSet( $key, 0, TRADE_CACHE_OBLI_TIMEOUT );
		}
		return $res;
	}
	//债权剩余可投金额操作－增加
	public function incObligationLeftAmount( $oid, $amount ){
		$key = "Obli_" . $oid;
		$amount = abs($amount);
		$this->memInc("ObliTotal", $amount);
		return $this->memInc($key, $amount);
	}
	//债权剩余可投金额操作－减少
	public function decObligationLeftAmount( $oid, $amount ){
		$key = "Obli_" . $oid;
		$amount = abs($amount);
		$this->memDec("ObliTotal", $amount);
		return $this->memDec($key, $amount);
	}

	//债权排队金额－获取
	public function getObligationInQueueAmount( $oid ){
		$key = "ObliInque_" . $oid;
		$res = $this->memGet( $key );
		if(false === $res){
			$this->realAmountRebuild();
			$res = $this->memGet( $key );
		}
		if(false === $res){
			$res = 0;
			$this->memSet( $key, 0, TRADE_CACHE_OBLI_TIMEOUT );
		}
		return $res;
	}
	//债权排队金额－增加
	public function incObligationInQueueAmount( $oid, $amount ){
		$key = "ObliInque_" . $oid;
		$amount = abs($amount);
		return $this->memInc($key, $amount);
	}
	//债权排队金额－减少
	public function decObligationInQueueAmount( $oid, $amount ){
		$key = "ObliInque_" . $oid;
		$amount = abs($amount);
		return $this->memDec($key, $amount);
	}
	
	//自动购买工具排队金额－获取
	public function getAPInQueueAmount( $via = null ){
		if(null === $via){
			$key = "APQueTotal";
		}else{
			$key = "APQue_" . $via;
		}
		$res = $this->memGet( $key );
		if(false === $res){
			$this->realAmountRebuild();
			$res = $this->memGet( $key );
		}
		if(false === $res){
			$res = 0;
			$this->memSet( $key, 0, TRADE_CACHE_OBLI_TIMEOUT );
		}
		return $res;
	}
	//自动购买工具排队金额－增加
	public function incAPInQueueAmount( $via, $amount ){
		$key = "APQue_" . $via;
		$amount = abs($amount);
		$this->memInc('APQueTotal', $amount);
		return $this->memInc($key, $amount);
	}
	//自动购买工具排队金额－减少
	public function decAPInQueueAmount( $via, $amount ){
		$key = "APQue_" . $via;
		$amount = abs($amount);
		$this->memDec('APQueTotal', $amount);
		return $this->memDec($key, $amount);
	}

	/* 公共缓存：END */


	/**
	 *	获取债权总额
	 *
	 */
	public function getObligationTotalAmount( $status_arr, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($status_arr, true);
		
		$sql = sprintf("SELECT sum(total_amount) AS total_amount, sum(left_amount) AS left_amount FROM `{$this->tbl_obligation}` WHERE status IN (%s)", $id_str);
		$result = $db->query($sql);
		if(!$result){			
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 *	获取可投债权总额
	 *
	 */
	public function getInvestableObligationTotalAmount( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		
		$sql = "SELECT sum(left_amount) AS left_amount FROM `{$this->tbl_obligation_holding_list}` WHERE selling = ". UOB_SELLING_YES ." AND status = " . USROBL_STATUS_IN_HELD;
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 *	获取新人专享总额
	 *
	 */
	public function getRookieObligationTotalAmount( $total = false, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		if(!$total){
			$ext = " status = " . USROBL_STATUS_IN_HELD ." AND ";
		}else{
			$ext = "";
		}
		$sql = "SELECT sum(left_amount) AS left_amount FROM `{$this->tbl_obligation_holding_list}` WHERE $ext via = " . TRADE_VIA_ROOKIE;
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 *	获取可投债权金额
	 *
	 */
	public function getInvestableObligationGroupAmount( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		
		$sql = "SELECT sum(left_amount) AS left_amount, oid FROM `{$this->tbl_obligation_holding_list}` WHERE selling = ". UOB_SELLING_YES ." AND status = " . USROBL_STATUS_IN_HELD . " GROUP BY oid";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

/*========================自动转投操作START========================*/
	public function getAutoShiftCount(){
		$db = & $this->getDB();
		$sql = sprintf("SELECT COUNT(*) AS numb FROM `{$this->tbl_autoshift_pool}` WHERE amount >= %d", TRADE_AUTOSHIFT_AMOUNT_LIMIT_MIN);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}
	
	public function getAutoShiftList($pagesize){
		$db = & $this->getDB();
		$limit = intval($pagesize);
		$sql = sprintf("SELECT * FROM `{$this->tbl_autoshift_pool}` WHERE amount >= %d LIMIT %d", TRADE_AUTOSHIFT_AMOUNT_LIMIT_MIN, $limit);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function resetAutoShiftPool($uid, $shift_to){
		$db = & $this->getDB();
		$sql = sprintf("UPDATE `{$this->tbl_autoshift_pool}` SET amount = 0, modified_time = NOW() WHERE uid = ? AND shift_to = %d", $shift_to);
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	/* 注册自动转投金额及方向 */
	public function addAutoShiftPool($uid, $amount, $shift_to){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_autoshift_pool}` (uid, amount, shift_to) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE amount = amount + ?, modified_time = NOW()";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql prepare failed');
			return false;
		}
		$stmt->bind_param('ssis', $uid, $amount, $shift_to, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}
/*========================自动转投操作END========================*/

	public function isUserObligationHolding( $uid ){
		$db = & $this->getReadonlyDB();
		
		$sql = "SELECT id FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? LIMIT 1";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$exists = null;
		$stmt->bind_result( $exists );
		$bool = $stmt->fetch();
		if(!$bool){
			$exists = false;
			// $this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $exists;
	}

	/**
	 *	根据所持债权号获取债权名
	 */
	public function getObligationNameByUoid( $idarr ){
		$db = & $this->getDB();

		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($idarr);
		if(empty($id_str)){
			return array();
		}
		$sql = "SELECT id, name FROM `{$this->tbl_obligation_holding_list}` WHERE id in ($id_str)";
		$result = $db->query($sql);
		if(!$result){
			return array();
		}
		$hash = array();
		while($row = $result->fetch_assoc()){
			$key = $this->getMapKey( $row['id'] );
			$hash[$key] = $row['name'];
		}
		$result->free();
		return $hash;
	}

	/**
	 *	根据债权号获取债权信息
	 */
	public function getObligationInfoByOid( $idarr ){
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($idarr);
		if(empty($id_str)){
			return array();
		}
		$db = & $this->getReadonlyDB();
		$sql = "SELECT a.id as id, b.make as make FROM `{$this->tbl_obligation}` AS a LEFT JOIN `{$this->tbl_projcar}` AS b ON a.extid = b.id WHERE a.id in ($id_str)";
		$result = $db->query($sql);
		if(!$result){
			return array();
		}
		$hash = array();
		while($row = $result->fetch_assoc()){
			$key = $this->getMapKey( $row['id'] );
			$hash[$key] = $row;
		}
		$result->free();
		return $hash;
	}

	/**
	 *	获取可未绑定还款人债权
	 */
	public function getNotBoundProjcars(){
		$db = & $this->getDB();
		$sql = "SELECT pc.* FROM {$this->tbl_projcar} AS pc LEFT JOIN {$this->tbl_loan_info} AS l ON l.id = pc.id WHERE l.id IS NULL AND pc.`created_time` > '2017-06-09 12:15:00' ORDER BY pc.`created_time`;";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	获取可上线债权
	 */
	public function getReadyObligationInDH(){
		$db = & $this->getDB();
		$sql = "SELECT pc.* FROM {$this->tbl_projcar} AS pc LEFT JOIN {$this->tbl_obligation_plan} AS op ON pc.id = op.id LEFT JOIN {$this->tbl_loan_info} AS l ON l.id = pc.id WHERE op.id IS NULL AND pc.`created_time` > '2017-06-09 12:15:00' AND l.status IN (0, -1) ORDER BY pc.`created_time`;";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	获取债权综合信息列表数目：基本信息，绑定的还款人信息，是否上线中，是否已经在出售中
	 */
	public function getComprehensiveProjcarCount($status = 0,$filter_id){
		$where = '1';
		// 仅仅查询未绑定还款人的债权
		if ($status&0x01) {
			$where .= ' AND li.uid is null';
		}
		// 仅仅查询未上线的债权
		if ($status&0x02) {
			$where .= ' AND o.id is null';
		}
		// 仅仅查询未上线中的债权
		if ($status&0x04) {
			$where .= ' AND op.id is null';
		}
		// 过滤ID
		if (!empty($filter_id)) {
			$filter_id = intval($filter_id);
			$where .= " AND pc.id LIKE '%{$filter_id}%'";			
		}
		$db = & $this->getDB();
		$sql = "SELECT COUNT(*) as numb
				FROM {$this->tbl_projcar} AS pc 
				LEFT JOIN {$this->tbl_loan_info} AS li ON li.id = pc.id 
				LEFT JOIN {$this->tbl_user} AS u on u.id = li.uid
				LEFT JOIN {$this->tbl_obligation} AS o ON o.extid=pc.id
				LEFT JOIN {$this->tbl_obligation_plan} AS op ON op.id=pc.id AND op.status = 0
				WHERE {$where} ;";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}
	/**
	 *	获取债权综合信息列表：基本信息，绑定的还款人信息，是否上线中，是否已经在出售中
	 */
	public function getComprehensiveProjcarList($index,$pagesize,$status = 0,$filter_id){
		 $where = '1';
		// 仅仅查询未绑定还款人的债权
		if ($status&0x01) {
			$where .= ' AND li.uid is null';
		}
		// 仅仅查询未上线的债权
		if ($status&0x02) {
			$where .= ' AND o.id is null';
		}
		// 仅仅查询未上线中的债权
		if ($status&0x04) {
			$where .= ' AND op.id is null';
		}
		// 过滤ID
		if (!empty($filter_id)) {
			$filter_id = intval($filter_id);
			$where .= " AND pc.id LIKE '%{$filter_id}%'";			
		}
		
		$limit = intval($pagesize);
		$start = $limit * $index;
		$db = & $this->getDB();
		// 2017-10-13 
		// 增加借款状态返回和债券状态，内部管理系统根据这个状态，来判断用户是否已经还款结清了和显示债权具体状态
		$sql = "SELECT pc.*,li.uid AS uid,u.mobile AS mobile,li.left_loan AS loan_left,li.status AS loan_status, o.id AS oid, o.status AS obligation_status, op.id AS opid
				FROM {$this->tbl_projcar} AS pc 
				LEFT JOIN {$this->tbl_loan_info} AS li ON li.id = pc.id 
				LEFT JOIN {$this->tbl_user} AS u on u.id = li.uid
				LEFT JOIN {$this->tbl_obligation} AS o ON o.extid=pc.id
				LEFT JOIN {$this->tbl_obligation_plan} AS op ON op.id=pc.id AND op.status = 0
				WHERE {$where}
				ORDER BY pc.created_time DESC
				LIMIT $start, $limit ;";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getObligationPlanRecently($time = 300){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM {$this->tbl_obligation_plan} WHERE status = 0 AND up_time < '%s'", date('Y-m-d H:i:s', time() + $time));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function addObligationPlan($id, $rate, $all_period_rate, $closed_period, $up_time){
		$db = & $this->getDB();
		$sql = sprintf( "INSERT INTO `{$this->tbl_obligation_plan}` SET id = '%s', rate = %f, all_period_rate = %f, closed_period = %d, up_time = '%s';", $id, $rate, $all_period_rate, $closed_period, $up_time);
		return $db->query($sql);
	}

	public function addObligationPlan2($id, $rate, $all_period_rate, $closed_period, $show_time,$up_time){
		$db = & $this->getDB();
		$sql = sprintf( "INSERT INTO `{$this->tbl_obligation_plan}` SET id = '%s', rate = %f, all_period_rate = %f, closed_period = %d, show_time = '%s', up_time = '%s';", $id, $rate, $all_period_rate, $closed_period, $show_time, $up_time);
		return $db->query($sql);
	}

	/**
	 *	获取待上线债权
	 */
	public function getObligationsReady(){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT * FROM `{$this->tbl_obligation_plan}` WHERE status = 0 AND up_time <= NOW()";
		$result = $db->query($sql);
		if(!$result){
			return array();
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getObligationsPlan(){
		$db = & $this->getReadonlyDB();
		// 2018-02-24
		// 数据库增加了字段show_time,根据show_time来显示给APP
		$sql = "SELECT * FROM `{$this->tbl_obligation_plan}` WHERE status = 0 AND show_time <= NOW() AND up_time > NOW() ORDER BY show_time ASC";
		$result = $db->query($sql);
		if(!$result){
			return array();
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getObligationsPlanById($id){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_plan}` WHERE id = '%s'", addslashes($id));
		$result = $db->query($sql);
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	protected function updateObligationPlanStatus($id,$status){		
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_obligation_plan}` SET status = ?, modified_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('is', $status,$id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	/**
	 *	设置债权已上线状态
	 */
	public function setObligationOnline($id) {
		return $this->updateObligationPlanStatus($id,OBL_PLAN_STATUS_DONE);
	}
	public function setObligationOnlineFailed($id) {
		return $this->updateObligationPlanStatus($id,OBL_PLAN_STATUS_FAILED);
	}

	public function getHoldingObligationAssort( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT SUM(left_amount) AS amount, via FROM `{$this->tbl_obligation_holding_list}` WHERE uid = %d and status = %d GROUP BY via;", $uid, USROBL_STATUS_IN_HELD);
		//$sql2 = sprintf("SELECT SUM(interest) + SUM(bonus_interest) AS interest FROM `{$this->tbl_obligation_repayment}`");
		$result = $db->query($sql);
		if(!$result){
			return array();
		}
		$hash = array();
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getHoldingObligationAssortInterests( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT SUM(a.interest) + SUM(a.bonus_interest) AS interest, a.via AS via FROM obligation_repayment AS a LEFT JOIN obligation_holding_list AS b ON a.uoid = b.id WHERE a.uid = %d AND b.status = %d GROUP BY a.via;", $uid, USROBL_STATUS_IN_HELD);
		$result = $db->query($sql);
		if(!$result){
			return array();
		}
		$hash = array();
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

/*========================提前还款等操作START========================*/

	/**
	 * 更新债权为已完成
	 */
	public function updateObligationDone($oid){
		$db = & $this->getDB();
		$status = OBL_STATUS_SOLDOUT;
		$status_open = OBL_STATUS_OPEN;
		$status_done = OBL_STATUS_DONE;
		$sql = "UPDATE `{$this->tbl_obligation}` SET status = {$status_done}, modified_time = NOW() WHERE id = ? AND status IN ($status, $status_open)";
		$stmt = $db->prepare( $sql );
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('i', $oid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$stmt->close();
			return false;
		}
		$stmt->close();
		return true;
	}

	/**
	 *	获取用户债权：根据债权ID
	 */
	public function getHoldingObligationByOid( $oid ){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_holding_list}` WHERE oid = %d AND status = %d", $oid, USROBL_STATUS_IN_HELD);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 提前结清债权，返还用户本金，
	 * 注意利息已经在 paybackObligationInterestEarly 提前支付所以这里的账户余额只改变本金
	 * 2017-11-22 VERIFIED
	 *
	 *  @param $uoid 用户持有债权记录ID
	 *  @param $oid 债权ID
	 *  @param $uid 用户ID
	 *  @param $amount 持有债权的剩余本金
	 *  @param $interest 未支付的利息
	 *  @param $name 债权名称
	 *  @param $via 债权购买方式
	 *  @param $auto_shift 是否自动转投
	 *  @param $shift_to 自动转投到什么
	 */
	public function paybackObligationEarly( $uoid, $oid, $uid, $amount, $interest, $name='', $via=0, $auto_shift=0, $shift_to=0 ){
		// 2018-06-01
		// 同时更新selling=0,否则导致数据不一致，而自动购买队列会选取selling=1的记录
		$selling_no = UOB_SELLING_NO;
		$sql_up_hold_obl = "UPDATE `{$this->tbl_obligation_holding_list}` SET status = ?, selling = {$selling_no}, left_amount = 0, left_period = 0, generated_interest = generated_interest + ?, remain_interest = 0, modified_time = NOW() WHERE id = ? AND oid = ? AND status = ? AND left_amount = ?";
		$sql_acc_amt_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, total_interest = total_interest + ?, modified_time = NOW() WHERE uid = ? AND ? >= 0";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		
		$db = & $this->getDB();
		$db->autocommit(false);

		$stmt = $db->prepare($sql_up_hold_obl);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_up_hold_obl prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$status = USROBL_STATUS_DONE;
		$status_now = USROBL_STATUS_IN_HELD;
		$stmt->bind_param('isssis', $status, $interest, $uoid, $oid, $status_now, $amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : array($status, $uoid, $oid, $status_now, $amount);
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();					
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		
		$stmt = $db->prepare($sql_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}

		$action = USRACCOUNT_ACTION_PAY_EARLY;
		$stmt->bind_param('ssisss', $amount, $amount, $action, $oid, $uoid, $uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();								
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_acc_amt_add);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_acc_amt_add prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$interest_amount = 0;
		$stmt->bind_param('sssss', $amount, $interest_amount, $interest_amount, $uid, $amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows' . "$uid,$amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		// 2017-11-15 新邀请 DONE
		// 插入一条提前结清的已支付的记录到债权支付表中，便于统计
		$sql_obl_repay_add = "INSERT INTO `{$this->tbl_obligation_repayment}` SET status = ?, finish_time = NOW(), uoid = ?,uid = ?,oid = ?, 
			name = ?,principal = ?,interest = ?,bonus_interest = 0,period_id = 0,via = ?,auto_shift = ?,shift_to = ?";
		$stmt = $db->prepare($sql_obl_repay_add);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_obl_repay_add prepare failed: errno:{$db->errno},error:{$db->error}.");
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$status = OBL_REPAYEMNT_STATUS_PAID_EARLY;
		$stmt->bind_param('ississsiii',$status,$uoid,$uid,$oid,$name,$amount,$interest,$via,$auto_shift,$shift_to);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows' . "$uoid,$amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$db->commit();
		$db->autocommit(true);
		return true;
	}

	public function paybackObligationInterestEarly( $uoid, $oid, $uid, $amount ){
		$sql_up_interest_obl = "UPDATE `{$this->tbl_obligation_interest}` SET status = ?, finish_time = NOW() WHERE uoid = ? AND status IN ( ?, ? )";
		$sql_acc_amt_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, total_interest = total_interest + ?, modified_time = NOW() WHERE uid = ? AND ? >= 0";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$db = & $this->getDB();
		$db->autocommit(false);
		
		$stmt = $db->prepare($sql_up_interest_obl);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_up_interest_obl prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$status = INTEREST_STATUS_PAYEARLY;
		$status_1 = INTEREST_STATUS_NORMAL;
		$status_2 = INTEREST_STATUS_PERIOD_PAID;
		$stmt->bind_param('isii', $status, $uoid, $status_1, $status_2);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : array($status, $uoid, $status_1, $status_2);
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();								
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		
		$stmt = $db->prepare($sql_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}

		$action = USRACCOUNT_ACTION_PAY_INTEREST_IMMEDIATELY;
		$stmt->bind_param('ssisss', $amount, $amount, $action, $oid, $uoid, $uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();				
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_acc_amt_add);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_acc_amt_add prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$interest_amount = $amount;
		$stmt->bind_param('sssss', $amount, $interest_amount, $interest_amount, $uid, $amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows' . "$uid,$amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$db->commit();
		$db->autocommit(true);
		return true;
	}

	public function getObligationInterest( $uoid ){
		$db = & $this->getDB();
		$sql_curr = "SELECT sum(`today_interest`), sum(`bonus_interest`) FROM `{$this->tbl_obligation_interest}`  WHERE  `uoid`  = ? AND `status` = ?";
		$sql_bonus = "SELECT sum(`bonus_interest`) FROM `{$this->tbl_obligation_interest}`  WHERE  `uoid`  = ? AND (`period_id`  > 1 AND `status` = ?)";
		$stmt = $db->prepare($sql_curr);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_curr prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = INTEREST_STATUS_NORMAL;
		$stmt->bind_param('si', $uoid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = $expamount = null;
		$stmt->bind_result( $amount, $expamount );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		$min_amount = intval($amount);
		$bonus_amount = intval($expamount);

		$stmt = $db->prepare($sql_bonus);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_bonus prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = INTEREST_STATUS_PERIOD_PAID;
		$stmt->bind_param('si', $uoid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = null;
		$stmt->bind_result( $amount );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		$bonus_amount += intval($amount);
		return $min_amount + $bonus_amount;
	}

	/**
	 *   2018-07-06
	 *   获取债权未支付的利息记录,uoid分组，提前结清后再调用一次，主要处理已转让但是未支付利息的记录
	 */
	public function getUnpaidObligationInterestsForEarly( $oid ){
		$db = & $this->getDB();
		$sql = sprintf("SELECT uid,oid,uoid,SUM(today_interest+bonus_interest) AS interest 
				FROM `{$this->tbl_obligation_interest}` WHERE oid = %d AND status = %d GROUP BY uoid", $oid, INTEREST_STATUS_NORMAL);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}
	/**
	 *  2018-07-06
	 *  支付债权利息，同时插入到obligation_repayment中，便于统计
	 */
	public function paybackObligationInterestEarlyWithRepayment($uoid, $name, $oid, $uid, $amount ) {
		$result = $this->paybackObligationInterestEarly( $uoid, $oid, $uid, $amount );
		if ($result) {
			$db = & $this->getDB();
			$sql_obl_repay_add = "INSERT INTO `{$this->tbl_obligation_repayment}` SET status = ?, finish_time = NOW(), uoid = ?,uid = ?,oid = ?, 
					name = ?,principal = 0,interest = ?,bonus_interest = 0,period_id = 0";
			$stmt = $db->prepare($sql_obl_repay_add);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql_obl_repay_add prepare failed: errno:{$db->errno},error:{$db->error}.");
				$stmt->close();
				return false;
			}
			$status = OBL_REPAYEMNT_STATUS_PAID_EARLY;
			$stmt->bind_param('ississ',$status,$uoid,$uid,$oid,$name,$amount);
			$res = $stmt->execute();
			if(!$res || !$stmt->affected_rows){
				$error = $stmt->error ? $stmt->error : 'no affected rows' . "$uoid,$amount";
				$this->logerror(__METHOD__, $error, __LINE__);
				$stmt->close();
				return false;
			}
			$stmt->close();
		}
		return $result;
	}	  
/*========================提前还款等操作END==========================*/

/*========================还本付息等操作START========================*/

	/**
	 *	获取所有用户总共持有债权数量
	 *
	 */
	public function countObligationHolding( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		
		$sql = "SELECT COUNT(*) AS numb FROM `{$this->tbl_obligation_holding_list}` WHERE status = " . USROBL_STATUS_IN_HELD;
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}

	/**
	 *	根据页码获取债权
	 */
	public function getObligationHoldingListByPage( $index, $pagesize ){
		$db = & $this->getDB();
		$limit = intval($pagesize);
		$start = $limit * $index;
		$sql = "SELECT * FROM `{$this->tbl_obligation_holding_list}` WHERE status = ". USROBL_STATUS_IN_HELD ." LIMIT $start, $limit";
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	检查当日利息是否已计算
	 */
	public function isObligationInterestExists( $uoid, $date ){
		$db = & $this->getDB();
		$sql = "SELECT id FROM `{$this->tbl_obligation_interest}` WHERE uoid = ? AND date = ? LIMIT 1";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ss', $uoid, $date);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$exists = null;
		$stmt->bind_result( $exists );
		$bool = $stmt->fetch();
		if(!$bool){
			$exists = false;
			// $this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $exists;
	}

	/**
	 *	录入用户债权当日利息
	 */
	public function addObligationInterest( $uoid, $uid, $oid, $name, $principal, $today_interest, $bonus_interest, $rate, $period_id, $date ){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_obligation_interest}` SET 
			uoid = ?,
			uid = ?,
			oid = ?,
			name = ?,
			principal = ?,
			today_interest = ?,
			bonus_interest = ?,
			rate = ?,
			period_id = ?,
			`date` = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ssisssssis', $uoid
			, $uid
			, $oid
			, $name
			, $principal
			, $today_interest
			, $bonus_interest
			, $rate
			, $period_id
			, $date
		);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
		}else{
			$res = $stmt->insert_id;
		}
		$stmt->close();
		return $res;
	}

	/**
	 *	增加债权还款计划
	 */
	public function addObligationRepayPlan( $oid, $date, $period_id ){
		$db = & $this->getDB();
		$sql = sprintf( "INSERT INTO `{$this->tbl_obligation_repay_dates}` SET oid = %d, repayment_date = '%s', period_id = %d", $oid, date('Y-m-d', strtotime($date)), $period_id);
		return $db->query($sql);
	}

	/**
	 *	获取债权还款计划
	 */
	public function getObligationRepayPlan( $oid, $date ){
		$db = & $this->getDB();
		$sql = sprintf( "SELECT * FROM `{$this->tbl_obligation_repay_dates}` WHERE oid = %d AND repayment_date = '%s'", $oid, date('Y-m-d', strtotime($date)) );
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 *	获取债权还款计划
	 */
	public function isObligationRepayPlanExists( $oid ){
		$db = & $this->getDB();
		$sql = sprintf( "SELECT * FROM `{$this->tbl_obligation_repay_dates}` WHERE oid = %d limit 1", $oid );
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return false;
		}
		return true;
	}

	/**
	 *	获取债权还款计划
	 */
	public function getObligationSYSRate( $oid ){
		$db = & $this->getDB();
		$sql = sprintf( "SELECT rate FROM `{$this->tbl_obligation_holding_list}` WHERE oid = %d AND uid = '%s' ORDER BY id LIMIT 1", $oid, OBL_SYSTEM_UID );
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return 0.00000001;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(!empty($row) && isset($row['rate'])){
			return $row['rate'];
		}
		return 0.00000001;
	}

	public function getObligationSYSHolding( $oid ){
		$db = & $this->getDB();
		
		$uid = OBL_SYSTEM_UID;
		$status = USROBL_STATUS_IN_HELD;
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_holding_list}` WHERE uid = %d AND oid = %d AND status = %d", $uid, $oid, $status);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return false;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function updateSYSObligationHoldingLeftAmount($sys_principal, $period_id, $uoid){
		$db = & $this->getDB();
		$sql_holding = "UPDATE `{$this->tbl_obligation_holding_list}` SET left_amount = left_amount - ?, left_period = ?, modified_time = NOW() WHERE id = ? AND uid = ? AND left_period = ?";
		$stmt = $db->prepare($sql_holding);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$sys_uid = OBL_SYSTEM_UID;
		$new_period_id = $period_id - 1;
		$stmt->bind_param('sisii', $sys_principal, $new_period_id, $uoid, $sys_uid, $period_id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	/**
	 *	更新债权还款计划
	 */
	public function updateObligationRepayPlanOblFinished( $oid, $pcarid, $date, $period_id, $principal, $proj_principal, $interest ){
		$db = & $this->getDB();
		$sql_repay_date = "UPDATE `{$this->tbl_obligation_repay_dates}` SET status = ?, in_principal = ?, in_interest = ?, obl_update_time = NOW() WHERE status = ? AND oid = ? AND repayment_date = ?";
		$sql_projcar = "UPDATE `{$this->tbl_projcar}` SET left_loan = left_loan - ?, left_period = ?, modified_time = NOW() WHERE id = ? AND left_period = ?";
		// $sql_obligation = "UPDATE `{$this->tbl_obligation}` SET left_period = ?, modified_time = NOW() WHERE id = ? AND left_period = ?";
		$sql_obligation = "UPDATE `{$this->tbl_obligation}` AS a INNER JOIN `{$this->tbl_obligation_holding_list}` AS b ON a.id = b.oid SET a.left_amount = b.left_amount, b.left_period = ?, a.left_period = ?, a.modified_time = NOW() WHERE a.id = ? AND b.uid = ?";


		$db->autocommit(false);
		$stmt = $db->prepare($sql_repay_date);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_repay_date prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->autocommit(true);
			return false;
		}
		
		$rd_status_normal = REPAY_DATES_STATUS_NORMAL;
		$rd_status_now = REPAY_DATES_STATUS_OBL_UPDATED;
		$stmt->bind_param('issiis', $rd_status_now, $principal, $interest, $rd_status_normal, $oid, $date);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();								
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_projcar);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_projcar prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$new_period_id = $period_id - 1;
		$stmt->bind_param('sisi', $proj_principal, $new_period_id, $pcarid, $period_id);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : array($proj_principal, $new_period_id, $pcarid, $period_id);
			$this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		
		$stmt = $db->prepare($sql_obligation);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_obligation prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		//$sql_obligation = "UPDATE `{$this->tbl_obligation}` AS a INNER JOIN `{$this->tbl_obligation_holding_list}` AS b ON a.id = b.oid SET a.left_amount = b.left_amount, b.left_period = ?, a.modified_time = NOW() WHERE a.id = ? AND b.uid = ?";
		// TODO 2018-02-05 更新了债权的剩余期数，是否需要同步更新债权的加息利息？因为加息利息是同剩余期数算出来的，
		$sys_uid = OBL_SYSTEM_UID;
		$stmt->bind_param('iiii', $new_period_id, $new_period_id, $oid, $sys_uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : array($new_period_id, $new_period_id, $oid, $sys_uid);
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		$bool = $db->commit();
		$db->autocommit(true);
		// $this->updateSYSObligationLeftAmount( $oid );
		return true;
	}
	/**
	 *	获取所有当日要还本付息债权数量
	 *
	 */
	public function countRepaymentObligation( $curr_day, $is_lastday, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		// 2018-06-21
		// 查询条件由“left_period > 0”修改为“left_period >= 0”，相关逻辑在外面调用进行判断过滤
		$sql = sprintf("SELECT COUNT(*) AS numb FROM `{$this->tbl_obligation}` WHERE status in (%d, %d) AND left_period >= 0 AND repayment_day %s= %d", OBL_STATUS_OPEN, OBL_STATUS_SOLDOUT, ($is_lastday ? '>' : ''), $curr_day);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}

	/**
	 *	根据页码获取当日要还本付息债权
	 */
	public function getRepaymentObligationListByPage( $curr_day, $is_lastday, $index, $pagesize ){
		$db = & $this->getDB();
		$limit = intval($pagesize);
		$start = $limit * $index;
		// 2018-06-21
		// 查询条件由“left_period > 0”修改为“left_period >= 0”，相关逻辑在外面调用进行判断过滤
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation}` WHERE status in (%d, %d) AND left_period >= 0 AND repayment_day %s= %d LIMIT %d, %d", OBL_STATUS_OPEN, OBL_STATUS_SOLDOUT, ($is_lastday ? '>' : ''), $curr_day, $start, $limit);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	//获取用户未付利息总额V2
	public function getUserPendingInterestAmount( $uid ){
		$key = md5('PendingInterest' . $uid);
		$res = $this->memGet($key);
		if(!empty($res)){
			return json_decode($res, true);
		}
		$db = & $this->getReadonlyDB();

		$sql_curr = "SELECT sum(`today_interest`), sum(`bonus_interest`) FROM `{$this->tbl_obligation_interest}`  WHERE  `uid`  = ? AND `status` = ?";
		$stmt = $db->prepare($sql_curr);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_curr prepare failed: errno:{$db->errno},error:{$db->error}.");			
			return false;
		}
		$status = INTEREST_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = $expamount = null;
		$stmt->bind_result( $amount, $expamount );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		$min_amount = intval($amount);
		$bonus_amount = intval($expamount);

		$interest = array(
			'min' => $min_amount,
			'max' => $min_amount + $bonus_amount
		);
		$timeout = 90;
		$this->memSet($key, json_encode($interest), $timeout);
		return $interest;
	}

	/**
	 *	根据债权获取分组利息
	 */
	public function getRepaymentInterestByOid( $oid, $period_id ){
		$db = & $this->getDB();
		$sql = sprintf("SELECT sum(today_interest) AS today_interest, name, period_id, uoid, uid FROM `{$this->tbl_obligation_interest}` 
			WHERE oid = %d AND status = %d AND period_id = %d GROUP BY uoid, period_id, uid, name", $oid, INTEREST_STATUS_NORMAL, $period_id);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getRepaymentInterestByUoid( $uoid ){
		$db = & $this->getDB();
		$sql = sprintf("SELECT sum(today_interest) AS today_interest, name, period_id, uoid, uid FROM `{$this->tbl_obligation_interest}` 
			WHERE uoid = %d AND status = %d", $uoid, INTEREST_STATUS_NORMAL);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 *	根据用户所持债权获取奖励利息
	 */
	public function getRepaymentBonusInterestByUoidAndPeriod( $uoid, $period_id, $status = INTEREST_STATUS_PERIOD_PAID ){
		$db = & $this->getDB();
		$sql = "SELECT sum(bonus_interest) FROM `{$this->tbl_obligation_interest}` WHERE uoid = ? AND period_id = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");			
			return false;
		}
		$stmt->bind_param('sii', $uoid, $period_id, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = null;
		$stmt->bind_result( $amount );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		$amount = intval($amount);
		return $amount;
	}

	/**
	 *	根据用户所持债权获取奖励利息
	 */
	public function getNotPaidBonusInterestByUoid( $uoid, $period_id ){
		$db = & $this->getDB();
		$sql = "SELECT sum(bonus_interest) FROM `{$this->tbl_obligation_interest}` WHERE uoid = ? AND period_id >= ? AND status IN(?, ?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");			
			return false;
		}
		$status1 = INTEREST_STATUS_PERIOD_PAID;
		$status2 = INTEREST_STATUS_WITHOUT_BOUNS;
		$stmt->bind_param('siii', $uoid, $period_id, $status1, $status2);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = null;
		$stmt->bind_result( $amount );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		$amount = intval($amount);
		return $amount;
	}

	/**
	 *	检查应兑付本金利息是否已计算
	 */
	public function isObligationRepaymentExists( $uoid, $period_id ){
		$db = & $this->getDB();
		$sql = "SELECT COUNT(*) FROM `{$this->tbl_obligation_repayment}` WHERE uoid = ? AND period_id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");			
			return false;
		}
		$stmt->bind_param('si', $uoid, $period_id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$exists = null;
		$stmt->bind_result( $exists );
		$bool = $stmt->fetch();
		if(!$bool){
			$exists = false;
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $exists;
	}


	/**
	 *	记录应兑付本金与利息
	 */
	public function addObligationRepayment($uoid, $uid, $oid, $name, $principal, $interest, $bonus_interest, $period_id, $via, $auto_shift, $shift_to, $total_period, $no_bonus = false, $skip_repayment = false){
		$sql_period_interest = "UPDATE `{$this->tbl_obligation_interest}` SET status = ?, process_time = NOW() WHERE status = ? AND uoid = ? AND period_id = ?";
		$sql_bonus_interest = "UPDATE `{$this->tbl_obligation_interest}` SET status = ?, finish_time = NOW() WHERE status = ? AND uoid = ? AND period_id = ?";
		$sql = "INSERT INTO `{$this->tbl_obligation_repayment}` SET
			uoid = ?,
			uid = ?,
			oid = ?,
			name = ?,
			principal = ?,
			interest = ?,
			bonus_interest = ?,
			period_id = ?,
			via = ?,
			auto_shift = ?,
			shift_to = ?";
		$db = & $this->getDB();
		$db->autocommit(false);
		$stmt = $db->prepare($sql_period_interest);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_period_interest prepare failed: errno:{$db->errno},error:{$db->error}.");			
			$db->autocommit(true);
			return false;
		}
		if($no_bonus){
			$interest_status_period = INTEREST_STATUS_WITHOUT_BOUNS;
		}elseif($period_id == 1){
			$interest_status_period = INTEREST_STATUS_BOUNS_PAID;
		}else{
			$interest_status_period = INTEREST_STATUS_PERIOD_PAID;
		}
		$is_normal = INTEREST_STATUS_NORMAL;
		$stmt->bind_param('iisi', $interest_status_period, $is_normal, $uoid, $period_id);
		$res = $stmt->execute();
		if(!$res || $stmt->affected_rows<1){
			$error = $stmt->error ? $stmt->error : array($interest_status_period, $is_normal, $uoid, $period_id);
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		if($total_period>$period_id){
			$stmt = $db->prepare($sql_bonus_interest);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql_bonus_interest prepare failed: errno:{$db->errno},error:{$db->error}.");			
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
			if($bonus_interest){
				$is_current = INTEREST_STATUS_BOUNS_PAID;
			}else{
				$is_current = INTEREST_STATUS_WITHOUT_BOUNS;
			}
			$is_period_paid = INTEREST_STATUS_PERIOD_PAID;
			$last_period = $period_id + 1;
			$stmt->bind_param('iisi', $is_current, $is_period_paid, $uoid, $last_period);
			$res = $stmt->execute();
			if(!$res){
				$error = $stmt->error ? $stmt->error : array($is_current, $is_period_paid, $uoid, $last_period);
				$this->logerror(__METHOD__, $error, __LINE__);
			}
			$stmt->close();
		}
		if(!$skip_repayment){
			$stmt = $db->prepare($sql);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");			
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
			/* $sql = "INSERT INTO `{$this->tbl_obligation_repayment}` SET
				uoid = ?,
				uid = ?,
				oid = ?,
				name = ?,
				principal = ?,
				interest = ?,
				bonus_interest = ?,
				period_id = ?,
				via = ?,
				auto_shift = ?,
				shift_to = ?";
			 */
			$stmt->bind_param('ssissssiiii', 
				$uoid,
				$uid,
				$oid,
				$name,
				$principal,
				$interest,
				$bonus_interest,
				$period_id,
				$via,
				$auto_shift,
				$shift_to);
			$res = $stmt->execute();
			if(!$res || $stmt->affected_rows<1){
				$error = $stmt->error ? $stmt->error : array($uoid, $uid, $oid, $name, $principal, $interest, $bonus_interest, $period_id, $via, $auto_shift, $shift_to);
				$this->logerror(__METHOD__, $error, __LINE__);
				// 2017-12-15 stmt close
				$stmt->close();										
				$db->rollback();
				$db->autocommit(true);
				return false;
			}else{
				$res = $stmt->insert_id;
			}
			$stmt->close();
		}

		$bool = $db->commit();
		$db->autocommit(true);
		return $res;
	}


	/**
	 *	获取所有应兑付资金条数
	 */
	public function countObligationRepaymentNormal(){
		$db = & $this->getDB();
		$sql = sprintf("SELECT COUNT(*) AS numb FROM `{$this->tbl_obligation_repayment}` WHERE status = %d", OBL_REPAYEMNT_STATUS_NORMAL);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}

	/**
	 *	获取用户应兑付资金
	 */
	public function getUserRepaymentAllInterest($uid){
		$db = & $this->getDB();
		$sql = "SELECT sum(interest) + sum(bonus_interest) FROM `{$this->tbl_obligation_repayment}` WHERE uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$interest = null;
		$stmt->bind_result( $interest );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return intval($interest);
	}

	/**
	 *	获取债权已兑付资金
	 */
	public function getUserObligationRepaymentByUoid($uoid){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_repayment}` WHERE uoid = %d ORDER BY id", $uoid);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	获取已付利息
	 */
	public function getUserObligationRepayments($uid, $start, $limit){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_repayment}` WHERE uid = %d ORDER BY id DESC LIMIT %d, %d", $uid, $start, $limit);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	获取已付利息
	 */
	public function getUserObligationRepaymentsCount($uid){
		$db = & $this->getDB();
		$sql = sprintf("SELECT count(*) AS total FROM `{$this->tbl_obligation_repayment}` WHERE uid = %d", $uid);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		$total = 0;
		if(isset($row['total'])){
			$total = $row['total'];
		}
		return $total;
	}

	/**
	 *	获取已付利息统计
	 */
	public function getUserObligationRepaymentsTotal($uid){
		$db = & $this->getDB();
		$sql = sprintf("SELECT SUM(interest) + SUM(bonus_interest) AS total FROM `{$this->tbl_obligation_repayment}` WHERE uid = %d", $uid);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");						
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		$total = 0;
		if(isset($row['total'])){
			$total = $row['total'];
		}
		return $total;
	}

	/**
	 *	根据页码获取所有应兑付资金详情
	 */
	public function getObligationRepaymentNormalListByPage( $pagesize ){
		$db = & $this->getDB();
		$limit = intval($pagesize);
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_repayment}` WHERE status = %d LIMIT %d", OBL_REPAYEMNT_STATUS_NORMAL, $limit);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");						
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function repaymentToUser( $rpid, $period_id, $sum_amount, $principal, $uoid, $interest_amount, $uid ){
		//更新用户所持债权所余本金和生成的利息
		$sql_holding_update = "UPDATE `{$this->tbl_obligation_holding_list}` SET left_amount = left_amount - ?, left_period = left_period - 1, generated_interest = generated_interest + ?, modified_time = NOW() WHERE id = ? AND uid = ? AND left_period = ?";
		//标记已兑付
		$sql_rp_update = "UPDATE `{$this->tbl_obligation_repayment}` SET status = ?, finish_time = NOW() WHERE id = ? AND status = ?";
		//余额增加，总资产增加，利息增加
		$sql_acc_amt_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, total_interest = total_interest + ?, modified_time = NOW() WHERE uid = ? AND ? >= 0";
		//账户金额变更记录
		//$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}` SET amount_change = ?, amount_before = ?, amount_after = ?, action = ?, act_id = ?, uid = ?";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$db = & $this->getDB();
		$db->autocommit(false);
		$stmt = $db->prepare($sql_rp_update);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_rp_update prepare failed: errno:{$db->errno},error:{$db->error}.");			
			$db->autocommit(true);
			return false;
		}
		$rp_status = OBL_REPAYEMNT_STATUS_PAID;
		$rp_status_normal = OBL_REPAYEMNT_STATUS_NORMAL;
		$stmt->bind_param('isi', $rp_status, $rpid, $rp_status_normal);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();											
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_holding_update);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_holding_update prepare failed: errno:{$db->errno},error:{$db->error}.");			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('ssssi', $principal, $interest_amount, $uoid, $uid, $period_id);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : array($principal, $interest_amount, $uoid, $uid, $period_id);
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();											
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		
		$stmt = $db->prepare($sql_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		//$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$action = USRACCOUNT_ACTION_REPAYMENT;
		$stmt->bind_param('ssisss', $sum_amount, $sum_amount, $action, $rpid, $uoid, $uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();											
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_acc_amt_add);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_acc_amt_add prepare failed: errno:{$db->errno},error:{$db->error}.");			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('sssss', $sum_amount, $interest_amount, $interest_amount, $uid, $sum_amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows' . "$uid,$sum_amount,$interest_amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();											
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$db->commit();
		$db->autocommit(true);
		return true;
	}

	/* 将已完成的债权关闭 */
	public function updateObligationWhichIsClosed(){
		$db = & $this->getDB();
		$sql = sprintf("UPDATE `{$this->tbl_obligation_holding_list}` SET status = %d, process_time = NOW(), modified_time = NOW() WHERE left_period = 0 AND status = %d", USROBL_STATUS_DONE, USROBL_STATUS_IN_HELD);
		$bool = $db->query($sql);
		if($bool && $db->affected_rows){
			return true;
		}
		return false;
	}

	public function getExpireRookieObligations($date){
		$db = & $this->getDB();
		
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation_holding_list}` WHERE status = %d AND created_time < '%s' AND via = %d", USROBL_STATUS_IN_HELD, $date, TRADE_VIA_ROOKIE);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");						
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function returnRookieObligation($uid, $uoid, $oid, $amount){
		$sql_buy_acc = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, modified_time = NOW() WHERE uid = ? AND amount >= ?";
		$sql_sell_acc = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, modified_time = NOW() WHERE uid = ? AND ? >= 0";
		//账户金额变更记录
		$sql_sell_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, -11, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$sql_buy_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount - ?, ?, ?, -11, uid FROM `{$this->tbl_account}` WHERE uid = ? AND amount >= ?";

		$sql_holding_sell = sprintf("UPDATE `{$this->tbl_obligation_holding_list}` SET status = %d, left_amount = 0, process_time = NOW(), modified_time = NOW() WHERE id = ? AND status = %d", USROBL_STATUS_DONE, USROBL_STATUS_IN_HELD);
		$sql_holding_buy = sprintf("UPDATE `{$this->tbl_obligation_holding_list}` SET status = %d, left_amount = left_amount + ?, selling = 1, modified_time = NOW() WHERE uid = %d AND oid = ? LIMIT 1", USROBL_STATUS_IN_HELD, OBL_SYSTEM_UID);

		$db = & $this->getDB();
		$db->autocommit(false);
		$stmt = $db->prepare($sql_holding_sell);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_holding_sell prepare failed: errno:{$db->errno},error:{$db->error}.");						
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('s', $uoid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "no affected rows, $uoid";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();											
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_holding_buy);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_holding_buy prepare failed: errno:{$db->errno},error:{$db->error}.");						
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('ss', $amount, $oid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "no affected rows, $amount, $oid";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();											
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_sell_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_sell_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");						
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = USRACCOUNT_ACTION_OBSELL;
		$stmt->bind_param('ssiss', $amount, $amount, $action, $uoid, $uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "no affected rows, $amount, $amount, $action, $uoid, $uid";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}

		$stmt = $db->prepare($sql_buy_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_buy_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");						
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = USRACCOUNT_ACTION_OBBUY;
		$sys_uid = OBL_SYSTEM_UID;
		$stmt->bind_param('ssisss', $amount, $amount, $action, $uoid, $sys_uid, $amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "no affected rows, $amount, $amount, $action, $uoid, $sys_uid, $amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();


		//$sql_buy_acc = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, modified_time = NOW() WHERE uid = ? AND amount >= ?";
		$stmt = $db->prepare($sql_buy_acc);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_buy_acc prepare failed: errno:{$db->errno},error:{$db->error}.");						
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('sss', $amount, $sys_uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "no affected rows, $amount, $sys_uid, $amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		//$sql_sell_acc = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, modified_time = NOW() WHERE uid = ? AND ? >= 0";
		$stmt = $db->prepare($sql_sell_acc);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_sell_acc prepare failed: errno:{$db->errno},error:{$db->error}.");						
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('sss', $amount, $uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "no affected rows, $amount, $uid, $amount";
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$db->commit();
		$db->autocommit(true);

		$this->updateSYSObligationLeftAmount( $oid );
		return true;
	}

/*========================还本付息等操作END========================*/
	public function countUserPendingInterests( $uid ) {
		$db = & $this->getReadonlyDB();
		// 2018-04-17
		// $status原来没有声明赋值
		$status = INTEREST_STATUS_NORMAL;		
		$sql = sprintf( "SELECT COUNT(*) AS total FROM ( 
			SELECT uoid FROM {$this->tbl_obligation_interest} WHERE uid = %d AND status = %d GROUP BY uoid ) a ", $uid, $status);		
		$query_result = $db->query($sql);
		if(!$query_result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$row = $query_result->fetch_assoc();
		$query_result->free();
		if($row && $row['total']){
			return $row['total'];
		}
		return 0;
	}	

	public function getUserPendingInterests2( $uid, $page=0, $page_size=30 ){
		$db = & $this->getReadonlyDB();
		$start = $page * $page_size;		
		$sql = "SELECT SUM(`today_interest`) AS curr_interest, SUM(`bonus_interest`) AS bonus_interest, uoid, b.name, b.repayment_day, c.rate, c.total_amount, c.created_time, c.status, c.left_period, c.selling, c.via
			FROM `{$this->tbl_obligation_interest}` AS a
				LEFT JOIN `{$this->tbl_obligation}` AS b ON a.oid = b.id
				LEFT JOIN `{$this->tbl_obligation_holding_list}` AS c ON a.uoid = c.id
			WHERE a.`uid` = ?
				AND a.`status` = ?
			GROUP BY uoid ORDER BY a.id ASC
			LIMIT {$start}, {$page_size}";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");						
			return false;
		}
		$status = INTEREST_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$curr_interest = $bonus_interest = $uoid = $name = $repayment_day = $rate = $principal = $created_time = $status = $period_id = $selling = $via = null;
		$stmt->bind_result(
			$curr_interest,
			$bonus_interest,
			$uoid,
			$name,
			$repayment_day,
			$rate,
			$principal,
			$created_time,
			$status,
			$period_id,
			$selling,
			$via );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $uoid,
				'name' => $name,
				'curr_interest' => $curr_interest,
				'bonus_interest' => $bonus_interest,
				'repayment_day' => $repayment_day,
				'rate' => $rate,
				'principal' => $principal,
				'period_id' => $period_id,
				'status' => $status,
				'selling' => $selling,
				'via' => $via,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getUserPendingInterests( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT SUM(`today_interest`) AS curr_interest, SUM(`bonus_interest`) AS bonus_interest, uoid, b.name, b.repayment_day, c.rate, c.total_amount, c.created_time, c.status, c.left_period, c.selling, c.via
			FROM `{$this->tbl_obligation_interest}` AS a
				LEFT JOIN `{$this->tbl_obligation}` AS b ON a.oid = b.id
				LEFT JOIN `{$this->tbl_obligation_holding_list}` AS c ON a.uoid = c.id
			WHERE a.`uid` = ?
				AND a.`status` = ?
			GROUP BY uoid ORDER BY a.id ASC";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");						
			return false;
		}
		$status = INTEREST_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$curr_interest = $bonus_interest = $uoid = $name = $repayment_day = $rate = $principal = $created_time = $status = $period_id = $selling = $via = null;
		$stmt->bind_result(
			$curr_interest,
			$bonus_interest,
			$uoid,
			$name,
			$repayment_day,
			$rate,
			$principal,
			$created_time,
			$status,
			$period_id,
			$selling,
			$via );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $uoid,
				'name' => $name,
				'curr_interest' => $curr_interest,
				'bonus_interest' => $bonus_interest,
				'repayment_day' => $repayment_day,
				'rate' => $rate,
				'principal' => $principal,
				'period_id' => $period_id,
				'status' => $status,
				'selling' => $selling,
				'via' => $via,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取新人专享当日交易总额
	 *
	 */
	public function getRookieTodayTotalAmount( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT sum(total_amount) FROM `{$this->tbl_auto_process_queue}` WHERE status in (?, ?) AND via = ? AND date( created_time ) = date(now()) ";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");						
			return false;
		}
		$status = AUTO_PROCESS_STATUS_NORMAL;
		$status2 = AUTO_PROCESS_STATUS_DONE;
		$via = TRADE_VIA_ROOKIE;
		//$date = date('Y-m-d');
		$stmt->bind_param('iii', $status, $status2, $via);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = null;
		$stmt->bind_result( $amount );
		$bool = $stmt->fetch();
		if(!$bool){
			$amount = null;
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $amount;
	}

	/**
	 *	获取用户新手债权
	 *
	 */
	public function getRookieObligation( $uid, $single = false ){
		$db = & $this->getReadonlyDB();
		if($single){
			$limit = ' LIMIT 1';
		}else{
			$limit = '';
		}
		$sql = "SELECT id, left_amount, total_amount, generated_interest, status, created_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND via = ? $limit";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");						
			return false;
		}
		$via = TRADE_VIA_ROOKIE;
		$stmt->bind_param('si', $uid, $via);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $left_amount = $total_amount = $generated_interest = $status = $created_time = null;
		$stmt->bind_result($id, $left_amount, $total_amount, $generated_interest, $status, $created_time);
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'left_amount' => $left_amount,
				'total_amount' => $total_amount,
				'generated_interest' => $generated_interest,
				'status' => $status,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getRookieAutoQueue( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, status, created_time FROM `{$this->tbl_auto_process_queue}` WHERE uid = ? AND via = ? AND status = 0 LIMIT 1";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");						
			return false;
		}
		$via = TRADE_VIA_ROOKIE;
		$stmt->bind_param('si', $uid, $via);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $status = $created_time = null;
		$stmt->bind_result($id, $status, $created_time);
		$arr = array();
		if($stmt->fetch()){
			$arr = array(
				'id' => $id,
				'status' => $status,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getRookieTradeQueue( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, status, created_time FROM `{$this->tbl_trade_queue}` WHERE uid = ? AND via = ? AND status >= 0 LIMIT 1";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed,uid:{$uid},errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$via = TRADE_VIA_ROOKIE;
		$stmt->bind_param('si', $uid, $via);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $status = $created_time = null;
		$stmt->bind_result($id, $status, $created_time);
		$arr = array();
		if($stmt->fetch()){
			$arr = array(
				'id' => $id,
				'status' => $status,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getObligationSellCount( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT COUNT(id) AS numb, SUM(left_amount) AS total FROM `{$this->tbl_obligation_holding_list}` WHERE selling = 1 AND uid != 1";
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");									
			return 0;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getObligationSellList( $index, $pagesize, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$pagesize = max(intval($pagesize), 1);
		$start = $index * $pagesize;
		
		$sql = "SELECT * FROM `{$this->tbl_obligation_holding_list}` WHERE selling = 1 AND uid != 1 ORDER BY selling_time ASC LIMIT $start, $pagesize";
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");									
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getOblDetailByExtid( $pid, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation}` WHERE extid = %d", $pid);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");									
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getOblDetailById( $id, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = sprintf("SELECT * FROM `{$this->tbl_obligation}` WHERE id = %d", $id);
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");									
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getObligationCount( $status = null, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		if(null === $status){
			$ext = '';
		}else{
			$ext = sprintf( " WHERE status = %d", $status );
		}
		$sql = "SELECT COUNT(id) AS numb FROM `{$this->tbl_obligation}`$ext";
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return 0;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if($row && $row['numb']){
			return $row['numb'];
		}
		return 0;
	}
	/**
	 *	获取债权列表
	 *
	 */
	public function getObligationList( $index, $pagesize, $status = null, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$pagesize = max(intval($pagesize), 1);
		$start = $index * $pagesize;
		if(null === $status){
			$ext = '';
		}else{
			$ext = sprintf( " WHERE status = %d", $status );
		}
		$sql = "SELECT id, name, extid, ext_tbl, repayment_method, rate, all_period_rate, closed_period, total_amount, left_amount, total_period, left_period, repayment_date, repayment_day, status, market_time, soldout_time, created_time, modified_time FROM `{$this->tbl_obligation}` $ext ORDER BY FIELD(status, 0, -1, 1, 2), id DESC LIMIT ?, $pagesize";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");									
			return false;
		}
		$stmt->bind_param('i', $start);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $name = $extid = $ext_tbl = $repayment_method = $rate = $all_period_rate = $closed_period = $total_amount = $left_amount = $total_period = $left_period = $repayment_date = $repayment_day = $status = $market_time = $soldout_time = $created_time = $modified_time = null;
		$stmt->bind_result($id, $name, $extid, $ext_tbl, $repayment_method, $rate, $all_period_rate, $closed_period, $total_amount, $left_amount, $total_period, $left_period, $repayment_date, $repayment_day, $status, $market_time, $soldout_time, $created_time, $modified_time);
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'name' => $name,
				'extid' => $extid,
				'ext_tbl' => $ext_tbl,
				'repayment_method' => $repayment_method,
				'rate' => $rate,
				'all_period_rate' => $all_period_rate,
				'closed_period' => $closed_period,
				'total_amount' => $total_amount,
				'left_amount' => $left_amount,
				'total_period' => $total_period,
				'left_period' => $left_period,
				'repayment_date' => $repayment_date,
				'repayment_day' => $repayment_day,
				'status' => $status,
				'market_time' => $market_time,
				'soldout_time' => $soldout_time,
				'created_time' => $created_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getObligationExt($ids, $keys, $live = false){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($ids);
		if(empty($id_str)){
			return false;
		}
		$avaliable_keys = array(
			'id' => true,
			'purpose' => true,
			'repayment_method' => true,
			'guarantee' => true,
			'total_loan' => true,
			'left_loan' => true,
			'total_period' => true,
			'left_period' => true,
			'repayment_date' => true,
			'repayment_day' => true,
			'make' => true,
			'model' => true,
			'year' => true,
			'price' => true,
			'vehicle_id' => true,
			'invoices' => true,
			'insurance' => true,
			'import_certificate' => true,
			'person_name' => true,
			'person_sex' => true,
			'person_id_pic' => true,
			'person_credit' => true,
			'person_financial' => true,
			'whole_report' => true,
			'grant_time' => true,
			'created_time' => true,
			'modified_time' => true
		);
		$keys_str = '';
		foreach ($keys as $key) {
			if(isset($avaliable_keys[$key])){
				$keys_str .= "`$key`,";
			}
		}
		if(empty($keys_str)){
			return false;
		}
		$keys_str = substr($keys_str, 0, -1);
		$sql = "SELECT $keys_str FROM `{$this->tbl_projcar}` WHERE id in ($id_str)";
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}
	
	public function countObligationHoldingUsersByOid( $id, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sys_uid = OBL_SYSTEM_UID;
		$status = USROBL_STATUS_SOLD;
		$sql = sprintf( "SELECT COUNT(id) AS numb FROM `{$this->tbl_obligation_holding_list}` WHERE oid = %d AND uid != %d AND status != %d", $id, $sys_uid, $status );
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if($row && $row['numb']){
			return $row['numb'];
		}
		return 0;
	}

	public function getObligationHoldingUsersByOid( $id, $index, $pagesize, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT a.uid, b.mobile, a.total_amount, a.via, a.status, a.selling, a.created_time FROM `{$this->tbl_obligation_holding_list}` AS a LEFT JOIN `{$this->tbl_user}` AS b ON a.uid = b.id WHERE a.oid = ? AND a.uid != ? AND a.status != ? ORDER BY a.id DESC LIMIT ?,?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$sys_uid = OBL_SYSTEM_UID;
		$status_sold = USROBL_STATUS_SOLD;
		$start = $index * $pagesize;
		$stmt->bind_param('isiii', $id, $sys_uid, $status_sold, $start, $pagesize);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$uid = $mobile = $total_amount = $via = $status = $selling = $created_time = null;
		$stmt->bind_result( $uid, $mobile, $total_amount, $via, $status, $selling, $created_time );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'uid' => $uid,
				'mobile' => $mobile,
				'total_amount' => $total_amount,
				'via' => $via,
				'status' => $status,
				'selling' => $selling,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function countHoldingObligationByUid( $uid, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = sprintf("SELECT COUNT(id) FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND status = ? AND left_amount >= %d", AUTOBUYER_SELL_AMOUNT_LIMIT_MIN);
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$status_held = USROBL_STATUS_IN_HELD;
		$stmt->bind_param('si', $uid, $status_held);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$count = null;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}

	public function countObligationByUid( $uid, $via = array(), $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		if(empty($via)){
			$sql = "SELECT COUNT(id) FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ?";
		}else{
			$sql = sprintf("SELECT COUNT(id) FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND via IN (%s)", implode(',', $via));
		}
		
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$count = null;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}
	/**
	 *	获取用户所持债权列表
	 *
	 */
	public function getHoldingObligationByUid( $uid, $index, $pagesize, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = sprintf("SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND status = ? AND left_amount >= %d ORDER BY id DESC LIMIT ?,?", AUTOBUYER_SELL_AMOUNT_LIMIT_MIN);
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$start = $index * $pagesize;
		$status_held = USROBL_STATUS_IN_HELD;
		$stmt->bind_param('siii', $uid, $status_held, $start, $pagesize);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $left_amount = $total_period = $left_period = $generated_interest = $remain_interest = $rate = $repayment_date = $repayment_day = $closed_period = $via = $auto_shift = $shift_to = $selling = $status = $created_time = $selling_time = $sold_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $left_amount, $total_period, $left_period, $generated_interest, $remain_interest, $rate, $repayment_date, $repayment_day, $closed_period, $via, $auto_shift, $shift_to, $selling, $status, $created_time, $selling_time, $sold_time, $process_time, $modified_time );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'name' => $name,
				'total_amount' => $total_amount,
				'left_amount' => $left_amount,
				'total_period' => $total_period,
				'left_period' => $left_period,
				'generated_interest' => $generated_interest,
				'remain_interest' => $remain_interest,
				'rate' => $rate,
				'repayment_date' => $repayment_date,
				'repayment_day' => $repayment_day,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'selling' => $selling,
				'status' => $status,
				'created_time' => $created_time,
				'selling_time' => $selling_time,
				'sold_time' => $sold_time,
				'process_time' => $process_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户债权列表
	 *
	 */
	public function getObligationByUid( $uid, $index, $pagesize, $via = array(), $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		if(empty($via)){
			$sql = "SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, all_period_holding, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? ORDER BY id DESC LIMIT ?,?";
		}else{
			$sql = sprintf("SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, all_period_holding, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND via IN (%s) ORDER BY id DESC LIMIT ?,?", implode(',', $via));
		}
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$start = $index * $pagesize;
		$stmt->bind_param('sii', $uid, $start, $pagesize);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $left_amount = $total_period = $left_period = $generated_interest = $remain_interest = $rate = $all_period_holding = $repayment_date = $repayment_day = $closed_period = $via = $auto_shift = $shift_to = $selling = $status = $created_time = $selling_time = $sold_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $left_amount, $total_period, $left_period, $generated_interest, $remain_interest, $rate, $all_period_holding, $repayment_date, $repayment_day, $closed_period, $via, $auto_shift, $shift_to, $selling, $status, $created_time, $selling_time, $sold_time, $process_time, $modified_time );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'name' => $name,
				'total_amount' => $total_amount,
				'left_amount' => $left_amount,
				'total_period' => $total_period,
				'left_period' => $left_period,
				'generated_interest' => $generated_interest,
				'remain_interest' => $remain_interest,
				'rate' => $rate,
				'all_period_holding' => $all_period_holding,
				'repayment_date' => $repayment_date,
				'repayment_day' => $repayment_day,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'selling' => $selling,
				'status' => $status,
				'created_time' => $created_time,
				'selling_time' => $selling_time,
				'sold_time' => $sold_time,
				'process_time' => $process_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取系统用户持有某债权列表
	 *
	 */
	public function getSYSHoldingObligationByOid( $oid, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$uid = OBL_SYSTEM_UID;
		$status = USROBL_STATUS_IN_HELD;
		$sql = sprintf("SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND oid = ? AND status = %d", $status);
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('si', $uid, $oid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $left_amount = $total_period = $left_period = $generated_interest = $remain_interest = $rate = $repayment_date = $repayment_day = $closed_period = $via = $auto_shift = $shift_to = $selling = $status = $created_time = $selling_time = $sold_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $left_amount, $total_period, $left_period, $generated_interest, $remain_interest, $rate, $repayment_date, $repayment_day, $closed_period, $via, $auto_shift, $shift_to, $selling, $status, $created_time, $selling_time, $sold_time, $process_time, $modified_time );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'name' => $name,
				'total_amount' => $total_amount,
				'left_amount' => $left_amount,
				'total_period' => $total_period,
				'left_period' => $left_period,
				'generated_interest' => $generated_interest,
				'remain_interest' => $remain_interest,
				'rate' => $rate,
				'repayment_date' => $repayment_date,
				'repayment_day' => $repayment_day,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'selling' => $selling,
				'status' => $status,
				'created_time' => $created_time,
				'selling_time' => $selling_time,
				'sold_time' => $sold_time,
				'process_time' => $process_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function countBoughtHistoryList( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT COUNT(id) FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$count = null;
		$stmt->bind_result( $count );
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}

	/**
	 *	获取用户债权列表
	 *
	 */
	public function getBoughtHistoryList( $uid, $index = 0, $pagesize = 30 ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? ORDER BY id DESC LIMIT ?, ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$start = $index * $pagesize;
		$stmt->bind_param('sii', $uid, $start, $pagesize);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $left_amount = $total_period = $left_period = $generated_interest = $remain_interest = $rate = $repayment_date = $repayment_day = $closed_period = $via = $auto_shift = $shift_to = $selling = $status = $created_time = $selling_time = $sold_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $left_amount, $total_period, $left_period, $generated_interest, $remain_interest, $rate, $repayment_date, $repayment_day, $closed_period, $via, $auto_shift, $shift_to, $selling, $status, $created_time, $selling_time, $sold_time, $process_time, $modified_time );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'name' => $name,
				'total_amount' => $total_amount,
				'left_amount' => $left_amount,
				'total_period' => $total_period,
				'left_period' => $left_period,
				'generated_interest' => $generated_interest,
				'remain_interest' => $remain_interest,
				'rate' => $rate,
				'repayment_date' => $repayment_date,
				'repayment_day' => $repayment_day,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'selling' => $selling,
				'status' => $status,
				'created_time' => $created_time,
				'selling_time' => $selling_time,
				'sold_time' => $sold_time,
				'process_time' => $process_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户债权简单列表
	 *
	 */
	public function getUserObligationHistoryList( $uid, $status = null, $get_total = false, $index = 0, $pagesize = 30 ){
		$db = & $this->getReadonlyDB();
		$status_str = '';
		if(!empty($status)){
			if(is_array($status)){
				$helper = load_helper('model');
				$id_str = $helper::idarr_to_string($status);
				$status_str = sprintf(" AND status in (%s)", $id_str);
			}else{
				$status = intval($status);
				if($status){
					$status_str = ' AND status = ' . $status;
				}
			}
		}
		if($get_total){
			$sql = "SELECT COUNT(id) AS numb FROM `{$this->tbl_obligation_holding_list}` WHERE uid = $uid $status_str";
			$result = $db->query($sql);
			if(!$result){
				$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
				return null;
			}
			$row = $result->fetch_assoc();
			$result->free();
			if(empty($row)){
				return 0;
			}
			return intval($row['numb']);
		}

		$sql = "SELECT id, uid, oid, name, total_amount, via, status, created_time, selling_time, sold_time FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? $status_str ORDER BY id DESC LIMIT ?, ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$start = $index * $pagesize;
		$stmt->bind_param('sii', $uid, $start, $pagesize);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $via = $status = $created_time = $selling_time = $sold_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $via, $status, $created_time, $selling_time, $sold_time );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'name' => $name,
				'total_amount' => $total_amount,
				'via' => $via,
				'status' => $status,
				'created_time' => $created_time,
				'selling_time' => $selling_time,
				'sold_time' => $sold_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户债权
	 *
	 */
	public function getObligationHolding( $id, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, all_period_holding, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $left_amount = $total_period = $left_period = $generated_interest = $remain_interest = $rate = $all_period_holding = $repayment_date = $repayment_day = $closed_period = $via = $auto_shift = $shift_to = $selling = $status = $created_time = $selling_time = $sold_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $left_amount, $total_period, $left_period, $generated_interest, $remain_interest, $rate, $all_period_holding, $repayment_date, $repayment_day, $closed_period, $via, $auto_shift, $shift_to, $selling, $status, $created_time, $selling_time, $sold_time, $process_time, $modified_time );
		$arr = array();
		$bool = $stmt->fetch();
		if(!$bool){
			$error = $stmt->error ? $stmt->error : "No data[$id]";
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			return false;
		}
		$stmt->close();
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'oid' => $oid,
			'name' => $name,
			'total_amount' => $total_amount,
			'left_amount' => $left_amount,
			'total_period' => $total_period,
			'left_period' => $left_period,
			'generated_interest' => $generated_interest,
			'remain_interest' => $remain_interest,
			'rate' => $rate,
			'all_period_holding' => $all_period_holding,
			'repayment_date' => $repayment_date,
			'repayment_day' => $repayment_day,
			'closed_period' => $closed_period,
			'via' => $via,
			'auto_shift' => $auto_shift,
			'shift_to' => $shift_to,
			'selling' => $selling,
			'status' => $status,
			'created_time' => $created_time,
			'selling_time' => $selling_time,
			'sold_time' => $sold_time,
			'process_time' => $process_time,
			'modified_time' => $modified_time
		);
	}

	/**
	 *	获取出售中债权
	 *
	 */
	public function getSellingObligationHolding( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, uid, oid, name, total_amount, left_amount, total_period, left_period, generated_interest, remain_interest, rate, repayment_date, repayment_day, closed_period, via, auto_shift, shift_to, selling, status, created_time, selling_time, sold_time, process_time, modified_time FROM `{$this->tbl_obligation_holding_list}` WHERE selling = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$selling_now = UOB_SELLING_YES;
		$stmt->bind_param('i', $selling_now);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $name = $total_amount = $left_amount = $total_period = $left_period = $generated_interest = $remain_interest = $rate = $repayment_date = $repayment_day = $closed_period = $via = $auto_shift = $shift_to = $selling = $status = $created_time = $selling_time = $sold_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id, $uid, $oid, $name, $total_amount, $left_amount, $total_period, $left_period, $generated_interest, $remain_interest, $rate, $repayment_date, $repayment_day, $closed_period, $via, $auto_shift, $shift_to, $selling, $status, $created_time, $selling_time, $sold_time, $process_time, $modified_time );
		$arr = array();
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$stmt->close();
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'oid' => $oid,
			'name' => $name,
			'total_amount' => $total_amount,
			'left_amount' => $left_amount,
			'total_period' => $total_period,
			'left_period' => $left_period,
			'generated_interest' => $generated_interest,
			'remain_interest' => $remain_interest,
			'rate' => $rate,
			'repayment_date' => $repayment_date,
			'repayment_day' => $repayment_day,
			'closed_period' => $closed_period,
			'via' => $via,
			'auto_shift' => $auto_shift,
			'shift_to' => $shift_to,
			'selling' => $selling,
			'status' => $status,
			'created_time' => $created_time,
			'selling_time' => $selling_time,
			'sold_time' => $sold_time,
			'process_time' => $process_time,
			'modified_time' => $modified_time
		);
	}

	/**
	 *	设置平台自动购买用户持债权金额小于100元的记录为持有，不再卖出，减少平台的持有碎片化
	 *
	 */
	public function cancelSysBuyerSmallSelling(){
		$db = & $this->getDB();
		
		$buyer = 100006;
		$status_held = USROBL_STATUS_IN_HELD;
		$selling_no = UOB_SELLING_NO;
		$selling_yes = UOB_SELLING_YES;
		$amount = AUTOBUYER_SELL_AMOUNT_LIMIT_MIN;

		$sql = "UPDATE `{$this->tbl_obligation_holding_list}` SET selling = {$selling_no}, modified_time = NOW() 
				WHERE uid = {$buyer} AND selling = {$selling_yes} AND status = {$status_held} AND left_amount < {$amount}";
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
		}
		return $result;
	}

	/**
	 *	获取出售中债权Lite
	 *
	 */
	public function getSellingObligationHoldingLite( $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, uid, oid, left_amount, selling_time, repayment_day FROM `{$this->tbl_obligation_holding_list}` WHERE selling = ? ORDER BY selling_time, id";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$selling_now = UOB_SELLING_YES;
		$stmt->bind_param('i', $selling_now);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $left_amount = $selling_time = $repayment_day = null;
		$stmt->bind_result( $id, $uid, $oid, $left_amount, $selling_time, $repayment_day );
		$arr = array();
		while( $stmt->fetch() ) {
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'left_amount' => $left_amount,
				'selling_time' => $selling_time,
				'repayment_day' => $repayment_day
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取出售中债权Except
	 *
	 */
	public function getSellingObligationHoldingExcept( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, uid, oid, left_amount, selling_time, repayment_day FROM `{$this->tbl_obligation_holding_list}` WHERE selling = ? AND uid > 1 AND uid != ? ORDER BY selling_time, id";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$selling_now = UOB_SELLING_YES;
		$stmt->bind_param('is', $selling_now, $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $oid = $left_amount = $selling_time = $repayment_day = null;
		$stmt->bind_result( $id, $uid, $oid, $left_amount, $selling_time, $repayment_day );
		$arr = array();
		while( $stmt->fetch() ) {
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'oid' => $oid,
				'left_amount' => $left_amount,
				'selling_time' => $selling_time,
				'repayment_day' => $repayment_day
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户债权总额
	 *
	 */
	public function getObligationHoldingAmount( $uid, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT sum(left_amount) FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND status = " . USROBL_STATUS_IN_HELD;
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$total_amount = 0;
		$stmt->bind_result( $total_amount );
		$bool = $stmt->fetch();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$total_amount = false;
		}
		$stmt->close();
		return $total_amount;
	}

	/**
	 *	获取债权详情
	 *
	 */
	public function getObligationDetail( $id, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, name, extid, ext_tbl, repayment_method, rate, all_period_rate, closed_period, total_amount, left_amount, total_period, left_period, repayment_date, repayment_day, status, market_time, soldout_time, created_time, modified_time FROM `{$this->tbl_obligation}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $name = $extid = $ext_tbl = $repayment_method = $rate = $all_period_rate = $closed_period = $total_amount = $left_amount = $total_period = $left_period = $repayment_date = $repayment_day = $status = $market_time = $soldout_time = $created_time = $modified_time = null;
		$stmt->bind_result($id, $name, $extid, $ext_tbl, $repayment_method, $rate, $all_period_rate, $closed_period, $total_amount, $left_amount, $total_period, $left_period, $repayment_date, $repayment_day, $status, $market_time, $soldout_time, $created_time, $modified_time);

		$bool = $stmt->fetch();
		if( !$bool ){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$stmt->close();
		return array(
			'id' => $id,
			'name' => $name,
			'extid' => $extid,
			'ext_tbl' => $ext_tbl,
			'repayment_method' => $repayment_method,
			'rate' => $rate,
			'all_period_rate' => $all_period_rate,
			'closed_period' => $closed_period,
			'total_amount' => $total_amount,
			'left_amount' => $left_amount,
			'total_period' => $total_period,
			'left_period' => $left_period,
			'repayment_date' => $repayment_date,
			'repayment_day' => $repayment_day,
			'status' => $status,
			'market_time' => $market_time,
			'soldout_time' => $soldout_time,
			'created_time' => $created_time,
			'modified_time' => $modified_time
		);
	}

	/**
	 *	获取债权的项目详情
	 *
	 */
	public function getProjcarDetail( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id,
			purpose,
			repayment_method,
			guarantee,
			rate,
			first_repayment_date,
			total_loan,
			left_loan,
			total_period,
			left_period,
			repayment_date,
			repayment_day,
			make,
			model,
			year,
			price,
			vehicle_id,
			invoices,
			insurance,
			import_certificate,
			person_name,
			person_sex,
			person_id_pic,
			person_credit,
			person_financial,
			whole_report,
			grant_time,
			created_time,
			modified_time FROM `{$this->tbl_projcar}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = 
			$purpose = 
			$repayment_method = 
			$guarantee = 
			$rate = 
			$first_repayment_date = 
			$total_loan = 
			$left_loan = 
			$total_period = 
			$left_period = 
			$repayment_date = 
			$repayment_day = 
			$make = 
			$model = 
			$year = 
			$price = 
			$vehicle_id = 
			$invoices = 
			$insurance = 
			$import_certificate = 
			$person_name = 
			$person_sex = 
			$person_id_pic = 
			$person_credit = 
			$person_financial = 
			$whole_report = 
			$grant_time = 
			$created_time = 
			$modified_time = null;

		$stmt->bind_result($id,
			$purpose,
			$repayment_method,
			$guarantee,
			$rate,
			$first_repayment_date,
			$total_loan,
			$left_loan,
			$total_period,
			$left_period,
			$repayment_date,
			$repayment_day,
			$make,
			$model,
			$year,
			$price,
			$vehicle_id,
			$invoices,
			$insurance,
			$import_certificate,
			$person_name,
			$person_sex,
			$person_id_pic,
			$person_credit,
			$person_financial,
			$whole_report,
			$grant_time,
			$created_time,
			$modified_time);

		$bool = $stmt->fetch();
		if( !$bool ){
			if($stmt->error){
				$this->logerror(__METHOD__, $stmt->error, __LINE__);
			}
			$stmt->close();
			return false;
		}
		$stmt->close();
		return array(
			'id' => $id,
			'purpose' => $purpose,
			'repayment_method' => $repayment_method,
			'guarantee' => $guarantee,
			'rate' => $rate,
			'first_repayment_date' => $first_repayment_date,
			'total_loan' => $total_loan,
			'left_loan' => $left_loan,
			'total_period' => $total_period,
			'left_period' => $left_period,
			'repayment_date' => $repayment_date,
			'repayment_day' => $repayment_day,
			'make' => $make,
			'model' => $model,
			'year' => $year,
			'price' => $price,
			'vehicle_id' => $vehicle_id,
			'invoices' => $invoices,
			'insurance' => $insurance,
			'import_certificate' => $import_certificate,
			'person_name' => $person_name,
			'person_sex' => $person_sex,
			'person_id_pic' => $person_id_pic,
			'person_credit' => $person_credit,
			'person_financial' => $person_financial,
			'whole_report' => $whole_report,
			'grant_time' => $grant_time,
			'created_time' => $created_time,
			'modified_time' => $modified_time
		);
	}

	/**
	 *	获取队列中债权金额
	 *
	 */
	public function getOblQueueAmount(){
		$db = & $this->getDB();
		$sql = "SELECT sum(amount), oid FROM `{$this->tbl_trade_queue}` WHERE status = ? GROUP BY oid";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$status = TRADE_STATUS_NORMAL;
		$stmt->bind_param('i', $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = $oid = null;
		$stmt->bind_result( $amount, $oid );
		$arr = array();
		while($stmt->fetch()){
			$arr[$oid] = $amount;
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户所投债权队列
	 *
	 */
	public function getOblQueue( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, amount, created_time FROM `{$this->tbl_trade_queue}` WHERE uid = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$status = TRADE_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $amount = $created_time = null;
		$stmt->bind_result( $id, $amount, $created_time );
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'amount' => $amount,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户队列内资金总额
	 *
	 */
	public function getUserInQueueAmount( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT sum(amount) FROM `{$this->tbl_auto_process_queue}` WHERE uid = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$status = AUTO_PROCESS_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = null;
		$stmt->bind_result( $amount );
		$bool = $stmt->fetch();
		if(!$bool){
			$amount = null;
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $amount;
	}

	/**
	 *	获取用户排队队列
	 *
	 */
	public function getUserInQueueList( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, uid, amount, total_amount, rate, closed_period, via, auto_shift, shift_to, status, created_time, process_time FROM `{$this->tbl_auto_process_queue}` WHERE uid = ? AND status = ? ORDER BY id DESC";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$status = AUTO_PROCESS_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $amount = $total_amount = $rate = $closed_period = $via = $auto_shift = $shift_to = $status = $created_time = $process_time = null;
		$stmt->bind_result( $id, $uid, $amount, $total_amount, $rate, $closed_period, $via, $auto_shift, $shift_to, $status, $created_time, $process_time );
		$arr = array();
		while ($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'amount' => $amount,
				'total_amount' => $total_amount,
				'rate' => $rate,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'status' => $status,
				'created_time' => $created_time,
				'process_time' => $process_time
				);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取用户排队队列
	 *
	 */
	public function getUserAPQueueById( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, uid, amount, total_amount, rate, closed_period, via, auto_shift, shift_to, status, created_time, process_time FROM `{$this->tbl_auto_process_queue}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$status = AUTO_PROCESS_STATUS_NORMAL;
		$stmt->bind_param('s', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $amount = $total_amount = $rate = $closed_period = $via = $auto_shift = $shift_to = $status = $created_time = $process_time = null;
		$stmt->bind_result( $id, $uid, $amount, $total_amount, $rate, $closed_period, $via, $auto_shift, $shift_to, $status, $created_time, $process_time );
		$bool = $stmt->fetch();
		
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$stmt->close();
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'amount' => $amount,
			'total_amount' => $total_amount,
			'rate' => $rate,
			'closed_period' => $closed_period,
			'via' => $via,
			'auto_shift' => $auto_shift,
			'shift_to' => $shift_to,
			'status' => $status,
			'created_time' => $created_time,
			'process_time' => $process_time
			);
	}

	/**
	 *	获取债权队列
	 *
	 */
	public function getOblQueueAll( $status, $limit ){
		$db = & $this->getDB();//因为主库实时，所以从主库获取队列后可以直接进行操作
		$sql = "SELECT id,
			uid,
			hoid,
			oid,
			amount,
			rate,
			all_period_holding,
			closed_period,
			via,
			auto_shift,
			shift_to,
			status,
			created_time,
			process_time,
			modified_time FROM `{$this->tbl_trade_queue}` WHERE status = ? ORDER BY id LIMIT ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ii', $status, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $hoid = $oid = $amount = $rate = $all_period_holding = $closed_period = $via = $auto_shift = $shift_to = $status = $created_time = $process_time = $modified_time = null;
		$stmt->bind_result( $id,
			$uid,
			$hoid,
			$oid,
			$amount,
			$rate,
			$all_period_holding,
			$closed_period,
			$via,
			$auto_shift,
			$shift_to,
			$status,
			$created_time,
			$process_time,
			$modified_time );
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'hoid' => $hoid,
				'oid' => $oid,
				'amount' => $amount,
				'rate' => $rate,
				'all_period_holding' => $all_period_holding,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'status' => $status,
				'created_time' => $created_time,
				'process_time' => $process_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获交易队列中未处理的持有债权ID及总金额
	 *
	 */
	public function getTradeQueueHoidAmount(){
		$db = & $this->getDB();//因为主库实时，所以从主库获取队列后可以直接进行操作
		$sql = "SELECT hoid, SUM(amount) AS amount FROM `{$this->tbl_trade_queue}` WHERE status = ? GROUP BY hoid";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status_normal = AUTO_PROCESS_STATUS_NORMAL;
		$stmt->bind_param('i', $status_normal);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$hoid = $amount = null;
		$stmt->bind_result($hoid,$amount);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array('hoid' => $hoid,'amount' => $amount);
		}
		$stmt->close();
		return $arr;
	}
	/**
	 *	获取用户自动队列
	 *
	 */
	public function getAutoProcessQueue( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, amount, created_time FROM `{$this->tbl_auto_process_queue}` WHERE uid = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = AUTO_PROCESS_STATUS_NORMAL;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $amount = $created_time = null;
		$stmt->bind_result( $id, $amount, $created_time );
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'amount' => $amount,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取自动队列中的金额
	 *
	 */
	public function getAutoProcessQueueAmount(){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT sum(amount), via FROM `{$this->tbl_auto_process_queue}` WHERE status = ? GROUP BY via";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = AUTO_PROCESS_STATUS_NORMAL;
		$stmt->bind_param('i', $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = $via = null;
		$stmt->bind_result( $amount, $via );
		$arr = array();
		while($stmt->fetch()){
			$arr[$via] = $amount;
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取自动处理队列
	 *
	 */
	public function getAutoProcessQueueAll( $status, $limit, $via = null ){
		$db = & $this->getDB();//因为主库实时，所以从主库获取队列后可以直接进行操作
		$sql = "SELECT id, uid, amount, rate, closed_period, via, auto_shift, shift_to, status, created_time, process_time FROM `{$this->tbl_auto_process_queue}` WHERE status = ?";

		if(null !== $via){
			if(is_array($via)){
				$helper = load_helper('model');
				$id_str = $helper::idarr_to_string($via);
				$sql .= sprintf(" AND via in (%s)", $id_str);
			}else{
				$sql .= sprintf(" AND via = %d", $via);
			}
		}
		$sql .= " ORDER BY id LIMIT ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ii', $status, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $amount = $rate = $closed_period = $via = $auto_shift = $shift_to = $status = $created_time = $process_time = null;
		$stmt->bind_result( $id,
			$uid,
			$amount,
			$rate,
			$closed_period,
			$via,
			$auto_shift,
			$shift_to,
			$status,
			$created_time,
			$process_time );
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'amount' => $amount,
				'rate' => $rate,
				'closed_period' => $closed_period,
				'via' => $via,
				'auto_shift' => $auto_shift,
				'shift_to' => $shift_to,
				'status' => $status,
				'created_time' => $created_time,
				'process_time' => $process_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	进入自动队列
	 *
	 */
	public function addAutoProcessQueue($uid, $amount, $rate, $closed_period, $via, $auto_shift, $shift_to){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql = "INSERT INTO `{$this->tbl_auto_process_queue}` SET 
			uid = ?,
			amount = ?,
			total_amount = ?,
			rate = ?,
			closed_period = ?,
			via = ?,
			auto_shift = ?,
			shift_to = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ssssiiii', $uid,
			$amount,
			$amount,
			$rate,
			$closed_period,
			$via,
			$auto_shift,
			$shift_to);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
		}else{
			$res = $stmt->insert_id;
			$this->incAPInQueueAmount( $via, $amount );
		}

		$stmt->close();
		return $res;
	}

	/**
	 *	获取用户待转让列表中的金额
	 *	
	 */
	public function getUserSellQueueAmounts( $via = null ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT left_amount, id FROM `{$this->tbl_obligation_holding_list}` WHERE selling = ? AND status = ?";
		if(null !== $via){
			if(is_array($via)){
				$helper = load_helper('model');
				$id_str = $helper::idarr_to_string($via);
				$sql .= sprintf(" AND via in (%s)", $id_str);
			}else{
				$sql .= sprintf(" AND via = %d", $via);
			}
		}
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = USROBL_STATUS_IN_HELD;
		$selling = 1;
		$stmt->bind_param('ii', $selling, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = $id = null;
		$stmt->bind_result( $amount, $id );
		$arr = array();
		while($stmt->fetch()){
			$arr[$id] = $amount;
		}
		$stmt->close();
		return $arr;
	}

	public function getTradeStatus( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, amount, status, created_time FROM `{$this->tbl_trade_queue}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = TRADE_STATUS_NORMAL;
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $amount = $status = $created_time = null;
		$stmt->bind_result( $id, $amount, $status, $created_time );
		$arr = array();
		$stmt->fetch();
		$stmt->close();
		if(!$id){
			return null;
		}
		return array(
			'id' => $id,
			'status' => $status
		);
	}

	public function getProcessStatus( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, total_amount, amount, status, created_time FROM `{$this->tbl_auto_process_queue}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = TRADE_STATUS_NORMAL;
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $total_amount = $amount = $status = $created_time = null;
		$stmt->bind_result( $id, $total_amount, $amount, $status, $created_time );
		$arr = array();
		$stmt->fetch();
		$stmt->close();
		if(!$id){
			return null;
		}
		return array(
			'id' => $id,
			'total_amount' => $total_amount,
			'amount' => $amount,
			'status' => $status,
			'created_time' => $created_time
		);
	}

	public function getSellStatus( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, left_amount, status, created_time, sold_time FROM `{$this->tbl_obligation_holding_list}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $left_amount = $status = $created_time = $sold_time = null;
		$stmt->bind_result( $id, $left_amount, $status, $created_time, $sold_time );
		$arr = array();
		$stmt->fetch();
		$stmt->close();
		if(!$id){
			return null;
		}
		return array(
			'id' => $id,
			'left_amount' => $left_amount,
			'status' => $status,
			'created_time' => $created_time,
			'sold_time' => $sold_time
		);
	}

	/**
	 *	查询债权出售队列
	 *
	 */
	public function getUserSellQueue($uid, $hoid){
		$db = & $this->getDB();
		$sql = "SELECT id FROM `{$this->tbl_obligation_holding_list}` WHERE uid = ? AND id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('si', $uid, $hoid);
		$bool = $stmt->execute();
		$id = null;
		$stmt->bind_result( $id );
		$stmt->fetch();
		$stmt->close();
		return $id;
	}

	public function addProjcar($id, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $first_repayment_date){
		$db = & $this->getDB();
		$sql_projcar = "INSERT INTO `{$this->tbl_projcar}` SET id = ?, purpose = ?, repayment_method = ?, guarantee = '无', rate = ?, total_loan = ?, left_loan = ?, total_period = ?, left_period = ?, repayment_date = null, repayment_day = ?, make = ?, model = ?, year = ?, price = ?, vehicle_id = ?, invoices = ?, insurance = ?, import_certificate = ?, person_name = ?, person_sex = ?, person_id_pic = ?, person_credit = ?, person_financial = ?, whole_report = ?, first_repayment_date = ?, grant_time = NOW()";

		$stmt = $db->prepare($sql_projcar);
		if (!$stmt) {
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ssisssssssssssssssssssss', $id, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $first_repayment_date);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = "Execute sql_projcar error!" . $stmt->error . "\n";
			$this->logerror(__METHOD__, $error);
			$stmt->close();
			return false;
		}
		$stmt->close();
		return $id;
	}

	public function updateProjcarPictures($id, $invoices, $insurance, $import_certificate, $person_id_pic, $person_credit, $person_financial, $whole_report){
		$db = & $this->getDB();
		$sql_projcar = "UPDATE `{$this->tbl_projcar}` SET modified_time = NOW()";
		$udpate_fields = array(
			'invoices' => $invoices,
			'insurance' => $insurance,
			'import_certificate' => $import_certificate,
			'person_id_pic' => $person_id_pic,
			'person_credit' => $person_credit,
			'person_financial' => $person_financial,
			'whole_report' => $whole_report,
		);
		foreach($udpate_fields as $k=>$v){
			if ($v===null) {
			} else {
				$sql_projcar .=",{$k}='{$v}'";
			}
		}
		$sql_projcar .= " WHERE id={$id}";
		$result = $db->query($sql_projcar);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}		
		return true;
	}

	public function updateProjcarLeft($id, $left_amount, $left_period){
		$db = & $this->getDB();
		$sql_projcar = "UPDATE `{$this->tbl_projcar}` SET left_loan = ?, left_period = ?, modified_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql_projcar);
		if (!$stmt) {
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('sis', $left_amount, $left_period, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = "Execute sql_projcar error!" . $stmt->error . "\n";
			$this->logerror(__METHOD__, $error);
			$stmt->close();
			return false;
		}
		$stmt->close();
		return $id;
	}

	public function addOrUpdateProjcar($id, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $first_repayment_date){
		$db = & $this->getDB();
		$sql_projcar = "INSERT INTO `{$this->tbl_projcar}` SET id = ?, purpose = ?, repayment_method = ?, guarantee = '无', rate = ?, total_loan = ?, left_loan = ?, total_period = ?, left_period = ?, repayment_date = null, repayment_day = ?, make = ?, model = ?, year = ?, price = ?, vehicle_id = ?, invoices = ?, insurance = ?, import_certificate = ?, person_name = ?, person_sex = ?, person_id_pic = ?, person_credit = ?, person_financial = ?, whole_report = ?, first_repayment_date = ?, grant_time = NOW() ON DUPLICATE KEY UPDATE purpose = ?, repayment_method = ?, guarantee = '无', rate = ?, total_loan = ?, left_loan = ?, total_period = ?, left_period = ?, repayment_date = null, repayment_day = ?, make = ?, model = ?, year = ?, price = ?, vehicle_id = ?, invoices = ?, insurance = ?, import_certificate = ?, person_name = ?, person_sex = ?, person_id_pic = ?, person_credit = ?, person_financial = ?, whole_report = ?, first_repayment_date = ?";

		$stmt = $db->prepare($sql_projcar);
		if (!$stmt) {
			$this->logerror(__METHOD__, "sql prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ssissssssssssssssssssssssisssssssssssssssssssss', $id, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $first_repayment_date, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $first_repayment_date);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = "Execute sql_projcar error!" . $stmt->error . "\n";
			$this->logerror(__METHOD__, $error);
			$stmt->close();
			return false;
		}
		$stmt->close();
		return $id;
	}

	/**
	 *	增加汽车金融债权
	 */
	public function addProjcarObligation($extid, $total_amount, $left_amount, $total_period, $left_period, $repayment_day,
		$purpose, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $rate, $first_repayment_date
		){
		$db = & $this->getDB();
		$sql_obl = "INSERT INTO `{$this->tbl_obligation}` SET name = ?, extid = ?, ext_tbl = 'projcar', repayment_method = ?, total_amount = ?, left_amount = ?, total_period = ?, left_period = ?, repayment_date = null, repayment_day = ?, market_time = NOW()";
		
		$sql_projcar = "INSERT INTO `{$this->tbl_projcar}` SET id = ?, purpose = ?, repayment_method = ?, guarantee = '无', rate = ?, total_loan = ?, left_loan = ?, total_period = ?, left_period = ?, repayment_date = null, repayment_day = ?, make = ?, model = ?, year = ?, price = ?, vehicle_id = ?, invoices = ?, insurance = ?, import_certificate = ?, person_name = ?, person_sex = ?, person_id_pic = ?, person_credit = ?, person_financial = ?, whole_report = ?, first_repayment_date = ?, grant_time = NOW()";

		$sql_acc = "INSERT INTO `{$this->tbl_account}` (uid, amount, total_amount) VALUES (?, 0, ?) ON DUPLICATE KEY UPDATE total_amount = total_amount + ?, modified_time = NOW()";

		$sql_holding = "INSERT INTO `{$this->tbl_obligation_holding_list}` SET `uid` = ?, `oid` = ?, `name` = ?, `total_amount` = ?, `left_amount` = ?, `total_period` = ?, `left_period` = ?, `generated_interest` = 0, `remain_interest` = 0, `rate` = ?, `repayment_date` = NULL, `repayment_day` = ?, `closed_period` = 0, `via` = 0, `auto_shift` = 0, `shift_to` = 0, `selling` = 1, `status` = 0, `selling_time` = NOW()";

		$db->autocommit(false);
		$error = false;
		$id = null;
		do{
			$repayment_method = REPAYMENT_PRINCIPAL_AND_INTEREST_EQUAL;
			$name = "$make $model";
			$stmt = $db->prepare($sql_obl);
			if (!$stmt) {
				$error = "sql_obl prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('ssisssss', $name, $extid, $repayment_method, $total_amount, $left_amount, $total_period, $left_period, $repayment_day);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_obl error!" . $stmt->error . "\n";
				break;
			}
			$id = $stmt->insert_id;
			$stmt->close();

			$stmt = $db->prepare($sql_projcar);
			if (!$stmt) {
				$error = "sql_projcar prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('ssisssssssssssssssssssss', $extid, $purpose, $repayment_method, $rate, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $year, $price, $vehicle_id, $invoices, $insurance, $import_certificate, $person_name, $person_sex, $person_id_pic, $person_credit, $person_financial, $whole_report, $first_repayment_date);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_projcar error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_acc);
			if (!$stmt) {
				$error = "sql_acc prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$sys_uid = OBL_SYSTEM_UID;
			$stmt->bind_param('iss', $sys_uid, $left_amount, $left_amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_acc error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_holding);
			if (!$stmt) {
				$error = "sql_holding prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('issssssss', $sys_uid, $id, $name, $total_amount, $left_amount, $total_period, $left_period, $rate, $repayment_day);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_holding error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
		}while (false);
		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $id;
	}

	/**
	 *	绑定汽车金融债权
	 */
	public function bindProjcarObligation($extid, $total_amount, $left_amount, $total_period, $left_period, $repayment_day, $make, $model, $rate, $rate_sell, $all_period_rate, $closed_period){
		$db = & $this->getDB();
		$sql_obl = "INSERT INTO `{$this->tbl_obligation}` SET name = ?, extid = ?, ext_tbl = 'projcar', repayment_method = ?, rate = ?, all_period_rate = ?, closed_period = ?, total_amount = ?, left_amount = ?, total_period = ?, left_period = ?, repayment_date = null, repayment_day = ?, market_time = NOW()";
		
		$sql_acc = "INSERT INTO `{$this->tbl_account}` (uid, amount, total_amount) VALUES (?, 0, ?) ON DUPLICATE KEY UPDATE total_amount = total_amount + ?, modified_time = NOW()";

		$sql_holding = "INSERT INTO `{$this->tbl_obligation_holding_list}` SET `uid` = ?, `oid` = ?, `name` = ?, `total_amount` = ?, `left_amount` = ?, `total_period` = ?, `left_period` = ?, `generated_interest` = 0, `remain_interest` = 0, `rate` = ?, `repayment_date` = NULL, `repayment_day` = ?, `closed_period` = 0, `via` = 0, `auto_shift` = 0, `shift_to` = 0, `selling` = 1, `status` = 0, `selling_time` = NOW()";

		$db->autocommit(false);
		$error = false;
		$id = null;
		do{
			$repayment_method = REPAYMENT_PRINCIPAL_AND_INTEREST_EQUAL;
			$name = "$make $model";
			$stmt = $db->prepare($sql_obl);
			if (!$stmt) {
				$error = "sql_obl prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('ssississsss', $name, $extid, $repayment_method, $rate_sell, $all_period_rate, $closed_period, $total_amount, $left_amount, $total_period, $left_period, $repayment_day);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_obl error!" . $stmt->error . "\n";
				break;
			}
			$id = $stmt->insert_id;
			$stmt->close();

			$stmt = $db->prepare($sql_acc);
			if (!$stmt) {
				$error = "sql_acc prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$sys_uid = OBL_SYSTEM_UID;
			$stmt->bind_param('iss', $sys_uid, $left_amount, $left_amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_acc error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_holding);
			if (!$stmt) {
				$error = "sql_holding prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('issssssss', $sys_uid, $id, $name, $total_amount, $left_amount, $total_period, $left_period, $rate, $repayment_day);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_holding error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
		}while (false);
		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $id;
	}

	/**
	 *	增加需要返还手续费的日志
	 */
	public function addTradeFeePaybackLog($uoid, $uid, $oid, $fee, $period_id){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_trade_fee_payback_log}` SET uoid = ?, uid = ?, oid = ?, fee = ?, period_id = ?";
		$sql_interest_update = "UPDATE `{$this->tbl_obligation_interest}` SET status = ? WHERE uoid = ? AND period_id >= ? AND status IN(?, ?)";

		$db->autocommit(false);
		$error = false;
		$id = null;
		do{
			$stmt = $db->prepare($sql_interest_update);
			if(!$stmt){
				$error = "sql_interest_update prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$status = INTEREST_STATUS_BOUNS_PAID;
			$status1 = INTEREST_STATUS_PERIOD_PAID;
			$status2 = INTEREST_STATUS_WITHOUT_BOUNS;
			$stmt->bind_param('isiii', $status, $uoid, $period_id, $status1, $status2);
			$bool = $stmt->execute();
			if(!$bool){
				$error = "Execute sql_interest_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql);
			if(!$stmt){
				$error = "sql prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('ssssi', $uoid, $uid, $oid, $fee, $period_id);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql error!" . $stmt->error . "\n";
				break;
			}
			$id = $stmt->insert_id;
			$stmt->close();

		}while (false);
		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $id;
	}

	/**
	 *	获取应返还手续费的记录
	 *
	 */
	public function getTradeFeePaybackNormal( $pagesize = 30 ){
		$pagesize = max(10, intval($pagesize));
		$db = & $this->getDB();
		$sql = "SELECT * FROM `{$this->tbl_trade_fee_payback_log}` WHERE status = ". TRADEFEE_PAYBACK_STATUS_NORMAL . " LIMIT $pagesize";
		$result = $db->query($sql);
		if(!$result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");			
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	返还手续费
	 */
	public function paybackTradeFee( $id, $uid, $amount, $uoid ){
		//标记已兑付
		$sql_tfee_payback_update = "UPDATE `{$this->tbl_trade_fee_payback_log}` SET status = ?, finish_time = NOW() WHERE id = ? AND status = ?";
		//余额增加，总资产增加，利息增加
		$sql_acc_amt_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, total_interest = total_interest + ?, modified_time = NOW() WHERE uid = ? AND ? > 0";
		//账户金额变更记录
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$db = & $this->getDB();
		$db->autocommit(false);
		$error = false;
		do{
			$stmt = $db->prepare($sql_tfee_payback_update);
			if(!$stmt){
				$error = "sql_tfee_payback_update prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$status = TRADEFEE_PAYBACK_STATUS_PAID;
			$status_normal = TRADEFEE_PAYBACK_STATUS_NORMAL;
			$stmt->bind_param('isi', $status, $id, $status_normal);
			$res = $stmt->execute();
			if(!$res || !$stmt->affected_rows){
				$error = "Execute sql_tfee_payback_update error!" . $stmt->error . " $status, $id, $status_normal\n";
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_acc_log);
			if(!$stmt){
				$error = "sql_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$action = USRACCOUNT_ACTION_PAYBACK_TRADEFEE;
			$stmt->bind_param('ssisss', $amount, $amount, $action, $uoid, $id, $uid);
			$res = $stmt->execute();
			if(!$res || !$stmt->affected_rows){
				$error = "Execute sql_acc_log error!" . $stmt->error . " $amount, $action, $uoid, $id, $uid\n";
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_acc_amt_add);
			if(!$stmt){
				$error = "sql_acc_amt_add prepare failed: errno:{$db->errno},error:{$db->error}.\n";
				break;
			}
			$stmt->bind_param('sssss', $amount, $amount, $amount, $uid, $amount);
			$res = $stmt->execute();
			if(!$res || !$stmt->affected_rows){
				$error = "Execute sql_acc_amt_add error!" . $stmt->error . " $amount, $uid\n";
				break;
			}
			$stmt->close();

		}while (false);

		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
	}

	/**
	 *	进入债权购买队列
	 *
	 */
	public function buyObligationQueue($uid, $oid, $hoid, $amount, $rate, $closed_period, $via, $auto_shift, $shift_to, $all_period_holding = 0){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql = "INSERT INTO `{$this->tbl_trade_queue}` SET 
			uid = ?,
			oid = ?,
			hoid = ?,
			amount = ?,
			rate = ?,
			all_period_holding = ?,
			closed_period = ?,
			via = ?,
			auto_shift = ?,
			shift_to = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('sisssiiiii', $uid,
			$oid,
			$hoid,
			$amount,
			$rate,
			$all_period_holding,
			$closed_period,
			$via,
			$auto_shift,
			$shift_to);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			return false;
		}else{
			$res = $stmt->insert_id;
			$this->incObligationInQueueAmount( $oid, $amount );	//债权排队金额－增加
		}

		$stmt->close();
		return $res;
	}

	/**
	 *	进入债权出售队列
	 *
	 */
	public function sellObligation($uid, $hoid, $oid, $amount){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_obligation_holding_list}` SET selling = ?, selling_time = NOW(), modified_time = NOW()
			WHERE id = ? AND uid = ? AND selling = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$selling_now = UOB_SELLING_YES;
		$status = USROBL_STATUS_IN_HELD;
		$selling = UOB_SELLING_NO;
		$stmt->bind_param('issii', $selling_now, $hoid, $uid, $selling, $status);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows' . ", $hoid, $uid";
			$this->logerror(__METHOD__, $error, __LINE__);
		}else{
			$this->incObligationLeftAmount( $oid, $amount );
		}
		$stmt->close();
		return $res;
	}

	/**
	 *	处理待交易队列中的用户余额不足
	 *
	 */
	public function queueAmountNotEnough( $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_trade_queue}` SET status = ?, process_time = NOW() WHERE id = ? AND status = ?";
		
		$status = TRADE_STATUS_FAILED_USER_AMOUNT_SHORT;
		$filter_status = TRADE_STATUS_NORMAL;

		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('iii', $status, $id, $filter_status);

		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	/**
	 *	处理交易队列中的债权已售完
	 *
	 */
	public function queueOBLSoldout( $oid ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_trade_queue}` SET status = ?, process_time = NOW() WHERE oid = ? AND status = ?";
		
		$status = TRADE_STATUS_FAILED_OBL_SOLDOUT;
		$filter_status = TRADE_STATUS_NORMAL;

		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('iii', $status, $oid, $filter_status);

		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function updateAutoProcessStatusById( $id, $status, $last_status ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_auto_process_queue}` SET status = ?, process_time = NOW() WHERE id = ? AND status = ?";
		
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('iii', $status, $id, $last_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function updateObligationHoldingAutoShift( $id, $uid, $auto_shift, $shift_to ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_obligation_holding_list}` SET auto_shift = ?, shift_to = ?, modified_time = NOW() WHERE id = ? AND uid = ? AND status = ?";
		
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$status = USROBL_STATUS_IN_HELD;
		$stmt->bind_param('iiisi', $auto_shift, $shift_to, $id, $uid, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	/**
	 *	处理自动交易队列，将自动交易队列转换成待交易队列
	 *
	 */
	public function processQueueToTradeQueue( $uid, $oid, $hoid, $auto_queue, $amount ){
		$db = & $this->getDB();

		$sql_trade = "INSERT INTO `{$this->tbl_trade_queue}` SET uid = ?, oid = ?, hoid = ?, amount = ?, rate = ?, closed_period = ?, via = ?, auto_shift = ?, shift_to = ?";

		$sql_change = "UPDATE `{$this->tbl_auto_process_queue}` SET status = IF(amount = ?, ?, ?), amount = amount - ?, process_time = NOW() WHERE id = ? AND status = ? AND amount >= ?";

		$db->autocommit(false);

		$amount = abs($amount);
		$stmt = $db->prepare($sql_trade);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_trade prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->autocommit(true);
			return false;
		}
		$rate = $auto_queue['rate'];
		$closed_period = $auto_queue['closed_period'];
		$via = $auto_queue['via'];
		$auto_shift = $auto_queue['auto_shift'];
		$shift_to = $auto_queue['shift_to'];
		$stmt->bind_param('sisssiiii', $uid, $oid, $hoid, $amount, $rate, $closed_period, $via, $auto_shift, $shift_to);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$filter_status = AUTO_PROCESS_STATUS_NORMAL;
		$status = AUTO_PROCESS_STATUS_DONE;
		$stmt = $db->prepare($sql_change);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_change prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('siisiis', $amount, $status, $filter_status, $amount, $auto_queue['id'], $filter_status, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}

		$this->decAPInQueueAmount( $auto_queue['via'], $amount );	//自动购买工具排队金额－减少
		$this->incObligationInQueueAmount( $oid, $amount );	//债权排队金额－增加
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
	}

	/**
	 *	清空已售完所持有债权的交易队列
	 *
	 */
	public function oblHoldingFlushQueue( $hoid ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_trade_queue}` SET status = ?, process_time = NOW() WHERE hoid = ? AND status = ?";
		
		$status = TRADE_STATUS_FAILED_OBL_HOLD_SOLDOUT;
		$filter_status = TRADE_STATUS_NORMAL;

		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('iii', $status, $hoid, $filter_status);

		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	/**
	 * 更新债权的可投余额＝obligation_holding_list中获取系统拥有债权
	 */
	public function updateSYSObligationLeftAmount($oid){
		$db = & $this->getDB();
		$status = OBL_STATUS_SOLDOUT;
		$status_open = OBL_STATUS_OPEN;
		$sql = "UPDATE `{$this->tbl_obligation}` AS a INNER JOIN `{$this->tbl_obligation_holding_list}` AS b ON a.id = b.oid SET a.status = if(b.left_amount < 100, {$status}, {$status_open}), soldout_time = if(b.left_amount < 100, NOW(), NULL), a.left_amount = b.left_amount, a.modified_time = NOW() WHERE b.uid = ? AND a.id = ?";

		$uid = OBL_SYSTEM_UID;
		$stmt = $db->prepare( $sql );
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('ii', $uid, $oid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $error = $stmt->error ? $stmt->error : 'no affected rows';
			// $this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			return false;
		}
		$stmt->close();
		return true;
	}

	/**
	 * 更新用户转让后 obligation_holding_list 中剩余金额（小于100豪）
	 */
	public function updateUserObligationDMAmount($uid, $hoid){
		$db = & $this->getDB();
		$sql = "SELECT left_amount, status FROM `{$this->tbl_obligation_holding_list}` WHERE id = ?";
		$stmt = $db->prepare( $sql );
		if(!$stmt){
			$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");
			return false;
		}
		$stmt->bind_param('s', $hoid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$amount = $status = null;
		$stmt->bind_result( $amount, $status );
		$bool = $stmt->fetch();
		if(!$bool){
			// 2017-12-15 stmt close
			$stmt->close();				
			return false;
		}
		$stmt->close();
		if($amount <= 0 || $amount >= 100){
			return true;
		}
		if($status != USROBL_STATUS_SOLD){
			return true;
		}
		
		$sql_acc = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, modified_time = NOW() WHERE uid = ?";

		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, uid) SELECT ?, amount, amount + ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$sql_holding_edit = "UPDATE `{$this->tbl_obligation_holding_list}` SET left_amount = 0, modified_time = NOW() WHERE uid = ? AND id = ? AND left_amount = ? AND left_amount < 100";

		$db->autocommit(false);
		$return = true;
		do{
			$stmt = $db->prepare($sql_acc_log);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");
				break;
			}
			$action = USRACCOUNT_ACTION_ADD_LEFT_DMAMOUNT;
			$stmt->bind_param('iiiss', $amount, $amount, $action, $hoid, $uid);
			$res = $stmt->execute();
			if(!$res || !$stmt->affected_rows){
				$error = $stmt->error ? $stmt->error : 'no affected rows';
				$this->logerror(__METHOD__, $error, __LINE__);
				// 2017-12-15 stmt close
				$stmt->close();			
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_acc);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql_acc prepare failed: errno:{$db->errno},error:{$db->error}.");
				break;
			}
			$stmt->bind_param('is', $amount, $uid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = $stmt->error ? $stmt->error : 'no affected rows';
				$this->logerror(__METHOD__, $error, __LINE__);
				// 2017-12-15 stmt close
				$stmt->close();							
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql_holding_edit);
			if(!$stmt){
				$this->logerror(__METHOD__, 'sql holding prepare failed');
				break;
			}
			$stmt->bind_param('ssi', $uid, $hoid, $amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = $stmt->error ? $stmt->error : 'no affected rows';
				$this->logerror(__METHOD__, $error, __LINE__);
				// 2017-12-15 stmt close
				$stmt->close();							
				break;
			}
			$stmt->close();

			$return = false;
		}while (false);
		if($return){
			$db->rollback();
			$db->autocommit(true);
			return false;
		}

		$bool = $db->commit();
		$db->autocommit(true);

		return true;
	}

	/**
	 *	购买队列处理
	 *
	 */
	public function oblTradeProcess($queue, $obl, $holding_obl){
		$db = & $this->getDB();
		/**
		 *	如果余额小于队列请求数据，则队列status置位余额不足，并返回false
		 *	如果债权余额小于等于队列请求数据，则交易债权余额，并置位队列status交易成功且Less amount, 同时将amount改为债权余额；置位债权status为售空
		 *	如果债权余额大于队列请求数据，则交易并队列置位成功
		 *	
		 */
		//账户金额更新
		$sql_buy_acc = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, modified_time = NOW() WHERE uid = ? AND amount >= ?";
		$sql_sell_acc = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, modified_time = NOW() WHERE uid = ?";
		//账户金额变更记录
		$sql_buy_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount - ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ? AND amount >= ?";
		$sql_sell_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$sql_same_uid_sell_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount - ?, amount, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		//用户债权录入
		$sql_obligation_holding_list_add = "INSERT INTO `{$this->tbl_obligation_holding_list}` SET uid = ?, oid = ?, name = ?, total_amount = ?, left_amount = ?, total_period = ?, left_period = ?, rate = ?, all_period_holding = ?, repayment_date = ?, repayment_day = ?, closed_period = ?, via = ?, auto_shift = ?, shift_to = ?";
		//出售方债权变更
		$sql_obligation_holding_list_edit = "UPDATE `{$this->tbl_obligation_holding_list}` SET status = IF(left_amount - ? < 100,?,?), selling = IF(left_amount - ? < 100,?,?), sold_time = IF(left_amount - ? < 100 , NOW(), NULL), left_amount = left_amount - ?, modified_time = NOW() WHERE uid = ? AND id = ? AND selling = ? AND left_amount >= ?";
		//交易队列状态变更
		$sql_trade = "UPDATE `{$this->tbl_trade_queue}` SET amount = ?, status = ?, process_time = NOW() WHERE id = ? AND status = ?";

		$qid = $queue['id'];//待交易队列ID
		$hoid = $queue['hoid'];
		$uid = $queue['uid'];
		$oid = $queue['oid'];
		$amount = abs($queue['amount']);
		$left_amount = $obl['left_amount'];
		$holding_left_amount = $holding_obl['left_amount'];
		$sell_uid = $holding_obl['uid'];
		$holding_soldout = false;	//清空所持债权为hoid的债权（可能是用户卖，也可能是系统卖，之一）
		if($holding_left_amount <= $amount){//可投资额度以holding_list内数据为准
			$amount = $holding_left_amount;//可投资额度不够，实际成交额度变为剩余可投资额度
			$holding_soldout = true;
		}

		$db->autocommit(false);

		//$sql_trade = "UPDATE `{$this->tbl_trade_queue}` SET amount = ?, status = ?, process_time = NOW() WHERE id = ? AND status = ?";
		//交易队列状态变更 START
		$stmt = $db->prepare($sql_trade);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_trade prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->autocommit(true);
			return false;
		}
		if($holding_soldout){
			$status_now = TRADE_STATUS_DONE_LESS_AMOUNT;
		}else{
			$status_now = TRADE_STATUS_DONE;
		}
		$status = TRADE_STATUS_NORMAL;
		$stmt->bind_param('siii', $amount, $status_now, $qid, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		//交易队列状态变更 END

		//$sql_obligation_holding_list_add = "INSERT INTO `{$this->tbl_obligation_holding_list}` SET uid = ?, oid = ?, name = ?, total_amount = ?, left_amount = ?, total_period = ?, left_period = ?, rate = ?, repayment_date = ?, repayment_day = ?, closed_period = ?, via = ?, auto_shift = ?, shift_to = ?";
		//用户债权信息录入 START
		$stmt = $db->prepare($sql_obligation_holding_list_add);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_obligation_holding_list_add prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('sisssiisissiiii', $uid, $oid, $obl['name'], $amount, $amount, $obl['left_period'], $obl['left_period'], $queue['rate'], $queue['all_period_holding'], $obl['repayment_date'], $obl['repayment_day'], $queue['closed_period'], $queue['via'], $queue['auto_shift'], $queue['shift_to']);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$buy_uoid = $stmt->insert_id;
		$stmt->close();
		//用户债权信息录入 END

		//出售方债权变更 START
		
		//$sql_obligation_holding_list_edit = "UPDATE `{$this->tbl_obligation_holding_list}` SET status = IF(left_amount = ?,?,?), selling = IF(left_amount = ?,?,?), sold_time = IF(left_amount = ? , NOW(), NULL), left_amount = left_amount - ?, modified_time = NOW() WHERE uid = ? AND id = ? AND selling = ? AND left_amount >= ?";
		$stmt = $db->prepare($sql_obligation_holding_list_edit);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_obligation_holding_list_edit prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$status_sold = USROBL_STATUS_SOLD;
		$status_held = USROBL_STATUS_IN_HELD;
		$selling_no = UOB_SELLING_NO;
		$selling_yes = UOB_SELLING_YES;
		$stmt->bind_param('siisiissssis', $amount, $status_sold, $status_held, 
			$amount, $selling_no, $selling_yes, $amount,
			$amount, $sell_uid, $hoid, $selling_yes, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		

		//出售方债权变更 END

		//账户金额变更记录 START
		// $sql_buy_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount - ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ? AND amount >= ?";
		$stmt = $db->prepare($sql_buy_acc_log);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_buy_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = USRACCOUNT_ACTION_OBBUY;
		$stmt->bind_param('ssissss', $amount, $amount, $action, $hoid, $buy_uoid, $uid, $amount);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		// $sql_sell_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		// $sql_same_uid_sell_acc_log;
		if($uid == $sell_uid){
			$stmt = $db->prepare($sql_same_uid_sell_acc_log);
		}else{
			$stmt = $db->prepare($sql_sell_acc_log);
		}
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_sell_acc_log prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = USRACCOUNT_ACTION_OBSELL;
		$stmt->bind_param('ssisss', $amount, $amount, $action, $hoid, $buy_uoid, $sell_uid);
		$res = $stmt->execute();
		if(!$res || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "$amount, $amount, $action, $hoid, $buy_uoid, $sell_uid";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();					
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		//账户金额变更记录 END


		//账户金额更新 START
		//$sql_buy_acc = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, modified_time = NOW() WHERE uid = ? AND amount >= ?";
		$stmt = $db->prepare($sql_buy_acc);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_buy_acc prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('sss', $amount, $uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		//$sql_sell_acc = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, modified_time = NOW() WHERE uid = ?";
		$stmt = $db->prepare($sql_sell_acc);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql_sell_acc prepare failed: errno:{$db->errno},error:{$db->error}.");
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('ss', $amount, $sell_uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : 'no affected rows';
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		//账户金额更新 END

		$bool = $db->commit();
		$db->autocommit(true);
		if($bool){
			if($holding_soldout){
				$this->oblHoldingFlushQueue( $hoid );
			}
		}else{
			return false;
		}
		$this->updateSYSObligationLeftAmount( $oid );
		$this->decObligationInQueueAmount( $oid, $amount );	//债权排队金额－减少
		$this->decObligationLeftAmount( $oid, $amount );	//债权剩余可投金额操作－减少
		if($sell_uid != OBL_SYSTEM_UID){
			$this->updateUserObligationDMAmount($sell_uid, $hoid);
		}
		return array($buy_uoid, $uid, $hoid, $sell_uid);
	}
}