<?php
require_once PATH_BASE_MODEL;

/*
1. 判断是否有贷款
2. 获取下月今日前所有未还贷款（含未还贷款与已逾期）
3. 获取用户所有贷款列表（含实际贷款状态）
4. 获取当前贷款信息
5. 获取当前贷款应还款列表
6. 设置自动还款
7. 手动还款（已逾期）
8. 提前还款
*/
class LoanModel extends Model{

	protected $tbl_user = 'users';

	protected $tbl_account = 'user_accounts';

	protected $tbl_account_log = 'user_accounts_log';

	protected $tbl_loan_info = 'loan_info';

	protected $tbl_projcar = 'projcar';

	protected $tbl_loan_repayment_list = 'loan_repayment_list';

	protected $tbl_loan_repayment_log = 'loan_repayment_log';

	protected $tbl_loan_overdue_log = 'loan_overdue_log';

	public function __construct(){
		parent::__construct();
	}

	public function getLoanRepaymentStatusListByDate($date_from, $date_to){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT a.repayment_date AS repayment_date ,c.person_name AS person_name ,b.mobile AS mobile, d.amount AS amount, a.pid AS pid, c.make, c.model, c.total_loan, a.period_id AS period_id, each_month, paid_principal, paid_interest, overdue_fee, paid_overdue_fee, overdue_days, a.status AS status, a.modified_time AS modified_time, a.finish_time AS finish_time FROM {$this->tbl_loan_repayment_list} AS a LEFT JOIN {$this->tbl_user} AS b ON a.uid = b.id LEFT JOIN {$this->tbl_projcar} AS c ON a.pid = c.id LEFT JOIN {$this->tbl_account} AS d ON a.uid = d.uid WHERE a.repayment_date >='%s' AND a.repayment_date <= '%s'", addslashes($date_from), addslashes($date_to));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getLoanRepaymentOverdueListByDate($date_to){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT a.repayment_date AS repayment_date ,c.person_name AS person_name ,b.mobile AS mobile, d.amount AS amount, a.pid AS pid, c.make, c.model, c.total_loan, a.period_id AS period_id, each_month, paid_principal, paid_interest, overdue_fee, paid_overdue_fee, overdue_days, a.status AS status, a.modified_time AS modified_time, a.finish_time AS finish_time FROM {$this->tbl_loan_repayment_list} AS a LEFT JOIN {$this->tbl_user} AS b ON a.uid = b.id LEFT JOIN {$this->tbl_projcar} AS c ON a.pid = c.id LEFT JOIN {$this->tbl_account} AS d ON a.uid = d.uid WHERE a.status = %d AND a.repayment_date <= '%s'", LOAN_REPAYMENT_STATUS_OVERDUED, addslashes($date_to));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getLoanInfoCount($uid){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT COUNT(*) AS numb FROM `{$this->tbl_loan_info}` WHERE uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$count = 0;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}

	/**
	 *	获取用户的贷款列表
	 */
	public function getLoanInfoList($uid, $page, $pagesize, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$pagesize = max(intval($pagesize), 1);
		$start = $page * $pagesize;
		$sql = "SELECT id, uid, repayment_method, total_loan, left_loan, returned_loan, paid_interest, paid_overdue_fee, curr_overdue_days, total_period, left_period, recent_repayment_date, repayment_date, repayment_day, make, model, grant_time, status, created_time, modified_time FROM `{$this->tbl_loan_info}` WHERE uid = ? ORDER BY id DESC LIMIT $start, $pagesize";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $repayment_method = $total_loan = $left_loan = $returned_loan = $paid_interest = $paid_overdue_fee = $curr_overdue_days = $total_period = $left_period = $recent_repayment_date = $repayment_date = $repayment_day = $make = $model = $grant_time = $status = $created_time = $modified_time = null;
		$stmt->bind_result($id, $uid, $repayment_method, $total_loan, $left_loan, $returned_loan, $paid_interest, $paid_overdue_fee, $curr_overdue_days, $total_period, $left_period, $recent_repayment_date, $repayment_date, $repayment_day, $make, $model, $grant_time, $status, $created_time, $modified_time);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'repayment_method' => $repayment_method,
				'total_loan' => $total_loan,
				'left_loan' => $left_loan,
				'returned_loan' => $returned_loan,
				'paid_interest' => $paid_interest,
				'paid_overdue_fee' => $paid_overdue_fee,
				'curr_overdue_days' => $curr_overdue_days,
				'total_period' => $total_period,
				'left_period' => $left_period,
				'recent_repayment_date' => $recent_repayment_date,
				'repayment_date' => $repayment_date,
				'repayment_day' => $repayment_day,
				'make' => $make,
				'model' => $model,
				'grant_time' => $grant_time,
				'status' => $status,
				'created_time' => $created_time,
				'modified_time' => $modified_time
				);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取当前贷款信息
	 */
	public function getLoanInfo($id, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, uid, repayment_method, total_loan, left_loan, returned_loan, paid_interest, paid_overdue_fee, curr_overdue_days, total_period, left_period, recent_repayment_date, repayment_date, repayment_day, make, model, grant_time, status, created_time, modified_time FROM `{$this->tbl_loan_info}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $repayment_method = $total_loan = $left_loan = $returned_loan = $paid_interest = $paid_overdue_fee = $curr_overdue_days = $total_period = $left_period = $recent_repayment_date = $repayment_date = $repayment_day = $make = $model = $grant_time = $status = $created_time = $modified_time = null;
		$stmt->bind_result($id, $uid, $repayment_method, $total_loan, $left_loan, $returned_loan, $paid_interest, $paid_overdue_fee, $curr_overdue_days, $total_period, $left_period, $recent_repayment_date, $repayment_date, $repayment_day, $make, $model, $grant_time, $status, $created_time, $modified_time);
		$stmt->fetch();
		$stmt->close();
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'repayment_method' => $repayment_method,
			'total_loan' => $total_loan,
			'left_loan' => $left_loan,
			'returned_loan' => $returned_loan,
			'paid_interest' => $paid_interest,
			'paid_overdue_fee' => $paid_overdue_fee,
			'curr_overdue_days' => $curr_overdue_days,
			'total_period' => $total_period,
			'left_period' => $left_period,
			'recent_repayment_date' => $recent_repayment_date,
			'repayment_date' => $repayment_date,
			'repayment_day' => $repayment_day,
			'make' => $make,
			'model' => $model,
			'grant_time' => $grant_time,
			'status' => $status,
			'created_time' => $created_time,
			'modified_time' => $modified_time
			);
	}

	/**
	 *	获取下月今日前所有未还贷款（含未还贷款与已逾期）
	 */
	public function getRecentLoanRepaymentList($uid, $date, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, principal, interest, overdue_days, repayment_date, status FROM `{$this->tbl_loan_repayment_list}` WHERE uid = ? AND repayment_date < ? AND status <= 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $uid, $date);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $principal = $interest = $overdue_days = $repayment_date = $status = null;
		$stmt->bind_result($id, $principal, $interest, $overdue_days, $repayment_date, $status);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'principal' => $principal,
				'interest' => $interest,
				'overdue_days' => $overdue_days,
				'repayment_date' => $repayment_date,
				'status' => $status
				);
		}
		$stmt->close();
		return $arr;
	}

	public function getObligateAmount( $uid, $date ){
		$db = & $this->getReadonlyDB();
		$sql = sprintf( "SELECT SUM(principal) + SUM(interest) + SUM(overdue_fee) AS amount FROM `{$this->tbl_loan_repayment_list}` WHERE uid = %d AND repayment_date <= '%s' AND status <= 0;", $uid, date('Y-m-d', strtotime($date)) );
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		$amount = 0;
		if($row && isset($row['amount'])){
			$amount = $row['amount'];
		}
		return $amount;
	}

	/**
	 *	获取用户的还款列表
	 */
	public function getLoanRepaymentList($uid, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, pid, uid, principal, interest, day_interest, interest_days, overdue_fee, paid_overdue_fee, overdue_days, period_id, repayment_date, auto_pay, status, created_time, modified_time, finish_time FROM `{$this->tbl_loan_repayment_list}` WHERE uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $pid = $uid = $principal = $interest = $day_interest = $interest_days = $overdue_fee = $paid_overdue_fee = $overdue_days = $period_id = $repayment_date = $auto_pay = $status = $created_time = $modified_time = $finish_time = null;
		$stmt->bind_result($id, $pid, $uid, $principal, $interest, $day_interest, $interest_days, $overdue_fee, $paid_overdue_fee, $overdue_days, $period_id, $repayment_date, $auto_pay, $status, $created_time, $modified_time, $finish_time);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id, 
				'pid' => $pid, 
				'uid' => $uid, 
				'principal' => $principal, 
				'interest' => $interest, 
				'day_interest' => $day_interest, 
				'interest_days' => $interest_days, 
				'overdue_fee' => $overdue_fee, 
				'paid_overdue_fee' => $paid_overdue_fee, 
				'overdue_days' => $overdue_days, 
				'period_id' => $period_id, 
				'repayment_date' => $repayment_date, 
				'auto_pay' => $auto_pay, 
				'status' => $status, 
				'created_time' => $created_time, 
				'modified_time' => $modified_time, 
				'finish_time' => $finish_time
				);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取指定贷款应还款列表
	 */
	public function getLoanRepaymentListByPid($pid, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		$sql = "SELECT id, pid, uid, principal, paid_principal, interest, paid_interest, day_interest, interest_days, overdue_fee, paid_overdue_fee, overdue_days, period_id, repayment_date, auto_pay, status, created_time, modified_time, finish_time FROM `{$this->tbl_loan_repayment_list}` WHERE pid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $pid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $pid = $uid = $principal = $paid_principal = $interest = $paid_interest = $day_interest = $interest_days = $overdue_fee = $paid_overdue_fee = $overdue_days = $period_id = $repayment_date = $auto_pay = $status = $created_time = $modified_time = $finish_time = null;
		$stmt->bind_result($id, $pid, $uid, $principal, $paid_principal, $interest, $paid_interest, $day_interest, $interest_days, $overdue_fee, $paid_overdue_fee, $overdue_days, $period_id, $repayment_date, $auto_pay, $status, $created_time, $modified_time, $finish_time);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id, 
				'pid' => $pid, 
				'uid' => $uid, 
				'principal' => $principal, 
				'paid_principal' => $paid_principal, 
				'interest' => $interest, 
				'paid_interest' => $paid_interest, 
				'day_interest' => $day_interest, 
				'interest_days' => $interest_days, 
				'overdue_fee' => $overdue_fee, 
				'paid_overdue_fee' => $paid_overdue_fee, 
				'overdue_days' => $overdue_days, 
				'period_id' => $period_id, 
				'repayment_date' => $repayment_date, 
				'auto_pay' => $auto_pay, 
				'status' => $status, 
				'created_time' => $created_time, 
				'modified_time' => $modified_time, 
				'finish_time' => $finish_time
				);
		}
		$stmt->close();
		return $arr;
	}

	public function getLoanDateByPidAndPeriod($pid, $period_id){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT repayment_date FROM `{$this->tbl_loan_repayment_list}` WHERE pid = ? AND period_id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('si', $pid, $period_id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$date = null;
		$stmt->bind_result($date);
		$stmt->fetch();
		$stmt->close();
		return $date;
	}
	/**
	 *	获取当日的还款列表（还款用）
	 */
	public function getLoanRepaymentListByDate($date, $only_before = false, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		if($only_before){
			$symbol = '<';
		}else{
			$symbol = '<=';
		}
		$sql = "SELECT id, pid, uid, principal, paid_principal, interest, paid_interest, day_interest, interest_days, overdue_fee, paid_overdue_fee, overdue_days, period_id, repayment_date, auto_pay, status, created_time, modified_time, finish_time FROM `{$this->tbl_loan_repayment_list}` WHERE repayment_date $symbol ? AND status <= 0 ORDER BY repayment_date";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $date);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $pid = $uid = $principal = $paid_principal = $interest = $paid_interest = $day_interest = $interest_days = $overdue_fee = $paid_overdue_fee = $overdue_days = $period_id = $repayment_date = $auto_pay = $status = $created_time = $modified_time = $finish_time = null;
		$stmt->bind_result($id, $pid, $uid, $principal, $paid_principal, $interest, $paid_interest, $day_interest, $interest_days, $overdue_fee, $paid_overdue_fee, $overdue_days, $period_id, $repayment_date, $auto_pay, $status, $created_time, $modified_time, $finish_time);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'pid' => $pid,
				'uid' => $uid,
				'principal' => $principal,
				'paid_principal' => $paid_principal,
				'interest' => $interest,
				'paid_interest' => $paid_interest,
				'day_interest' => $day_interest,
				'interest_days' => $interest_days,
				'overdue_fee' => $overdue_fee,
				'paid_overdue_fee' => $paid_overdue_fee,
				'overdue_days' => $overdue_days,
				'period_id' => $period_id,
				'repayment_date' => $repayment_date,
				'auto_pay' => $auto_pay,
				'status' => $status,
				'created_time' => $created_time,
				'modified_time' => $modified_time,
				'finish_time' => $finish_time
				);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取x天内还款列表（催款用）
	 */
	public function getLoanRecentListByDate($date, $days = 3, $live = false ){
		if($live){
			$db = & $this->getDB();
		}else{
			$db = & $this->getReadonlyDB();
		}
		// 2018-02-23
		// 修改SQL语句，日期范围锁定为$days
		$sql = "SELECT a.id, a.pid, a.uid, a.principal, a.interest, a.period_id, a.repayment_date, a.auto_pay, a.status, a.created_time, a.modified_time, a.finish_time FROM `{$this->tbl_loan_repayment_list}` AS a LEFT JOIN `{$this->tbl_account}` AS b ON a.uid = b.uid WHERE a.repayment_date >= ? AND a.repayment_date < ? AND a.status <= 0 AND b.amount < a.each_month ORDER BY a.repayment_date";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$recent_date = date('Y-m-d', strtotime("+$days day", strtotime($date)));
		$stmt->bind_param('ss', $date, $recent_date);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $pid = $uid = $principal = $interest = $period_id = $repayment_date = $auto_pay = $status = $created_time = $modified_time = $finish_time = null;
		$stmt->bind_result($id, $pid, $uid, $principal, $interest, $period_id, $repayment_date, $auto_pay, $status, $created_time, $modified_time, $finish_time);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'pid' => $pid,
				'uid' => $uid,
				'principal' => $principal,
				'interest' => $interest,
				'period_id' => $period_id,
				'repayment_date' => $repayment_date,
				'auto_pay' => $auto_pay,
				'status' => $status,
				'created_time' => $created_time,
				'modified_time' => $modified_time,
				'finish_time' => $finish_time
				);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 *	获取项目详情
	 */
	public function getProjcarDetail( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, repayment_method, first_repayment_date, rate, total_loan, left_loan, total_period, left_period, repayment_date, repayment_day FROM `{$this->tbl_projcar}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $repayment_method = $first_repayment_date = $rate = $total_loan = $left_loan = $total_period = $left_period = $repayment_date = $repayment_day = null;
		$stmt->bind_result($id, $repayment_method, $first_repayment_date, $rate, $total_loan, $left_loan, $total_period, $left_period, $repayment_date, $repayment_day);

		$bool = $stmt->fetch();
		if( !$bool ){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$stmt->close();
		return array(
			'id' => $id,
			'repayment_method' => $repayment_method,
			'first_repayment_date' => $first_repayment_date,
			'rate' => $rate,
			'total_loan' => $total_loan,
			'left_loan' => $left_loan,
			'total_period' => $total_period,
			'left_period' => $left_period,
			'repayment_date' => $repayment_date,
			'repayment_day' => $repayment_day
		);
	}


	/**
	 *	设置用户自动还款
	 */
	public function setLoanRepaymentListAutoPay($uid, $pid){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_loan_repayment_list}` SET auto_pay = 1, loan_repayment_time = NOW() WHERE auto_pay = 0 AND uid = ? AND pid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $uid, $pid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();			
		return true;
	}

	/**
	 *	设置用户有借款
	 */
	public function setUserHaveLoan($uid){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_user}` SET have_loan = 1,modified_time = now() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();			
		return true;
	}

	/**
	 *	更新用户逾期信息
	 */
	public function updateLoanRepaymentOverdues($id, $overdue_days, $day_overdue_fee, $uid, $left_principal, $left_interest, $compute_date){
		$db = & $this->getDB();

		$sql_update = "UPDATE `{$this->tbl_loan_repayment_list}` SET overdue_days = ?, overdue_fee = overdue_fee + ?, status = ?, modified_time = NOW() WHERE id = ?";
		$sql_insert = "INSERT INTO `{$this->tbl_loan_overdue_log}` SET lid = ?, uid = ?, principal = ?, interest = ?, compute_date = ?, overdue_fee = ?";

		$db->autocommit(false);
		$error = false;

		do{

			//增加逾期费用日志
			$stmt = $db->prepare($sql_insert);
			if (!$stmt) {
				$error = "Prepare sql_insert error!\n";
				break;
			}
			$stmt->bind_param('ssssss', $id, $uid, $left_principal, $left_interest, $compute_date, $day_overdue_fee);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_insert error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			//更新应还款项记录
			$stmt = $db->prepare($sql_update);
			if (!$stmt) {
				$error = "Prepare sql_update error!\n";
				break;
			}
			$status = LOAN_REPAYMENT_STATUS_OVERDUED;
			$stmt->bind_param('isis', $overdue_days, $day_overdue_fee, $status, $id);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

		}while (false);

		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
	}

	/**
	 *	还款后借款信息更新
	 *	id: 贷款项目ID
	 */
	public function updateLoanInfoReturned($id, $principal, $interest, $overdue_fee, $status){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_loan_info}` SET left_loan = left_loan - ?, returned_loan = returned_loan + ?, paid_interest = paid_interest + ?, paid_overdue_fee = paid_overdue_fee + ?, status = ?, modified_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssssss', $principal, $principal, $interest, $overdue_fee, $status, $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();			
		return true;
	}

	/**
	 *	逾期后借款信息更新
	 *	id: 贷款项目ID
	 */
	public function updateLoanInfoOverdued($id, $overdue_days){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_loan_info}` SET curr_overdue_days = GREATEST(?, curr_overdue_days), status = ?, modified_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = LOAN_INFO_STATUS_OVERDUED;
		$stmt->bind_param('iis', $overdue_days, $status, $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();					
		return true;
	}

	/**
	 *	增加借款信息
	 *	uid: 用户ID
	 *	pid: 贷款项目ID
	 *	interest: 已付利息
	 */
	public function addLoanInfo($uid, $pid, $total_loan, $paid_loan, $left_loan, $interest, $recent_repayment_date){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_loan_info}`(id, uid, repayment_method, total_loan, left_loan, returned_loan, paid_interest, total_period, left_period, repayment_date, repayment_day, recent_repayment_date, make, model, grant_time) SELECT id, ?, repayment_method, ?, ?, ?, ?, total_period, left_period, repayment_date, repayment_day, ?, make, model, grant_time FROM `{$this->tbl_projcar}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sssssss', $uid, $total_loan, $left_loan, $paid_loan, $interest, $recent_repayment_date, $pid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();			
		return true;
	}

	/**
	 *	增加借款信息
	 *	uid: 用户ID
	 *	pid: 贷款项目ID
	 *	interest: 已付利息
	 */
	public function addLoanRepayment($pid, $uid, $principal, $interest, $each_month, $day_interest, $interest_days, $period_id, $repayment_date, $status){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_loan_repayment_list}` SET pid = ?, uid = ?, principal = ?, paid_principal = ?, interest = ?, paid_interest = ?, each_month = ?, day_interest = ?, interest_days = ?, period_id = ?, repayment_date = ?, status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		if($status == LOAN_REPAYMENT_STATUS_RETURNED){
			$paid_principal = $principal;
			$paid_interest = $interest;
		}else{
			$paid_principal = 0;
			$paid_interest = 0;
		}
		$stmt->bind_param('ssssssssiisi', $pid, $uid, $principal, $paid_principal, $interest, $paid_interest, $each_month, $day_interest, $interest_days, $period_id, $repayment_date, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();		
		return true;
	}

	/**
	 *	增加借款信息和借款条目,事务处理
	 *	uid: 用户ID
	 *	pid: 合同ID
	 *	loan: 借款信息，数组
	 *	lr_list: 借款条目列表，数组
	 */
	public function addLoan($uid,$pid,$loan,$lr_list){
		// 插入loan_info语句
		$sql_li = "INSERT INTO `{$this->tbl_loan_info}`
		          (id, uid, repayment_method, total_loan, left_loan, returned_loan, paid_interest, total_period, left_period, repayment_date, repayment_day, recent_repayment_date, make, model, grant_time) 
			SELECT id, ?, repayment_method, ?, ?, ?, ?, total_period, left_period, repayment_date, repayment_day, ?, make, model, grant_time FROM `{$this->tbl_projcar}` WHERE id = ?";
		// 插入loan_repayment_list语句
		$sql_lr_list = "INSERT INTO `{$this->tbl_loan_repayment_list}` SET pid = ?, uid = ?, principal = ?, paid_principal = ?, interest = ?, paid_interest = ?, each_month = ?, day_interest = ?, interest_days = ?, period_id = ?, repayment_date = ?, status = ?";
			
		$db = & $this->getDB();
		// 开始事务处理
		$db->autocommit(false);
		$no_error = false;
		do{
			// 插入loan_info
			$stmt = $db->prepare($sql_li);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql_li prepare failed: errno:{$db->errno},error:{$db->error}.");
				break;
			}
			$stmt->bind_param('sssssss', $uid, $loan['total_loan'], $loan['left_loan'], $loan['paid_loan'], $loan['paid_interest'], $loan['recent_repayment_date'], $pid);
			$result = $stmt->execute();
			if(!$result){
				$this->logerror(__METHOD__, "sql_li execute failed: error:{$stmt->error}.");
				$stmt->close();
				break;
			}
			$stmt->close();
			// 插入loan_repayment_list,多条记录
			$broken = false;		
			foreach($lr_list as $lr) {
				$period_id = $lr['period_id'];
				$stmt = $db->prepare($sql_lr_list);
				if(!$stmt){
					$this->logerror(__METHOD__, "sql_lr_list prepare failed: period_id:{$period_id},errno:{$db->errno},error:{$db->error}.");
					$stmt->close();
					$broken = true;
					break;
				}
				$status = $lr['status'];
				$paid_principal = 0;
				$paid_interest = 0;
				if($status == LOAN_REPAYMENT_STATUS_RETURNED){
					$paid_principal = $lr['principal'];
					$paid_interest = $lr['interest'];
				}
				$stmt->bind_param('ssssssssiisi', $pid, $uid, $lr['principal'], $paid_principal, $lr['interest'], $paid_interest, $lr['each_month'], $lr['day_interest'], $lr['interest_days'], $period_id, $lr['repayment_date'], $status);
				$bool = $stmt->execute();
				if(!$bool){
					$this->logerror(__METHOD__,"sql_lr_list execute failed: {$period_id},error:{$stmt->error}.");
					$stmt->close();
					$broken = true;
					break;
				}
				$stmt->close();
			}
			if ($broken) {
				break;
			}
			// 设置用户贷款标志				
			$no_error = $this->setUserHaveLoan($uid);
		}while (false);
		// 执行错误，回滚事务
		if($no_error==false){
			$db->rollback();
			$db->autocommit(true);
			return false;
		} 
		// 提交事务
		$result = $db->commit();
		$db->autocommit(true);
		return $result;
	}


	/**
	 *	增加逾期记录
	 */
	public function addOverdueLog( $lid, $uid, $principal, $interest, $compute_date, $overdue_fee ){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_loan_overdue_log}` SET lid = ?, uid = ?, principal = ?, interest = ?, compute_date = ?, overdue_fee = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('isssss', $lid, $uid, $principal, $interest, $compute_date, $overdue_fee);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();		
		return true;
	}

	/**
	 *	增加还款记录
	 */
	public function addRepaymentLog( $lid, $uid, $principal, $interest, $overdue_fee ){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_loan_repayment_log}` SET lid = ?, uid = ?, principal = ?, interest = ?, overdue_fee = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('issss', $lid, $uid, $principal, $interest, $overdue_fee);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();		
		return true;
	}

	public function loanPayEarly($id){
		$sql_info = sprintf("UPDATE `{$this->tbl_loan_info}` SET status = %d, returned_loan = returned_loan + left_loan, left_loan = 0, left_period = 0, modified_time = NOW() WHERE id = %d", LOAN_INFO_STATUS_ADVANCE_PAID, $id);
		$sql_list = sprintf("UPDATE `{$this->tbl_loan_repayment_list}` SET status = %d, modified_time = NOW(), finish_time = NOW() WHERE pid = %d AND status <= 0", LOAN_REPAYMENT_STATUS_PAYEARLY, $id);
		$db = & $this->getDB();
		// echo $sql_info, "\n";
		$bool_1 = $db->query($sql_info);
		if(!$bool_1){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		// echo $sql_list, "\n";
		$bool_2 = $db->query($sql_list);
		if(!$bool_2){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		return $bool_1 && $bool_2;
	}


	/**
	 *	还款
	 *	id : 还款条目ID
	 *	pid: 贷款项目ID
	 *	uid: 用户ID
	 *	amount: 还款金额
	 */
	public function repaymentPiece( $id, $pid, $uid, $amount, $paid_principal, $paid_interest, $paid_overdue_fee ){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql_loan_repayment_update = "UPDATE `{$this->tbl_loan_repayment_list}` SET paid_principal = paid_principal + ?, paid_interest = paid_interest + ?, paid_overdue_fee = paid_overdue_fee + ?, loan_repayment_time = NOW() WHERE id = ? AND pid = ? AND status <= 0";
		$sql_loan_repayment_log = "INSERT INTO `{$this->tbl_loan_repayment_log}` SET lid = ?, uid = ?, principal = ?, interest = ?, overdue_fee = ?";
		$sql_loan_info_update = "UPDATE `{$this->tbl_loan_info}` SET left_loan = left_loan - ?, returned_loan = returned_loan + ?, paid_interest = paid_interest + ?, paid_overdue_fee = paid_overdue_fee + ?, modified_time = NOW() WHERE id = ?";
		$sql_acc_update = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, total_amount = total_amount - ?, modified_time = NOW() WHERE uid = ? and amount >= ?";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, uid) SELECT ?, amount, amount - ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$db->autocommit(false);
		$error = false;

		do{

			//增加账号扣款记录
			$action = USRACCOUNT_ACTION_RETURN_LOAN_PIECE;
			$stmt = $db->prepare($sql_acc_log);
			if (!$stmt) {
				$error = "Prepare sql_acc_log error!\n";
				break;
			}
			$stmt->bind_param('ssiss', $amount, $amount, $action, $id, $uid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_acc_log error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			//用户账号扣款
			$stmt = $db->prepare($sql_acc_update);
			if (!$stmt) {
				$error = "Prepare sql_acc_update error!\n";
				break;
			}
			$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_acc_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
			
			//还款条目状态更新
			$stmt = $db->prepare($sql_loan_repayment_update);
			if (!$stmt) {
				$error = "Prepare sql_loan_repayment_update error!\n";
				break;
			}
			$stmt->bind_param('sssss', $paid_principal, $paid_interest, $paid_overdue_fee, $id, $pid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_loan_repayment_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
			
			//记录还款条目日志
			$stmt = $db->prepare($sql_loan_repayment_log);
			if (!$stmt) {
				$error = "Prepare sql_loan_repayment_log error!\n";
				break;
			}
			$stmt->bind_param('issss', $id, $uid, $paid_principal, $paid_interest, $paid_overdue_fee);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_loan_repayment_log error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
			
			//贷款状态更新
			$stmt = $db->prepare($sql_loan_info_update);
			if (!$stmt) {
				$error = "Prepare sql_loan_info_update error!\n";
				break;
			}
			$stmt->bind_param('sssss', $paid_principal, $paid_principal, $paid_interest, $paid_overdue_fee, $pid);
			$bool = $stmt->execute();
			if(!$bool){
				$error = "Execute sql_loan_info_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();


		}while (false);

		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
		
	}


	/**
	 *	还款
	 *	id : 还款条目ID
	 *	pid: 贷款项目ID
	 *	uid: 用户ID
	 *	amount: 还款金额
	 */
	public function loanRepayment( $id, $pid, $uid, $amount, $paid_principal, $paid_interest, $paid_overdue_fee, $period_id, $next_date = null, $all_returned = false ){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql_loan_repayment_update = "UPDATE `{$this->tbl_loan_repayment_list}` SET status = ?, paid_principal = paid_principal + ?, paid_interest = paid_interest + ?, paid_overdue_fee = paid_overdue_fee + ?, loan_repayment_time = NOW(), finish_time = NOW() WHERE id = ? AND pid = ? AND status <= 0";
		$sql_loan_repayment_log = "INSERT INTO `{$this->tbl_loan_repayment_log}` SET lid = ?, uid = ?, principal = ?, interest = ?, overdue_fee = ?";
		$sql_loan_info_update = "UPDATE `{$this->tbl_loan_info}` SET status = ?, curr_overdue_days = 0, recent_repayment_date = ?, left_period = ?, modified_time = NOW() WHERE id = ?";
		$sql_acc_update = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, total_amount = total_amount - ?, modified_time = NOW() WHERE uid = ? and amount >= ?";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, act_id, uid) SELECT ?, amount, amount - ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		$db->autocommit(false);
		$error = false;

		do{

			//增加账号扣款记录
			$action = USRACCOUNT_ACTION_RETURN_LOAN;
			$stmt = $db->prepare($sql_acc_log);
			if (!$stmt) {
				$error = "Prepare sql_acc_log error!\n";
				break;
			}
			$stmt->bind_param('ssiss', $amount, $amount, $action, $id, $uid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_acc_log error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();

			//用户账号扣款
			$stmt = $db->prepare($sql_acc_update);
			if (!$stmt) {
				$error = "Prepare sql_acc_update error!\n";
				break;
			}
			$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_acc_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
			
			//还款条目状态更新
			$status = LOAN_REPAYMENT_STATUS_RETURNED;
			$stmt = $db->prepare($sql_loan_repayment_update);
			if (!$stmt) {
				$error = "Prepare sql_loan_repayment_update error!\n";
				break;
			}
			$stmt->bind_param('isssss', $status, $paid_principal, $paid_interest, $paid_overdue_fee, $id, $pid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_loan_repayment_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
			
			//记录还款条目日志
			$stmt = $db->prepare($sql_loan_repayment_log);
			if (!$stmt) {
				$error = "Prepare sql_loan_repayment_log error!\n";
				break;
			}
			$stmt->bind_param('issss', $id, $uid, $paid_principal, $paid_interest, $paid_overdue_fee);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$error = "Execute sql_loan_repayment_log error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();
			
			//贷款状态更新
			if($all_returned){
				if($all_returned == 'all'){
					$status = LOAN_INFO_STATUS_ADVANCE_PAID;
				}else{
					$status = LOAN_INFO_STATUS_RETURNED;
				}
			}else{
				$status = LOAN_INFO_STATUS_NORMAL;
			}
			$stmt = $db->prepare($sql_loan_info_update);
			if (!$stmt) {
				$error = "Prepare sql_loan_info_update error!\n";
				break;
			}
			$next_period = $period_id - 1;
			$stmt->bind_param('isis', $status, $next_date, $next_period, $pid);
			$bool = $stmt->execute();
			if(!$bool){
				$error = "Execute sql_loan_info_update error!" . $stmt->error . "\n";
				break;
			}
			$stmt->close();


		}while (false);

		if($error){
			$this->logerror(__METHOD__, $error);
			if($stmt){
				$stmt->close();
			}
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
		
	}

}