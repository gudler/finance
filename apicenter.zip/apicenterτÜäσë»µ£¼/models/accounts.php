<?php
require_once PATH_BASE_MODEL;

class AccountsModel extends Model{

	protected $tbl_user = 'users';

	protected $tbl_account = 'user_accounts';

	protected $tbl_bank = 'user_bank_accounts';

	protected $tbl_bank_verify = 'user_bank_account_verify';

	protected $tbl_recharge = 'user_recharge';

	protected $tbl_offline_recharge = 'user_offline_recharge';

	protected $tbl_withdraw = 'user_withdraw';

	protected $tbl_withdraw_tp = 'user_withdraw_tp';
	
	protected $tbl_offline_withdraw = 'user_offline_withdraw';

	protected $tbl_account_log = 'user_accounts_log';

	protected $tbl_users_rel = 'users_rel';

	protected $tbl_inviter_bonus_repayment = 'inviter_bonus_repayment';

	public function __construct(){
		parent::__construct();
	}

	public function getBankAbbr($name){
		$abbr_map = array(
			'光大银行' => 'CEB',
			'中国光大银行' => 'CEB',
			'中信银行' => 'CNCB',
			'中信实业银行' => 'CNCB',
			'中国邮政储蓄' => 'PSBC',
			'邮政储蓄' => 'PSBC',
			'中国银行' => 'BOC',
			'中国农业银行' => 'ABC',
			'农业银行' => 'ABC',
			'中国民生银行' => 'CMBC',
			'民生银行' => 'CMBC',
			'中国建设银行' => 'CCB',
			'建设银行' => 'CCB',
			'中国工商银行' => 'ICBC',
			'工商银行' => 'ICBC',
			'招商银行' => 'CMB',
			'兴业银行' => 'CIB',
			'上海浦东发展银行' => 'SPDB',
			'浦东发展银行' => 'SPDB',
			'浦发银行' => 'SPDB',
			'平安银行' => 'PAB',
			'中国交通银行' => 'BCM',
			'交通银行' => 'BCM',
			'华夏银行' => 'HXB',
			'广东发展银行' => 'CGB',
			'广发银行' => 'CGB',
			// 2017-09-27
			// 增加上海北京银行
			'上海银行' => 'SHB',
			'北京银行' => 'BJB',
		);
		if(isset($abbr_map[$name])){
			return $abbr_map[$name];
		}
		return $name;
	}

	public function getUserAccountInfo($uid){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT uid, amount, total_amount, total_interest, auto_shift, amount_shift, shift_amount_min, status, created_time, modified_time FROM `{$this->tbl_account}` WHERE uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$uid = $amount = $total_amount = $total_interest = $auto_shift = $amount_shift = $shift_amount_min = $status = $created_time = $modified_time = null;
		$stmt->bind_result($uid, $amount, $total_amount, $total_interest, $auto_shift, $amount_shift, $shift_amount_min, $status, $created_time, $modified_time);
		$stmt->fetch();
		$stmt->close();
		if(empty($uid)){
			return null;
		}
		return array(
			'uid' => $uid,
			'amount' => $amount,
			'total_amount' => $total_amount,
			'total_interest' => $total_interest,
			'auto_shift' => $auto_shift,
			'amount_shift' => $amount_shift,
			'shift_amount_min' => $shift_amount_min,
			'status' => $status,
			'created_time' => $created_time,
			'modified_time' => $modified_time
		);
	}

	public function getUserCurrentAccount($uid){
		$db = & $this->getDB();
		$sql = "SELECT uid, amount, total_amount FROM `{$this->tbl_account}` WHERE uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$uid = $amount = $total_amount = null;
		$stmt->bind_result($uid, $amount, $total_amount);
		$stmt->fetch();
		$stmt->close();
		if(empty($uid)){
			return null;
		}
		return array(
			'uid' => $uid,
			'amount' => $amount,
			'total_amount' => $total_amount
		);
	}

	public function getAmountShiftCount(){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT count(*) AS numb FROM `{$this->tbl_account}` WHERE amount_shift = 1 AND shift_amount_min <= amount";
		$result = $db->query($sql);
		if(!$result){
			return 0;
		}
		$row = $result->fetch_assoc();
		$result->free();
		$total = 0;
		if($row && isset($row['numb'])){
			$total = $row['numb'];
		}
		return $total;
	}

	public function getAmountShiftList($limit, $min_uid){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_account}` WHERE amount_shift = 1 AND shift_amount_min <= amount AND uid > %d ORDER BY uid LIMIT %d", $min_uid, $limit);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 *	获取平台总体账户情况
	 */
	public function getTotalBalance(){
		$db = & $this->getDB();
		$sql = "SELECT SUM(amount) as amount, count(*) as numb, SUM(total_amount) as total_amount FROM `{$this->tbl_account}` WHERE uid != " . OBL_SYSTEM_UID;
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getTotalBankBounds(){
		$db = & $this->getDB();
		// 2018/01/03 FIX BUG
		// 需要过滤掉删除/换预留手机号等带来的标记为删除的记录
		$sql = "SELECT count(*) as numb FROM `{$this->tbl_bank}` WHERE status >= 0 AND uid != " . OBL_SYSTEM_UID;
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function countAccByIdentID($key_identcode){
		$db = & $this->getDB();
		// 2018/01/03 FIX BUG
		// 根据用户身份证查询账户记录个数的时候，需要过滤掉删除/换预留手机号等带来的标记为删除的记录
		$sql = sprintf("SELECT count(*) as numb FROM `{$this->tbl_bank}` WHERE key_identcode = '%s' AND status >=0 ", addslashes($key_identcode));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row['numb'];
	}

	public function getUserCurrentBankAccount($uid){
		$db = & $this->getDB();
		$sql = "SELECT id, uid, idtype, bank, bank_name, city, bank_sub, cardno, realname, identcode, mobile, status, key_mobile, key_cardno, key_identcode, created_time, modified_time FROM `{$this->tbl_bank}` WHERE uid = ? and status >= 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $idtype = $bank = $bank_name = $city = $bank_sub = $cardno = $realname = $identcode = $mobile = $status = $key_mobile = $key_cardno = $key_identcode = $created_time = $modified_time = null;
		$stmt->bind_result($id, $uid, $idtype, $bank, $bank_name, $city, $bank_sub, $cardno, $realname, $identcode, $mobile, $status, $key_mobile, $key_cardno, $key_identcode, $created_time, $modified_time);
		$stmt->fetch();
		$stmt->close();
		if(empty($uid)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'idtype' => $idtype,
			'bank' => $bank,
			'bank_name' => $bank_name,
			'city' => $city,
			'bank_sub' => $bank_sub,
			'cardno' => $cardno,
			'realname' => $realname,
			'identcode' => $identcode,
			'mobile' => $mobile,
			'status' => $status,
			'key_mobile' => $key_mobile,
			'key_cardno' => $key_cardno,
			'key_identcode' => $key_identcode,
			'created_time' => $created_time,
			'modified_time' => $modified_time
		);
	}
	/**
	 * 根据手机号码和加密后的卡号进行用户和账户组合查询，内部系统使用
	 */
	public function getUserCurrentBankAccount2($mobile,$key_cardno){
		$mobile_empty = empty($mobile);
		$key_cardno_empty = empty($key_cardno);
		$sql = '';
		if ($mobile_empty && $key_cardno_empty) {
				return null;
		} else if (!$mobile_empty && $key_cardno_empty) {
			$sql = "SELECT u.id AS uid, u.mobile AS mobile, u.created_time AS created_time, b.id as bid, b.bank, b.cardno, b.realname, b.identcode, b.mobile AS phone
				FROM `{$this->tbl_user}` AS u LEFT JOIN `{$this->tbl_bank}` AS b ON b.uid = u.id AND b.status >=0
				WHERE u.mobile = '{$mobile}' ";
		} else if (!$key_cardno_empty && $mobile_empty) {
			$sql = "SELECT u.id AS uid, u.mobile AS mobile, u.created_time AS created_time, b.id as bid, b.bank, b.cardno, b.realname, b.identcode, b.mobile AS phone
				FROM `{$this->tbl_bank}` AS b LEFT JOIN `{$this->tbl_user}` AS u ON u.id = b.uid
				WHERE b.status >=0 AND b.key_cardno = '{$key_cardno}' ";
		} else {
			$sql = "SELECT u.id AS uid, u.mobile AS mobile, u.created_time AS created_time, b.id as bid, b.bank, b.cardno, b.realname, b.identcode, b.mobile AS phone
				FROM `{$this->tbl_user}` AS u LEFT JOIN `{$this->tbl_bank}` AS b ON b.uid = u.id AND b.status >=0
				WHERE u.mobile = '{$mobile}' AND b.key_cardno = '{$key_cardno}' ";
		}
		$db = & $this->getDB();
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getUserAllBankAccount($uid){
		$db = & $this->getDB();
		// 2018/01/03 BUG FIX
		// 需要过滤状态为删除的记录
		$sql = "SELECT id, uid, bank, cardno, realname, identcode, mobile, status, created_time, modified_time FROM `{$this->tbl_bank}` WHERE uid = ? AND status >=0 ";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $bank = $cardno = $realname = $identcode = $mobile = $status = $created_time = $modified_time = null;
		$stmt->bind_result($id, $uid, $bank, $cardno, $realname, $identcode, $mobile, $status, $created_time, $modified_time);
		$arr = array();
		while($row = $stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'bank' => $bank,
				'cardno' => $cardno,
				'realname' => $realname,
				'identcode' => $identcode,
				'mobile' => $mobile,
				'status' => $status,
				'created_time' => $created_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getAllBankAccountByStatus($status, $limit = 50, $start = 0){
		$db = & $this->getDB();
		$sql = "SELECT id, uid, bank, cardno, realname, identcode, mobile, status, created_time, modified_time FROM `{$this->tbl_bank}` WHERE status = ? limit ?, ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('iii', $status, $start, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $bank = $cardno = $realname = $identcode = $mobile = $status = $created_time = $modified_time = null;
		$stmt->bind_result($id, $uid, $bank, $cardno, $realname, $identcode, $mobile, $status, $created_time, $modified_time);
		$arr = array();
		while($row = $stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'bank' => $bank,
				'cardno' => $cardno,
				'realname' => $realname,
				'identcode' => $identcode,
				'mobile' => $mobile,
				'status' => $status,
				'created_time' => $created_time,
				'modified_time' => $modified_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function setWithdrawOrderBatch($batch, $status, $limit){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw}` SET batch = ?, batched_time = NOW() WHERE status = ? AND batch is null LIMIT ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sii', $batch, $status, $limit);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			//$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();
		return true;
	}

	public function getWithdrawOrderList($status, $batch){
		$db = & $this->getDB();
		$sql = "SELECT id, uid, baid, money, fee, cardno, username, bank_name, city, bank_sub, order_id, trans_id, status, curr_date, created_time, trans_response_time, done_time 
				FROM `{$this->tbl_withdraw}` 
				WHERE status = ? AND batch = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('is', $status, $batch);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $baid = $money = $fee = $cardno = $username = $bank_name = $city = $bank_sub = $order_id = $trans_id = $status = $curr_date = $created_time = $trans_response_time = $done_time = null;
		$stmt->bind_result( $id, $uid, $baid, $money, $fee, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $trans_id, $status, $curr_date, $created_time, $trans_response_time, $done_time );
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'baid' => $baid,
				'money' => $money,
				'fee' => $fee,
				'cardno' => $cardno,
				'username' => $username,
				'bank_name' => $bank_name,
				'city' => $city,
				'bank_sub' => $bank_sub,
				'order_id' => $order_id,
				'trans_id' => $trans_id,
				'status' => $status,
				'curr_date' => $curr_date,
				'created_time' => $created_time,
				'trans_response_time' => $trans_response_time,
				'done_time' => $done_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getUserAccountLogs($uid, $action = null, $get_total = false, $limit = 50, $start = 0){
		$db = & $this->getReadonlyDB();
		$action_str = '';
		if(!empty($action)){
			if(is_array($action)){
				$helper = load_helper('model');
				$id_str = $helper::idarr_to_string($action);
				$action_str = sprintf(" AND action in (%s)", $id_str);
			}else{
				$action = intval($action);
				if($action){
					$action_str = ' AND action = ' . $action;
				}
			}
		}
		if($get_total){
			$sql = sprintf("SELECT COUNT(id) AS numb FROM `{$this->tbl_account_log}` WHERE uid = %d $action_str", $uid);
			$result = $db->query($sql);
			if(!$result){
				return null;
			}
			$row = $result->fetch_assoc();
			$result->free();
			if(empty($row)){
				return 0;
			}
			return intval($row['numb']);
		}

		$sql = sprintf("SELECT * FROM `{$this->tbl_account_log}` WHERE uid = %d $action_str ORDER BY id DESC limit %d, %d", $uid, $start, $limit);
		// echo $sql;exit();
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getRechargeOrderList($status, $limit = 50){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, uid, money, created_time FROM `{$this->tbl_recharge}` WHERE status = ? limit ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ii', $status, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$id = $uid = $money = $created_time = null;
		$stmt->bind_result($id, $uid, $money, $created_time);
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'money' => $money,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getRechargeOrderById( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			id,
			uid,
			baid,
			money,
			trans_id,
			status,
			created_time,
			trans_response_time,
			done_time
			FROM `{$this->tbl_recharge}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $baid = $money = $trans_id = $status = $created_time = $trans_response_time = $done_time = null;
		$stmt->bind_result( $id, $uid, $baid, $money, $trans_id, $status, $created_time, $trans_response_time, $done_time );

		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'baid' => $baid,
			'money' => $money,
			'trans_id' => $trans_id,
			'status' => $status,
			'created_time' => $created_time,
			'trans_response_time' => $trans_response_time,
			'done_time' => $done_time
		);
	}

	public function getRechargeOrderByTransId( $trans_id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			id,
			uid,
			baid,
			money,
			trans_id,
			status,
			created_time,
			trans_response_time,
			done_time
			FROM `{$this->tbl_recharge}` WHERE trans_id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('i', $trans_id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $baid = $money = $trans_id = $status = $created_time = $trans_response_time = $done_time = null;
		$stmt->bind_result( $id, $uid, $baid, $money, $trans_id, $status, $created_time, $trans_response_time, $done_time );

		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'baid' => $baid,
			'money' => $money,
			'trans_id' => $trans_id,
			'status' => $status,
			'created_time' => $created_time,
			'trans_response_time' => $trans_response_time,
			'done_time' => $done_time
		);
	}

	public function getOfflineRechargeOrderById( $id ){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_offline_recharge}` WHERE id = %d", $id);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}


	public function getOfflineRechargeByRLID($rl_id){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_offline_recharge}` WHERE rl_id = %d ORDER BY id LIMIT 1", $rl_id);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getOfflineWithdrawByWLID($wl_id){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_offline_withdraw}` WHERE wl_id = %d ORDER BY id LIMIT 1", $wl_id);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getOfflineRechargeNoticed( $date, $hour ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			a.id,
			a.uid,
			a.money,
			a.status,
			a.created_time,
			a.trans_response_time,
			a.done_time,
			b.bank,
			b.cardno,
			b.realname,
			b.mobile
			FROM `{$this->tbl_offline_recharge}` AS a LEFT JOIN `{$this->tbl_bank}` AS b ON a.uid = b.uid WHERE b.status = 0 AND a.status = ? AND date(a.trans_response_time) = ? AND hour(a.trans_response_time) = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_NOTICE_PAID;
		$stmt->bind_param('isi', $status, $date, $hour);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $money = $status = $created_time = $trans_response_time = $done_time = $bank = $cardno = $realname = $mobile = null;
		$stmt->bind_result( $id, $uid, $money, $status, $created_time, $trans_response_time, $done_time, $bank, $cardno, $realname, $mobile );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'money' => $money,
				'status' => $status,
				'created_time' => $created_time,
				'trans_response_time' => $trans_response_time,
				'done_time' => $done_time,
				'bank' => $bank,
				'cardno' => $cardno,
				'realname' => $realname,
				'mobile' => $mobile
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getOfflineRechargeWaitingNoticeLocalSRV(){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			a.id,
			a.uid,
			a.money,
			a.status,
			a.created_time,
			a.trans_response_time,
			a.done_time,
			b.bank,
			b.cardno,
			b.realname,
			b.mobile
			FROM `{$this->tbl_offline_recharge}` AS a LEFT JOIN `{$this->tbl_bank}` AS b ON a.uid = b.uid WHERE b.status = 0 AND a.status = ? AND a.id > 171";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_NOTICE_PAID;
		$stmt->bind_param('i', $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $money = $status = $created_time = $trans_response_time = $done_time = $bank = $cardno = $realname = $mobile = null;
		$stmt->bind_result( $id, $uid, $money, $status, $created_time, $trans_response_time, $done_time, $bank, $cardno, $realname, $mobile );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'money' => $money,
				'status' => $status,
				'created_time' => $created_time,
				'trans_response_time' => $trans_response_time,
				'done_time' => $done_time,
				'bank' => $bank,
				'cardno' => $cardno,
				'realname' => $realname,
				'mobile' => $mobile
			);
		}
		$stmt->close();
		return $arr;
	}

	public function getOfflineRechargeByStatus( $status, $limit = 100, $start = 0 ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			a.id,
			a.uid,
			a.money,
			a.status,
			a.created_time,
			a.trans_response_time,
			a.done_time,
			b.bank,
			b.cardno,
			b.realname,
			b.mobile,
			FROM `{$this->tbl_offline_recharge}` AS a LEFT JOIN `{$this->tbl_bank}` AS b ON a.uid = b.uid WHERE b.status = 0 AND a.status = ? LIMIT ?, ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('iii', $status, $start, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $money = $status = $created_time = $trans_response_time = $done_time = $bank = $cardno = $realname = $mobile = null;
		$stmt->bind_result( $id, $uid, $money, $status, $created_time, $trans_response_time, $done_time, $bank, $cardno, $realname, $mobile );
		$arr = array();
		while( $stmt->fetch() ){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'money' => $money,
				'status' => $status,
				'bank' => $bank,
				'cardno' => $cardno,
				'realname' => $realname,
				'mobile' => $mobile,
				'created_time' => $created_time,
				'trans_response_time' => $trans_response_time,
				'done_time' => $done_time
			);
		}
		$stmt->close();

		return $arr;
	}

	public function addOfflineRechargeOrder( $uid, $mobile, $money ){
		if($money<=0){
			return false;
		}
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_offline_recharge}` SET uid = ?, mobile = ?, money = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sss', $uid, $mobile, $money);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function addOfflineRechargePaidOrder( $uid, $mobile, $money ){
		if($money<=0){
			$this->logerror(__METHOD__, "money:{$money} is less than 0");
			return false;
		}
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_offline_recharge}` SET uid = ?, mobile = ?, money = ?, status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_NOTICE_PAID;		
		$stmt->bind_param('sssi', $uid, $mobile, $money, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function addLocalOfflineRechargeOrder( $uid, $mobile, $money, $rl_id, $type ){
		if($money<=0){
			return false;
		}
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_offline_recharge}` SET uid = ?, mobile = ?, money = ?, rl_id = ?, notice_local_srv_time = NOW(), status = ?, type = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_NOTICED_LOCAL_SRV;
		$stmt->bind_param('ssssii', $uid, $mobile, $money, $rl_id, $status, $type);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function offlineRechargeNoticedLocalSRV( $uid, $id, $rl_id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_recharge}` SET status = ?, rl_id = ?, notice_local_srv_time = NOW() WHERE id = ? AND uid = ? AND rl_id IS NULL";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_NOTICED_LOCAL_SRV;
		$stmt->bind_param('isss', $status, $rl_id, $id, $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$bool = !!$stmt->affected_rows;
		$stmt->close();
		return $bool;
	}

	public function noticeOfflineRecharged( $uid, $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_recharge}` SET status = ?, trans_response_time = NOW() WHERE id = ? AND uid = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_ORDER_CREATED;
		$status_new = OFFLINE_RECHARGE_STATUS_NOTICE_PAID;
		$stmt->bind_param('issi', $status_new, $id, $uid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$bool = !!$stmt->affected_rows;
		$stmt->close();
		return $bool;
	}

	public function verifiedOfflineRecharged( $uid, $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_recharge}` SET status = ? WHERE id = ? AND uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_PAID_VERIFIED;
		$stmt->bind_param('iss', $status, $id, $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$bool = !!$stmt->affected_rows;
		$stmt->close();
		return $bool;
	}

	public function offlineRechargeDone( $uid, $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_recharge}` SET status = ?, done_time = NOW() WHERE id = ? AND uid = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_DONE;
		$stmt->bind_param('iss', $status, $id, $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$bool = !!$stmt->affected_rows;
		$stmt->close();
		return $bool;
	}

	public function addRechargeOrder( $uid, $baid, $money ){
		if($money<=0){
			return false;
		}
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_recharge}` SET uid = ?, baid = ?, money = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sis', $uid, $baid, $money);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function rechargeOrderUpdateTransId( $id, $trans_id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_recharge}` SET trans_id = ? WHERE id = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$ex_status = RECHARGE_STATUS_ORDER_CREATED;
		$stmt->bind_param('sii', $trans_id, $id, $ex_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function rechargeOrderResponsed( $id, $status ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_recharge}` SET status = ?, trans_response_time = NOW() WHERE id = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$ex_status = RECHARGE_STATUS_ORDER_CREATED;
		$stmt->bind_param('iii', $status, $id, $ex_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function rechargeOrderResponsedByOrderID( $trans_id, $status, $rdesc = '' ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_recharge}` SET status = ?, rdesc = ?, trans_response_time = NOW() WHERE trans_id = ? AND status in (?,?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$ex_status = RECHARGE_STATUS_ORDER_CREATED;
		$ex_status2 = RECHARGE_STATUS_FAILED;
		$stmt->bind_param('isiii', $status, $rdesc, $trans_id, $ex_status, $ex_status2);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			// $this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function rechargeOrderDoneAndToAccount( $id ){
		$db = & $this->getDB();

		$sql_order_status_done = "UPDATE `{$this->tbl_recharge}` SET status = ?, done_time = NOW() WHERE id = ? AND done_time IS NULL";
		$sql_account_amount_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? and ? > 0";
		$sql_account_log = "INSERT INTO `{$this->tbl_account_log}` SET amount_change = ?, amount_before = ?, amount_after = ?, action = ?, bank_account_id = ?, uid = ?";
		$order = $this->getRechargeOrderById( $id );
		if(!$order){
			$this->logerror(__METHOD__, "get recharge order [$id] failed");
			return false;
		}
		$uid = $order['uid'];
		$baid = $order['baid'];
		$amount = $order['money'] * 100;//分to毫，*100
		$acc = $this->getUserCurrentAccount( $uid );
		if(!$acc){
			$this->logerror(__METHOD__, "get account[$uid] info failed");
			return false;
		}
		$db->autocommit(false);
		$amount_before = intval($acc['amount']);
		$stmt = $db->prepare($sql_account_amount_add);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_account_amount_add prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$amount_after = $amount_before + $amount;
		$stmt = $db->prepare($sql_account_log);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_account_log prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = USRACCOUNT_ACTION_RECHARGE;
		$stmt->bind_param('ssssss', $amount, $amount_before, $amount_after, $action, $baid, $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_order_status_done);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_order_status_done prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$status = RECHARGE_STATUS_DONE;
		$stmt->bind_param('ii', $status, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		$bool = $db->commit();
		$db->autocommit(true);
		return true;
	}

	public function offlineRechargeOrderDoneAndToAccount( $id, $type ){
		$db = & $this->getDB();

		$sql_order_status_done = "UPDATE `{$this->tbl_offline_recharge}` SET status = ?, done_time = NOW() WHERE id = ? AND done_time IS NULL";
		$sql_account_amount_add = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? and ? > 0";
		$sql_account_log = "INSERT INTO `{$this->tbl_account_log}` SET amount_change = ?, amount_before = ?, amount_after = ?, action = ?, uid = ?";
		$order = $this->getOfflineRechargeOrderById( $id );
		if(!$order){
			$this->logerror(__METHOD__, "get recharge order [$id] failed");
			return false;
		}
		$uid = $order['uid'];
		$amount = $order['money'] * 100;//分to毫，*100
		$acc = $this->getUserCurrentAccount( $uid );
		if(!$acc){
			$this->logerror(__METHOD__, "get account[$uid] info failed");
			return false;
		}
		$db->autocommit(false);
		$amount_before = intval($acc['amount']);
		$stmt = $db->prepare($sql_account_amount_add);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_account_amount_add prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$amount_after = $amount_before + $amount;
		$stmt = $db->prepare($sql_account_log);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_account_log prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$action = intval($type);
		$stmt->bind_param('sssss', $amount, $amount_before, $amount_after, $action, $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		$stmt = $db->prepare($sql_order_status_done);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql_order_status_done prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$status = OFFLINE_RECHARGE_STATUS_DONE;
		$stmt->bind_param('ii', $status, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		$bool = $db->commit();
		$db->autocommit(true);
		return true;
	}

	public function getWithdrawOrderByOrderId($order_id){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_withdraw}` WHERE order_id = '%s'", addslashes($order_id));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getWithdrawOrderById( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			id,
			uid,
			baid,
			money,
			cardno,
			username,
			bank_name,
			city,
			bank_sub,
			order_id,
			trans_id,
			status,
			created_time,
			trans_response_time,
			done_time
			FROM `{$this->tbl_withdraw}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$id = $uid = $baid = $money = $cardno = $username = $bank_name = $city = $bank_sub = $order_id = $trans_id = $status = $created_time = $trans_response_time = $done_time = null;
		$stmt->bind_result( $id, $uid, $baid, $money, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $trans_id, $status, $created_time, $trans_response_time, $done_time );

		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'baid' => $baid,
			'money' => $money,
			'cardno' => $cardno,
			'username' => $username,
			'bank_name' => $bank_name,
			'city' => $city,
			'bank_sub' => $bank_sub,
			'order_id' => $order_id,
			'trans_id' => $trans_id,
			'status' => $status,
			'created_time' => $created_time,
			'trans_response_time' => $trans_response_time,
			'done_time' => $done_time
		);
	}

	public function getWithdrawTodayTotalByUid( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT sum(money) FROM `{$this->tbl_withdraw}` WHERE uid = ? AND curr_date = ? AND status in (0, 2)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$curr_date = date('Y-m-d');
		$stmt->bind_param('ss', $uid, $curr_date);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$money = null;
		$stmt->bind_result( $money );
		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		return array(
			'total' => $money,
			'date' => $curr_date
		);
	}

	public function getWithdrawMonthTotalByUid( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT sum(money) FROM `{$this->tbl_withdraw}` WHERE uid = ? AND curr_date >= ? AND status in (0, 2)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$date_start = date('Y-m-01');
		$stmt->bind_param('ss', $uid, $date_start);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$money = null;
		$stmt->bind_result( $money );
		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		return array(
			'total' => $money,
			'date' => date('Y-m')
		);
	}


	public function getWithdrawMonthTimesByUid( $uid ){
		$db = & $this->getReadonlyDB();
		$month = date('Y-m');
		$sql = "SELECT count(*) FROM `{$this->tbl_withdraw}` WHERE uid = ? AND status >= 0 AND status != 1 AND curr_date like '$month%'";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$times = null;
		$stmt->bind_result( $times );
		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		return array(
			'times' => $times,
			'date' => $month
		);
	}

	public function addWithdrawOrder( $uid, $baid, $money, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $fee ){
		if($money - $fee <= 0){
			return false;
		}
		$db = & $this->getDB();

		$sql_withdraw = "INSERT INTO `{$this->tbl_withdraw}` SET uid = ?, baid = ?, money = ?, curr_date = ?, cardno = ?, username = ?, bank_name = ?, city = ?, bank_sub = ?, order_id = ?, fee = ?";

		$db->autocommit(false);
		
		$stmt = $db->prepare($sql_withdraw);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$curr_date = date('Y-m-d');
		$stmt->bind_param('sissssssssi', $uid, $baid, $money, $curr_date, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $fee);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$id = $stmt->insert_id;
		$stmt->close();
		
		$amount = $money * 100;//分 to 毫
		$res = $this->changeAccount($uid, $amount, USRACCOUNT_ACTION_WITHDRAW, $baid, true);
		if(!$res){
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $id;
	}

	public function withdrawOrderResponsed( $id, $status, $response_txt = '' ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw}` SET status = ?, response_txt = ?, trans_response_time = NOW(), done_time = NOW() WHERE id = ? AND status NOT IN (?, ?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$ex_status = WITHDRAW_STATUS_DONE;
		$ex_status2 = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$stmt->bind_param('isiii', $status, $response_txt, $id, $ex_status, $ex_status2);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function updateBankAccountCityInfoByWithdraw( $wdid ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_bank}` AS a INNER JOIN `{$this->tbl_withdraw}` AS b ON a.id = b.baid SET a.bank_name = b.bank_name, a.city = b.city, a.bank_sub = b.bank_sub, a.modified_time = NOW() WHERE b.id = ? AND b.status = ? AND a.city IS NULL";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = WITHDRAW_STATUS_DONE;
		$stmt->bind_param('si', $wdid, $status);
		$bool = $stmt->execute();
		if(!$bool){
			$error = ($stmt->error ? $stmt->error : '') . " $wdid, $status";
			$this->logerror(__METHOD__, $error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			return false;
		}
		$stmt->close();
		return true;
	}

	public function withdrawOrderRollbacked( $id, $uid, $amount, $baid ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw}` SET status = ?, done_time = NOW() WHERE id = ? AND status NOT IN (?, ?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$db->autocommit(false);
		$ex_status = WITHDRAW_STATUS_DONE;
		$ex_status2 = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$status = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$stmt->bind_param('iiii', $status, $id, $ex_status, $ex_status2);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		$amount = $amount * 100;// 分 to 毫
		$bool = $this->changeAccount($uid, $amount, USRACCOUNT_ACTION_WITHDRAW_ROLLBACK, $baid, true);
		if(!$bool){
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
	}

	public function withdrawOrderDone( $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw}` SET status = ?, done_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = WITHDRAW_STATUS_DONE;
		$stmt->bind_param('ii', $status, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function withdrawOrderTuipiaoRollbacked( $id, $tpid, $uid, $amount, $baid ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw}` SET status = ?, done_time = NOW() WHERE id = ? AND status = ?";
		$sql2 = "UPDATE `{$this->tbl_withdraw_tp}` SET status = ?, done_time = NOW() WHERE id = ? AND status = ?";
		//提现状态变更
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$db->autocommit(false);
		$ex_status = WITHDRAW_STATUS_DONE;
		$status = WITHDRAW_STATUS_TUIPIAO_ROLLBACK;
		$stmt->bind_param('iii', $status, $id, $ex_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();						
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		//退票状态变更
		$stmt = $db->prepare($sql2);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$ex_status = WITHDRAW_TUIPIAO_CONFIRMED;
		$status = WITHDRAW_TUIPIAO_DONE;
		$stmt->bind_param('iii', $status, $tpid, $ex_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();

		//账户返还相应金额
		$amount = $amount * 100;// 分 to 毫
		$bool = $this->changeAccount($uid, $amount, USRACCOUNT_ACTION_WITHDRAW_TUIPIAO_ROLLBACK, $baid, true);
		if(!$bool){
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
	}

	public function addWithdrawTuipiao($orderno, $merdt, $fuorderno, $tpmerdt, $futporderno, $accntno, $accntnm, $bankno, $amt, $state, $result, $reason, $mac){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_withdraw_tp}` SET orderno = ?, merdt = ?, fuorderno = ?, tpmerdt = ?, futporderno = ?, accntno = ?, accntnm = ?, bankno = ?, amt = ?, state = ?, result = ?, reason = ?, mac = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sssssssssssss', $orderno, $merdt, $fuorderno, $tpmerdt, $futporderno, $accntno, $accntnm, $bankno, $amt, $state, $result, $reason, $mac);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$last_id = $stmt->insert_id;
		$stmt->close();
		return $last_id;
	}
	/**
	 * 确认退票记录
	 * $uid: 用户ID,$withdrawid:提现记录ID,$baid: 银行ID, $fee: 原来提现的手续费用
	 */
	public function updateWithdrawTuipiaoConfirmed($id,$uwid,$uid=0,$baid=0,$fee=0 ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw_tp}` SET status = ?, uid = ?, baid = ?, uwid = ?, fee = ?, verify_time = NOW() WHERE id = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = WITHDRAW_TUIPIAO_CONFIRMED;
		$ex_status = WITHDRAW_TUIPIAO_CREATED;
		$stmt->bind_param('isissii', $status, $uid, $baid, $uwid, $fee, $id, $ex_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function updateWithdrawTuipiaoIllegal( $id, $reason='' ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_withdraw_tp}` SET status = ?, response_txt = ?, verify_time = NOW() WHERE id = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = WITHDRAW_TUIPIAO_ILLEGAL;
		$ex_status = WITHDRAW_TUIPIAO_CREATED;
		$stmt->bind_param('isii', $status, $reason, $id, $ex_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function getWithdrawTuipiao($orderno){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_withdraw_tp}` WHERE orderno = '%s'", addslashes($orderno));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getWithdrawTPCount($status,$filter_orderno){
		$where = '1';
		if ($status!==null) {
				$where .= " AND tp.status = {$status}";
		}
		if (!empty($filter_orderno)) {
			$where .= " AND tp.orderno LIKE '%{$filter_orderno}%'";			
		}
	   
		$db = & $this->getReadonlyDB();
		$sql = "SELECT COUNT(*) AS numb
				FROM {$this->tbl_withdraw_tp} AS tp
				WHERE {$where}";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
    }		
	/**
	 *	
	 */
	public function getWithdrawTPs($page,$pagesize,$status,$filter_orderno){
		$where = '1';
	   if ($status!==null) {
	   	    $where .= " AND tp.status = {$status}";
	   }
	   if (!empty($filter_orderno)) {
		   $where .= " AND tp.orderno LIKE '%{$filter_orderno}%'";			
	   }
	   
	   $limit = intval($pagesize);
	   $start = $limit * $page;
	   $db = & $this->getReadonlyDB();
	   $sql = "SELECT tp.id, tp.uid, u.mobile,tp.orderno, tp.accntnm, tp.amt AS amount, tp.fee, tp.state, tp.result, tp.reason, tp.status, tp.created_time, tp.done_time
			   FROM {$this->tbl_withdraw_tp} AS tp
			   LEFT JOIN {$this->tbl_user} AS u on u.id = tp.uid
			   WHERE {$where}
			   ORDER BY tp.created_time DESC
			   LIMIT $start, $limit ;";
	   $result = $db->query($sql);
	   if(!$result){
		   return null;
	   }
	   $arr = $result->fetch_all(MYSQLI_ASSOC);
	   $result->free();
	   return $arr;
    }	
   
    public function getInviteAwardTotal($datetime){
		$db = & $this->getReadonlyDB();
		$datetime = date('Y-m-d H:i:s', strtotime($datetime));
		$sql = sprintf("SELECT SUM(bind_card_award_invitee) + SUM(buy_long_award_inviter) AS total_amount FROM `{$this->tbl_users_rel}` WHERE created_time >= '%s'", $datetime);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row['total_amount'];
	}

/*======OFFLINE WITHDRAW START======*/

	public function getOfflineWithdrawOrderById( $id ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT 
			id,
			uid,
			baid,
			money,
			cardno,
			username,
			bank_name,
			city,
			bank_sub,
			order_id,
			trans_id,
			status,
			created_time,
			trans_response_time,
			done_time
			FROM `{$this->tbl_offline_withdraw}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('i', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$id = $uid = $baid = $money = $cardno = $username = $bank_name = $city = $bank_sub = $order_id = $trans_id = $status = $created_time = $trans_response_time = $done_time = null;
		$stmt->bind_result( $id, $uid, $baid, $money, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $trans_id, $status, $created_time, $trans_response_time, $done_time );

		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'uid' => $uid,
			'baid' => $baid,
			'money' => $money,
			'cardno' => $cardno,
			'username' => $username,
			'bank_name' => $bank_name,
			'city' => $city,
			'bank_sub' => $bank_sub,
			'order_id' => $order_id,
			'trans_id' => $trans_id,
			'status' => $status,
			'created_time' => $created_time,
			'trans_response_time' => $trans_response_time,
			'done_time' => $done_time
		);
	}

	public function getOfflineWithdrawTodayTotalByUid( $uid ){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT sum(money) FROM `{$this->tbl_offline_withdraw}` WHERE uid = ? AND curr_date = ? AND status >= 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$curr_date = date('Y-m-d');
		$stmt->bind_param('ss', $uid, $curr_date);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$money = null;
		$stmt->bind_result( $money );
		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		return array(
			'total' => $money,
			'date' => $curr_date
		);
	}

	public function getOfflineWithdrawMonthTimesByUid( $uid ){
		$db = & $this->getReadonlyDB();
		$month = date('Y-m');
		$sql = "SELECT count(*) FROM `{$this->tbl_offline_withdraw}` WHERE uid = ? AND status >= 0 AND status != 1 AND curr_date like '$month%'";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$arr = array();
		$times = null;
		$stmt->bind_result( $times );
		$bool = $stmt->fetch();
		$stmt->close();
		if(!$bool){
			return false;
		}
		return array(
			'times' => $times,
			'date' => $month
		);
	}

	public function setOfflineWithdrawOrderBatch($batch, $status, $limit){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_withdraw}` SET batch = ?, batched_time = NOW() WHERE status = ? AND batch is null LIMIT ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sii', $batch, $status, $limit);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			//$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		// 2017-12-15 stmt close
		$stmt->close();			
		return true;
	}

	public function getOfflineWithdrawOrderList($status, $batch){
		$db = & $this->getDB();
		$sql = "SELECT id, uid, baid, money, fee, cardno, username, bank_name, city, bank_sub, order_id, trans_id, status, curr_date, created_time, trans_response_time, done_time 
				FROM `{$this->tbl_offline_withdraw}` 
				WHERE status = ? AND batch = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('is', $status, $batch);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$id = $uid = $baid = $money = $fee = $cardno = $username = $bank_name = $city = $bank_sub = $order_id = $trans_id = $status = $curr_date = $created_time = $trans_response_time = $done_time = null;
		$stmt->bind_result( $id, $uid, $baid, $money, $fee, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $trans_id, $status, $curr_date, $created_time, $trans_response_time, $done_time );
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'uid' => $uid,
				'baid' => $baid,
				'money' => $money,
				'fee' => $fee,
				'cardno' => $cardno,
				'username' => $username,
				'bank_name' => $bank_name,
				'city' => $city,
				'bank_sub' => $bank_sub,
				'order_id' => $order_id,
				'trans_id' => $trans_id,
				'status' => $status,
				'curr_date' => $curr_date,
				'created_time' => $created_time,
				'trans_response_time' => $trans_response_time,
				'done_time' => $done_time
			);
		}
		$stmt->close();
		return $arr;
	}

	public function addOfflineWithdrawOrder( $uid, $baid, $money, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $fee ){
		if($money - $fee <= 0){
			return false;
		}
		$db = & $this->getDB();

		$sql_withdraw = "INSERT INTO `{$this->tbl_offline_withdraw}` SET uid = ?, baid = ?, money = ?, curr_date = ?, cardno = ?, username = ?, bank_name = ?, city = ?, bank_sub = ?, order_id = ?, fee = ?";

		$db->autocommit(false);
		
		$stmt = $db->prepare($sql_withdraw);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$curr_date = date('Y-m-d');
		$stmt->bind_param('sissssssssi', $uid, $baid, $money, $curr_date, $cardno, $username, $bank_name, $city, $bank_sub, $order_id, $fee);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$id = $stmt->insert_id;
		$stmt->close();
		
		$amount = $money * 100;//分 to 毫
		$res = $this->changeAccount($uid, $amount, USRACCOUNT_ACTION_OFFLINE_WITHDRAW, $baid, true);
		if(!$res){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $id;
	}

	public function offlineWithdrawOrderResponsedDone( $id, $wl_id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_withdraw}` SET status = ?, wl_id = ?, trans_response_time = NOW(), done_time = NOW() WHERE id = ? AND status NOT IN (?, ?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status_done = WITHDRAW_STATUS_DONE;
		$status_rollback = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$stmt->bind_param('iiiii', $status_done, $wl_id, $id, $status_done, $status_rollback);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function offlineWithdrawOrderResponsedFailed( $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_withdraw}` SET status = ?, trans_response_time = NOW(), done_time = NOW() WHERE id = ? AND status NOT IN (?, ?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status_done = WITHDRAW_STATUS_DONE;
		$status_rollback = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$stmt->bind_param('iiii', $status_rollback, $id, $status_done, $status_rollback);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function offlineWithdrawOrderRollbacked( $id, $uid, $amount, $baid ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_withdraw}` SET status = ?, done_time = NOW() WHERE id = ? AND status NOT IN (?, ?)";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$db->autocommit(false);
		$ex_status = WITHDRAW_STATUS_DONE;
		$ex_status2 = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$status = WITHDRAW_STATUS_ACCOUNT_ROLLBACK;
		$stmt->bind_param('iiii', $status, $id, $ex_status, $ex_status2);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();			
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		$amount = $amount * 100;// 分 to 毫
		$bool = $this->changeAccount($uid, $amount, USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK, $baid, true);
		if(!$bool){
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return $bool;
	}

	public function offlineWithdrawOrderDone( $id ){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_offline_withdraw}` SET status = ?, done_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = WITHDRAW_STATUS_DONE;
		$stmt->bind_param('ii', $status, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}


/*======OFFLINE WITHDRAW END======*/

	public function regAccount($uid){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_account}` SET uid = ?, amount = 0, total_amount = 0, total_interest = 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function updateAccountNormal($uid){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_account}` SET status = ?, modified_time = NOW() WHERE uid = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = USRACCOUNT_STATUS_EGG;
		$status_new = USRACCOUNT_STATUS_NORMAL;
		$stmt->bind_param('isi', $status_new ,$uid, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function updateAccountOffline($uid){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_account}` SET status = ?, modified_time = NOW() WHERE uid = ? AND status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = USRACCOUNT_STATUS_EGG;
		$status_new = USRACCOUNT_STATUS_OFFLINE;
		$stmt->bind_param('isi', $status_new ,$uid, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function regAccountEgg($uid){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_account}` SET uid = ?, status = ?, amount = 0, total_amount = 0, total_interest = 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = USRACCOUNT_STATUS_EGG;
		$stmt->bind_param('si', $uid, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function regAccountOffline($uid){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_account}` SET uid = ?, amount = 0, total_amount = 0, total_interest = 0, status = " . USRACCOUNT_STATUS_OFFLINE;
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function regBankAccount($uid, $idtype, $bank, $cardno, $realname, $identcode, $mobile, $key_mobile, $key_cardno, $key_identcode){
		$db = & $this->getDB();
		$account = $this->getUserCurrentBankAccount( $uid );
		if(!empty($account)){
			stored_messages(getlang('account.bankcardexists'));
			return false;
		}
		$sql = "INSERT INTO `{$this->tbl_bank}` SET uid = ?, idtype = ?, bank = ?, cardno = ?, realname = ?, identcode = ?, mobile = ?, key_mobile = ?, key_cardno = ?, key_identcode = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sissssssss', $uid, $idtype, $bank, $cardno, $realname, $identcode, $mobile, $key_mobile, $key_cardno, $key_identcode);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function regBankAccountVerify($uid, $idtype, $bank, $cardno, $realname, $identcode, $mobile){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_bank_verify}` SET uid = ?, idtype = ?, bank = ?, cardno = ?, realname = ?, identcode = ?, mobile = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sisssss', $uid, $idtype, $bank, $cardno, $realname, $identcode, $mobile);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			return false;
		}
		$last_id = $stmt->insert_id;
		$stmt->close();
		return $last_id;
	}

	public function removeBankAccount($uid, $id){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_bank}` SET status = ?, modified_time = NOW() WHERE uid = ? and id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$status = USRBANKACC_STATUS_REMOVED;
		$stmt->bind_param('iss', $status, $uid, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function changeBankAccountStatus($id, $status){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_bank}` SET status = ?, modified_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('is', $status, $id);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
		}
		$stmt->close();
		return $bool;
	}

	public function batchChangeBankAccountStatus($status, $id_arr){
		$db = & $this->getDB();

		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($id_arr);
		$sql = sprintf("UPDATE `{$this->tbl_bank}` SET status = %d, modified_time = NOW() WHERE id in (%s)", $status, $id_str);
		$bool = $db->query($sql);
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $db->error);
		}
		return $bool;
	}

	/**
	 * 支付邀请者利息收益
	 * 调用函数已经废弃，这个函数也相应的废弃了
	 * @deprecated
	 * @param $id 邀请记录ID
	 * @param $uid 邀请者用户ID，如果是一级邀请，那么就是本条邀请记录的邀请者ID，如果是二级邀请，那么是邀请者的邀请者
	 */
	public function payUsersRelInterest( $id, $uid, $amount){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_users_rel}` SET invite_interest_status = ?, modified_time = NOW() WHERE id = ? AND invite_interest_status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$db->autocommit(false);
		$status = INVITE_STATUS_PENDING;
		$status_new = INVITE_STATUS_DONE;
		$stmt->bind_param('isi', $status_new, $id, $status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			// 2017-12-15 stmt close
			$stmt->close();						
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		if($amount>0){
			$bool = $this->changeAccount($uid, $amount, USRACCOUNT_ACTION_INVITE_INTEREST, SYSACCOUNT_INVITE_INTEREST, true);
			if(!$bool){
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
		}
		$db->commit();
		$db->autocommit(true);
		return true;
	}

	/**
	 * 根据被邀请者用户ID获取记录信息
	 * 
	 * @param $uid 被邀请者用户ID
	 */
	public function getUserRel($uid){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_users_rel}` WHERE invitee = %d", $uid);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getInviteeBindCard($start_time, $end_time){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_users_rel}` WHERE created_time >= '%s' AND created_time <= '%s' AND bind_card_time IS NOT NULL AND bind_card_award_invitee IS NULL LIMIT 30", date('Y-m-d H:i:s', strtotime($start_time)), date('Y-m-d H:i:s', strtotime($end_time)));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getInviterBuyLong($start_time, $end_time){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_users_rel}` WHERE created_time >= '%s' AND created_time <= '%s' AND buy_long_time IS NOT NULL AND buy_long_award_inviter IS NULL LIMIT 30", date('Y-m-d H:i:s', strtotime($start_time)), date('Y-m-d H:i:s', strtotime($end_time)));
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function setUserRelBindCardTime($uid){
		$db = & $this->getDB();
		$sql = sprintf("UPDATE `{$this->tbl_users_rel}` SET bind_card_time = NOW() WHERE invitee = %d", $uid);
		$bool = $db->query($sql);
		if(!$bool){
			$this->logerror(__METHOD__, "$db->error $uid", __LINE__);
		}
		return $bool;
	}

	public function setUserRelBuyLongTime($uid){
		$db = & $this->getDB();
		$sql = sprintf("UPDATE `{$this->tbl_users_rel}` SET buy_long_time = NOW() WHERE invitee = %d", $uid);
		$bool = $db->query($sql);
		if(!$bool){
			$this->logerror(__METHOD__, "$db->error $uid", __LINE__);
		}
		return $bool;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 支付邀请者奖励
     *
	 * @param $ibr_id 邀请支付（inviter_bonus_repayment）记录ID
	 * @param $invitee 被邀请者用户ID
	 * @param $invitee_interest 被邀请者利息
	 * @param $inviter 邀请者用户ID
	 * @param $inviter_bonus 邀请者用户奖励
	 * @param $l2_inviter 二级邀请者用户ID
	 * @param $l2_inviter_bonus 二级邀请者用户奖励
	 */
	public function payInviterBonus($ibr_id, $invitee, $invitee_interest, $inviter , $inviter_bonus, $l2_inviter , $l2_inviter_bonus){
		$db = & $this->getDB();
		// 更新邀请者奖励支付表状态
		$sql = "UPDATE `{$this->tbl_inviter_bonus_repayment}` 
			SET bonus_status = ?, finish_time = NOW() WHERE id = ? AND bonus_status = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed', __LINE__);
			return false;
		}
		$db->autocommit(false);

		$old_status = INVITER_BONUS_REPAYMENT_STATUS_NORMAL;
		$new_status = INVITER_BONUS_REPAYMENT_STATUS_PAID;
		$stmt->bind_param('isi', $new_status, $ibr_id, $old_status);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();	
			$db->autocommit(true);
			return false;
		}
		$stmt->close();	
		// 更新邀请记录中信息
		$sql = "UPDATE `{$this->tbl_users_rel}` 
			SET  invite_interest = invite_interest+?,l2_invite_interest = l2_invite_interest+?, modified_time = NOW() 
			WHERE invitee = ? ";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed : $sql",__LINE__);
			$db->rollback();
			$db->autocommit(true);
			return false;
		}			
		$stmt->bind_param('sss', $inviter_bonus, $l2_inviter_bonus, $invitee);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : "ibr_id:{$ibr_id},invitee:{$invitee}";
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();		
		// 支付邀请者奖励	
		if($inviter_bonus>0){
			$bool = $this->changeAccount2($inviter, $inviter_bonus, USRACCOUNT_ACTION_INVITE_INTEREST, SYSACCOUNT_INVITE_INTEREST, $ibr_id, $ibr_id,true);
			if(!$bool){
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
		}
		// 支付二级邀请者奖励	
		if($l2_inviter_bonus>0){
			$bool = $this->changeAccount2($l2_inviter, $l2_inviter_bonus, USRACCOUNT_ACTION_INVITE_INTEREST, SYSACCOUNT_INVITE_INTEREST, $ibr_id,$ibr_id,true);
			if(!$bool){
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
		}
		
		$db->commit();
		$db->autocommit(true);
		return true;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 设置支付邀请者奖励失败
     *
	 * @param $failed_ids 支付失败的记录ID数组
	 */
	public function setPayInviterBonusFailed($failed_ids){
		$db = & $this->getDB();
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($failed_ids);
		$new_status = INVITER_BONUS_REPAYMENT_STATUS_FAILED;
		$old_status = INVITER_BONUS_REPAYMENT_STATUS_NORMAL;
		$sql = "UPDATE `{$this->tbl_inviter_bonus_repayment}` 
				SET bonus_status = {$new_status}, finish_time = NOW() WHERE bonus_status = {$old_status} AND id IN ($id_str)"; 
		return $db->query($sql);
	}

	public function setAmountShiftOn($uid){
		$db = & $this->getDB();
		$sql = sprintf("UPDATE `{$this->tbl_account}` SET amount_shift = 1, modified_time = NOW() WHERE uid = %d", $uid);
		$bool = $db->query($sql);
		if(!$bool){
			$this->logerror(__METHOD__, "$db->error $uid", __LINE__);
		}
		return $bool;
	}

	public function setAmountShiftOff($uid){
		$db = & $this->getDB();
		$sql = sprintf("UPDATE `{$this->tbl_account}` SET amount_shift = 0, modified_time = NOW() WHERE uid = %d", $uid);
		$bool = $db->query($sql);
		if(!$bool){
			$this->logerror(__METHOD__, "$db->error $uid", __LINE__);
		}
		return $bool;
	}

	public function addUserAmount($uid, $amount, $action){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? and ? > 0";
		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, uid) SELECT ?, amount, amount + ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$db->autocommit(false);
		$error = 0;
		$line = __LINE__;
		do{
			$stmt = $db->prepare($sql_acc_log);
			if(!$stmt){
				$line = __LINE__;
				$error = 'sql_acc_log prepare failed';
				break;
			}
			$stmt->bind_param('ssis', $amount, $amount, $action, $uid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$line = __LINE__;
				$error = $stmt->error;
				// 2017-12-15 stmt close
				$stmt->close();			
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql);
			if(!$stmt){
				$line = __LINE__;
				$error = 'sql1 prepare failed';
				break;
			}
			$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$line = __LINE__;
				$error = $stmt->error;
				// 2017-12-15 stmt close
				$stmt->close();						
				break;
			}
			$stmt->close();
			$bool = $db->commit();
		}while( false );
		
		if($error !== 0){
			$this->logerror(__METHOD__, $error, $line);
			$db->rollback();
		}
		$db->autocommit(true);
		return true;

	}

	public function addUserAmountByRelAward($id, $uid, $amount, $action, $type){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? and ? > 0";
		switch ($type) {
			case 'bind_card_award_invitee':
			case 'buy_long_award_inviter':
				break;
			default:
				return 'err type';
		}
		$sql_rel = "UPDATE `{$this->tbl_users_rel}` SET $type = ?, modified_time = NOW() WHERE id = ? and $type IS NULL";

		$sql_acc_log = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, uid) SELECT ?, amount, amount + ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$db->autocommit(false);
		$error = 0;
		$line = __LINE__;
		do{

			$stmt = $db->prepare($sql_rel);
			if(!$stmt){
				$line = __LINE__;
				$error = 'sql_rel prepare failed';
				break;
			}
			$stmt->bind_param('ss', $amount, $id);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$line = __LINE__;
				$error = $stmt->error;
				// 2017-12-15 stmt close
				$stmt->close();						
				break;
			}

			$stmt = $db->prepare($sql_acc_log);
			if(!$stmt){
				$line = __LINE__;
				$error = 'sql_acc_log prepare failed';
				break;
			}
			$stmt->bind_param('ssis', $amount, $amount, $action, $uid);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$line = __LINE__;
				$error = $stmt->error;
				// 2017-12-15 stmt close
				$stmt->close();						
				break;
			}
			$stmt->close();

			$stmt = $db->prepare($sql);
			if(!$stmt){
				$line = __LINE__;
				$error = 'sql prepare failed';
				break;
			}
			$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
			$bool = $stmt->execute();
			if(!$bool || !$stmt->affected_rows){
				$line = __LINE__;
				$error = $stmt->error;
				// 2017-12-15 stmt close
				$stmt->close();						
				break;
			}

			$stmt->close();
			$bool = $db->commit();
		}while( false );
		$bool = true;
		if($error !== 0){
			$this->logerror(__METHOD__, $error, $line);
			$db->rollback();
			$bool = false;
		}
		$db->autocommit(true);
		return $bool;

	}

	public function changeAccount($uid, $amount, $action, $bank_account_id, $not_commit = false){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql1 = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? and ? > 0";
		$sql2 = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, total_amount = total_amount - ?, modified_time = NOW() WHERE uid = ? and amount >= ?";
		$sql_acc_log_1 = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, bank_account_id, uid) SELECT ?, amount, amount + ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$sql_acc_log_2 = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, bank_account_id, uid) SELECT ?, amount, amount - ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		if($action == USRACCOUNT_ACTION_RECHARGE || $action == USRACCOUNT_ACTION_OBSELL || $action == USRACCOUNT_ACTION_WITHDRAW_ROLLBACK || $action == USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK || $action == USRACCOUNT_ACTION_INVITE_INTEREST || $action == USRACCOUNT_ACTION_WITHDRAW_TUIPIAO_ROLLBACK ){
			$sql = $sql1;
			$sql_acc_log = $sql_acc_log_1;
		}elseif($action == USRACCOUNT_ACTION_WITHDRAW || $action == USRACCOUNT_ACTION_OFFLINE_WITHDRAW || $action == USRACCOUNT_ACTION_OBBUY){
			$sql = $sql2;
			$sql_acc_log = $sql_acc_log_2;
		}else{
			return false;
		}
		if(!$not_commit){
			$db->autocommit(false);
		}

		$stmt = $db->prepare($sql_acc_log);
		if(!$stmt){
			$db->rollback();
			$this->logerror(__METHOD__, 'sql_acc_log prepare failed');
			if(!$not_commit){
				$db->autocommit(true);
			}
			return false;
		}
		$stmt->bind_param('ssiss', $amount, $amount, $action, $bank_account_id, $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$db->rollback();
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			if(!$not_commit){
				$db->autocommit(true);
			}
			return false;
		}
		$stmt->close();
		

		$stmt = $db->prepare($sql);
		if(!$stmt){
			$db->rollback();
			$this->logerror(__METHOD__, 'sql1/2 prepare failed');
			return false;
		}
		$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$db->rollback();
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			if(!$not_commit){
				$db->autocommit(true);
			}
			return false;
		}
		$stmt->close();

		if($not_commit){
			return true;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return true;
	}

	public function changeAccount2($uid, $amount, $action, $bank_account_id, $act_id, $act_to_id,$not_commit = false){
		$db = & $this->getDB();
		$amount = abs($amount);
		$sql1 = "UPDATE `{$this->tbl_account}` SET amount = amount + ?, total_amount = total_amount + ?, modified_time = NOW() WHERE uid = ? and ? > 0";
		$sql2 = "UPDATE `{$this->tbl_account}` SET amount = amount - ?, total_amount = total_amount - ?, modified_time = NOW() WHERE uid = ? and amount >= ?";
		$sql_acc_log_1 = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, bank_account_id, act_id, act_to_id, uid) SELECT ?, amount, amount + ?, ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";
		$sql_acc_log_2 = "INSERT INTO `{$this->tbl_account_log}`(amount_change, amount_before, amount_after, action, bank_account_id, act_id, act_to_id, uid) SELECT ?, amount, amount - ?, ?, ?, ?, ?, uid FROM `{$this->tbl_account}` WHERE uid = ?";

		if($action == USRACCOUNT_ACTION_RECHARGE || $action == USRACCOUNT_ACTION_OBSELL || $action == USRACCOUNT_ACTION_WITHDRAW_ROLLBACK || $action == USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK || $action == USRACCOUNT_ACTION_INVITE_INTEREST || $action == USRACCOUNT_ACTION_WITHDRAW_TUIPIAO_ROLLBACK ){
			$sql = $sql1;
			$sql_acc_log = $sql_acc_log_1;
		}elseif($action == USRACCOUNT_ACTION_WITHDRAW || $action == USRACCOUNT_ACTION_OFFLINE_WITHDRAW || $action == USRACCOUNT_ACTION_OBBUY){
			$sql = $sql2;
			$sql_acc_log = $sql_acc_log_2;
		}else{
			return false;
		}
		if(!$not_commit){
			$db->autocommit(false);
		}

		$stmt = $db->prepare($sql_acc_log);
		if(!$stmt){
			$db->rollback();
			$this->logerror(__METHOD__, 'sql_acc_log prepare failed');
			if(!$not_commit){
				$db->autocommit(true);
			}
			return false;
		}
		$stmt->bind_param('ssissss', $amount, $amount, $action, $bank_account_id,$act_id,$act_to_id, $uid);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$db->rollback();
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			if(!$not_commit){
				$db->autocommit(true);
			}
			return false;
		}
		$stmt->close();
		

		$stmt = $db->prepare($sql);
		if(!$stmt){
			$db->rollback();
			$this->logerror(__METHOD__, 'sql1/2 prepare failed');
			return false;
		}
		$stmt->bind_param('ssss', $amount, $amount, $uid, $amount);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$db->rollback();
			$this->logerror(__METHOD__, $stmt->error, __LINE__);
			$stmt->close();
			if(!$not_commit){
				$db->autocommit(true);
			}
			return false;
		}
		$stmt->close();

		if($not_commit){
			return true;
		}
		$bool = $db->commit();
		$db->autocommit(true);
		return true;
	}	

	/**
	 * 2018-03-07
	 * 得到用户其他奖励金额，合计值，目前包括签到、返拥和活动奖励
	 */
	public function getUserOtherAmount($uid){
		$result = array('total_invite'=>0,'total_award'=>0,'total_sign'=>0,'total_other'=>0);
		$db = & $this->getReadonlyDB();
		$invite_action = USRACCOUNT_ACTION_INVITE_INTEREST;
		$award_action = USRACCOUNT_ACTION_AWARD;
		$sign_action = USRACCOUNT_ACTION_SIGN_BONUS;
		$sql = " SELECT SUM( CASE action WHEN {$invite_action} THEN amount_change END) as total_invite,
						SUM( CASE action WHEN {$award_action} THEN amount_change END) as total_award,
						SUM( CASE action WHEN {$sign_action} THEN amount_change END) as total_sign, 
						SUM(amount_change) as total_other 
						FROM {$this->tbl_account_log}
						WHERE uid = {$uid} AND action in($invite_action,$award_action,$sign_action)";
		$query_result = $db->query($sql);
		if(!$query_result){
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return $result;
		}
		$row = $query_result->fetch_assoc();
		$query_result->free();
		if(empty($row)){
			return $result;
		}
		$result['total_invite'] = $row['total_invite'];
		$result['total_award'] = $row['total_award'];
		$result['total_sign'] = $row['total_sign'];
		$result['total_other'] = $row['total_other'];
		return $result;
	} 
}