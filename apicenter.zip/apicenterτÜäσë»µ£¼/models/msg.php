<?php
require_once PATH_BASE_MODEL;

class MsgModel extends Model{

	protected $tbl_msg = 'msg_list';
	
	protected $tbl_push = 'push_list';

	protected $tbl_device = 'devicetoken';

	public function __construct(){
		parent::__construct();
	}

	public function addMsg($uid, $content){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_msg}` SET uid = ?, content = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $uid, $content);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	public function getMsgList($uid, $limit, $last_id = null, $old = false){
		$db = & $this->getReadonlyDB();
		if($last_id){
			if($old){
				$sql = sprintf("SELECT id,uid,content,created_time FROM `{$this->tbl_msg}` WHERE uid = %d AND id < %d ORDER BY id DESC LIMIT %d", $uid, $last_id, $limit);
			}else{
				$sql = sprintf("SELECT id,uid,content,created_time FROM `{$this->tbl_msg}` WHERE uid = %d AND id > %d ORDER BY id DESC LIMIT %d", $uid, $last_id, $limit);
			}
		}else{
			$sql = sprintf("SELECT id,uid,content,created_time FROM `{$this->tbl_msg}` WHERE uid = %d ORDER BY id DESC LIMIT %d", $uid, $limit);
		}
		$result = $db->query($sql);		
		$arr = array();
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return $arr;
		}				
		while ($row = $result->fetch_assoc()) {
			$arr[] = $row;
		}
		$result->free();
		return $arr;
	}
	/**
	 * 获取批量消息
	 */
	public function getMsgBatch($limit, $last_id = null){
		$db = & $this->getReadonlyDB();
		// 2017-11-23 BUG FIX
		// 如果取$last_id之后的$limit个元素，不应该倒序排，否则从上次取到本次获取，如果消息增加的个数大于$limit，那么会丢失数据
		if($last_id){
			$sql = sprintf("SELECT id,uid,content,created_time FROM `{$this->tbl_msg}` WHERE id > %d ORDER BY id ASC LIMIT %d", $last_id, $limit);
		}else{
			$sql = sprintf("SELECT id,uid,content,created_time FROM `{$this->tbl_msg}` ORDER BY id ASC LIMIT %d", $limit);
		}
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return array();
		}		
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getPushLastRow(){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT * FROM `{$this->tbl_push}` ORDER BY mid DESC LIMIT 1";
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}				
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 * 2018-08-23,69豪车整合
	 * 增加app请求参数，兼容原请求
	 */
	public function addPush($title, $content, $devtoken, $device, $platform, $uid = null, $mid = null, $tag = null, $app = APP_DEFAULT){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_push}` SET uid = ?, app = ?, plantform = ?, title = ?, content = ?, token = ?, device = ?, mid = ?, tag = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sssssssss', $uid, $app, $platform, $title, $content, $devtoken, $device, $mid, $tag);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $stmt->insert_id;
		$stmt->close();
		return $id;
	}

	/**
	 * 2018-08-23,69豪车整合
	 * 增加app请求参数，兼容原请求
	 */
	public function getPushList($limit, $app=APP_DEFAULT){
		$db = & $this->getReadonlyDB();
		$status = APP_PUSH_STATUS_NORMAL;
		$sql = sprintf("SELECT * FROM `{$this->tbl_push}` WHERE status = %d and app = '%s' LIMIT %d", $status, $app, $limit);
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return array();
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	public function getPushDetail($id){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_push}` WHERE id = %d ", $id);
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}						
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function setPushSent($id){
		$db = & $this->getDB();
		$status = APP_PUSH_STATUS_SENT;
		$sql = sprintf("UPDATE `{$this->tbl_push}` SET status = %d, sent_time = NOW() WHERE id = %d", $status, $id);
		return $db->query($sql);
	}

	public function setPushFailed($id){
		$db = & $this->getDB();
		$status = APP_PUSH_STATUS_FAILED;
		$sql = sprintf("UPDATE `{$this->tbl_push}` SET status = %d, sent_time = NOW() WHERE id = %d", $status, $id);
		return $db->query($sql);
	}

	public function setPushSentArr($id_arr){
		$db = & $this->getDB();
		$status = APP_PUSH_STATUS_SENT;
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($id_arr);
		$sql = sprintf("UPDATE `{$this->tbl_push}` SET status = %d, sent_time = NOW() WHERE id in (%s)", $status, $id_str);
		return $db->query($sql);
	}

	public function setPushFailedArr($id_arr){
		$db = & $this->getDB();
		$status = APP_PUSH_STATUS_FAILED;
		$helper = load_helper('model');
		$id_str = $helper::idarr_to_string($id_arr);
		$sql = sprintf("UPDATE `{$this->tbl_push}` SET status = %d, sent_time = NOW() WHERE id in (%s)", $status, $id_str);
		return $db->query($sql);
	}

	public function setPushClicked($id, $device){
		$db = & $this->getDB();
		$status = APP_PUSH_STATUS_CLICKED;
		$sql = sprintf("UPDATE `{$this->tbl_push}` SET status = %d, clicked_time = NOW() WHERE id = %d AND device = '%s'", $status, $id, addslashes($device));
		return $db->query($sql);
	}
	
	public function getiOSPushPropByTag($tag = null){
		$prop = array(
			'url' => APP_INNERVIEW_RECOMMEND,
			'badge' => 1,
			'method' => APP_VIEW_METHOD_INNERVIEW,
			'sound' => APP_PUSH_SOUND_NORMAL,
			'type' => APP_PUSH_TYPE_NORMAL
		);
		return $prop;
	}
}