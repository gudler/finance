<?php
require_once PATH_BASE_MODEL;

class NoticeModel extends Model{

	protected $tbl_notice = 'notice_list';

	public function __construct(){
		parent::__construct();
	}
	/**
	 * 添加系统公告
	 */
	public function addNotice($title, $content, $show_begin_time, $show_end_time){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_notice}` SET title = ?, content = ?, show_begin_time = ?, show_end_time = ?";
		$smt = null;
		$last_id = 0;
		do {
			$stmt = $db->prepare($sql);
			if(empty($stmt)){
				$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
				break;
			}
			$stmt->bind_param('ssss', $title, $content, $show_begin_time, $show_end_time);
			$bool = $stmt->execute();
			if(!$bool){
				$this->logerror(__METHOD__, 'execute failed: ' . $stmt->error);
				break;
			}
			$last_id = $stmt->insert_id;
		} while(false);
		if ($stmt) {
			$stmt->close();
			$stmt = null;
		}
		return $last_id;
	}

	/**
	 * 更新系统公告
	 */
	public function updateNotice($id, $title, $content, $show_begin_time, $show_end_time){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_notice}` SET title = ?, content = ?, show_begin_time = ?, show_end_time = ? WHERE id = ?";
		$smt = null;
		$last_id = 0;
		do {
			$stmt = $db->prepare($sql);
			if(empty($stmt)){
				$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
				break;
			}
			$stmt->bind_param('sssss', $title, $content, $show_begin_time, $show_end_time, $id);
			$bool = $stmt->execute();
			if(!$bool){
				$this->logerror(__METHOD__, 'execute failed: ' . $stmt->error);
				break;
			}
			$last_id = $stmt->insert_id;
		} while(false);
		if ($stmt) {
			$stmt->close();
			$stmt = null;
		}
		return $last_id;
	}

	/**
	 * 更新系统公告
	 */
	public function updateNoticeDeleted($id,$deleted){
		$db = & $this->getDB();
		$deleted = intval($deleted);
		if ($deleted!=0) {
			$deleted = 1;
		}
		$sql = "UPDATE `{$this->tbl_notice}` SET deleted = ? WHERE id = ?";
		$smt = null;
		$last_id = 0;
		do {
			$stmt = $db->prepare($sql);
			if(empty($stmt)){
				$this->logerror(__METHOD__, "prepare failed: errno:{$db->errno},error:{$db->error}.");												
				break;
			}
			$stmt->bind_param('is', $deleted, $id);
			$bool = $stmt->execute();
			if(!$bool){
				$this->logerror(__METHOD__, 'execute failed: ' . $stmt->error);
				break;
			}
			$last_id = $stmt->insert_id;
		} while(false);
		if ($stmt) {
			$stmt->close();
			$stmt = null;
		}
		return $last_id;
	}	

	public function getNoticeDetail($id) {
		$db = & $this->getReadonlyDB();
		$id = intval($id);
		$sql = "SELECT id,title,content,show_begin_time,show_end_time,deleted,created_time,modified_time 
				FROM `{$this->tbl_notice}` WHERE id = {$id} ";
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed(id={$id}): errno:{$db->errno},error:{$db->error}.");												
			return false;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;		
	}

	/**
	 * 获取当前显示公告列表，特别提示：当前显示的公告一般只有几条
	 */
	public function getCurrentNoticeList($current_time=null,$limit=10) {
		$db = & $this->getReadonlyDB();
		$time = strtotime($current_time);
		$current_time = date("Y-m-d H:i:s",$time);		
		$limit = intval($limit);
		$sql = "SELECT id,title,created_time FROM `{$this->tbl_notice}` 
				WHERE deleted = 0  AND show_begin_time <= '{$current_time}' AND show_end_time >= '{$current_time}' 
				ORDER BY id DESC LIMIT {$limit}";
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed(current_time={$current_time}): errno:{$db->errno},error:{$db->error}.");												
			return false;
		}		
		$rows = array();
		while ($row = $result->fetch_assoc()) {
			$rows[] = $row;
		}
		$result->free();
		return $rows;
	}
	/**
	 * 获取公告总数
	 */
	public function getNoticeCount($with_deleted=false) {
		$db = & $this->getReadonlyDB();
		$sql = "SELECT COUNT(id) AS total FROM `{$this->tbl_notice}`";
		if (!$with_deleted) {
			$sql .= ' WHERE deleted = 0';
		}
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");												
			return 0;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if (isset($row['total'])) {
			return $row['total'];		
		} else {
			$this->logerror(__METHOD__, "no result.");												
			return 0;			
		}
	}
	/**
	 * 按页获取公告列表
	 */
	public function getNoticeList($page, $page_size, $with_deleted=0){
		$db = & $this->getReadonlyDB();
		$page = intval($page);
		$page_size = intval($page_size);
		$start = $page * $page_size;
		$sql = "SELECT id,title,created_time,modified_time,deleted FROM `{$this->tbl_notice}` ";
		if (!$with_deleted) {
			$sql .= " WHERE deleted = 0";
		}
		$sql .= " ORDER BY id DESC LIMIT {$start}, {$page_size}";
		$result = $db->query($sql);
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed(current_time={$current_time}): errno:{$db->errno},error:{$db->error}.");												
			return false;
		}		
		$rows = array();
		while ($row = $result->fetch_assoc()) {
			$rows[] = $row;
		}
		$result->free();
		return $rows;
	}

}