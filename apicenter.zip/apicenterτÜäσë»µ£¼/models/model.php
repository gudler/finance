<?php

class Model{

	private static $db;

	private static $db_readonly;

	private static $memcached;

	private static $is_memcached = null;

	private static $db_reconnect_errors = array(
		2006,//CR_SERVER_GONE_ERROR,
		2008,//CR_OUT_OF_MEMORY,
		2013,//CR_SERVER_LOST,
		2048,//CR_INVALID_CONN_HANDLE,
		2055,//CR_SERVER_LOST_EXTENDED
	);

	public function __construct(){
		
	}

	public function getMapKey($key){
		return 'a' . $key;
	}

	public function memGet($key){
		$mem = & $this->getMemcached();
		if(!$mem){
			return null;
		}
		return $mem->get( $key );
	}

	public function memSet($key, $data, $timeout = 60){
		$mem = & $this->getMemcached();
		if(!$mem){
			return null;
		}
		if(self::$is_memcached){
			$res = $mem->set($key, $data, $timeout);
		}else{
			$res = $mem->set($key, $data, 0, $timeout);
		}
		return $res;
	}

	public function memDel($key, $time = 0){
		$mem = & $this->getMemcached();
		if(!$mem){
			return null;
		}
		if(self::$is_memcached){
			$res = $mem->delete($key, $time);
		}else{
			$res = $mem->delete($key, $time);
		}
		return $res;
	}

	public function memInc($key, $value = 1){
		$mem = & $this->getMemcached();
		if(!$mem){
			return null;
		}
		if(self::$is_memcached){
			$res = $mem->increment($key, $value);
		}else{
			$res = $mem->increment($key, $value);
		}
		return $res;
	}

	public function memDec($key, $value = 1){
		$mem = & $this->getMemcached();
		if(!$mem){
			return null;
		}
		if(self::$is_memcached){
			$res = $mem->decrement($key, $value);
		}else{
			$res = $mem->decrement($key, $value);
		}
		return $res;
	}

	protected function needToReconnectDB($db){
		return in_array($db->errno,self::$db_reconnect_errors);
	}

	private function &connectDB(){
		$cnfs = config_item('mysql');
		$cnf = $cnfs['writable'];
		$db = new mysqli($cnf['host'], $cnf['user'], $cnf['passwd'], $cnf['dbname']);
		if (mysqli_connect_errno()) {
			$db = null;
			echo 'Database connect failed.';
			return $db;
		}
		if(isset($cnf['charset']) && $cnf['charset']){
			$db->set_charset($cnf['charset']);
		}
		return $db;
	}

	private function &connectReadonlyDB(){
		$cnfs = config_item('mysql');
		$cnfs = $cnfs['readonly'];
		$db = null;
		$weight_total = 0;
		$weight_arr = array();
		foreach ($cnfs as $idx => $cnf) {
			$weight = $cnf['weight'];
			$weight = intval($weight);
			if($weight < 0){
				continue;
			}
			$weight = max(1, $weight);
			$weight_total += $weight;
			$weight_arr[$idx] = $weight_total;
		}
		if($weight_total<1){
			echo 'Database config file error.';
			return $db;
		}
		$needle = mt_rand(1,$weight_total);
		reset($weight_arr);
		do{
			$weight = current($weight_arr);
			$cnf = $cnfs[key($weight_arr)];
			if(false === next($weight_arr)){
				break;
			}
		}while ($needle>$weight);
		if(empty($cnf)){
			echo 'Database config file error.';
			return $db;
		}

		$db = new mysqli($cnf['host'], $cnf['user'], $cnf['passwd'], $cnf['dbname']);
		if (mysqli_connect_errno()) {
			echo 'Database connect failed.';
			$db = null;
			return $db;
		}
		if(isset($cnf['charset']) && $cnf['charset']){
			$db->set_charset($cnf['charset']);
		}
		return $db;
	}

	private function connectMemcached(){
		if(class_exists('Memcache')){
			$m = new Memcache();
			self::$is_memcached = false;
		}elseif(class_exists('Memcached')){
			$m = new Memcached();
			self::$is_memcached = true;
		}else{
			return false;
		}
		$cnfs = config_item('memcached');
		if(self::$is_memcached){
			$m->addServers($cnfs);
		}else{
			foreach($cnfs as $cnf){
				if($cnf && isset($cnf[0])){
					$m->addServer($cnf[0], isset($cnf[1]) ? $cnf[1] : null, null, isset($cnf[2]) ? $cnf[2] : null);
				}
			}
		}
		if($m){
			self::$memcached = & $m;
		}
	}

	protected function &getDB($create_new = false){
		if($create_new){
			return $this->connectDB();
		}
		if(is_null(self::$db)){
			self::$db = & $this->connectDB();
		} else {
			// 2018-02-27
			// 在任务调用里面，很多都是长时间执行，并且重用DB对象的，如果DB链接出现了问题，那么需要重新链接，防止一直错误下去。
			if ($this->needToReconnectDB(self::$db)) {
				self::$db->close();
				self::$db = null;
				self::$db = & $this->connectDB();
			}
		}
		return self::$db;
	}

	protected function &getReadonlyDB($create_new = false){
		if($create_new){
			return $this->connectReadonlyDB();
		}
		if(is_null(self::$db_readonly)){
			self::$db_readonly = & $this->connectReadonlyDB();
		} else {
			// 2018-02-27
			// 在任务调用里面，很多都是长时间执行，并且重用DB对象的，如果DB链接出现了问题，那么需要重新链接，防止一直错误下去。
			if ($this->needToReconnectDB(self::$db_readonly)) {
				self::$db_readonly->close();
				self::$db_readonly = null;
				self::$db_readonly = & $this->connectReadonlyDB();
			}
		}		
		return self::$db_readonly;
	}

	protected function &getMemcached(){
		if(is_null(self::$memcached)){
			$this->connectMemcached();
		}
		return self::$memcached;
	}

	protected function transaction_start(){
		$db = & $this->getDB();
		return $db->autocommit(false);
	}

	protected function transaction_commit(){
		$db = & $this->getDB();
		$bool = $db->commit();
		if(!$bool){
			$db->rollback();
		}
		$db->autocommit(true);
		return $bool;
	}

	protected function transaction_rollback(){
		$db = & $this->getDB();
		$bool = $db->rollback();
		$db->autocommit(true);
		return $bool;
	}

	protected function logerror($method, $msg, $line = 0){
		$filename = DIR_LOG . 'model_' . date('Y-m') . '.log';
		if($line>0){
			$line = sprintf("\tLine:%d", $line);
		}else{
			$line = "\t";
		}
		$data = sprintf("%s\t%s%s\t%s\n", date('Y-m-d H:i:s'), $method, $line, json_encode($msg));
		file_put_contents($filename, $data, FILE_APPEND);
	}

}