<?php
require_once PATH_BASE_MODEL;

class UserModel extends Model{

	protected $tbl_user = 'users';

	protected $tbl_users_rel = 'users_rel';

	protected $tbl_inviter_bonus_repayment = 'inviter_bonus_repayment';

	protected $tbl_info = 'userinfo';

	protected $tbl_token = 'logintoken';

	protected $tbl_device = 'devicetoken';

	protected $tbl_device_history = 'device_history';

	protected $tbl_token_history = 'token_history';

	public function __construct(){
		parent::__construct();
	}

	protected function getUser($type, $value){
		$db = & $this->getReadonlyDB();
		switch ($type) {
			case 'phone':
				$key = 'mobile';
				break;
			case 'id':
				$key = 'id';
				break;
			
			default:
				return false;
		}
		$sql = "SELECT id,mobile,passwd,pay_passwd,salt,freeze,have_loan,created_time FROM `{$this->tbl_user}` WHERE {$key} = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $value);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $mobile = $passwd = $pay_passwd = $salt = $freeze = $have_loan = $created_time = null;
		$stmt->bind_result($id, $mobile, $passwd, $pay_passwd, $salt, $freeze, $have_loan, $created_time);
		$stmt->fetch();
		$stmt->close();
		if(empty($id)){
			return null;
		}
		return array(
			'id' => $id,
			'mobile' => $mobile,
			'passwd' => $passwd,
			'pay_passwd' => $pay_passwd,
			'salt' => $salt,
			'freeze' => $freeze,
			'have_loan' => $have_loan,
			'created_time' => $created_time
		);
	}

	public function getUserByPhone($phone){
		return $this->getUser('phone', $phone);
	}

	public function getUserById($id){
		return $this->getUser('id', $id);
	}

	public function getUserInfoById($id){
		$db = & $this->getReadonlyDB();

		$sql = "SELECT sex,birthday,himg,realname,identcode,idtype,idverified FROM `{$this->tbl_info}` WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$sex = $birthday = $himg = $realname = $identcode = $idtype = $idverified = null;
		$stmt->bind_result($sex, $birthday, $himg, $realname, $identcode, $idtype, $idverified);
		$stmt->fetch();
		$stmt->close();
		if(null === $sex){
			return null;
		}
		return array('sex' => $sex
			, 'birthday' => $birthday
			, 'himg' => $himg
			, 'realname' => $realname
			, 'identcode' => $identcode
			, 'idtype' => $idtype
			, 'idverified' => $idverified
			);
	}

	public function setUserIdentityById($id, $idtype, $realname, $identcode){
		$db = & $this->getDB();

		$sql = "INSERT INTO `{$this->tbl_info}` SET idtype = ?, realname = ?, identcode = ?, id = ? ON DUPLICATE KEY UPDATE idtype = ?, realname = ?, identcode = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sssssss', $idtype, $realname, $identcode, $id, $idtype, $realname, $identcode);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function setUserInfoById($id, $sex, $birthday, $himg){
		$db = & $this->getDB();

		$sql = "INSERT INTO `{$this->tbl_info}` SET birthday = ?, sex = ?, himg = ?, id = ? ON DUPLICATE KEY UPDATE birthday = ?, sex = ?, himg = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sisssis', $birthday, $sex, $himg, $id, $birthday, $sex, $himg);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function createUser($phone){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_user}` SET mobile = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $phone);
		$bool = $stmt->execute();
		$id = null;
		if($bool){
			$id = $stmt->insert_id;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $id;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 创建邀请关系记录，同时插入二级邀请者
	 * 2017-11-22 VERIFIED
	 */
	public function createUsersRel($inviter, $invitee){
		$db = & $this->getDB();
		// 同时插入上上级的邀请者：l2_inviter
		$sql = "INSERT INTO `{$this->tbl_users_rel}` (inviter,invitee,l2_inviter) 
				SELECT ?, ?, b.inviter FROM `{$this->tbl_users_rel}`
				LEFT JOIN `{$this->tbl_users_rel}` b ON b.invitee = ? 
				LIMIT 1";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sss', $inviter, $invitee,$inviter);
		$bool = $stmt->execute();
		$id = null;
		if($bool){
			$id = $stmt->insert_id;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $id;
	}

	public function countUsersRel($inviter){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT count(id) FROM `{$this->tbl_users_rel}` WHERE inviter = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $inviter);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$count = null;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}

	public function createUserWithPasswd($phone, $passwd, $salt){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_user}` SET mobile = ?, passwd = ?, salt = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sss', $phone, $passwd, $salt);
		$bool = $stmt->execute();
		$id = null;
		if($bool){
			$id = $stmt->insert_id;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $id;
	}
	/**
	 * 2018-05-23 
	 * 支持同一用户多通道同时登录，一个通道还是只有一个登录
	 */
	public function getUserTokenById( $id, $device, $ip, $channel=0 ){
		$this->removeLoginCacheById($id, $channel);
		$token = sha1(uniqid('MT', true)) . substr(time(), 0, 10);
		$db = & $this->getDB();
		$sql = "REPLACE INTO `{$this->tbl_token}` SET id = ?, channel = ?, token = ?, device = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('siss', $id, $channel, $token, $device);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		if($bool){
			$this->addTokenHistory($token, $id, $device, $ip);
			return $token;
		}
		return null;
	}

	public function addTokenHistory( $token, $uid, $device, $ip ){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_token_history}` SET uid = ?, token = ?, device = ?, ip = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssss', $uid, $token, $device, $ip);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function removeDeviceToken( $uid){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_device}` SET deleted = 1, modified_time = NOW() WHERE uid = ? AND deleted = 0 ";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
			return false;
		}
		$stmt->close();
		return true;
	}
	/**
	 * 2018-08-23,69豪车整合
	 * 增加app参数，兼容原来调用
	 */
	public function addDeviceToken( $uid, $token, $platform, $device, $ip, $app = APP_DEFAULT ){
		$db = & $this->getDB();
		$sql = "REPLACE INTO `{$this->tbl_device}` SET uid = ?, app = ?, token = ?, plantform = ?, device = ?, deleted = 0, modified_time = NOW()";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sssss', $uid, $app, $token, $platform, $device);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		if($bool){
			$this->addDeviceTokenHistory($token, $uid, $platform, $device, $ip, $app);
			return $token;
		}
		return null;
	}
	/**
	 * 2018-08-23,69豪车整合
	 * 增加app参数，兼容原来调用
	 */
	public function addDeviceTokenHistory( $token, $uid, $platform, $device, $ip, $app = APP_DEFAULT ){
		$db = & $this->getDB();
		$sql = "INSERT INTO `{$this->tbl_device_history}` SET uid = ?, app = ?, token = ?, plantform = ?, device = ?, ip = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssssss', $uid, $app, $token, $platform, $device, $ip);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function getDeviceInfoByUid($uid){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_device}` WHERE uid = %d AND deleted = 0 ORDER BY created_time DESC LIMIT 1", $uid);
		$result = $db->query($sql);
		// 2018-04-04
		// 代码逻辑加强，需要判断SQL执行是否成功
		if ($result==false) {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
			return null;
		}						
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	public function getUserIdByToken($token){

		$info = $this->memGet($token);
		if(!empty($info)){
			$info = json_decode($info, true);
			if($info && isset($info['id']) && $info['id']){
				return $info;
			}
		}
		$db = & $this->getReadonlyDB();
		$sql = "SELECT id, device FROM `{$this->tbl_token}` WHERE token = ? and deleted = 0";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $token);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $device = null;
		$stmt->bind_result($id, $device);
		$stmt->fetch();
		$stmt->close();
		if(!$id){
			return null;
		}
		$info = array('id' => $id, 'device' => $device);
		$this->memSet($token, json_encode($info), 3*3600);
		return $info;
	}

	public function getHistoryInfoByToken($token){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT uid, device, created_time FROM `{$this->tbl_token_history}` WHERE token = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $token);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $device = $created_time = null;
		$stmt->bind_result($id, $device, $created_time);
		$stmt->fetch();
		$stmt->close();
		if(!$id){
			return null;
		}
		return array('id' => $id, 'device' => $device, 'created_time' => $created_time);
	}

	public function setUserPassword($id, $passwd, $salt, $phone = null){
		$db = & $this->getDB();
		if(empty($phone)){
			$sql = "UPDATE `{$this->tbl_user}` SET passwd = ?, salt = ? WHERE id = ?";
		}else{
			$sql = "UPDATE `{$this->tbl_user}` SET mobile = ?, passwd = ?, salt = ? WHERE id = ?";
		}
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		if(empty($phone)){
			$stmt->bind_param('sss', $passwd, $salt, $id);
		}else{
			$stmt->bind_param('ssss', $phone, $passwd, $salt, $id);
		}
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function setUserPayPassword($id, $pay_passwd){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_user}` SET pay_passwd = ? WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $pay_passwd, $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function setUserPhone($id, $phone){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_user}` SET mobile = ? WHERE id = ? and mobile is null";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $phone, $id);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

	public function changeUserPhone($id, $phone, $last_phone){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_user}` SET mobile = ? WHERE id = ? and mobile = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sss', $phone, $id, $last_phone);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}

    /*
     * 2018-11-07 更新用户其他联系手机号码
     */
    public function updateUserContact($mobile, $contact){
        $db = & $this->getDB();
        $sql = "UPDATE `{$this->tbl_user}` SET contact = ? WHERE mobile = ?";
        $stmt = $db->prepare($sql);
        if(!$stmt){
            $this->logerror(__METHOD__, 'prepare failed');
            return false;
        }
        $stmt->bind_param('ss', $contact, $mobile);
        $bool = $stmt->execute();
        if(!$bool){
            $this->logerror(__METHOD__, $stmt->error);
        }
        $stmt->close();
        return $bool;
    }

	public function setUserLogout($token){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_token}` SET deleted = 1 WHERE token = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		
		$stmt->bind_param('s', $token);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$this->memDel($token);
		$stmt->close();
		return $bool;
	}
	/**
	 * 设置用户登出，所有的通道全部登出，用于用户忘记登录密码的操作
	 */
	public function setUserLogoutByID($uid){
		$db = & $this->getDB();
		// 获取用户当前所有登录的token,然后从缓存中删除
		$sql = sprintf("SELECT token FROM `{$this->tbl_token}` WHERE id = %d AND deleted = 0", $uid);
		$result = $db->query($sql);
		if($result!=false){
			while ($row = $result->fetch_assoc()) {
				$this->memDel($row['token']);
			}
			$result->free();
		} else {
			$this->logerror(__METHOD__, "query failed: errno:{$db->errno},error:{$db->error}.");
		}
		// 更新用户token deleted标志
		$sql = "UPDATE `{$this->tbl_token}` SET deleted = 1 WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $uid);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $bool;
	}
	/*
	 * 2018-05-23
	 * 支持同一用户多通道同时登录，一个通道还是只有一个登录
	 */
	public function removeLoginCacheById($id, $channel=0){
		$db = & $this->getDB();
		$sql = sprintf("SELECT * FROM `{$this->tbl_token}` WHERE id = %d AND channel = %d", $id, $channel);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->close();
		if(!isset($row['token']) || empty($row['token'])){
			return true;
		}
		$token = $row['token'];
		return $this->memDel($token);
	}

/*======邀请获利计算================================================================================================================*/

	/**
	 * 2017-11-15 新邀请 DONE
	 * 计算邀请者的邀请数目
	 * 2017-11-22 VERIFIED
	 * 
	 * @param $inviter 邀请者用户ID
	 * @param $is_done 邀请利息是否已经支付
	 */
	public function countUsersRelInterest($inviter, $is_done){
		$db = & $this->getReadonlyDB();
		$ext = '';
		if($is_done){
			$ext = 'AND invite_interest > 0';
		}else{
			$ext = 'AND invite_unpaid_interest >0';
		}
		$sql = "SELECT count(id) FROM `{$this->tbl_users_rel}` WHERE inviter = ? $ext";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $inviter);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$count = null;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}
	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取邀请者合计信息
	 * 兼容老的APP接口
	 * 2017-11-22 VERIFIED
	 */
	public function sumUsersRelInterest($inviter){
		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT count(*) as number, sum(invite_interest) as interest, sum(invite_unpaid_interest) as unpaid_interest 
			FROM `{$this->tbl_users_rel}` WHERE inviter = %d", $inviter);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		return $row;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取邀请者的邀请统计信息
	 * 2017-11-22 VERIFIED
	 * 
	 */
	public function sumUsersRelInterest2($inviter){

		$db = & $this->getReadonlyDB();
		$sql = sprintf("SELECT count(*) as number, sum(invite_interest) as interest, sum(invite_unpaid_interest) as unpaid_interest 
			FROM `{$this->tbl_users_rel}` WHERE inviter = %d", $inviter);
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if ($row) {
			$sql = sprintf("SELECT count(*) as l2_number, sum(l2_invite_interest) as l2_interest, sum(l2_invite_unpaid_interest) as l2_unpaid_interest 
			FROM `{$this->tbl_users_rel}` WHERE l2_inviter = %d", $inviter);
			$result = $db->query($sql);
			if(!$result){
				return $row;
			}
			$row2 = $result->fetch_assoc();
			$result->free();
			$row = array_merge($row,$row2);
		}
		return $row;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取邀请者的详细收益利息
	 * 2017-11-22 VERIFIED
	 * 
	 * @param $inviter 邀请者用户ID
	 * @param $is_done 邀请利息是否已经支付
	 * @param $page 分页页码
	 * @param $pagesize 每页条数
	 */
	public function getUsersRelInterest($inviter, $is_done, $page, $pagesize){
		$db = & $this->getReadonlyDB();
		$page = max(intval($page), 0);
		$limit = max(intval($pagesize), 1);
		$start = $page * $limit;
		$ext = '';		
		if($is_done){
			$ext = 'AND invite_interest > 0';
		}else{
			$ext = 'AND invite_unpaid_interest >0';
		}
		$sql = "SELECT b.id, b.mobile, a.invite_interest, a.invite_unpaid_interest, a.invite_interest_status, a.created_time, a.id
				FROM `{$this->tbl_users_rel}` AS a 
				LEFT JOIN `{$this->tbl_user}` AS b ON a.invitee = b.id 
				WHERE a.inviter = ? $ext ORDER BY a.id DESC LIMIT ?,?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('sii', $inviter, $start, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $mobile = $invite_interest = $invite_unpaid_interest = $invite_interest_status = $created_time = $idx = null;
		$stmt->bind_result($id, $mobile, $invite_interest, $invite_unpaid_interest, $invite_interest_status, $created_time, $idx);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
				'id' => $id,
				'mobile' => $mobile,
				'interest' => $invite_interest,
				'unpaid_interest' => $invite_unpaid_interest,
				'status' => $invite_interest_status,
				'created_time' => $created_time
			);
		}
		$stmt->close();
		return $arr;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 计算邀请者一级邀请数目
	 * 新接口
	 * 2017-11-22 VERIFIED
	 * 
	 * @param $inviter 邀请者用户ID
	 */
	public function countUsersRelInterest2($inviter){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT count(id) FROM `{$this->tbl_users_rel}` WHERE inviter = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('s', $inviter);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$count = null;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取邀请者的详细收益利息
	 * 新接口
	 * 2017-11-22 VERIFIED
	 * @param $inviter 邀请者用户ID
	 * @param $page 分页页码
	 * @param $pagesize 每页条数
	 */
	public function getUsersRelInterest2($inviter, $page, $pagesize){
		$db = & $this->getReadonlyDB();
		$page = max(intval($page), 0);
		$limit = max(intval($pagesize), 1);
		$start = $page * $limit;
		// TODO，这个查询语句性能需要分析确认
		$sql = "SELECT b.id, b.mobile, a.invite_interest, a.invite_unpaid_interest, a.invite_interest_status, a.created_time, a.id,
					  c.number as l2_number, c.l2_interest as l2_interest,c.l2_unpaid_interest as l2_unpaid_interest 
   				FROM `{$this->tbl_users_rel}` AS a 
   				LEFT JOIN `{$this->tbl_user}` AS b ON b.id = a.invitee 
   				LEFT JOIN ( SELECT inviter ,count(id) as number, sum(l2_invite_interest) as l2_interest, sum(l2_invite_unpaid_interest) as l2_unpaid_interest 
	   			FROM `{$this->tbl_users_rel}` WHERE l2_inviter = ? GROUP BY inviter ) c on c.inviter = a.invitee 
   				WHERE a.inviter = ? ORDER BY a.id DESC LIMIT ?,?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssii', $inviter, $inviter,$start, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $mobile = $invite_interest = $invite_unpaid_interest = $invite_interest_status = $created_time = $idx = null;
		$l2_number = $l2_interest = $l2_unpaid_interest = null;
		$stmt->bind_result($id, $mobile, $invite_interest, $invite_unpaid_interest, $invite_interest_status, $created_time, $idx,
		$l2_number,$l2_interest,$l2_unpaid_interest);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
   				'id' => $id,
				'mobile' => $mobile,
				'interest' => $invite_interest,
				'unpaid_interest' => $invite_unpaid_interest,
				'status' => $invite_interest_status,
				'l2_number' => $l2_number,
				'l2_interest' => $l2_interest,
				'l2_unpaid_interest' => $l2_unpaid_interest				
			);
		}		
		$stmt->close();
		return $arr;
	}	

	/**
	 * 2017-11-15 新邀请 DONE
	 * 计算邀请者某个被邀请者的下级邀请数目
	 * 2017-11-22 VERIFIED
	 * 
	 * @param $inviter 邀请者用户ID
	 * @param $invitee 被邀请者用户ID
	 */
	public function countUsersRelL2Interest2($inviter,$invitee){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT count(id) FROM `{$this->tbl_users_rel}` WHERE l2_inviter = ? and inviter = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ss', $inviter,$invitee);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$count = null;
		$stmt->bind_result($count);
		$stmt->fetch();
		$stmt->close();
		return intval($count);
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 获取邀请者的某个被邀请者下级的详细收益利息
	 * 2017-11-22 VERIFIED
	 * @param $inviter 邀请者用户ID
	 * @param $invitee 被邀请者用户ID
	 * @param $page 分页页码
	 * @param $pagesize 每页条数
	 */
	public function getUsersRelL2Interest2($inviter, $invitee, $page, $pagesize){
		$db = & $this->getReadonlyDB();
		$page = max(intval($page), 0);
		$limit = max(intval($pagesize), 1);
		$start = $page * $limit;
		$sql = "SELECT b.id, b.mobile, a.l2_invite_interest, a.l2_invite_unpaid_interest,a.created_time, a.id 
   				FROM `{$this->tbl_users_rel}` AS a 
   				LEFT JOIN `{$this->tbl_user}` AS b ON a.invitee = b.id 
   				WHERE a.l2_inviter = ? and a.inviter = ? ORDER BY a.id DESC LIMIT ?,?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'prepare failed');
			return false;
		}
		$stmt->bind_param('ssii', $inviter, $invitee, $start, $limit);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$id = $mobile = $l2_interest = $l2_unpaid_interest = $created_time = $idx = null;;
		$stmt->bind_result($id, $mobile, $l2_interest, $l2_unpaid_interest, $created_time, $idx);
		$arr = array();
		while($stmt->fetch()){
			$arr[] = array(
   				'id' => $id,
				'mobile' => $mobile,
				'l2_interest' => $l2_interest,
				'l2_unpaid_interest' => $l2_unpaid_interest				
			);
		}		
		$stmt->close();
		return $arr;
	}		
	
	public function countUsersRelInPaperInterest(){
		$db = & $this->getReadonlyDB();
		$sql = "SELECT count(id) as numb FROM `{$this->tbl_users_rel}` WHERE invite_interest_status >= 0";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}

	public function getUsersRelInPaperInterest($index, $pagesize){
		$db = & $this->getReadonlyDB();
		$limit = intval($pagesize);
		$start = $limit * $index;
		$sql = "SELECT * FROM `{$this->tbl_users_rel}` WHERE invite_interest_status >= 0 ORDER BY id DESC LIMIT $start, $limit";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 调用者已经废弃，所以该函数也废弃了
	 * @deprecated
	 */
	public function countUsersRelPendingInterest(){
		$db = & $this->getReadonlyDB();
		$status = INVITE_STATUS_PENDING;
		$sql = "SELECT count(id) as numb FROM `{$this->tbl_users_rel}` WHERE invite_interest_status = $status";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 调用者已经废弃，所以该函数也废弃了
	 * @deprecated
	 */	
	public function getUsersRelPendingInterest($index, $pagesize){
		$db = & $this->getReadonlyDB();
		$limit = intval($pagesize);
		$start = $limit * $index;
		$status = INVITE_STATUS_PENDING;
		$sql = "SELECT * FROM `{$this->tbl_users_rel}` WHERE invite_interest_status = $status ORDER BY id DESC LIMIT $start, $limit";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}
	/**
	 * 2017-11-15 新邀请 DONE
	 * 更新用户邀请记录数据及状态
	 * 调用者已经废弃，所以该函数也废弃了
	 * 
	 * @param $data 更新的数据，数组
	 * @param $failed 返回的失败记录ID，数组
	 * @deprecated
	 */
	public function updateUsersRelInPaperInterest($data, &$failed = array()){
		$db = & $this->getDB();
		$sql = "UPDATE `{$this->tbl_users_rel}` SET invite_interest_status = ?, invite_interest = ?, modified_time = NOW() WHERE id = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'sql prepare failed');
			return false;
		}
		$failed = array();
		foreach ($data as $row) {
			// 由于计算的时候，是按被邀请人统一计算的，所以一级和二级的邀请利息状态这个时候是一样的
			// 只有在支付的时候，分开给一级二级邀请者，才会有不同的状态
			$stmt->bind_param('iss', $row['status'],$row['interest'], $row['id']);
			$bool = $stmt->execute();
			if(!$bool){
				$failed[] = $row['id'];
			}
		}
		$stmt->close();
		return empty($failed);
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 插入邀请者奖励支付数据记录
	 * 
	 * @param $data 更新的记录数据，一个数组
	 *  $data['invitee'] 被邀请者ID
	 *  $data['invitee_interest'] 被邀请者本次支付的利息
	 *  $data['invitee_unpaid_interest'] 被邀请者目前未支付的利息
	 *  $data['inviter'] 邀请者ID
	 *  $data['inviter_bonus'] 邀请者本次支付的奖励
	 *  $data['inviter_unpaid_bonus'] 邀请者目前未支付的奖励
	 *  $data['l2_inviter'] 二级邀请者ID
	 *  $data['l2_inviter_bonus'] 二级邀请者本次支付的奖励
	 *  $data['l2_inviter_unpaid_bonus'] 二级邀请者目前未支付的奖励
	 */
	public function addInviterBonusRepayment($data,$update_invite_status = 0){
		$db = & $this->getDB();
		$db->autocommit(false);
		// 更新邀请记录中被邀请者的利息收益，邀请者的奖励发放是当前被邀请者所有已支付的利息和数据库中记录的两次的差
		$update_str = '';
		if (1==$update_invite_status) {
			$status =INVITE_STATUS_NORMAL;
			$update_str = ", invite_interest_status = {$status}, invite_interest = 0 ";
		} else if (2==$update_invite_status) {
			$status =INVITE_STATUS_DONE;
			$update_str = ", invite_interest_status = {$status} ";
		}
		$sql = "UPDATE `{$this->tbl_users_rel}` 
				SET invitee_paid_interest = invitee_paid_interest + ?, invitee_unpaid_interest = ?, 
				invite_unpaid_interest = ?,l2_invite_unpaid_interest = ?, modified_time = NOW() {$update_str}
				WHERE invitee = ? ";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, "sql prepare failed : $sql",__LINE__);
			$db->autocommit(true);
			return false;
		}
		$stmt->bind_param('sssss', $data['invitee_interest'], $data['invitee_unpaid_interest'],
			$data['inviter_unpaid_bonus'], $data['l2_inviter_unpaid_bonus'], $data['invitee']);
		$bool = $stmt->execute();
		if(!$bool || !$stmt->affected_rows){
			$error = $stmt->error ? $stmt->error : $data;
			$this->logerror(__METHOD__, $error, __LINE__);
			$stmt->close();
			$db->rollback();
			$db->autocommit(true);
			return false;
		}
		$stmt->close();
		// 只有被邀请者本次支付的利息大于0的时候才产生邀请者的奖励支付记录
		// 可能产生inviter_bonus/l2_inviter_bonus为0的情况，作为记录保存，最后不做任何奖励发放，直接标记为结束
		if ($data['invitee_interest']>0) {
			// 插入邀请者奖励支付记录，状态为待支付
			$sql = "INSERT INTO `{$this->tbl_inviter_bonus_repayment}` 
			SET invitee = ?, invitee_interest = ?, inviter = ?, inviter_bonus = ?, l2_inviter = ?, l2_inviter_bonus = ?, bonus_status = ?";
			$stmt = $db->prepare($sql);
			if(!$stmt){
				$this->logerror(__METHOD__, "sql prepare failed : $sql");
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
			$bonus_status = INVITER_BONUS_REPAYMENT_STATUS_NORMAL;
			$stmt->bind_param('ssssssi',$data['invitee'], $data['invitee_interest'],$data['inviter'],$data['inviter_bonus'],
				$data['l2_inviter'], $data['l2_inviter_bonus'],$bonus_status);
			$res = $stmt->execute();
			if(!$res || $stmt->affected_rows<1){
				$error = $stmt->error ? $stmt->error : $data;
				$this->logerror(__METHOD__, $error, __LINE__);
				$stmt->close();
				$db->rollback();
				$db->autocommit(true);
				return false;
			}
			$stmt->close();
		}

		$bool = $db->commit();
		$db->autocommit(true);
		return true;
	}

	/**
	 * 计算邀请者未支付奖励的记录总数
	 */
	public function countInviterPendingBonus(){
		$db = & $this->getReadonlyDB();
		$status = INVITER_BONUS_REPAYMENT_STATUS_NORMAL;
		$sql = "SELECT count(id) as numb 
				FROM `{$this->tbl_inviter_bonus_repayment}` 
				WHERE bonus_status = $status";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$row = $result->fetch_assoc();
		$result->free();
		if(empty($row)){
			return 0;
		}
		return intval($row['numb']);
	}

	/**
	 * 获取邀请者未支付奖励的记录
	 * 
	 * @param $index 开始索引
	 * @param $pageSize 当前页记录数
	 */
	public function getInviterPendingBonus($index, $pagesize){
		$db = & $this->getReadonlyDB();
		$limit = intval($pagesize);
		$start = $limit * $index;
		$status = INVITER_BONUS_REPAYMENT_STATUS_NORMAL;
		$sql = "SELECT id, invitee, invitee_interest, inviter, inviter_bonus, l2_inviter, l2_inviter_bonus 
				FROM `{$this->tbl_inviter_bonus_repayment}` 
				WHERE bonus_status = $status ORDER BY id DESC LIMIT $start, $limit";
		$result = $db->query($sql);
		if(!$result){
			return null;
		}
		$arr = $result->fetch_all(MYSQLI_ASSOC);
		$result->free();
		return $arr;
	}

}