<?php
require_once PATH_BASE_MODEL;

class CipherModel extends Model{

	protected $tbl_deviceinfo = 'deviceinfo';

	protected $tbl_cipher = 'cipher';

	protected $tbl_aeskey = 'aeskey';

	public function __construct(){
		parent::__construct();
	}

	public function addPublicKey($device, $udid, $key){
		$db = & $this->getDB();
		$sql = "INSERT INTO {$this->tbl_cipher} SET device = ?, pubkey = ?, udid = ?, md5val = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'PREPARE FAILED');
			return false;
		}
		$md5val = md5($key);
		$stmt->bind_param('ssss', $device, $key, $udid, $md5val);
		$bool = $stmt->execute();
		$res = false;
		if($bool){
			$res = true;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $res;
	}

	public function addAESKey($device, $key){
		$db = & $this->getDB();
		$sql = "INSERT INTO {$this->tbl_aeskey} SET device = ?, aeskey = ?, modified_time = NOW() ON DUPLICATE KEY UPDATE aeskey = ?, modified_time = NOW()";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'PREPARE FAILED');
			return false;
		}
		$stmt->bind_param('sss', $device, $key, $key);
		$bool = $stmt->execute();
		$res = false;
		if($bool){
			$res = true;
		}else{
			$this->logerror(__METHOD__, $stmt->error);
		}
		$stmt->close();
		return $res;
	}

	public function getPublicKeyInfo($device){
		$token = 'Cipher_'.$device;
		$info = $this->memGet($token);
		if(!empty($info)){
			$info = json_decode($info, true);
			if($info && isset($info['device']) && $info['device']){
				return $info;
			}
		}
		$db = & $this->getReadonlyDB();
		$sql = "SELECT device,pubkey,udid,created_time FROM `{$this->tbl_cipher}` WHERE device = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'PREPARE FAILED');
			return false;
		}
		$stmt->bind_param('s', $device);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$device = $pubkey = $created_time = $udid = null;
		$stmt->bind_result($device, $pubkey, $udid, $created_time);
		$stmt->fetch();
		$stmt->close();
		if(empty($device)){
			return null;
		}
		$ts = strtotime($created_time);
		$info = array(
			'device' => $device,
			'pubkey' => $pubkey,
			'udid' => $udid,
			'created_time' => $ts
		);
		$this->cachePublicKey($device, $pubkey, $udid, $ts);
		return $info;
	}

	public function getAESKeyInfo($device){
		$token = 'AESKEY_'.$device;
		$info = $this->memGet($token);
		if(!empty($info)){
			$info = json_decode($info, true);
			if($info && isset($info['device']) && $info['device']){
				return $info;
			}
		}
		$db = & $this->getReadonlyDB();
		$sql = "SELECT device,aeskey,created_time,modified_time FROM `{$this->tbl_aeskey}` WHERE device = ?";
		$stmt = $db->prepare($sql);
		if(!$stmt){
			$this->logerror(__METHOD__, 'PREPARE FAILED');
			return false;
		}
		$stmt->bind_param('s', $device);
		$bool = $stmt->execute();
		if(!$bool){
			$this->logerror(__METHOD__, $stmt->error);
		}
		$device = $aeskey = $created_time = $modified_time = null;
		$stmt->bind_result($device, $aeskey, $created_time, $modified_time);
		$stmt->fetch();
		$stmt->close();
		if(empty($device)){
			return null;
		}
		$ts = strtotime($created_time);
		$ts_m = strtotime($modified_time);
		$info = array(
			'device' => $device,
			'aeskey' => $aeskey,
			'created_time' => $ts,
			'modified_time' => $ts_m
		);
		$this->cacheAESKey($device, $aeskey, $ts, $ts_m);
		return $info;
	}

	public function cachePublicKey($device, $key, $udid, $ts){
		$token = 'Cipher_'.$device;
		$info = array(
			'device' => $device,
			'pubkey' => $key,
			'udid' => $udid,
			'created_time' => $ts
		);
		load_define('cipher');
		return $this->memSet($token, json_encode($info), CIPHER_INFO_MEMCACHE_TIMEOUT);
	}

	public function cacheAESKey($device, $key, $ts, $ts_m){
		$token = 'AESKEY_'.$device;
		$info = array(
			'device' => $device,
			'aeskey' => $key,
			'created_time' => $ts,
			'modified_time' => $ts_m
		);
		load_define('cipher');
		return $this->memSet($token, json_encode($info), CIPHER_AESKEY_MEMCACHE_TIMEOUT);
	}
}