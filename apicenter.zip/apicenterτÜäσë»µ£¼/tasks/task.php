<?php

if(!isset($_SERVER['ENVIRONMENT']) || empty($_SERVER['ENVIRONMENT'])){
	$environment = 'development';
}else{
	$environment = strtolower($_SERVER['ENVIRONMENT']);
}

define('ENVIRONMENT', $environment);

if (defined('ENVIRONMENT'))
{
	switch (ENVIRONMENT)
	{
		case 'development':
			error_reporting(E_ALL);
		break;

		case 'testing':
		case 'production':
			error_reporting(0);
		break;

		default:
			exit('The application environment is not set correctly.');
	}
}

require dirname(dirname(__FILE__)) . '/base.php';

@ob_start();

define('IN_TASK', true);

$controller = isset($argv['1']) ? trim($argv['1']) : 'task';
$method = isset($argv[2]) ? trim($argv[2]) : 'list';

$file_path = DIR_CTRL . $controller . '.php';
if (!file_exists($file_path)){
	$controller = 'controller';
	$method = 'notExists';
}

$ctrl = & load_ctrl($controller);
if(!method_exists($ctrl, $method)){
	$method = 'notExists';
}

$ctrl->$method(array_slice($argv, 3));

//$res = ob_get_clean();
