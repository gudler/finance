<?php
class InterestHelper {


	static public function getRepaymentMonthDays($repayment_day, $day, $month, $year){
		$monthdays = self::getMonthDays($month, $year);
		$lastmonthdays = self::getMonthDays($month - 1, $year);
		$nextmonthdays = self::getMonthDays($month + 1, $year);

		$last_repayment_day = min($lastmonthdays, $repayment_day);
		$next_repayment_day = min($nextmonthdays, $repayment_day);
		$repayment_day = min($repayment_day, $monthdays);
		
		if($day <= $repayment_day){
			$days = $lastmonthdays - $last_repayment_day + $repayment_day;
		}else{
			$days = $monthdays - $repayment_day + $next_repayment_day;
		}
		return $days;
	}

	/* 已于2017年07月07日废弃
	static public function getRepaymentMonthDays($repayment_day, $day, $month, $year){
		$month = intval($month);
		if($month<1 || $month>12){//数值非法，返回默认30日
			return 30;
		}
		$days_map = array(
			31,
			28,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		);
		$idx = $month - 1;
		if( $repayment_day < $day ){//付款时间小于当前日，选当月天数
			$days = $days_map[$idx];
		}else{
			$idx -= 1;//付款时间大于等于当前日，选前一月天数
			if($idx == -1){
				$idx = 11;
			}
			$days = $days_map[$idx];
		}
		if($idx == 1 && $year%4 == 0){
			$days = 29;//闰年二月29天。
		}

		$monthdays = self::getMonthDays($month, $year);
		$lastmonthdays = self::getMonthDays($month - 1, $year);
		if($lastmonthdays > $repayment_day){
			$days = $lastmonthdays - $repayment_day + min($monthdays, $repayment_day);
		}else{
			$days = $monthdays;
		}
		return $days;
	}
	*/

	static public function getRepaymentDate($repayment_day, $month, $year){
		$month = intval($month);
		if($month<1 || $month>12){//数值非法，返回默认30日
			return 30;
		}
		$days_map = array(
			31,
			28,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		);
		$idx = $month - 1;
		$days = $days_map[$idx];
		if($idx == 1 && $year%4 == 0){
			$days = 29;//闰年二月29天。
		}
		if($repayment_day > $days){
			$repayment_day = $days;
		}
		return "$year-$month-$repayment_day";
	}

	static public function getMonthDays($month, $year){
		$month = intval($month);
		if($month<0 || $month>13){//数值非法，返回默认30日
			return 30;
		}
		if($month == 0){
			$month = 12;
			$year = $year - 1;
		}elseif($month == 13){
			$month = 1;
			$year = $year + 1;
		}
		$days_map = array(
			31,
			28,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		);
		$idx = $month - 1;
		$days = $days_map[$idx];
		if($idx == 1 && $year%4 == 0){
			$days = 29;//闰年二月29天。
		}
		return $days;
	}

	static public function getMaxDays($year, $month, $repayment_day){
		$last_day_max = self::getMonthDays($month - 1, $year);
		$current_day_max = self::getMonthDays($month, $year);
		return max(0, $last_day_max - $repayment_day) + min($repayment_day, $current_day_max);
	}

	static public function principalAndInterestEqual($money, $year_rate, $monthes){
		if($money <= 0) {
			return 0;
		}
		if(abs($year_rate) <= 1e-7){
			return $money/$monthes;
		}
		$month_rate = $year_rate/12;
		$each_month = $money * $month_rate * ( pow ( 1 + $month_rate , $monthes ) ) / ( pow( 1 + $month_rate , $monthes) - 1 );
		return $each_month;
	}

	static public function getLeftAmountAndPeriod($money, $rate, $monthes, $firstdate){
		$last = $money;
		$total_interest = 0;
		$each_month = self::principalAndInterestEqual($money, $rate, $monthes);
		$month_rate = $rate/12;
		$date = $firstdate;
		list($year, $month, $day) = explode('-', $firstdate);
		//echo "期号\t日期\t本金余额\t应付本金\t月利息\t本息合计\n";
		$now = time();
		$bang = 1;
		for($i=1;$i<=$monthes;$i++){
			$interest = $last * $month_rate;
			$capital = $each_month - $interest;
			$total_interest += $interest;

			if($bang && strtotime($date)>$now){
				$bang = 0;
				return array(
					'left_period' => $monthes - $i + 1,
					'left_amount' => $last,
					);
				// echo sprintf("========== %d ========== %0.2f ==========\n", $monthes - $i + 1, $last);
			}

			// printf("%d\t%s\t%0.2f\t%0.2f\t%0.2f\t%0.2f\n", $i, $date, $last, $capital, $interest, $each_month );
			$month++;
			if($month>12){
				$month = 1;
				$year += 1;
			}
			$date = $year . '-' . $month . '-' . $day;
			$last -= $capital;
			// $real_total_interest += $real_interest;
		}
		return false;
		// echo "\n", $total_interest, "\t", $total_interest*100/$money, "\n";
	}

	static public function getDayInterest($money, $year_rate, $repayment_day, $day, $month, $year){
		$month_rate = $year_rate/12;
		$interest = $money * $month_rate;
		$days = self::getRepaymentMonthDays($repayment_day, $day, $month, $year);
		return $interest/$days;
	}

	static public function getRookieList($money, $month_rate, $days, $repayment_day, $day, $month, $year){
		$list = array();
		$list[] = array(
			'date' => "日期",
			'principal' => "本金",
			'day_interest' => "日利息"
			);
		$total_interest = 0;
		$day_interest = floor($money * $month_rate * 12 / 365 * 10000) / 10000;
		$ts = strtotime("$year-$month-$day");
		for ($i=0; $i < $days; $i++) {
			$list[] = array(
				'date' => date('Y-m-d', $ts + 86400*$i),
				'principal' => $money,
				'day_interest' => $day_interest,
				);
			$total_interest += $day_interest;
		}
		return array( 'total_interest' => $total_interest,
			'list' => $list );
	}

	/*
	 *	鹰眼宝计算本息
	 */
	static public function getEagleEyedList($money, $month_rate, $monthes, $repayment_day, $day, $month, $year){
		$list = array();
		$list[] = array(
			'i' => "期号",
			'date' => "日期",
			'last' => "本金余额",
			'capital' => "应付本金",
			'interest' => "月利息",
			'each_month' => "本息合计",
			'day_interest' => "日利息",
			'day_bonus' => "日奖金",
			'days' => "天数",
			'pay_interest' => "实付利息",
			'pay_bonus' => "实付奖金",
			'pay_sum' => "实付本息");
		$total_interest = $real_total_interest = 0;
		$last = $money;
		$each_month = self::principalAndInterestEqual($money, $month_rate*12, $monthes);
		$firstmonth = 0;
		$day_max = self::getMonthDays($month, $year);
		
		if($day<=$repayment_day){
			if($day_max<$repayment_day){
				$firstmonth = $day_max - $day + 1;
			}else{
				$firstmonth = $repayment_day - $day + 1;
			}
		}else{
			$firstmonth = $day_max + $repayment_day - $day + 1;
			$month++;
			if($month>12){
				$month = 1;
				$year = $year + 1;
			}
		}

		for($i=1;$i<=$monthes;$i++){
			$interest = $last * $month_rate;
			$capital = floor(($each_month - $interest)*10000)/10000;
			$day_max = self::getMaxDays($year, $month, $repayment_day);
			
			$day_interest = floor($last * $month_rate / $day_max * 10000)/10000;
			$real_days = $day_max;
			if($firstmonth){
				$real_interest = $day_interest * $firstmonth;
				$real_days = $firstmonth;
				$firstmonth = 0;
			}else{
				$real_interest = $day_interest * $day_max;
			}
			$total_interest += $interest;
			$interest = floor($interest * 10000) / 10000;
			$each_month = floor($each_month * 10000) / 10000;
			$show_day = min($repayment_day, self::getMonthDays($month, $year));

			$list[] = array(
				'i' => $i,
				'date' => "$year/$month/$show_day",
				'last' => $last,
				'capital' => $capital,
				'interest' => $interest,
				'each_month' => $each_month,
				'day_interest' => $day_interest,
				'day_bonus' => 0,
				'days' => $real_days,
				'pay_interest' => $real_interest,
				'pay_bonus' => 0,
				'pay_sum' => $real_interest + $capital );
			$last -= $capital;
			$real_total_interest += $real_interest;
			$month ++;
			if($month > 12){
				$year ++;
				$month = 1;
			}
		}
		return array( 'total_interest' => $real_total_interest,
			'list' => $list );
	}

	/*
	 *	易购宝计算本息
	 */
	/*
	static public function getFastEntryList($money, $month_rate, $monthes, $repayment_day, $day, $month, $year){
		$list = array();
		$list[] = array(
			'i' => "期号",
			'date' => "日期",
			'last' => "本金余额",
			'capital' => "应付本金",
			'interest' => "月利息",
			'each_month' => "本息合计",
			'day_interest' => "日利息",
			'day_bonus' => "日奖金(下次结息给)",
			'days' => "天数",
			'pay_interest' => "实付利息",
			'pay_bonus' => "实付奖金",
			'pay_sum' => "实付本息");
		$total_interest = $real_total_interest = 0;
		$last = $money;
		$each_month = self::principalAndInterestEqual($money, $month_rate*12, $monthes);
		$firstmonth = 0;

		$day_max = self::getMonthDays($month, $year);
		if($day<=$repayment_day){
			if($day_max<$repayment_day){
				$firstmonth = $day_max - $day + 1;
			}else{
				$firstmonth = $repayment_day - $day + 1;
			}
		}else{
			$firstmonth = $day_max + $repayment_day - $day + 1;
			$month++;
		}
		$real_bonus = 0;
		for($i=1;$i<=$monthes;$i++){
			$interest = $last * $month_rate;
			$capital = floor(($each_month - $interest)*10000)/10000;
			$day_max = self::getMonthDays($month, $year);
			$day_interest = $last * $month_rate / $day_max;
			$day_interest = $day_bonus = floor($day_interest/2 * 10000)/10000;
			$real_days = $day_max;
			if($firstmonth){
				$real_interest = $day_interest * $firstmonth;
				$real_days = $firstmonth;
				$firstmonth = 0;
			}else{
				$real_interest = $day_interest * $day_max;
			}
			if($i == $monthes){
				$real_bonus += $real_interest;
			}
			$total_interest += $interest;

			$interest = floor($interest * 10000) / 10000;
			$each_month = floor($each_month * 10000) / 10000;
			$list[] = array(
				'i' => $i,
				'date' => "$year/$month/$repayment_day",
				'last' => $last,
				'capital' => $capital,
				'interest' => $interest,
				'each_month' => $each_month,
				'day_interest' => $day_interest,
				'day_bonus' => $day_bonus,
				'days' => $real_days,
				'pay_interest' => $real_interest,
				'pay_bonus' => $real_bonus,
				'pay_sum' => $real_interest + $real_bonus + $capital );
			$last -= $capital;
			$real_total_interest += $real_interest + $real_bonus;
			$real_bonus = $real_interest;
			$month ++;
			if($month > 12){
				$year ++;
				$month = 1;
			}
		}
		return array( 'total_interest' => $real_total_interest,
			'list' => $list );
	}
	*/

	/*
	 *	易购宝计算本息2
	 */
	static public function getFastEntryList($money, $month_rate, $monthes, $repayment_day, $day, $month, $year){
		$list = array();
		$list[] = array(
			'i' => "期号",
			'date' => "日期",
			'last' => "本金余额",
			'capital' => "应付本金",
			'interest' => "月利息",
			'each_month' => "本息合计",
			'day_interest' => "日利息",
			'day_bonus' => "日奖金",
			'days' => "天数",
			'pay_interest' => "实付利息",
			'pay_bonus' => "实付奖金",
			'pay_sum' => "实付本息");
		$total_interest = $real_total_interest = 0;
		$last = $money;
		$each_month = self::principalAndInterestEqual($money, $month_rate*12, $monthes);
		$firstmonth = 0;

		$day_max = self::getMonthDays($month, $year);
		if($day<=$repayment_day){
			if($day_max<$repayment_day){
				$firstmonth = $day_max - $day + 1;
			}else{
				$firstmonth = $repayment_day - $day + 1;
			}
		}else{
			$firstmonth = $day_max + $repayment_day - $day + 1;
			$month++;
			if($month>12){
				$month = 1;
				$year = $year + 1;
			}
		}
		$real_bonus = 0;
		for($i=1;$i<=$monthes;$i++){
			$interest = $last * $month_rate;
			$capital = floor(($each_month - $interest)*10000)/10000;
			$day_max = self::getMaxDays($year, $month, $repayment_day);

			$day_interest = $last * $month_rate / $day_max;
			$day_interest = floor($day_interest * 10000)/10000;
			$day_bonus = 0;
			$real_days = $day_max;
			if($firstmonth){
				$real_interest = $day_interest * $firstmonth;
				$real_days = $firstmonth;
				$firstmonth = 0;
			}else{
				$real_interest = $day_interest * $day_max;
			}
			$total_interest += $interest;

			$interest = floor($interest * 10000) / 10000;
			$each_month = floor($each_month * 10000) / 10000;
			$show_day = min($repayment_day, self::getMonthDays($month, $year));
			
			$list[] = array(
				'i' => $i,
				'date' => "$year/$month/$show_day",
				'last' => $last,
				'capital' => $capital,
				'interest' => $interest,
				'each_month' => $each_month,
				'day_interest' => $day_interest,
				'day_bonus' => $day_bonus,
				'days' => $real_days,
				'pay_interest' => $real_interest,
				'pay_bonus' => $real_bonus,
				'pay_sum' => $real_interest + $real_bonus + $capital );
			$last -= $capital;
			$real_total_interest += $real_interest + $real_bonus;
			$real_bonus = 0;
			$month ++;
			if($month > 12){
				$year ++;
				$month = 1;
			}
		}
		return array( 'total_interest' => $real_total_interest,
			'list' => $list );
	}

}