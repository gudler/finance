<?php
class DatetimeHelper {

	static public function runTime( $time, $length = 2 ) {
		if($time>0){
			$arr = array();
			$sec = $time%60;
			array_unshift($arr, $sec . '秒');
			$n = floor($time/60);
			if($n>0){
				$min = $n%60;
				array_unshift($arr, $min . '分钟');
				$n = floor($n/60);
				if($n>0){
					$hour = $n%24;
					array_unshift($arr, $hour . '小时');
					$n = floor($n/24);
					if($n>0){
						array_unshift($arr, $n . '天');
					}
				}
			}
			if(count($arr) > $length){
				$arr = array_slice($arr, 0, $length);
			}
			return implode('', $arr);
		}else{
			return '';
		}
	}

	static public function diffDays( $from, $to ){
		$to_date = date('Y-m-d', $to);
		$from_date = date('Y-m-d', $from);
		return floor( ( strtotime($to_date) - strtotime($from_date) ) / 86400 );
	}

}