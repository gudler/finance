<?php
class StaticHelper{

	public static function url_root($idx = 0, $channel = 1){
		if(defined('ENVIRONMENT') && ENVIRONMENT == 'development'){
			return '/';
		}
		$map = array(
			0 => 'static',
			1 => 's1',
			2 => 's2',
			3 => 's3',
			);
		return ($channel != 1 ? 'http:' : '').'//'.(isset($map[$idx])?$map[$idx]:$map[0]).'.eagleeyedfinance.com/';
	}

}