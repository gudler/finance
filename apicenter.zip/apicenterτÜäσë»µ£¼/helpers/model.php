<?php

class ModelHelper{

	public static function idarr_to_string($id_arr, $keep_zero = false){
		$tmp = array();
		foreach($id_arr as $id){
			$id = intval($id);
			if($id || ($keep_zero && $id.'' === '0')){
				$tmp[$id] = true;
			}
		}
		if(empty($tmp)){
			return false;
		}
		$tmp = array_keys($tmp);
		return implode(',', $tmp);
	}
}