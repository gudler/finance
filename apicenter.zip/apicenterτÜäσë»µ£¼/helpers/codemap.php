<?php
class CodemapHelper {

	static public function viaCodes($code, $closed_period = null) {
		switch ($code) {
			case TRADE_VIA_DIRECT_BUY_OBLIGATION:
				return '直接购买';
			case TRADE_VIA_EAGLEEYED:
				return '通过鹰眼宝购买';
			case TRADE_VIA_FAST_ENTRY:
				return '通过易购宝购买';
			case TRADE_VIA_AUTOSHIFT_EAGLEEYED:
				return '通过自动转投鹰眼宝购买';
			case TRADE_VIA_AUTOSHIFT_FAST_ENTRY:
				return '通过自动转投易购宝购买';
			case TRADE_VIA_AMOUNT_SHIFT:
				return '通过余额转投易购宝购买';
			case TRADE_VIA_ROOKIE:
				return '通过新人专享购买';
			default:
				return '未定义';
		}
	}

	static public function viaCodeName($code, $closed_period = null) {
		switch ($code) {
			case TRADE_VIA_DIRECT_BUY_OBLIGATION:
				return '债权';
			case TRADE_VIA_EAGLEEYED:
				return '鹰眼宝';
			case TRADE_VIA_FAST_ENTRY:
				return '易购宝';
			case TRADE_VIA_AUTOSHIFT_EAGLEEYED:
				return '自动转投鹰眼宝';
			case TRADE_VIA_AUTOSHIFT_FAST_ENTRY:
				return '自动转投易购宝';
			case TRADE_VIA_AMOUNT_SHIFT:
				return '余额转投易购宝';
			case TRADE_VIA_ROOKIE:
				return '新人专享';
			default:
				return '未定义';
		}
	}

	static public function accountActionName( $action ) {
		switch ($action) {
			case USRACCOUNT_ACTION_RECHARGE:
				return '充值';
			case USRACCOUNT_ACTION_OFFLINE_RECHARGE:
				return '充值（线下）';
			case USRACCOUNT_ACTION_OBSELL:
				return '出售';
			case USRACCOUNT_ACTION_WITHDRAW_ROLLBACK:
				return '提现失败返还';
			case USRACCOUNT_ACTION_REPAYMENT:
				return '兑付本金利息';
			case USRACCOUNT_ACTION_ADD_LEFT_DMAMOUNT:
				return '给用户返还低于1分的债权转让金额';
			case USRACCOUNT_ACTION_INVITE_INTEREST:
				return '返佣';
			case USRACCOUNT_ACTION_LARGE_AMT_RECHARGE:
				return '转账充值';
			case USRACCOUNT_ACTION_AWARD:
				return '奖励';
			case USRACCOUNT_ACTION_PAYBACK_TRADEFEE:
				return '返交易手续费';
			case USRACCOUNT_ACTION_PAYBACK_DEPOSIT:
				return '退还保证金';
			case USRACCOUNT_ACTION_SIGN_BONUS:
				return '签到金';
			case USRACCOUNT_ACTION_WITHDRAW:
				return '提现';
			case USRACCOUNT_ACTION_OBBUY:
				return '购买';
			case USRACCOUNT_ACTION_PAY_EARLY:
				return '提前结清本金';
			case USRACCOUNT_ACTION_PAY_INTEREST_IMMEDIATELY:
				return '提前结清利息';
			case USRACCOUNT_ACTION_PAYBACK_LOAN:
				return '退还还款';
			case USRACCOUNT_ACTION_OFFLINE_WITHDRAW:
				return '转账提现';
			case USRACCOUNT_ACTION_OFFLINE_WITHDRAW_ROLLBACK:
				return '转账提现失败返还';
			case USRACCOUNT_ACTION_RETURN_LOAN:
				return '还款';
			case USRACCOUNT_ACTION_RETURN_LOAN_PIECE:
				return '还款（不足）';
			case USRACCOUNT_ACTION_WITHDRAW_TUIPIAO_ROLLBACK:
				return '支付通道退票返还';
			default:
				return '未定义';
		}
	}

	static public function holdingStatusCodeName($code, $selling, $pending = false) {
		switch ($code) {
			case USROBL_STATUS_IN_HELD:
				if($selling == UOB_SELLING_YES){
					return '转让中';
				}else{
					return '持有中';
				}
			case USROBL_STATUS_SOLD:
				return '已转让';
			case USROBL_STATUS_DONE:
				if($pending){
					return '已还本待付息';
				}else{
					return '已结清';
				}
			default:
				return '未定义';
		}
	}

	static public function historyStatusCodeName($code) {
		switch ($code) {
			case USROBL_STATUS_IN_HELD:
				return '购买';
			case USROBL_STATUS_SOLD:
				return '已售';
			case USROBL_STATUS_DONE:
				return '结清';
			default:
				return '未定义';
		}
	}

	static public function obligationRepaymentDate($rpdate, $rpday, $method, $closed_period = null, $created_time = null){
		switch ($method) {
			case REPAYMENT_PRINCIPAL_AND_INTEREST_EQUAL://等额本息
				return "每月{$rpday}日";

			case REPAYMENT_EQUAL_PRINCIPAL://等额本金
				return "每月{$rpday}日";

			case REPAYMENT_PRINCIPAL_AND_INTEREST_AT_MATURITY://到期还本付息
				if(empty($rpdate)){
					return date("Y年m月d日", strtotime("+{$closed_period} days", strtotime($created_time)));
				}
				return date("Y年m月d日", strtotime($rpdate));

			case REPAYMENT_PRINCIPAL_AT_MATURITY_REGULAR_INTEREST_PAYMENT://到期还本按期付息
				return "每月{$rpday}日";

		}
	}

	static public function repaymentMethod($method){
		switch ($method) {
			case REPAYMENT_PRINCIPAL_AND_INTEREST_EQUAL://等额本息
				return getlang('repayment.principal_and_interest_equal');

			case REPAYMENT_EQUAL_PRINCIPAL://等额本金
				return getlang('repayment.repayment_equal_principal');

			case REPAYMENT_PRINCIPAL_AND_INTEREST_AT_MATURITY://到期还本付息
				return getlang('repayment.repayment_principal_and_interest_at_maturity');

			case REPAYMENT_PRINCIPAL_AT_MATURITY_REGULAR_INTEREST_PAYMENT://到期还本按期付息
				return getlang('repayment.repayment_principal_at_maturity_regular_interest_payment');

		}
	}

	static public function loanInfoStatusCodeName($code, $overdue_days = 0){
		switch ($code) {
			case LOAN_INFO_STATUS_NORMAL://正常
				return '正常';
			case LOAN_INFO_STATUS_RETURNED://已结清
				return '已结清';
			case LOAN_INFO_STATUS_ADVANCE_PAID://已提前结清
				return '已提前结清';
			case LOAN_INFO_STATUS_OVERDUED://已逾期
				return '已逾期' . $overdue_days . '天';
		}
	}

	static public function loanRepaymentStatusCodeName($code, $overdue_days = 0){
		switch ($code) {
			case LOAN_REPAYMENT_STATUS_NORMAL://正常
				return '正常';
			case LOAN_REPAYMENT_STATUS_RETURNED://已还
				return '已还';
			case LOAN_REPAYMENT_STATUS_PAYEARLY://已提前结清
				return '提前结清';
			case LOAN_REPAYMENT_STATUS_OVERDUED://已逾期
				return '已逾期' . $overdue_days . '天';
		}
	}

	static public function obligationStatusCodeName($code){
		switch ($code) {
			case OBL_STATUS_OPEN://开放
				return '出售中';
			case OBL_STATUS_SOLDOUT://售空
				return '售空';
			case OBL_STATUS_CLOSED://关闭
				return '关闭';
			case OBL_STATUS_DONE://完成
				return '结清';
		}
	}

	static public function inviteStatusCodeName($code){
		switch ($code) {
			case INVITE_STATUS_NORMAL:
				return '未投资';

			case INVITE_STATUS_INVESTED:
				return '已投资';
			case INVITE_STATUS_GENERATED:
				return '已生利';

			case INVITE_STATUS_PENDING:
				return '待付息';
			case INVITE_STATUS_DONE:
				return '已结清';
		}
	}

	/**
	 * 2017-11-15 新邀请 DONE
	 * 修改状态文本
	 * 2017-11-22 VERIFIED
	 */
	static public function inviteStatusCodeName2($is_done){
		if (1==$is_done){
			return '已结算';
		} else {
			return '未结算';
		}
	}

	static public function loanListStatusCodeName($code){
		switch ($code) {
			case LOAN_REPAYMENT_STATUS_NORMAL:
				return '正常';
			case LOAN_REPAYMENT_STATUS_RETURNED:
				return '已还';
			case LOAN_REPAYMENT_STATUS_PAYEARLY:
				return '已提前结清';
			case LOAN_REPAYMENT_STATUS_OVERDUED:
				return '已逾期';
				
		}
	}

	static public function sellingChannelQueueStatusName($status){
		switch ($status) {
			case SCQ_STATUS_NORMAL:
				return '未处理';
			case SCQ_STATUS_DONE:
				return '已处理';
			case SCQ_STATUS_FAILED:
				return '处理失败';
			default:
				return '未定义';
				
		}
	}

}