<?php
/**
 * 消息推送帮助库
 * ====================================================
 * =====================================================
*/
!defined('MESSAGE_PUSH_PRODUCTION') && define('MESSAGE_PUSH_PRODUCTION', 0);

if(defined('MESSAGE_PUSH_PRODUCTION') && MESSAGE_PUSH_PRODUCTION){
	define('IOS_PUSH_ENTRY', 'ssl://gateway.push.apple.com:2195');
	define('IOS_PUSH_PEM', DIR_ETC . 'ck.pem');
	define('IOS_PUSH_PEM_PASS', 'yylc@2016iospem');
	// 2018-08-23 69豪车整合
	define('IOS_PUSH_PEM_69HC', DIR_ETC . 'ck69hc.pem');
	define('IOS_PUSH_PEM_PASS_69HC', 'mm180829');
}else{
	define('IOS_PUSH_ENTRY', 'ssl://gateway.sandbox.push.apple.com:2195');
	define('IOS_PUSH_PEM', DIR_ETC . 'ck.pem');
	define('IOS_PUSH_PEM_PASS', 'yylc@2016iospem');
	// 2018-08-23 69豪车整合
	define('IOS_PUSH_PEM_69HC', DIR_ETC . 'ck69hc.pem');
	define('IOS_PUSH_PEM_PASS_69HC', 'mm180829');
}

/**
* 
*/
class MsgpushLibrary
{
	protected $_timeout = 60;

	protected $_ios = null;
	protected $_android = null;

	public function __construct(){
		
	}

	/**
	 * 2018-08-23 69豪车整合
	 * 带上app参数进行初始化，不同的app，对应不同的证书
	 */
	public function androidOpen($app = APP_DEFAULT){
		return true;
	}
	public function androidClose(){
		// 2018-02-23
		// Bug Fix: 修正原来由于判断逻辑错误没有关闭句柄		
		if($this->_android){
			fclose($this->_android);
		}
		$this->_android = null;
	}
	public function androidPush($dev, $body){
		return false;
	}
	public function getAndroidBody(){
		return null;
	}

	/**
	 * 2018-08-23 69豪车整合
	 * 带上app参数进行初始化，不同的app，对应不同的证书
	 */
	public function iOSOpen($app = APP_DEFAULT){
		$ctx = stream_context_create();
		$pem = IOS_PUSH_PEM;
		$passphrase = IOS_PUSH_PEM_PASS;
		if ($app==APP_69HC) {
			$pem = IOS_PUSH_PEM_69HC;
			$passphrase = IOS_PUSH_PEM_PASS_69HC;
		}
		stream_context_set_option($ctx, 'ssl', 'local_cert', $pem);
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		$fp = stream_socket_client(IOS_PUSH_ENTRY, $err, $errstr, $this->_timeout, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
		if (!$fp) exit("Failed to connect: $err $errstr" . PHP_EOL);
		$this->_ios = $fp;
	}

	public function iOSClose(){
		// 2018-02-23
		// Bug Fix: 修正原来由于判断逻辑错误没有关闭句柄		
		if($this->_ios){
			fclose($this->_ios);
		}
		$this->_ios = null;
	}

	public function iOSPush($dev, $body, $app = APP_DEFAULT){
		if(!$this->_ios){
			$this->iOSOpen($app);
		}
		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $dev) . pack('n', strlen($payload)) . $payload;
		$result = fwrite($this->_ios, $msg, strlen($msg));
		// 2018-02-23
		// Enhanced: 增加重试逻辑
		if ($result==false) {
			// Try to solve issue :SSL operation failed with code 1. OpenSSL Error messages: error:1409F07F:SSL routines:SSL3_WRITE_PENDING:bad write retry. 
			usleep(100*1000);
			$result = fwrite($this->_ios, $msg, strlen($msg));
		}
		return $result;
		
	}

	public function getIOSBody( $msg, $title, $alert = '', $url = APP_INNERVIEW_RECOMMEND, $badge = 1, $method = APP_VIEW_METHOD_INNERVIEW, $sound = APP_PUSH_SOUND_NORMAL, $type = APP_PUSH_TYPE_NORMAL ){
		$message = array(
			'method' => $method
		,	'msg' => $msg
		,	'title' => $title
		,	'url' => $url
		);
		$body = array(
			'aps' => array(
				'alert' => $alert,
				'sound' => $sound,
				'badge' => $badge
			)
		);
		$body['type'] = $type;
		$body['data'] = $message;
		return $body;
	}

}