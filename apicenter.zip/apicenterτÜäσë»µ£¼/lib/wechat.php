<?php

class WechatLibrary{

	protected $cnf = array();
	
	protected $parameters = array();//请求参数，类型为关联数组
	protected $response;//微信返回的响应
	protected $result;//返回参数，类型为关联数组
	protected $url;//接口链接

	protected $data;//Server通知接口接收到的数据，类型为关联数组
	protected $returnParameters = array();//返回参数，类型为关联数组


	public function __construct() {
		$app = config_item('wechat');
		$this->cnf = $app;
		/*
		$this->cnf['id'] = $app['id'];
		$this->cnf['secret'] = $app['secret'];
		$this->cnf['persistent'] = $app['persistent'];
		$this->cnf['jsticket'] = $app['jsticket'];
		*/
	}
	
	public function changeConfToWeb(){
		$app = config_item('wechat');
		$this->cnf = $app;
	}

	public function changeConfToApp(){
		$app = config_item('wechat_app');
		$this->cnf = $app;
	}

	public function getMchId(){
		return $this->parameters["mch_id"];
	}

	/**
	 *	统一支付接口类
	 */
	public function unifiedOrder(){
		$this->url = "https://api.mch.weixin.qq.com/pay/unifiedorder";

		if(!isset($this->parameters["out_trade_no"]) || $this->parameters["out_trade_no"] == null) {
			echo "缺少统一支付接口必填参数out_trade_no！";
			return false;
		}elseif(!isset($this->parameters["body"]) || $this->parameters["body"] == null){
			echo "缺少统一支付接口必填参数body！";
			return false;
		}elseif (!isset($this->parameters["total_fee"]) || $this->parameters["total_fee"] == null ) {
			echo "缺少统一支付接口必填参数total_fee！";
			return false;
		}elseif (!isset($this->parameters["trade_type"]) || $this->parameters["trade_type"] == null) {
			echo "缺少统一支付接口必填参数trade_type！";
			return false;
		}elseif ($this->parameters["trade_type"] == "JSAPI" && (!isset($this->parameters["openid"]) || $this->parameters["openid"] == NULL)){
			echo "统一支付接口中，缺少必填参数openid！trade_type为JSAPI时，openid为必填参数！";
			return false;
		}
		if(!isset($this->parameters["time_start"])){
			$now = time();
			$this->parameters["time_start"] = date('YmdHis', $now);
			$this->parameters["time_expire"] = date('YmdHis', $now + 3660);
		}
		if(!isset($this->parameters["notify_url"])){
			$this->parameters["notify_url"] = $this->cnf['notify_url'];//通知地址
		}
		if(!isset($this->parameters["spbill_create_ip"])){
			$this->parameters["spbill_create_ip"] = $_SERVER['REMOTE_ADDR'];//终端ip	
		}
		return $this->getResult();
	}

	/**
	 *	获取prepay_id
	 */
	public function unifiedOrderGetPrepayId(){
		$result = $this->unifiedOrder();
		if(isset($result["prepay_id"])){
			return $result["prepay_id"];
		}else{
			return false;
		}
	}

	public function getPrepayJSObj( $prepay_id, $ts ){
		$obj = array();
		$obj["appId"] = $this->cnf['id'];
	    $obj["timeStamp"] = $ts;
	    $obj["nonceStr"] = $this->parameters['nonce_str'];
		$obj["package"] = "prepay_id=$prepay_id";
	    $obj["signType"] = "MD5";
	    $obj["paySign"] = $this->get_sign($obj);
	    return $obj;
	}

	public function getPrepayAppObj( $prepay_id, $ts ){
		$obj = array();
		$obj["appid"] = $this->cnf['id'];
		$obj["timestamp"] = $ts;
		$obj["noncestr"] = $this->parameters['nonce_str'];
		$obj["package"] = "Sign=WXPay";
		$obj["partnerid"] = $this->cnf['mchid'];
		$obj["prepayid"] = $prepay_id;
		$obj["sign"] = $this->get_sign($obj);
		return $obj;
	}
	/**
	 *	订单查询接口
	 */
	public function orderQuery(){
		$this->url = "https://api.mch.weixin.qq.com/pay/orderquery";

		if((!isset($this->parameters["out_trade_no"]) || $this->parameters["out_trade_no"] == null) &&  (!isset($this->parameters["transaction_id"]) || $this->parameters["transaction_id"] == null)){
			echo "订单查询接口中，out_trade_no、transaction_id至少填一个！";
			return false;
		}
		return $this->getResult();
	}

	/**
	 *	退款申请接口
	 */
	public function refund(){
		$this->url = "https://api.mch.weixin.qq.com/secapi/pay/refund";

		if((!isset($this->parameters["out_trade_no"]) || $this->parameters["out_trade_no"] == null) &&  (!isset($this->parameters["transaction_id"]) || $this->parameters["transaction_id"] == null)){
			echo "退款申请接口中，out_trade_no、transaction_id至少填一个！";
			return false;
		}elseif(!isset($this->parameters["out_refund_no"]) || $this->parameters["out_refund_no"] == null){
			echo "退款申请接口中，缺少必填参数out_refund_no！";
			return false;
		}elseif(!isset($this->parameters["total_fee"]) || $this->parameters["total_fee"] == null ) {
			echo "退款申请接口中，缺少必填参数total_fee！";
			return false;
		}elseif(!isset($this->parameters["refund_fee"]) || $this->parameters["refund_fee"] == null){
			echo "退款申请接口中，缺少必填参数refund_fee！";
			return false;
		}elseif(!isset($this->parameters["op_user_id"]) || $this->parameters["op_user_id"] == null){
			echo "退款申请接口中，缺少必填参数op_user_id！";
			return false;
		}
		return $this->getResultSSL();
	}

	/**
	 *	退款查询接口
	 */
	public function refundQuery(){
		$this->url = "https://api.mch.weixin.qq.com/pay/refundquery";
		
		if(	(!isset($this->parameters["out_refund_no"]) || $this->parameters["out_refund_no"] == null) &&
			(!isset($this->parameters["out_trade_no"]) || $this->parameters["out_trade_no"] == null) &&
			(!isset($this->parameters["transaction_id"]) || $this->parameters["transaction_id"] == null) &&
			(!isset($this->parameters["refund_id"]) || $this->parameters["refund_id "] == null) ){
			echo "退款查询接口中，out_refund_no、out_trade_no、transaction_id、refund_id四个参数必填一个！";
			return false;
		}
		return $this->getResultSSL();
	}

	/**
	 *	对账单接口
	 */
	public function downloadBill(){
		$this->url = "https://api.mch.weixin.qq.com/pay/downloadbill";

		if((!isset($this->parameters["bill_date"]) || $this->parameters["bill_date"] == null)){
			echo "对账单接口中，缺少必填参数bill_date！";
			return false;
		}
		return $this->getResult();
	}
	
	/**
	 *	短链接转换接口
	 */
	public function shortUrl(){
		$this->url = "https://api.mch.weixin.qq.com/tools/shorturl";

		if((!isset($this->parameters["long_url"]) || $this->parameters["long_url"] == null)){
			echo "短链接转换接口中，缺少必填参数long_url！";
			return false;
		}
		return $this->getResult();
	}
	public function shortUrlGet(){
		$result = $this->shortUrl();
		if(isset($result['short_url'])){
			return $result['short_url'];
		}else{
			return false;
		}
	}

	/**
	 *	响应型接口
	 *	校验获取数据
	 */
	public function notifyCheckSign(){
		$xml = file_get_contents("php://input");

		$this->data = $this->xml_to_array($xml);
		$tmp = $this->data;
		unset($tmp['sign']);
		$sign = $this->get_sign($tmp);//本地签名
		if ($sign && $this->data['sign'] == $sign) {
			return true;
		}
		return false;
	}
	public function notifyReturnXml(){
		return $this->array_to_xml($this->returnParameters);
	}
	/**
	 *	自动校验接收到的数据，并输出返回的数据。
	 */
	public function notifyAutoCheckSign(){
		$bool = $this->notifyCheckSign();
		if($bool == false){
			$this->setReturnParameter("return_code", "FAIL");//返回状态码
			$this->setReturnParameter("return_msg", "签名失败");//返回信息
		}else{
			$this->setReturnParameter("return_code","SUCCESS");//设置返回码
		}
		echo $this->notifyReturnXml();
		return $bool;
	}

	public function notifyCheckStatus(){
		$xml = file_get_contents("php://input");
		$bool = false;
		if($this->data['return_code'] == 'FAIL'){
			$str = "【通信出错】:\n".$xml."\n\n";
			$bool = false;
		}elseif($this->data['result_code'] == 'FAIL'){
			$str = "【业务出错】:\n".$xml."\n\n";
			$bool = false;
		}else{
			$str = "【支付成功】:\n".$xml."\n\n";
			$bool = true;
		}
		if(isset($this->cnf['noticelog']) && $this->cnf['noticelog']){
			file_put_contents($this->cnf['noticelog'], $str, FILE_APPEND);
		}
		return $bool;
	}

	public function notifyGetData(){
		return $this->data;
	}

	/**
	 *	静态链接二维码
	 *	生成Native支付链接
	 */
	public function createPayLink(){
		if(!isset($this->parameters["product_id"]) || $this->parameters["product_id"] == null){
			echo "缺少Native支付二维码链接必填参数product_id！";
			return false;
		}
		$this->parameters["appid"] = $this->cnf['id'];//公众账号ID
		$this->parameters["mch_id"] = $this->cnf['mchid'];//商户号
	   	$time_stamp = time();
	   	$this->parameters["time_stamp"] = "$time_stamp";//时间戳
	    $this->parameters["nonce_str"] = $this->create_nonce_str();//随机字符串
	    $this->parameters["sign"] = $this->get_sign($this->parameters);//签名
		$biz_string = $this->format_query_params($this->parameters, false);
		$this->url = "weixin://wxpay/bizpayurl?".$biz_string;
		return $this->url;
	}

	/**
	 *	获取微信JSAPI的sign package
	 */
	public function getSignPackage($timestamp = null, $noncestr = null) {
		$jsapiTicket = $this->get_js_api_ticket();
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		if(empty($timestamp))
			$timestamp = time();
		if(empty($noncestr))
			$nonceStr = $this->create_nonce_str();

		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

		$signature = sha1($string);

		$signPackage = array(
			"appId"     => $this->cnf['id'],
			"nonceStr"  => $nonceStr,
			"timestamp" => $timestamp,
			"url"       => $url,
			"signature" => $signature,
			"rawString" => $string
		);
		return $signPackage; 
	}

	/**
	 *	获取公众号的AccessToken
	 */
	public function getAccessToken() {
		$json = json_decode(file_get_contents($this->cnf['persistent']));
		if($json && $json->expire_time > time()){
			return $json->access_token;
		}
		// 如果是企业号用以下URL获取access_token
		// $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$this->cnf['id']&corpsecret=$this->cnf['secret']";
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$this->cnf['id']}&secret={$this->cnf['secret']}";
		$res = json_decode($this->http_get($url));
		$access_token = $res->access_token;
		if ($access_token) {
			$json = new stdClass();
			$json->expire_time = time() + 7000;
			$json->access_token = $access_token;
			$fp = fopen($this->cnf['persistent'], "wb");
		    fwrite($fp, json_encode($json));
		    fclose($fp);
		}
		return $access_token;
	}

	public function getUserinfo($openid){
		$access_token = $this->getAccessToken();
		$url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$openid}&lang=zh_CN";
		return json_decode($this->http_get($url), true);
	}

	public function getUserinfoAccess($access_token, $openid){
		$url = "https://api.weixin.qq.com/sns/userinfo?access_token={$access_token}&openid={$openid}";
		return json_decode($this->http_get($url), true);
	}


	/**
	 *	获取跳转到微信获取用户信息CODE的链接
	 */
	public function getWechatCodeURL(){
		$current_url = current_url();
		$ruri = urlencode( $current_url . (strpos($current_url, '?') ? '&' : '?') . "requested=1" );

		$ruri = urlencode( "http://m.meitoday.com/wechat_redirect.php?redirect=" . $ruri );
		$uri = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".
			$this->cnf['id']
			."&redirect_uri=".
			$ruri
			. "&scope=snsapi_base&response_type=code&state=".
			time()
			."#wechat_redirect";
		return $uri;
	}

	/**
	 *	用CODE获取微信用户的OpenID
	 */
	public function getOpenIDByCode( $code ){
		$res = $this->getOauthAccessTokenByCode( $code );
		if($res && $res->openid){
			return $res->openid;
		}
		return null;
	}

	/**
	 *	用CODE获取微信用户的unionid,openid
	 */
	public function getIDsByCode( $code ){
		$res = $this->getOauthAccessTokenByCode( $code );
		if($res && $res->unionid){
			return array('unionid' => $res->unionid, 'openid' => $res->openid );
		}
		return null;
	}

	protected function getOauthAccessTokenByCode( $code ){
		$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$this->cnf['id']}&secret={$this->cnf['secret']}&code={$code}&grant_type=authorization_code";
		return json_decode($this->http_get($url));
	}

	public function encryptOpenId( $id ){
		return $this->encrypt('MTE_' . $id, 'XVpatx81xG3Lm2nZ');
	}

	public function decryptOpenId( $str ){
		$str = $this->decrypt($str, 'XVpatx81xG3Lm2nZ');
		if(substr($str, 0, 4) != 'MTE_'){
			return false;
		}
		return substr($str, 4);
	}

	public function encrypt($string, $key) {
		$cipher_alg = MCRYPT_TRIPLEDES;
		$iv = mcrypt_create_iv(mcrypt_get_iv_size($cipher_alg,MCRYPT_MODE_ECB), MCRYPT_RAND);
		$encrypted_string = mcrypt_encrypt($cipher_alg, $key, $string, MCRYPT_MODE_ECB, $iv);
		return base64_encode($encrypted_string);
	}

	public function decrypt($string, $key) {
		$string = base64_decode($string);
		$cipher_alg = MCRYPT_TRIPLEDES;
		$iv = mcrypt_create_iv(mcrypt_get_iv_size($cipher_alg,MCRYPT_MODE_ECB), MCRYPT_RAND);
		$decrypted_string = mcrypt_decrypt($cipher_alg, $key, $string, MCRYPT_MODE_ECB, $iv);
		return trim($decrypted_string);
	}

	public function setParameter($parameter, $parameterValue){
		$this->parameters[$this->trim_string($parameter)] = $this->trim_string($parameterValue);
	}

	public function getParameters(){
		return $this->parameters;
	}

	/**
	 * 设置返回微信的xml数据
	 */
	public function setReturnParameter($parameter, $parameterValue)
	{
		$this->returnParameters[$this->trim_string($parameter)] = $this->trim_string($parameterValue);
	}
	

	/**
	 * 	作用：获取结果，默认不使用证书
	 */
	protected function getResult(){
		$this->post_xml();
		$this->result = $this->xml_to_array($this->response);
		return $this->result;
	}

	/**
	 * 	作用：获取结果，默认不使用证书
	 */
	protected function getResultSSL(){
		$this->post_xml_ssl();
		$this->result = $this->xml_to_array($this->response);
		return $this->result;
	}

	/** protected methods **/

	protected function http_get($url) {
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 500);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_URL, $url);

		$res = curl_exec($curl);
		curl_close($curl);

		return $res;
	}

	protected function trim_string($value){
		$ret = null;
		if (null !== $value){
			$ret = $value;
			if (strlen($ret) == 0){
				$ret = null;
			}
		}
		return $ret;
	}

	/**
	 * 	作用：格式化参数，签名过程需要使用
	 */
	protected function format_query_params($params, $urlencode = false){
		$buff = '';
		if(empty($params)){
			return null;
		}
		if(is_object($params)){
			$params = json_decode(json_encode($params), true);
		}
		if(!is_array($params)){
			return $params;
		}
		ksort($params, SORT_STRING);
		foreach ($params as $k => $v){
		    if($urlencode){
			   $v = urlencode($v);
			}
			$buff .= "{$k}={$v}&";
		}
		$res = null;
		if (strlen($buff) > 0)
		{
			$res = substr($buff, 0, -1);
		}
		return $res;
	}
	
	/**
	 * 	作用：生成签名
	 */
	protected function get_sign($arr){
		if(!is_array($arr) && !is_object($arr)){
			return '';
		}
		$params = array();
		foreach ($arr as $k => $v)
		{
			$params[$k] = $v;
		}
		//签名步骤一：按字典序排序参数
		ksort($params, SORT_STRING);
		$str = $this->format_query_params($params, false);
		//签名步骤二：在str后加入KEY
		$str = $str . "&key=".$this->cnf['mchkey'];
		//签名步骤三：MD5加密
		$str = md5($str);
		//签名步骤四：所有字符转为大写
		$res = strtoupper($str);
		return $res;
	}

	/**
	* 	作用：array转xml
	*/
	protected function array_to_xml($arr){
		$xml = "<xml>";
		foreach ($arr as $key=>$val){
			if (is_numeric($val)){
				$xml .= "<{$key}>{$val}</{$key}>";
			}else{
				$xml .= "<{$key}><![CDATA[{$val}]]></{$key}>";
			}
		}
		$xml .= "</xml>";
		return $xml; 
	}

	/**
	 * 	作用：将xml转为array
	 */
	protected function xml_to_array($xml){
		//将XML转为array        
		$arr = json_decode( json_encode( simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NOCDATA ) ), true );
		return $arr;
	}

	/**
	 * 	作用：以post方式提交xml到对应的接口url
	 */
	protected function post_xml_curl($xml, $url, $second=30){
		//初始化curl
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		//这里设置代理，如果有的话
		//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
		//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		//设置header
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		//post提交方式
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		//运行curl
		$data = curl_exec($ch);
		//curl_close($ch);
		//返回结果
		if($data){
			curl_close($ch);
			if(isset($this->cnf['netlog']) && $this->cnf['netlog']){
				file_put_contents($this->cnf['netlog'], 'POST:' . $xml . "\n\n", FILE_APPEND);
				file_put_contents($this->cnf['netlog'], $data . "\n\n", FILE_APPEND);
			}
			return $data;
		}else{ 
			$error = curl_errno($ch);
			$data = "curl出错，错误码:$error ";
			if(isset($this->cnf['netlog']) && $this->cnf['netlog']){
				file_put_contents($this->cnf['netlog'], 'POST:' . $xml . "\n\n", FILE_APPEND);
				file_put_contents($this->cnf['netlog'], $data . "\n\n", FILE_APPEND);
			}
			curl_close($ch);
			return false;
		}
	}

	/**
	 * 	作用：使用证书，以post方式提交xml到对应的接口url
	 */
	protected function post_xml_ssl_curl($xml, $url, $second=30){
		$ch = curl_init();
		//超时时间
		curl_setopt($ch,CURLOPT_TIMEOUT,$second);
		//这里设置代理，如果有的话
		//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
		//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		//设置header
		curl_setopt($ch,CURLOPT_HEADER,FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
		//设置证书
		//使用证书：cert 与 key 分别属于两个.pem文件
		//默认格式为PEM，可以注释
		curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
		curl_setopt($ch,CURLOPT_SSLCERT, $this->cnf['sslcert']);
		//默认格式为PEM，可以注释
		curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
		curl_setopt($ch,CURLOPT_SSLKEY, $this->cnf['sslkey']);
		//post提交方式
		curl_setopt($ch,CURLOPT_POST, true);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$xml);
		$data = curl_exec($ch);
		//返回结果
		if($data){
			curl_close($ch);
			if(isset($this->cnf['netlog']) && $this->cnf['netlog']){
				file_put_contents($this->cnf['netlog'], 'POST:' . $xml . "\n\n", FILE_APPEND);
				file_put_contents($this->cnf['netlog'], $data . "\n\n", FILE_APPEND);
			}
			return $data;
		}
		else { 
			$error = curl_errno($ch);
			$data = "curl出错，错误码:$error ";
			if(isset($this->cnf['netlog']) && $this->cnf['netlog']){
				file_put_contents($this->cnf['netlog'], 'POST:' . $xml . "\n\n", FILE_APPEND);
				file_put_contents($this->cnf['netlog'], $data . "\n\n", FILE_APPEND);
			}
			curl_close($ch);
			return false;
		}
	}
	
	/**
	 * 	作用：设置标配的请求参数，生成签名，生成接口参数xml
	 */
	protected function create_xml(){
		$this->parameters["appid"] = $this->cnf['id'];//公众账号ID
		$this->parameters["mch_id"] = $this->cnf['mchid'];//商户号
		$this->parameters["nonce_str"] = $this->create_nonce_str();//随机字符串
		$this->parameters["sign"] = $this->get_sign($this->parameters);//签名
		return  $this->array_to_xml($this->parameters);
	}
	
	/**
	 * 	作用：post请求xml
	 */
	protected function post_xml(){
		$xml = $this->create_xml();
		$this->response = $this->post_xml_curl($xml, $this->url, $this->cnf['curl_timeout']);
		return $this->response;
	}
	
	/**
	 * 	作用：使用证书post请求xml
	 */
	protected function post_xml_ssl(){
		$xml = $this->create_xml();
		$this->response = $this->post_xml_ssl_curl($xml, $this->url, $this->cnf['curl_timeout']);
		return $this->response;
	}

	protected function create_nonce_str($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		$charposmax = strlen($chars) - 1;
		for ($i = 0; $i < $length; $i++) {
			$str .= $chars[mt_rand(0, $charposmax)];
		}
		return $str;
	}

	protected function get_js_api_ticket() {
		$json = json_decode(file_get_contents($this->cnf['jsticket']));

		if($json && $json->expire_time > time()){
			return $json->jsapi_ticket;
		}
		$accessToken = $this->getAccessToken();
		// 如果是企业号用以下 URL 获取 ticket
		// $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
		$url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
		$res = json_decode($this->http_get($url));
		$ticket = $res->ticket;
		if ($ticket) {
			$json = new stdClass();
			$json->expire_time = time() + 7000;
			$json->jsapi_ticket = $ticket;
	        $fp = fopen($this->cnf['jsticket'], "wb");
	        fwrite($fp, json_encode($json));
	        fclose($fp);
		}

		return $ticket;
	}
}
