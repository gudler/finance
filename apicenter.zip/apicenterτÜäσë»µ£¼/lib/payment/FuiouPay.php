<?php
/**
 * 富友支付帮助库
 * ====================================================
 * 接口分两种类型：
 * 【请求型接口】--FuiouPay_client_
 * 		商户订单创建接口类--CreateOrder
 * 		查询接口--OrderQuery
 * 【响应型接口】--FuiouPay_server_
 * 		通用通知接口--Notify
 * =====================================================
 * 【CommonUtil】常用工具：
 * 		trim()，设置参数时需要用到的字符处理函数
 * 		getSign(),生成签名
 * 		arrayToXml(),array转xml
 * 		xmlToArray(),xml转 array
 * 		postXmlCurl(),以post方式提交xml到对应的接口url
 * 		postXmlSSLCurl(),使用证书，以post方式提交xml到对应的接口url
*/
!defined('FUIOUPAY_PRODUCTION') && define('FUIOUPAY_PRODUCTION', 0);

if(defined('FUIOUPAY_PRODUCTION') && FUIOUPAY_PRODUCTION){
	//define('FUIOUPAY_API_ROOT', 'https://mpay.fuiou.com:16128');
	//define('FUIOUPAY_API_WITHDRAW_ROOT', 'https://fht-api.fuiou.com');
	//2019-05-21 富友更换新域名
	define('FUIOUPAY_API_ROOT', 'https://mpay.fuioupay.com:16128');
	define('FUIOUPAY_API_WITHDRAW_ROOT', 'https://fht-api.fuioupay.com');
}else{
	//define('FUIOUPAY_API_ROOT', 'http://www-1.fuiou.com:18670/mobile_pay');
	// 2018-03-27 原来的接口没有回复了，新的接口
	//define('FUIOUPAY_API_WITHDRAW_ROOT', 'https://fht-test.fuiou.com/fuMer/req.do');
	//2019-05-21 富友更换新域名
	define('FUIOUPAY_API_ROOT', 'http://www-1.fuioupay.com:18670/mobile_pay');
	define('FUIOUPAY_API_WITHDRAW_ROOT', 'https://fht-test.fuioupay.com/fuMer/req.do');
}

function FPayLog($data){
	// return true;
	file_put_contents(PATH_PAYMENT_NETWORK_LOG, date('Y-m-d H:i:s'). "\n" . $data . "\n", FILE_APPEND);
}

function FPayDie($data){
	// return true;
	file_put_contents(PATH_PAYMENT_NETWORK_LOG . '.die', date('Y-m-d H:i:s'). "\n" . $data . "\n", FILE_APPEND);
	die();
}

class  FPSDKRuntimeException extends Exception {
	public function errorMessage(){
		return $this->getMessage();
	}

}

/**
 * 所有接口的基类
 */
class FPCommon_util_pub
{
	public function __construct() {
	}

	protected function trim($str){
		$str = trim($str);
		return $str;
	}
	/**
	 * 	作用：array转xml
	 */
	protected function arrayToXml($arr){
		$xml = "<FM>";
		foreach ($arr as $key => $val){
			$xml .= "<".$key.">".$val."</".$key.">";
		}
		$xml .= "</FM>";
		return $xml;
	}

	/**
	 * 	作用：将xml转为array
	 */
	protected function xmlToArray($xml){
		//将XML转为array
		return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
	}

	/**
	 * 	作用：以post方式提交xml到对应的接口url
	 */
	protected function postXmlCurl($xml,$url,$second=30){
		//初始化curl
			$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		//这里设置代理，如果有的话
		//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
		//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		//设置header
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		//post提交方式
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		//运行curl
		$data = curl_exec($ch);
		//curl_close($ch);
		//返回结果
		// file_put_contents(PATH_PAYMENT_NETWORK_LOG, $data . "\n\n", FILE_APPEND);
		FPayLog($data);
		if($data){
			curl_close($ch);
			return $data;
		} else {
			$error = curl_errno($ch);
			echo "curl出错，错误码:$error"."<br>";
			echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
			curl_close($ch);
			return false;
		}
	}

	/**
	 * 	作用：使用证书，以post方式提交xml到对应的接口url
	 */
	protected function postXmlSSLCurl($xml,$url,$second=30){
		$ch = curl_init();
		//超时时间
		curl_setopt($ch,CURLOPT_TIMEOUT,$second);
		//这里设置代理，如果有的话
		//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
		//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		//设置header
		curl_setopt($ch,CURLOPT_HEADER,FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
		//设置证书
		//使用证书：cert 与 key 分别属于两个.pem文件
		//默认格式为PEM，可以注释
		curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');

		$cnf = config_item('payment_fuiou');

		curl_setopt($ch,CURLOPT_SSLCERT, $cnf['sslcert']);
		//默认格式为PEM，可以注释
		curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
		curl_setopt($ch,CURLOPT_SSLKEY, $cnf['sslkey']);
		//post提交方式
		curl_setopt($ch,CURLOPT_POST, true);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$xml);
		$data = curl_exec($ch);
		//返回结果
		if($data){
			curl_close($ch);
			return $data;
		} else {
			$error = curl_errno($ch);
			echo "curl出错，错误码:$error"."<br>";
			echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
			curl_close($ch);
			return false;
		}
	}

	protected function getSign($kvarr, $orders){
		$cnf = config_item('payment_fuiou');
		$mchkey = $cnf['mchkey'];
		//Rcd+"|"+ OSsn +"|"+ CardNo +"|"+ MchntCd+"|"+ Ver+"|"+mchnt_key
		if(!is_array($orders)){
			$orders = explode("|", $orders);
		}
		$md5str = '';
		foreach ($orders as $key) {
			// 2018-03-16
			// '{"Sign":"94b7025fda95bb165db0e1cbacafd839","Rcd":"10001M","RDesc":"\u624b\u7eed\u8d39\u8d26\u6237\u4f59\u989d\u4e0d\u8db3","OSsn":[],"MchntCd":"0002900F0283799","CardNo":"6212261001031747881","Ver":"1.30"}'
			// 由于上面数据中的OSsn是一个空数组（原始的xml中是一个空节点）,如果直接取值转换为字符串(.操作)，显示为'array'，
			// 最后导致得到的签名同原来的不一样，所以加一个判断
			$value = $kvarr[$key];
			if (is_array($value)){
				$value = '';
			}
			$md5str .= $value . '|';
		}
		$md5str .= $mchkey;

		$md5 = md5($md5str);
		//file_put_contents(DIR_LOG . 'fuiou.sign.log', $md5str . "\n" . $md5 . "\n\n" , FILE_APPEND);
		return $md5;
	}

	/**
	 * 	作用：打印数组
	 */
	protected function printErr($wording='',$err=''){
		print_r('<pre>');
		echo $wording."</br>";
		var_dump($err);
		print_r('</pre>');
	}

	public function bankCodeName($code = null){
		static $map = array(
			'0102' => '中国工商银行',
			'0103' => '中国农业银行',
			'0104' => '中国银行',
			'0105' => '中国建设银行',
			'0301' => '交通银行',
			'0308' => '招商银行',
			'0309' => '兴业银行',
			'0305' => '中国民生银行',
			'0306' => '广东发展银行',
			'0307' => '平安银行股份有限公司',
			'0310' => '上海浦东发展银行',
			'0304' => '华夏银行',
			'0313' => '其他城市商业银行',
			'1401' => '邯郸市城市信用社',
			'0314' => '其他农村商业银行',
			'0315' => '恒丰银行',
			'0403' => '国家邮政局邮政储汇局',
			'0303' => '中国光大银行',
			'0302' => '中信实业银行',
			'0316' => '浙商银行股份有限公司',
			'0318' => '渤海银行股份有限公司',
			'0423' => '杭州市商业银行',
			'0412' => '温州市商业银行',
			'0424' => '南京市商业银行',
			'0461' => '长沙市商业银行',
			'0409' => '济南市商业银行',
			'0422' => '石家庄市商业银行',
			'0458' => '西宁市商业银行',
			'0404' => '烟台市商业银行',
			'0462' => '潍坊市商业银行',
			'0515' => '德州市商业银行',
			'0431' => '临沂市商业银行',
			'0481' => '威海商业银行',
			'0497' => '莱芜市商业银行',
			'0450' => '青岛市商业银行',
			'0319' => '徽商银行',
			'0322' => '上海农村商业银行'
			);
		if(null === $code){
			return $map;
		}
		if(isset($map[$code])){
			return $map[$code];
		}
		return $code;
	}

	public function bankNameCode($name = null){
		static $map = array(
			'中国工商银行' => '0102',
			'工商银行' => '0102',
			'中国农业银行' => '0103',
			'农业银行' => '0103',
			'中国银行' => '0104',
			'中国建设银行' => '0105',
			'建设银行' => '0105',
			'中国交通银行' => '0301',
			'交通银行' => '0301',
			'招商银行' => '0308',
			'兴业银行' => '0309',
			'中国民生银行' => '0305',
			'民生银行' => '0305',
			'广东发展银行' => '0306',
			'广发银行' => '0306',
			'平安银行股份有限公司' => '0307',
			'平安银行' => '0307',
			'上海浦东发展银行' => '0310',
			'浦东发展银行' => '0310',
			'浦发银行' => '0310',
			'华夏银行' => '0304',
			'其他城市商业银行' => '0313',
			'邯郸市城市信用社' => '1401',
			'其他农村商业银行' => '0314',
			'恒丰银行' => '0315',
			'中国邮政储蓄银行股份有限公司' => '0403',
			'国家邮政局邮政储汇局' => '0403',
			'邮政储汇' => '0403',
			'邮储银行北京分行' => '0403',
			'邮储银行天津分行' => '0403',
			'邮储银行河北分行' => '0403',
			'邮储银行山西分行' => '0403',
			'邮储银行内蒙古分行' => '0403',
			'邮储银行辽宁分行' => '0403',
			'邮储银行吉林分行' => '0403',
			'邮储银行黑龙江分行' => '0403',
			'邮储银行上海分行' => '0403',
			'邮储银行江苏分行' => '0403',
			'邮储银行浙江分行' => '0403',
			'邮储银行安徽分行' => '0403',
			'邮储银行福建分行' => '0403',
			'邮储银行江西分行' => '0403',
			'邮储银行山东分行' => '0403',
			'邮储银行河南分行' => '0403',
			'邮储银行湖北分行' => '0403',
			'邮储银行湖南分行' => '0403',
			'邮储银行广东分行' => '0403',
			'邮储银行广西分行' => '0403',
			'邮储银行海南分行' => '0403',
			'邮储银行重庆分行' => '0403',
			'邮储银行四川分行' => '0403',
			'邮储银行贵州分行' => '0403',
			'邮储银行云南分行' => '0403',
			'邮储银行西藏分行' => '0403',
			'邮储银行陕西分行' => '0403',
			'邮储银行甘肃分行' => '0403',
			'邮储银行青海分行' => '0403',
			'邮储银行宁夏分行' => '0403',
			'邮储银行新疆分行' => '0403',
			'邮储银行大连分行' => '0403',
			'邮储银行宁波分行' => '0403',
			'邮储银行厦门分行' => '0403',
			'邮储银行青岛分行' => '0403',
			'邮储银行深圳分行' => '0403',
			'邮政储蓄银行' => '0403',
			'邮储银行' => '0403',
			'中国邮政储蓄' => '0403',
			'邮政储蓄' => '0403',
			'中国光大银行' => '0303',
			'光大银行' => '0303',
			'中信实业银行' => '0302',
			'中信银行' => '0302',
			'浙商银行股份有限公司' => '0316',
			'浙商银行' => '0316',
			'渤海银行股份有限公司' => '0318',
			'渤海银行' => '0318',
			'杭州市商业银行' => '0423',
			'温州市商业银行' => '0412',
			'南京市商业银行' => '0424',
			'长沙市商业银行' => '0461',
			'济南市商业银行' => '0409',
			'石家庄市商业银行' => '0422',
			'西宁市商业银行' => '0458',
			'烟台市商业银行' => '0404',
			'潍坊市商业银行' => '0462',
			'德州市商业银行' => '0515',
			'临沂市商业银行' => '0431',
			'威海商业银行' => '0481',
			'莱芜市商业银行' => '0497',
			'青岛市商业银行' => '0450',
			'徽商银行' => '0319',
			'上海农村商业银行' => '0322',
			// 2017-09-27 增加北京银行和上海银行，归纳到其他城市商业银行
			// 0313    其他城市商业银行  (北京银行、上海银行)
			'上海银行' => '0313',
			'北京银行' => '0313',
			);
		if(null === $name){
			return $map;
		}
		if(isset($map[$name])){
			return $map[$name];
		}
		$prefix = mb_substr($name, 0, 2);
		if($prefix == '工行'){
			return '0102';
		}
		if(in_array($prefix, array('邮储', '邮政'))){
			return '0403';
		}
		if (false !== strpos($name, '农村商业银行')) {
			return '0314';
		}
		return $name;
	}

	public function cityCodeName($code = null){
		static $map = array(
			'1000' => '北京市',
			'1100' => '天津市',
			'1340' => '保定市',
			'1430' => '沧州市',
			'1410' => '承德市',
			'1270' => '邯郸市',
			'1480' => '衡水市',
			'1460' => '廊坊市',
			'1260' => '秦皇岛市',
			'1210' => '石家庄市',
			'1240' => '唐山市',
			'1310' => '邢台市',
			'1380' => '张家口市',
			// '1660' => '长治市',
			'1620' => '大同市',
			'1680' => '晋城市',
			'1750' => '晋中市',
			'1770' => '临汾市',
			'1730' => '吕梁市',
			'1690' => '朔州市',
			'1610' => '太原市',
			'1710' => '忻州市',
			'1630' => '阳泉市',
			'1810' => '运城市',
			'2080' => '阿拉善盟',
			'2070' => '巴彦淖尔市',
			'1920' => '包头市',
			'1940' => '赤峰市',
			'2050' => '鄂尔多斯市',
			'1910' => '呼和浩特市',
			'1960' => '呼伦贝尔市',
			'1990' => '通辽市',
			'1930' => '乌海市',
			'2030' => '乌兰察布市',
			'2010' => '锡林郭勒盟',
			'1980' => '兴安盟',
			'2230' => '鞍山市',
			'2250' => '本溪市',
			'2340' => '朝阳市',
			'2220' => '大连市',
			'2260' => '丹东市',
			'2240' => '抚顺市',
			'2290' => '阜新市',
			'2276' => '葫芦岛市',
			'2270' => '锦州市',
			'2310' => '辽阳市',
			'2320' => '盘锦市',
			'2210' => '沈阳市',
			'2330' => '铁岭市',
			'2280' => '营口市',
			'2470' => '白城市',
			'2460' => '白山市',
			'2410' => '长春市',
			'2420' => '吉林市',
			'2440' => '辽源市',
			'2430' => '四平市',
			'2520' => '松原市',
			'2450' => '通化市',
			'2490' => '延边朝鲜族自治州',
			'2650' => '大庆市',
			'2790' => '大兴安岭地区',
			'2610' => '哈尔滨市',
			'2670' => '鹤岗市',
			'2780' => '黑河市',
			'2660' => '鸡西市',
			'2690' => '佳木斯市',
			'2720' => '牡丹江市',
			'2740' => '七台河市',
			'2640' => '齐齐哈尔市',
			'2680' => '双鸭山市',
			'2760' => '绥化市',
			'2710' => '伊春市',
			'2900' => '上海市',
			'3040' => '常州市',
			'3080' => '淮安市',
			'3070' => '连云港市',
			'3010' => '南京市',
			'3060' => '南通市',
			'3050' => '苏州市',
			'3090' => '宿迁市',
			'3128' => '泰州市',
			'3020' => '无锡市',
			'3030' => '徐州市',
			'3110' => '盐城市',
			'3120' => '扬州市',
			'3140' => '镇江市',
			'3310' => '杭州市',
			'3360' => '湖州市',
			'3350' => '嘉兴市',
			'3380' => '金华市',
			'3430' => '丽水市',
			'3320' => '宁波市',
			'3370' => '绍兴市',
			'3450' => '台州市',
			'3330' => '温州市',
			'3420' => '舟山市',
			'3410' => '衢州市',
			'3680' => '安庆市',
			'3630' => '蚌埠市',
			'3781' => '巢湖市',
			'3790' => '池州市',
			'3750' => '滁州市',
			'3720' => '阜阳市',
			'3610' => '合肥市',
			'3660' => '淮北市',
			'3640' => '淮南市',
			'3710' => '黄山市',
			'3760' => '六安市',
			'3650' => '马鞍山市',
			'3740' => '宿州市',
			'3670' => '铜陵市',
			'3620' => '芜湖市',
			'3771' => '宣城市',
			'3722' => '亳州市',
			'3910' => '福州市',
			'4050' => '龙岩市',
			'4010' => '南平市',
			'4030' => '宁德市',
			'3940' => '莆田市',
			'3970' => '泉州市',
			'3950' => '三明市',
			'3930' => '厦门市',
			'3990' => '漳州市',
			'4370' => '抚州市',
			'4280' => '赣州市',
			'4350' => '吉安市',
			'4220' => '景德镇市',
			'4240' => '九江市',
			'4210' => '南昌市',
			'4230' => '萍乡市',
			'4330' => '上饶市',
			'4260' => '新余市',
			'4310' => '宜春市',
			'4270' => '鹰潭市',
			'4660' => '滨州市',
			'4680' => '德州市',
			'4550' => '东营市',
			'4750' => '菏泽市',
			'4510' => '济南市',
			'4610' => '济宁市',
			'4634' => '莱芜市',
			'4710' => '聊城市',
			'4730' => '临沂市',
			'4520' => '青岛市',
			'4732' => '日照市',
			'4630' => '泰安市',
			'4650' => '威海市',
			'4580' => '潍坊市',
			'4560' => '烟台市',
			'4540' => '枣庄市',
			'4530' => '淄博市',
			'4960' => '安阳市',
			'4970' => '鹤壁市',
			// '5120' => '济源市',
			'5010' => '焦作市',
			'4920' => '开封市',
			'4930' => '洛阳市',
			'5130' => '南阳市',
			'4950' => '平顶山市',
			'5050' => '三门峡市',
			'5060' => '商丘市',
			'4980' => '新乡市',
			'5150' => '信阳市',
			'5030' => '许昌市',
			'4910' => '郑州市',
			'5080' => '周口市',
			'5110' => '驻马店市',
			'5040' => '漯河市',
			'5020' => '濮阳市',
			'5310' => '鄂州市',
			'5410' => '恩施土家族苗族自治州',
			'5330' => '黄冈市',
			'5220' => '黄石市',
			'5320' => '荆门市',
			'5370' => '荆州市',
			'5375' => '潜江市',
			'5311' => '神农架林区',
			'5230' => '十堰市',
			'5286' => '随州市',
			'5374' => '天门市',
			'5210' => '武汉市',
			'5371' => '仙桃市',
			'5360' => '咸宁市',
			'5280' => '襄阳市',
			'5350' => '孝感市',
			'5260' => '宜昌市',
			'5580' => '常德市',
			'5510' => '长沙市',
			'5630' => '郴州市',
			'5540' => '衡阳市',
			'5670' => '怀化市',
			'5620' => '娄底市',
			'5550' => '邵阳市',
			'5530' => '湘潭市',
			'5690' => '湘西土家族苗族自治州',
			'5610' => '益阳市',
			'5650' => '永州市',
			'5570' => '岳阳市',
			'5590' => '张家界市',
			'5520' => '株洲市',
			'5869' => '潮州市',
			'6020' => '东莞市',
			'5880' => '佛山市',
			'5810' => '广州市',
			'5980' => '河源市',
			'5950' => '惠州市',
			'5890' => '江门市',
			'5865' => '揭阳市',
			'5920' => '茂名市',
			'5960' => '梅州市',
			'6010' => '清远市',
			'5860' => '汕头市',
			'5970' => '汕尾市',
			'5820' => '韶关市',
			'5840' => '深圳市',
			'5990' => '阳江市',
			'5937' => '云浮市',
			'5910' => '湛江市',
			'5930' => '肇庆市',
			'6030' => '中山市',
			'5850' => '珠海市',
			'6261' => '百色市',
			'6230' => '北海市',
			'6128' => '崇左市',
			'6330' => '防城港市',
			'6170' => '桂林市',
			'6242' => '贵港市',
			'6281' => '河池市',
			'6225' => '贺州市',
			'6155' => '来宾市',
			'6140' => '柳州市',
			'6110' => '南宁市',
			'6311' => '钦州市',
			'6210' => '梧州市',
			'6240' => '玉林市',
			'6432' => '白沙黎族自治县',
			'6437' => '保亭黎族苗族自治县',
			'6433' => '昌江黎族自治县',
			'6428' => '澄迈县',
			'6426' => '定安县',
			'6434' => '东方市',
			'6410' => '海口市',
			'6435' => '乐东黎族自治县',
			'6429' => '临高县',
			'6436' => '陵水黎族自治县',
			'6441' => '南沙群岛',
			'6424' => '琼海市',
			'6438' => '琼中黎族苗族自治县',
			'6420' => '三亚市',
			'6427' => '屯昌县',
			// '6425' => '万宁市',
			'6423' => '文昌市',
			'6421' => '五指山市',
			'6439' => '西沙群岛',
			'6442' => '中沙群岛的岛礁及其海域',
			'6431' => '儋州市',
			'6530' => '重庆市',
			'6790' => '阿坝藏族羌族自治州',
			'6758' => '巴中市',
			'6510' => '成都市',
			'6750' => '达州市',
			'6580' => '德阳市',
			'6810' => '甘孜藏族自治州',
			'6737' => '广安市',
			'6610' => '广元市',
			'6650' => '乐山市',
			'6840' => '凉山彝族自治州',
			'6652' => '眉山市',
			'6590' => '绵阳市',
			'6730' => '南充市',
			'6630' => '内江市',
			'6560' => '攀枝花市',
			'6620' => '遂宁市',
			'6770' => '雅安市',
			'6710' => '宜宾市',
			// '6780' => '资阳市',
			'6550' => '自贡市',
			'6570' => '泸州市',
			'7110' => '安顺市',
			'7090' => '毕节地区',
			'7010' => '贵阳市',
			'7020' => '六盘水市',
			'7130' => '黔东南苗族侗族自治州',
			'7150' => '黔南布依族苗族自治州',
			'7070' => '黔西南布依族苗族自治州',
			'7050' => '铜仁地区',
			'7030' => '遵义市',
			'7530' => '保山市',
			'7380' => '楚雄彝族自治州',
			'7510' => '大理白族自治州',
			'7540' => '德宏傣族景颇族自治州',
			'7570' => '迪庆藏族自治州',
			'7430' => '红河哈尼族彝族自治州',
			'7310' => '昆明市',
			'7550' => '丽江市',
			'7580' => '临沧市',
			'7560' => '怒江傈僳族自治州',
			'7470' => '普洱市',
			'7360' => '曲靖市',
			'7450' => '文山壮族苗族自治州',
			'7490' => '西双版纳傣族自治州',
			'7410' => '玉溪市',
			'7340' => '昭通市',
			'7810' => '阿里地区',
			'7720' => '昌都地区',
			'7700' => '拉萨市',
			'7830' => '林芝地区',
			'7790' => '那曲地区',
			'7760' => '日喀则地区',
			'7740' => '山南地区',
			'8010' => '安康市',
			'7930' => '宝鸡市',
			'7990' => '汉中市',
			'8030' => '商洛市',
			'7920' => '铜川市',
			'7970' => '渭南市',
			'7910' => '西安市',
			'7950' => '咸阳市',
			'8040' => '延安市',
			'8060' => '榆林市',
			'8240' => '白银市',
			'8290' => '定西市',
			'8380' => '甘南藏族自治州',
			'8220' => '嘉峪关市',
			'8230' => '金昌市',
			'8260' => '酒泉市',
			'8210' => '兰州市',
			'8360' => '临夏回族自治州',
			'8310' => '陇南市',
			'8330' => '平凉市',
			'8340' => '庆阳市',
			'8250' => '天水市',
			'8280' => '武威市',
			'8270' => '张掖市',
			'8570' => '果洛藏族自治州',
			'8540' => '海北藏族自治州',
			'8520' => '海东地区',
			'8560' => '海南藏族自治州',
			'8590' => '海西蒙古族藏族自治州',
			'8550' => '黄南藏族自治州',
			'8510' => '西宁市',
			'8580' => '玉树藏族自治州',
			'8741' => '固原市',
			'8720' => '石嘴山市',
			'8731' => '吴忠市',
			'8710' => '银川市',
			'8750' => '中卫市',
			'8910' => '阿克苏地区',
			'9031' => '阿拉尔市',
			'9020' => '阿勒泰地区',
			'8880' => '巴音郭楞蒙古自治州',
			'8870' => '博尔塔拉蒙古自治州',
			'8850' => '昌吉回族自治州',
			'8840' => '哈密地区',
			'8960' => '和田地区',
			'8940' => '喀什地区',
			'8820' => '克拉玛依市',
			'8930' => '克孜勒苏柯尔克孜自治州',
			'9028' => '石河子市',
			'9010' => '塔城地区',
			'9032' => '图木舒克市',
			'8830' => '吐鲁番地区',
			'8810' => '乌鲁木齐市',
			'9060' => '五家渠市',
			'8980' => '伊犁哈萨克自治州',
			'9910' => '台湾省',
			'9920' => '香港特别行政区',
			'9930' => '澳门特别行政区'
			);
		if(null === $code){
			return $map;
		}
		if(isset($map[$code])){
			return $map[$code];
		}
		return $code;
	}

	public function cityNameCode($name){
		static $map = array(
			'北京市' => '1000',
			'天津市' => '1100',
			'保定市' => '1340',
			'沧州市' => '1430',
			'承德市' => '1410',
			'邯郸市' => '1270',
			'衡水市' => '1480',
			'廊坊市' => '1460',
			'秦皇岛市' => '1260',
			'石家庄市' => '1210',
			'唐山市' => '1240',
			'邢台市' => '1310',
			'张家口市' => '1380',
			// '长治市' => '1660',
			'大同市' => '1620',
			'晋城市' => '1680',
			'晋中市' => '1750',
			'临汾市' => '1770',
			'吕梁市' => '1730',
			'朔州市' => '1690',
			'太原市' => '1610',
			'忻州市' => '1710',
			'阳泉市' => '1630',
			'运城市' => '1810',
			'阿拉善盟' => '2080',
			'巴彦淖尔市' => '2070',
			'包头市' => '1920',
			'赤峰市' => '1940',
			'鄂尔多斯市' => '2050',
			'呼和浩特市' => '1910',
			'呼伦贝尔市' => '1960',
			'通辽市' => '1990',
			'乌海市' => '1930',
			'乌兰察布市' => '2030',
			'锡林郭勒盟' => '2010',
			'兴安盟' => '1980',
			'鞍山市' => '2230',
			'本溪市' => '2250',
			'朝阳市' => '2340',
			'大连市' => '2220',
			'丹东市' => '2260',
			'抚顺市' => '2240',
			'阜新市' => '2290',
			'葫芦岛市' => '2276',
			'锦州市' => '2270',
			'辽阳市' => '2310',
			'盘锦市' => '2320',
			'沈阳市' => '2210',
			'铁岭市' => '2330',
			'营口市' => '2280',
			'白城市' => '2470',
			'白山市' => '2460',
			'长春市' => '2410',
			'吉林市' => '2420',
			'辽源市' => '2440',
			'四平市' => '2430',
			'松原市' => '2520',
			'通化市' => '2450',
			'延边朝鲜族自治州' => '2490',
			'大庆市' => '2650',
			'大兴安岭地区' => '2790',
			'哈尔滨市' => '2610',
			'鹤岗市' => '2670',
			'黑河市' => '2780',
			'鸡西市' => '2660',
			'佳木斯市' => '2690',
			'牡丹江市' => '2720',
			'七台河市' => '2740',
			'齐齐哈尔市' => '2640',
			'双鸭山市' => '2680',
			'绥化市' => '2760',
			'伊春市' => '2710',
			'上海市' => '2900',
			'常州市' => '3040',
			'淮安市' => '3080',
			'连云港市' => '3070',
			'南京市' => '3010',
			'南通市' => '3060',
			'苏州市' => '3050',
			'宿迁市' => '3090',
			'泰州市' => '3128',
			'无锡市' => '3020',
			'徐州市' => '3030',
			'盐城市' => '3110',
			'扬州市' => '3120',
			'镇江市' => '3140',
			'杭州市' => '3310',
			'湖州市' => '3360',
			'嘉兴市' => '3350',
			'金华市' => '3380',
			'丽水市' => '3430',
			'宁波市' => '3320',
			'绍兴市' => '3370',
			'台州市' => '3450',
			'温州市' => '3330',
			'舟山市' => '3420',
			'衢州市' => '3410',
			'安庆市' => '3680',
			'蚌埠市' => '3630',
			'巢湖市' => '3781',
			'池州市' => '3790',
			'滁州市' => '3750',
			'阜阳市' => '3720',
			'合肥市' => '3610',
			'淮北市' => '3660',
			'淮南市' => '3640',
			'黄山市' => '3710',
			'六安市' => '3760',
			'马鞍山市' => '3650',
			'宿州市' => '3740',
			'铜陵市' => '3670',
			'芜湖市' => '3620',
			'宣城市' => '3771',
			'亳州市' => '3722',
			'福州市' => '3910',
			'龙岩市' => '4050',
			'南平市' => '4010',
			'宁德市' => '4030',
			'莆田市' => '3940',
			'泉州市' => '3970',
			'三明市' => '3950',
			'厦门市' => '3930',
			'漳州市' => '3990',
			'抚州市' => '4370',
			'赣州市' => '4280',
			'吉安市' => '4350',
			'景德镇市' => '4220',
			'九江市' => '4240',
			'南昌市' => '4210',
			'萍乡市' => '4230',
			'上饶市' => '4330',
			'新余市' => '4260',
			'宜春市' => '4310',
			'鹰潭市' => '4270',
			'滨州市' => '4660',
			'德州市' => '4680',
			'东营市' => '4550',
			'菏泽市' => '4750',
			'济南市' => '4510',
			'济宁市' => '4610',
			'莱芜市' => '4634',
			'聊城市' => '4710',
			'临沂市' => '4730',
			'青岛市' => '4520',
			'日照市' => '4732',
			'泰安市' => '4630',
			'威海市' => '4650',
			'潍坊市' => '4580',
			'烟台市' => '4560',
			'枣庄市' => '4540',
			'淄博市' => '4530',
			'安阳市' => '4960',
			'鹤壁市' => '4970',
			// '济源市' => '5120',
			'焦作市' => '5010',
			'开封市' => '4920',
			'洛阳市' => '4930',
			'南阳市' => '5130',
			'平顶山市' => '4950',
			'三门峡市' => '5050',
			'商丘市' => '5060',
			'新乡市' => '4980',
			'信阳市' => '5150',
			'许昌市' => '5030',
			'郑州市' => '4910',
			'周口市' => '5080',
			'驻马店市' => '5110',
			'漯河市' => '5040',
			'濮阳市' => '5020',
			'鄂州市' => '5310',
			'恩施土家族苗族自治州' => '5410',
			'黄冈市' => '5330',
			'黄石市' => '5220',
			'荆门市' => '5320',
			'荆州市' => '5370',
			'潜江市' => '5375',
			'神农架林区' => '5311',
			'十堰市' => '5230',
			'随州市' => '5286',
			'天门市' => '5374',
			'武汉市' => '5210',
			'仙桃市' => '5371',
			'咸宁市' => '5360',
			'襄阳市' => '5280',
			'孝感市' => '5350',
			'宜昌市' => '5260',
			'常德市' => '5580',
			'长沙市' => '5510',
			'郴州市' => '5630',
			'衡阳市' => '5540',
			'怀化市' => '5670',
			'娄底市' => '5620',
			'邵阳市' => '5550',
			'湘潭市' => '5530',
			'湘西土家族苗族自治州' => '5690',
			'益阳市' => '5610',
			'永州市' => '5650',
			'岳阳市' => '5570',
			'张家界市' => '5590',
			'株洲市' => '5520',
			'潮州市' => '5869',
			'东莞市' => '6020',
			'佛山市' => '5880',
			'广州市' => '5810',
			'河源市' => '5980',
			'惠州市' => '5950',
			'江门市' => '5890',
			'揭阳市' => '5865',
			'茂名市' => '5920',
			'梅州市' => '5960',
			'清远市' => '6010',
			'汕头市' => '5860',
			'汕尾市' => '5970',
			'韶关市' => '5820',
			'深圳市' => '5840',
			'阳江市' => '5990',
			'云浮市' => '5937',
			'湛江市' => '5910',
			'肇庆市' => '5930',
			'中山市' => '6030',
			'珠海市' => '5850',
			'百色市' => '6261',
			'北海市' => '6230',
			'崇左市' => '6128',
			'防城港市' => '6330',
			'桂林市' => '6170',
			'贵港市' => '6242',
			'河池市' => '6281',
			'贺州市' => '6225',
			'来宾市' => '6155',
			'柳州市' => '6140',
			'南宁市' => '6110',
			'钦州市' => '6311',
			'梧州市' => '6210',
			'玉林市' => '6240',
			'白沙黎族自治县' => '6432',
			'保亭黎族苗族自治县' => '6437',
			'昌江黎族自治县' => '6433',
			'澄迈县' => '6428',
			'定安县' => '6426',
			'东方市' => '6434',
			'海口市' => '6410',
			'乐东黎族自治县' => '6435',
			'临高县' => '6429',
			'陵水黎族自治县' => '6436',
			'南沙群岛' => '6441',
			'琼海市' => '6424',
			'琼中黎族苗族自治县' => '6438',
			'三亚市' => '6420',
			'屯昌县' => '6427',
			// '万宁市' => '6425',
			'文昌市' => '6423',
			'五指山市' => '6421',
			'西沙群岛' => '6439',
			'中沙群岛的岛礁及其海域' => '6442',
			'儋州市' => '6431',
			'重庆市' => '6530',
			'阿坝藏族羌族自治州' => '6790',
			'巴中市' => '6758',
			'成都市' => '6510',
			'达州市' => '6750',
			'德阳市' => '6580',
			'甘孜藏族自治州' => '6810',
			'广安市' => '6737',
			'广元市' => '6610',
			'乐山市' => '6650',
			'凉山彝族自治州' => '6840',
			'眉山市' => '6652',
			'绵阳市' => '6590',
			'南充市' => '6730',
			'内江市' => '6630',
			'攀枝花市' => '6560',
			'遂宁市' => '6620',
			'雅安市' => '6770',
			'宜宾市' => '6710',
			// '资阳市' => '6780',
			'自贡市' => '6550',
			'泸州市' => '6570',
			'安顺市' => '7110',
			'毕节地区' => '7090',
			'贵阳市' => '7010',
			'六盘水市' => '7020',
			'黔东南苗族侗族自治州' => '7130',
			'黔南布依族苗族自治州' => '7150',
			'黔西南布依族苗族自治州' => '7070',
			'铜仁地区' => '7050',
			'遵义市' => '7030',
			'保山市' => '7530',
			'楚雄彝族自治州' => '7380',
			'大理白族自治州' => '7510',
			'德宏傣族景颇族自治州' => '7540',
			'迪庆藏族自治州' => '7570',
			'红河哈尼族彝族自治州' => '7430',
			'昆明市' => '7310',
			'丽江市' => '7550',
			'临沧市' => '7580',
			'怒江傈僳族自治州' => '7560',
			'普洱市' => '7470',
			'曲靖市' => '7360',
			'文山壮族苗族自治州' => '7450',
			'西双版纳傣族自治州' => '7490',
			'玉溪市' => '7410',
			'昭通市' => '7340',
			'阿里地区' => '7810',
			'昌都地区' => '7720',
			'拉萨市' => '7700',
			'林芝地区' => '7830',
			'那曲地区' => '7790',
			'日喀则地区' => '7760',
			'山南地区' => '7740',
			'安康市' => '8010',
			'宝鸡市' => '7930',
			'汉中市' => '7990',
			'商洛市' => '8030',
			'铜川市' => '7920',
			'渭南市' => '7970',
			'西安市' => '7910',
			'咸阳市' => '7950',
			'延安市' => '8040',
			'榆林市' => '8060',
			'白银市' => '8240',
			'定西市' => '8290',
			'甘南藏族自治州' => '8380',
			'嘉峪关市' => '8220',
			'金昌市' => '8230',
			'酒泉市' => '8260',
			'兰州市' => '8210',
			'临夏回族自治州' => '8360',
			'陇南市' => '8310',
			'平凉市' => '8330',
			'庆阳市' => '8340',
			'天水市' => '8250',
			'武威市' => '8280',
			'张掖市' => '8270',
			'果洛藏族自治州' => '8570',
			'海北藏族自治州' => '8540',
			'海东地区' => '8520',
			'海南藏族自治州' => '8560',
			'海西蒙古族藏族自治州' => '8590',
			'黄南藏族自治州' => '8550',
			'西宁市' => '8510',
			'玉树藏族自治州' => '8580',
			'固原市' => '8741',
			'石嘴山市' => '8720',
			'吴忠市' => '8731',
			'银川市' => '8710',
			'中卫市' => '8750',
			'阿克苏地区' => '8910',
			'阿拉尔市' => '9031',
			'阿勒泰地区' => '9020',
			'巴音郭楞蒙古自治州' => '8880',
			'博尔塔拉蒙古自治州' => '8870',
			'昌吉回族自治州' => '8850',
			'哈密地区' => '8840',
			'和田地区' => '8960',
			'喀什地区' => '8940',
			'克拉玛依市' => '8820',
			'克孜勒苏柯尔克孜自治州' => '8930',
			'石河子市' => '9028',
			'塔城地区' => '9010',
			'图木舒克市' => '9032',
			'吐鲁番地区' => '8830',
			'乌鲁木齐市' => '8810',
			'五家渠市' => '9060',
			'伊犁哈萨克自治州' => '8980',
			'台湾省' => '9910',
			'香港特别行政区' => '9920',
			'澳门特别行政区' => '9930'
			);
		if(null === $name){
			return $map;
		}
		if(isset($map[$name])){
			return $map[$name];
		}
		return $name;
	}

	public function rcdCodeToTxt($code){
		switch ($code) {
			case '001001':
				return '商户已复核，短信未发送';
			case '100011':
				return '户名验证失败';
			case '111111':
				return '版本号为空';
			case '111112':
				return '起始截止日期错误';
			case '111113':
				return '日期格式不正确';
			case '111114':
				return '日期不等于当前日期';
			case '111115':
				return '请求流水为空';
			case '111116':
				return '当天交易重复';
			case '111117':
				return '请求流水号只能为数字';
			case '111118':
				return '请求流水号小于10位';
			case '111119':
				return '请求流水号大于30位';
			case '111120':
				return '总行代码为空';
			case '111121':
				return '总行代码不存在';
			case '111122':
				return '总行代码非数字';
			case '111123':
				return '总行代码小于4位';
			case '111124':
				return '总行代码大于4位';
			case '111125':
				return '账号为空';
			case '111126':
				return '账号小于10位';
			case '111127':
				return '账号大于28位';
			case '111128':
				return '账号有非数字字符';
			case '111129':
				return '账户名为空';
			case '111130':
				return '账户名称大于30位';
			case '111131':
				return '金额为空';
			case '111132':
				return '金额为0';
			case '111133':
				return '金额为负数';
			case '111134':
				return '金额小于手续费';
			case '111135':
				return '金额等于手续费';
			case '111136':
				return '金额输入有误';
			case '111137':
				return '企业流水号不能少于10位';
			case '111138':
				return '企业流水号过长';
			case '111139':
				return '备注过长';
			case '111140':
				return '请填写正确的手机号';
			case '111140':
				return '手机格式不正确';
			case '111141':
				return '城市代码为空';
			case '111142':
				return '城市代码不正确';
			case '111143':
				return '城市代码不等于4位';
			case '111144':
				return '支行名称的长度超长';
			case '111145':
				return '证件类型为空';
			case '111146':
				return '证件类型不正确';
			case '111147':
				return '证件号不能为空';
			case '111148':
				return '证件号过长';
			case '111149':
				return '原请求时间为空';
			case '111150':
				return '原请求时间格式不正确';
			case '111151':
				return '原请求流水为空';
			case '111152':
				return '原请求流水长度大于30位';
			case '111153':
				return '退票交易已经存在退款或重发记录';
			case '111154':
				return '该商户为手续费实时结算商户，没有重发的权限';
			case '111155':
				return '未获取到机构账户信息';
			case '111156':
				return '代付业务D方向的收款不能重发';
			case '111157':
				return '业务代码为空';
			case '111158':
				return '商户号为空';
			case '111159':
				return '商户号过长';
			case '111160':
				return '没有找到对应的商户';
			case '111161':
				return '开始时间格式不正确';
			case '111162':
				return '结束时间格式不正确';
			case '111163':
				return '金额超限';
			case '111164':
				return '请求类型为空';
			case '111165':
				return '请求类型不存在';
			case '111166':
				return '非http对接商户';
			case '111167':
				return '请求过于频繁,稍后再试';
			case '111167':
				return '查询请求过于频繁,稍后再试';
			case '111168':
				return '请求单卡单日扣款失败次数过多';
			case '111169':
				return '业务校验失败';
			case '111169':
				return '手续费计算出错';
			case '111200':
				return '请填写业务定义';
			case '111201':
				return '业务定义错误';
			case '111202':
				return '请填写项目ID';
			case '111203':
				return '项目ID错误';
			case '111204':
				return '批量查询的流水号码不能超过50个';
			case '111205':
				return '协议号为空';
			case '200007':
				return '无此商户';
			case '200008':
				return '商户停用';
			case '200009':
				return '商户注销';
			case '200018':
				return '请求参数为空';
			case '200023':
				return '未获得电子联行号';
			case '200024':
				return '匹配银行代码失败,不支持此行';
			case '200025':
				return '匹配省份代码失败';
			case '200029':
				return '未查询到数据';
			case '200030':
				return '未获取到卡bin值';
			case '200039':
				return '请求参数与校验值不匹配';
			case '200046':
				return '业务验证错误';
			case '200047':
				return '没有匹配到路由';
			case '200048':
				return '月结商户存在生效的手续费方案';
			case '200049':
				return '富友入账户错误';
			case '200050':
				return '计算手续费失败';
			case '200051':
				return '计算手续费失败';
			case '200052':
				return '手机号码有误';
			case '200053':
				return '虚拟账户余额不足';
			case '200054':
				return '没有开通虚拟账户';
			case '200055':
				return '虚拟账户查余发生错误';
			case '200056':
				return '预授权失败';
			case '200057':
				return '银行卡号和行别不一致';
			case '202012':
				return '未找到交易';
			case '299998':
				return '请求参数解析错误';
			case '300023':
				return '开户行和银行卡号不一致';
			case '100012':
				return '证件错误';
			case '100013':
				return '无效卡号（无此号）';
			case '999999':
				return '其他错误';
			case '100014':
				return '协议号不存在';
			case '100016':
				return '超出取款/转账金额限制';
			case '200001':
				return '接收的响应已过时';
			case '100017':
				return '资金不足';
			case '1001':
				return '查交易接收方';
			case '1002':
				return '查交易接收方的特殊条件';
			case '1003':
				return '无效商户';
			case '1004':
				return '没收卡';
			case '1005':
				return '不予承兑';
			case '1006':
				return '出错';
			case '1007':
				return '特定条件下没收卡';
			case '1009':
				return '请求正在处理中';
			case '1012':
				return '无效交易';
			case '1013':
				return '无效金额';
			case '1014':
				return '无效卡号（无此号）';
			case '1015':
				return '无此交易接收方';
			case '1017':
				return '客户取消';
			case '1019':
				return '重新送入交易';
			case '1020':
				return '无效响应';
			case '1021':
				return '不能采取行动';
			case '1022':
				return '故障怀疑';
			case '1023':
				return '不可接受的交易费';
			case '1025':
				return '找不到原始交易';
			case '1030':
				return '格式错误';
			case '1031':
				return '交换中心不支持的银行';
			case '1033':
				return '过期的卡';
			case '1034':
				return '有作弊嫌疑';
			case '1035':
				return '受卡方与代理方联系';
			case '1036':
				return '受限制的卡';
			case '1037':
				return '受卡方电话通知代理方安全部门';
			case '1038':
				return '超过允许的PIN试输入';
			case '1039':
				return '无贷记账户';
			case '1040':
				return '请求的功能尚不支持';
			case '1041':
				return '挂失卡';
			case '1042':
				return '无此账户';
			case '1043':
				return '被窃卡';
			case '1044':
				return '无此投资账户';
			case '1052':
				return '无此支票账户';
			case '1053':
				return '无此储蓄卡账户';
			case '1054':
				return '过期的卡';
			case '1055':
				return '不正确的PIN';
			case '1056':
				return '无此卡记录';
			case '1057':
				return '不允许持卡人进行的交易';
			case '1058':
				return '不允许终端进行的交易';
			case '1059':
				return '有作弊嫌疑';
			case '1060':
				return '受卡方与代理方联系';
			case '1061':
				return '超出取款/转账金额限制';
			case '1062':
				return '受限制的卡';
			case '1063':
				return '侵犯安全';
			case '1064':
				return '原始金额错误';
			case '1065':
				return '超出取款次数限制';
			case '1066':
				return '受卡方通知受理方安全部门';
			case '1067':
				return '强行受理（要求在自动会员机上没收此卡）';
			case '1068':
				return '接收的响应已过时';
			case '1075':
				return '允许的输入PIN次数超限';
			case '1076':
				return '无效账户';
			case '1090':
				return '正在日终处理（系统终止一天的活动，开始第二天的活动，交易在几分钟后可再次发送）';
			case '1091':
				return '交易接收方或交换中心不能操作';
			case '1092':
				return '金融机构或中间网络设施找不到或无法达到、金融机构签退';
			case '1093':
				return '交易违法、不能完成';
			case '1094':
				return '重复交易';
			case '1095':
				return '核对差错';
			case '1096':
				return '系统异常、失效';
			case '1098':
				return '交换中心收不到交易接收方应答';
			case '1099':
				return 'PIN格式错';
			case '10A0':
				return 'MAC鉴别失败';
			case '1051':
				return '资金不足';
			default:
				return $code;
		}
	}

}

/**
 * 请求型接口的基类
 */
class FuiouPay_client_pub extends FPCommon_util_pub
{
	protected $parameters;//请求参数，类型为关联数组
	protected $sign_order;//签名顺序
	protected $url;//接口链接
	protected $curl_timeout;//curl超时时间

	public $response;//微信返回的响应
	public $result;//返回参数，类型为关联数组

	/**
	 * 	作用：设置请求参数
	 */
	protected function setParameter($key, $value){
		$key = trim($key);
		$value = trim($value);
		$this->parameters[$key] = $value;
	}

	/**
	 * 	作用：设置标配的请求参数，生成签名，生成接口参数xml
	 */
	protected function createXml(){

		$cnf = config_item('payment_fuiou');
	   	$this->parameters["MchntCd"] = $cnf['mchid'];
	    $this->parameters["Sign"] = $this->getSign($this->parameters, $this->sign_order);//签名
	    return  $this->arrayToXml($this->parameters);
	}

	/**
	 * 	作用：post请求xml
	 */
	protected function postXml(){
	    $xml = $this->createXml();
	    // file_put_contents(PATH_PAYMENT_NETWORK_LOG, 'URL:' . $this->url . "\n" . 'POST:'.$xml . "\n\n", FILE_APPEND);
	    FPayLog('URL:' . $this->url . "\n" . 'POST:'.$xml);
	    $post_data = array('FM' => $xml);
		$this->response = $this->postXmlCurl($post_data,$this->url,$this->curl_timeout);
		return $this->response;
	}

	/**
	 * 	作用：使用证书post请求xml
	 */
	protected function postXmlSSL(){
	    $xml = $this->createXml();
		$this->response = $this->postXmlSSLCurl($xml,$this->url,$this->curl_timeout);
		return $this->response;
	}

	/**
	 * 	作用：获取结果，默认不使用证书
	 */
	protected function getResult()
	{
		$this->postXml();
		$this->result = $this->xmlToArray($this->response);
		return $this->result;
	}

	protected function verifyResponse( $orders ){
		$cmp_sign = $this->getSign($this->result, $orders);
		if($cmp_sign != $this->result['Sign']){
			// file_put_contents(PATH_PAYMENT_NETWORK_LOG, "FATAL ERROR: RESPONSE SIGN NOT MATCH\nSign: {$this->result['Sign']}\nCmpSign:$cmp_sign\n".$this->response . "\n\n", FILE_APPEND);
			FPayLog("FATAL ERROR: RESPONSE SIGN NOT MATCH\nSign: {$this->result['Sign']}\nCmpSign:$cmp_sign\n".$this->response);
			return false;
		}
		return true;
	}
}


/**
 * 商户订单创建接口类
 */
class CreateOrder_pub extends FuiouPay_client_pub
{
	public function __construct()
	{
		//设置接口链接
		$this->url = FUIOUPAY_API_ROOT . "/findPay/createOrder.pay";
		$cnf = config_item('payment_fuiou');
		//设置curl超时时间
		$this->curl_timeout = $cnf['timeout'];
		$this->sign_order = 'MchntCd|Amt';
		$this->parameters['Rmk1'] = 'hide';
	}

	/**
	 * 生成接口参数xml
	 */
	protected function createXml(){
		try
		{
			//检测必填参数
			if($this->parameters["Amt"] == null)
			{
				throw new FPSDKRuntimeException("缺少创建订单接口必填参数Amt！"."<br>");
			}
		   	return  parent::createXml();
		}catch (FPSDKRuntimeException $e)
		{
			FPayDie($e->errorMessage());
		}
	}

	public function setAmount( $amt ){
		$this->parameters['Amt'] = $amt;
	}

	public function setPayId( $id ){
		$this->parameters['Rmk2'] = $id;
	}

	/**
	 * 获取OrderId
	 */
	public function getOrderId(){
		$this->getResult();
		if(empty($this->result)){
			return false;
		}
		if(!$this->verifyResponse('Rcd|OrderId')){
			return false;
		}
		if($this->result["Rcd"] != '0000'){
			return false;
		}
		$OrderId = $this->result["OrderId"];
		return $OrderId;
	}

}

/**
 * 支付信息接口
 */
class OrderPayinfo_pub extends FuiouPay_client_pub
{

	public function __construct()
	{
		//设置接口链接
		$this->url = FUIOUPAY_API_ROOT . "/timbnew/timb01.pay";
		$cnf = config_item('payment_fuiou');
		$this->parameters['mchntCd'] = $cnf['mchid'];
		$this->parameters['reurl'] = $cnf['reurl'];
		$this->parameters['backurl'] = $cnf['backurl'];
		$this->parameters['homeurl'] = $cnf['homeurl'];
		$this->sign_order = 'mchntCd|orderid|name|ono|sfz';
	}

	public function setOrderId( $id ){
		$this->parameters['orderid'] = $id;
	}

	public function setBankcardno( $cardno ){
		$this->parameters['ono'] = $cardno;
	}

	public function setUsername( $name ){
		$this->parameters['name'] = $name;
	}

	public function setIDNumber( $idno ){
		$this->parameters['sfz'] = $idno;
	}

	public function getPackData(){
		$data = $this->parameters;
		$data['md5'] = $this->getSign($this->parameters, $this->sign_order);
		return array(
				'url' => $this->url,
				'data' => $data,
			);
	}
}

/**
 * 查询接口
 */
class OrderQuery_pub extends FuiouPay_client_pub
{

	public function __construct()
	{
		//设置接口链接
		$this->url = FUIOUPAY_API_ROOT . "/findPay/queryOrderId.pay";
		$cnf = config_item('payment_fuiou');
		//设置curl超时时间
		$this->curl_timeout = $cnf['timeout'];
		$this->sign_order = 'MchntCd|OrderId';
	}

	/**
	 * 生成接口参数xml
	 */
	protected function createXml(){
		try
		{
			//检测必填参数
			if($this->parameters["OrderId"] == null)
			{
				throw new FPSDKRuntimeException("缺少查询接口必填参数OrderId！"."<br>");
			}
		   	return  parent::createXml();
		}catch (FPSDKRuntimeException $e)
		{
			FPayDie($e->errorMessage());
		}
	}

	public function setOrderId( $oid ){
		$this->parameters['OrderId'] = $oid;
	}

	/**
	 * 获取订单状态
	 */
	public function getStatus(){
		$this->getResult();
		if(empty($this->result)){
			return false;
		}
		if(!$this->verifyResponse('Rcd')){
			return false;
		}
		//5185 表示“订单已支付” 5077 表示“无此订单” 11V3 表示“订单失效” 11E3 表示“订单支付失败”
		//$Rcd = $this->result["Rcd"];		//响应代码
		//$RDesc = $this->result["RDesc"];	//中文描述
		$Rcd = $this->result["Rcd"];		//响应代码
		switch ($Rcd) {
			case '5185':
				$Rcd = RECHARGE_ORDER_OK;
				break;
			case '5077':
				$Rcd = RECHARGE_ORDER_NOT_EXISTS;
				break;
			case '11V3':
				$Rcd = RECHARGE_ORDER_EXPIRED;
				break;
			case '11E3':
				$Rcd = RECHARGE_ORDER_PAY_FAILED;
				break;
		}
		$RDesc = $this->result["RDesc"];	//中文描述
		if(empty($RDesc)){
			$RDesc = $this->rcdCodeToTxt( $Rcd );
		}
		return array(
				'code' => $Rcd,
				'msg' => $RDesc
			);
	}

}

/**
 * 银行卡信息验证接口
 */
class VerifyCardInfo_pub extends FuiouPay_client_pub
{

	public function __construct()
	{
		//设置接口链接
		$this->url = FUIOUPAY_API_ROOT . "/checkCard/checkCardDebit.pay";
		$cnf = config_item('payment_fuiou');
		//设置curl超时时间
		$this->curl_timeout = $cnf['timeout'];
		$this->sign_order = 'MchntCd|Ver|OSsn|Ono|OCerTp|OCerNo';
		$this->parameters['Ver'] = '1.30';
		$this->parameters['OCerTp'] = '0';
	}
	/**
	 * 写文件日志，文件按月划分
	 */
	protected function log($str) {
		$_log_file_name = DIR_LOG . 'fuiou_verifycard_' . date('Y-m') . '.log';
		$_log_data = sprintf("%s\t%s\n", date('Y-m-d H:i:s'), $str);
		file_put_contents($_log_file_name, $_log_data, FILE_APPEND);
	}

	/**
	 * 生成接口参数xml
	 */
	protected function createXml(){
		try
		{
			//检测必填参数
			if($this->parameters["OSsn"] == null)
			{
				throw new FPSDKRuntimeException("缺少银行卡信息验证接口必填参数OSsn！"."<br>");
			}elseif($this->parameters["Ono"] == null)
			{
				throw new FPSDKRuntimeException("缺少银行卡信息验证接口必填参数Ono！"."<br>");
			}elseif($this->parameters["Onm"] == null)
			{
				throw new FPSDKRuntimeException("缺少银行卡信息验证接口必填参数Onm！"."<br>");
			}elseif($this->parameters["OCerTp"] == null)
			{
				throw new FPSDKRuntimeException("缺少银行卡信息验证接口必填参数OCerTp！"."<br>");
			}elseif($this->parameters["OCerNo"] == null)
			{
				throw new FPSDKRuntimeException("缺少银行卡信息验证接口必填参数OCerNo！"."<br>");
			}
		   	return  parent::createXml();
		}catch (FPSDKRuntimeException $e)
		{
			FPayDie($e->errorMessage());
		}
	}

	public function setSequnceID( $id ){
		$this->parameters['OSsn'] = $id;
	}

	public function setBankcardno( $cardno ){
		$this->parameters['Ono'] = $cardno;
	}

	public function setUsername( $name ){
		$this->parameters['Onm'] = $name;
	}

	public function setIDType( $idtype ){
		$this->parameters['OCerTp'] = $idtype;
	}

	public function setIDNumber( $idno ){
		$this->parameters['OCerNo'] = $idno;
	}

	public function setMobile( $idno ){
		$this->parameters['Mno'] = $idno;
	}

	/**
	 * 获取OrderId
	 */
	public function getResponse(){
		$this->getResult();
		if(empty($this->result)){
			$this->log('empty response.');
			return false;
		}
		$this->log(json_encode($this->result));
		//Rcd+"|"+ OSsn +"|"+ CardNo +"|"+ MchntCd+"|"+ Ver+"
		if(!$this->verifyResponse('Rcd|OSsn|CardNo|MchntCd|Ver')){
			$this->log('verify response failed.');
			return false;
		}
		$Rcd = $this->result["Rcd"];		//响应代码
		$RDesc = $this->result["RDesc"];	//中文描述
		if($Rcd == '0000'){
			return true;
		}else{
			if(empty($RDesc)){
				$RDesc = $this->rcdCodeToTxt( $Rcd );
			}
			return $RDesc;
		}
	}

}

/**
 * 商户支持银行卡BIN查询接口
 */
class BankcardQuery_pub extends FuiouPay_client_pub
{

	public function __construct()
	{
		//设置接口链接
		$this->url = FUIOUPAY_API_ROOT . "/findPay/cardBinQuery.pay";
		$cnf = config_item('payment_fuiou');
		//设置curl超时时间
		$this->curl_timeout = $cnf['timeout'];
		$this->sign_order = 'MchntCd|Ono';
	}
	/**
	 * 写文件日志，文件按月划分
	 */
	protected function log($str) {
		$_log_file_name = DIR_LOG . 'fuiou_bankquery_' . date('Y-m') . '.log';
		$_log_data = sprintf("%s\t%s\n", date('Y-m-d H:i:s'), $str);
		file_put_contents($_log_file_name, $_log_data, FILE_APPEND);
	}

	/**
	 * 生成接口参数xml
	 */
	protected function createXml(){
		try
		{
			//检测必填参数
			if($this->parameters["Ono"] == null) {
				throw new FPSDKRuntimeException("缺少商户支持银行卡BIN查询接口必填参数Ono！"."<br>");
			}
			$xml = parent::createXml();
			$this->log($xml);
			return $xml;

		}catch (FPSDKRuntimeException $e)
		{
			FPayDie($e->errorMessage());
		}
	}

	public function setBankcardno( $cardno ){
		$this->parameters['Ono'] = $cardno;
	}

	/**
	 * 根据银行机构代码获取银行名称, 2017-10-31
	 * 目前在调用https://mpay.fuioupay.com:16128/findPay/cardBinQuery.pay这个接口的时候
	 * 有时候返回的Cnm(银行名称)不是准确的名字（例如，本来是农业银行，返回的是农行厦门支行),
	 * 所以用InsCd(银行机构代码)矫正一下
	 *
	 * @param $inscd 银行机构代码,通常为10位数字字符串
	 * @return 如果能够找到银行名称，则返回银行名称，否则返回false
	 */
	public function getBankNameByInsCode($inscd){
		// 银行机构代码对应银行名称映射数组
		static  $insid_bank_map = array (
			'080102' => '中国工商银行',
			'080103' => '中国农业银行',
			'080104' => '中国银行',
			'080105' => '中国建设银行',
			'080100' => '邮政储蓄银行',
			'080410' => '平安银行',
			'080305' => '民生银行',
			'080303' => '光大银行',
			'080306' => '广发银行',
			'080302' => '中信银行',
			'080309' => '兴业银行',
			'080304' => '华夏银行',
			'080308' => '招商银行',
			'080310' => '浦发银行',
			'080301' => '交通银行',
			'080401' => '上海银行',
			'0804031000' => '北京银行', // 北京银行是10位全匹配
		);
		// 判断银行机构代码是否为空
		if (empty($inscd)) {
			return false;
		}
		// 银行机构代码目前都是10位数字
		if (strlen($inscd)!=10) {
			return false;
		}
		// 先用10位长度全匹配验证
		if(isset($insid_bank_map[$inscd])){
			return $insid_bank_map[$inscd];
		}
		// 再用前面6位匹配验证
		$inscd_6 = substr($inscd,0,6);
		if (isset($insid_bank_map[$inscd_6])) {
			return $insid_bank_map[$inscd_6];
		}
		// 没有匹配
		return false;
	}

	/**
	 * 获取OrderId
	 */
	public function getUseful(){
		$this->getResult();
		if(empty($this->result)){
			return false;
		}
		if(!$this->verifyResponse('Rcd')){
			return false;
		}
		$this->log(json_encode($this->result));
		//0000 表示“成功”		1014 表示“无效卡号”		5505 表示“不支持的银行卡”		100001 表示“不支持的卡类型”
		$Rcd = $this->result["Rcd"];		//响应代码
		switch ($Rcd) {
			case '0000':
				$Rcd = BANK_CARD_OK;
				break;
			case '1014':
				$Rcd = BANK_CARD_INVALID;
				break;
			case '5505':
				$Rcd = BANK_CARD_NOT_SUPPORT;
				break;
			case '100001':
				$Rcd = BANK_CARD_TYPE_NOT_SUPPORT;
				break;
		}
		$RDesc = $this->result["RDesc"];	//中文描述
		if(empty($RDesc)){
			$RDesc = $this->rcdCodeToTxt( $Rcd );
		}
		$Ctp = isset($this->result["Ctp"]) ? $this->result["Ctp"] : '';		//卡类型 01-借记卡,02-信用卡,03-准贷记 卡,04-富友卡,05-非法卡号
		switch ($Ctp) {
			case '01':
				$Ctp = BANK_CARD_TYPE_DEBIT_CARD;
				break;
			case '02':
				$Ctp = BANK_CARD_TYPE_CREDIT_CARD;
				break;
			case '03':
				$Ctp = BANK_CARD_TYPE_QUASI_CREDIT_CARD;
				break;
			case '04':
				$Ctp = BANK_CARD_TYPE_SPECIAL_CARD;
				break;
			case '05':
				$Ctp = BANK_CARD_TYPE_INVALID;
				break;
		}
		$Cnm = isset($this->result["Cnm"]) ? $this->result["Cnm"] : '';		//银行名称
		$InsCd = isset($this->result["InsCd"]) ? $this->result["InsCd"] : '';	//银行机构号

		$bankname = $this->getBankNameByInsCode($InsCd);
		if ($bankname!=false) {
			$Cnm = $bankname;
		}

		$rt_data = array(
			'code' => $Rcd,
			'msg' => $RDesc,
			'cardtype' => $Ctp,
			'bankname' => $Cnm,
			'bankcode' => $InsCd
			);
		$this->log(json_encode($rt_data));
		return $rt_data;
	}

}

/**
 * 响应型接口基类
 */
class FuiouPay_server_pub extends FPCommon_util_pub
{
	public $data;//接收到的数据，类型为关联数组
	protected $returnParameters;//返回参数，类型为关联数组

	/**
	 * 将微信的请求xml转换成关联数组，以方便数据处理
	 */
	protected function saveData($xml){
		$this->data = $this->xmlToArray($xml);
	}

	protected function checkSign(){
		$tmpData = $this->data;
		unset($tmpData['sign']);
		$sign = $this->getSign($tmpData);//本地签名
		if ($this->data['sign'] == $sign) {
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 获取微信的请求数据
	 */
	protected function getData(){
		return $this->data;
	}

	/**
	 * 设置返回微信的xml数据
	 */
	protected function setReturnParameter($key, $value){
		$key = trim($key);
		$value = trim($value);
		$this->returnParameters[$key] = $value;
	}

	/**
	 * 生成接口参数xml
	 */
	protected function createXml(){
		return $this->arrayToXml($this->returnParameters);
	}

	/**
	 * 将xml数据返回微信
	 */
	protected function returnXml(){
		$returnXml = $this->createXml();
		return $returnXml;
	}
}


/**
 * 通用通知接口
 */
class FuiouNotify_pub extends FuiouPay_server_pub
{

}



//==========================================================//
//						代付款接口							//
//==========================================================//

class FuiouPerPayment{

	protected $merid = '';

	protected $merkey = '';

	protected $reqtype = 'payforreq';

	protected $xml = '';

	protected $mac = '';

	protected $timeout = 30;

	protected $url = FUIOUPAY_API_WITHDRAW_ROOT . '/req.do';


	/**
	 * 	作用：以post方式提交xml到对应的接口url
	 */
	protected function postXmlCurl(){
		//初始化curl
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
		curl_setopt($ch,CURLOPT_URL, $this->url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, array(
			'merid' => $this->merid,
			'reqtype' => $this->reqtype,
			'xml' => $this->xml,
			'mac' => $this->mac,
		));
		$data = curl_exec($ch);
		// file_put_contents(PATH_PAYMENT_NETWORK_LOG, $data . "\n\n", FILE_APPEND);
		FPayLog($data);
		if($data){
			curl_close($ch);
			return $data;
		} else {
			$error = curl_errno($ch);
			echo "curl出错，错误码:$error"."<br>";
			echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
			curl_close($ch);
			return false;
		}
	}

	/**
	 * 	作用：使用证书，以post方式提交xml到对应的接口url
	 */
	protected function postXmlSSLCurl(){
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_TIMEOUT,$this->timeout);
		curl_setopt($ch,CURLOPT_URL, $this->url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch,CURLOPT_HEADER,FALSE);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
		//设置证书
		//使用证书：cert 与 key 分别属于两个.pem文件
		//默认格式为PEM，可以注释
		curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
		$cnf = config_item('payment_fuiou_perpay');
		curl_setopt($ch,CURLOPT_SSLCERT, $cnf['sslcert']);
		//默认格式为PEM，可以注释
		curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
		curl_setopt($ch,CURLOPT_SSLKEY, $cnf['sslkey']);
		curl_setopt($ch,CURLOPT_POST, true);
		curl_setopt($ch,CURLOPT_POSTFIELDS, array(
			'merid' => $this->merid,
			'reqtype' => $this->reqtype,
			'xml' => $this->xml,
			'mac' => $this->mac,
		));
		$data = curl_exec($ch);
		if($data){
			curl_close($ch);
			return $data;
		} else {
			$error = curl_errno($ch);
			echo "curl出错，错误码:$error"."<br>";
			echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
			curl_close($ch);
			return false;
		}
	}

	protected function getSign(){
		$md5str = $this->merid . '|' . $this->merkey . '|' . $this->reqtype . '|' . $this->xml;
		$md5 = md5($md5str);
		//file_put_contents(DIR_LOG . 'fuiouprepay.sign.log', $md5str . "\n" . $md5 . "\n\n" , FILE_APPEND);
		$this->mac = $md5;
	}

	protected function arrayToXml($arr){
		$xml = '<?xml version="1.0" encoding="utf-8" standalone="yes"?><payforreq>';
		foreach ($arr as $key => $val){
			$xml .= "<".$key.">".$val."</".$key.">";
		}
		$xml .= "</payforreq>";
		return $xml;
	}

	protected function xmlToArray($xml){
		//将XML转为array
		return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
	}


	public function __construct(){
		$cnf = config_item('payment_fuiou_perpay');
		$this->merid = $cnf['mchid'];
		$this->merkey = $cnf['mchkey'];
		$this->timeout = $cnf['timeout'];
	}

	public function userPerpay($orderno, $bankno, $cityno, $branchnm, $accntno, $accntnm, $amt, $entseq, $memo, $mobile){
		$arr = array(
			'ver' => '1.00',
			'merdt' => date('Ymd'),	//请求日期
			'orderno' => $orderno,	//请求流水, 数字串,当天必须唯一
			'bankno' => $bankno,	//总行代码
			'cityno' => $cityno,	//城市代码
			'branchnm' => $branchnm,//支行名称, 中行、建行、广发必填
			'accntno' => $accntno,	//用户账号
			'accntnm' => $accntnm,	//用户账户名称
			'amt' => $amt,			//金额, 单位:分
			'entseq' => $entseq,	//企业流水号, 填写后,系统体现在交易查询和外部通知中
			'memo' => $memo,		//备注, 填写后,系统体现在交易查询和外部通知中
			'mobile' => $mobile 	//手机号, 为将来短信通知时使用
		);
		// file_put_contents(PATH_PAYMENT_NETWORK_LOG, 'URL:' . $this->url . "\nPOST:$orderno,$amt,$entseq\n\n", FILE_APPEND);
		$this->xml = $this->arrayToXml( $arr );
		FPayLog("Req to {$this->url} with: {$this->xml}");
		$this->getSign();
		$res = $this->postXmlCurl();
		if($res){
			FPayLog("Resp : {$res}");
			$res = $this->xmlToArray($res);
			if($res && isset($res['ret'])){
				if($res['ret'] == '000000'){
					return true;
				}
				return $res['memo'];
			}
			return $res;
		}else{
			FPayLog('Resp: no response!!');
			return false;
		}
	}

}