<?php
/**
 * @Author Chengzhou Tao
 * 
 */
class SmailerLibrary{

    protected $mailer = null;

	protected $data = array();


	public function __construct(){
		if(!class_exists('PHPMailer')){
			$path = dirname(__FILE__) . '/Mailer/PHPMailerAutoload.php';
			if(!file_exists($path)){
				echo "File not exists: $path";
				exit();
			}
			require_once($path);
		}
		if(empty($this->mailer)){
			$this->mailer = new PHPMailer;
		}
	}

	public function init( $user, $passwd, $secure = 'ssl', $host = 'smtp.exmail.qq.com', $port = 465 ){
		$mail = &$this->mailer;
		$mail->isSMTP();
		$mail->Host = $host;
		$mail->SMTPAuth = true;
		$mail->Username = $user;
		$mail->Password = $passwd;
		$mail->SMTPSecure = $secure;
		$mail->Port = $port;
	}

	public function setFrom( $email, $name ){
		$this->mailer->From = $email;
		$this->mailer->FromName = $name;
	}

	public function setSubject( $subject ){
		$this->mailer->Subject = $subject;
	}

	public function setContent( $content ){
		$this->mailer->Body = $content;
	}

	public function addMail( $email, $name = null ){
		if(null === $name){
			$name = substr($email, 0, strpos($email, '@'));
		}
		$this->mailer->addAddress( $email, $name );
	}

	public function addCCMail( $email, $name = null ){
		if(null === $name){
			$name = substr($email, 0, strpos($email, '@'));
		}
		$this->mailer->addCC( $email, $name );
	}

	public function setReply( $email, $name = null ){
		if(null === $name){
			$name = substr($email, 0, strpos($email, '@'));
		}
		$this->mailer->addReplyTo( $email, $name );
	}

	public function addAttachment( $path, $filename ){
		$this->mailer->addAttachment( $path, $filename );
	}

	public function addStringAttachment( $string, $filename ){
		$this->mailer->addStringAttachment( $string, $filename );
	}

	public function send(){
		return $this->mailer->send();
	}
}
