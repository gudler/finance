<?php
/**
 * @Author Chengzhou Tao
 * 
 */

define('_IN_XTRANS_CODE_OK', 0);
define('_IN_XTRANS_TYPE_LARGE_RECHARGE', 60);
define('_IN_XTRANS_TYPE_OFFLINE_RECHARGE', 6);
define('_IN_XTRANS_TYPE_PAYBACK_DEPOSIT', 22);
define('_IN_XTRANS_TYPE_OFFLINE_WITHDRAW', -6);
define('_IN_XTRANS_ROLE_ACCOUNTANT', 'acc');
define('_IN_XTRANS_ROLE_FINANCIAL', 'fin');
define('_IN_XTRANS_ROLE_MANAGER', 'mng');
define('_IN_XTRANS_ACCOUNTANT_PHONE', '13801696717');//会计接受确认短信的手机号：张洪 13801696717，2017-09-26目前在华培红那里管理
define('_IN_XTRANS_FINANCIAL_PHONE', '13482220151');//财务接受确认短信的手机号：蔡元文 13482220151
define('_IN_XTRANS_MANAGER_PHONE', '13601922686');//经理接受确认短信的手机号：Jacky Wu 13601922686
define('_IN_XTRANS_ALLOWED_IPS', '127.0.0.1|0,114.80.245.191|0,114.80.245.192|0');

class XtransferLibrary{

	protected $cnf = array();
	protected $cipher = null;
	protected $data = array();

	public function __construct(){
		$this->cnf = config_item('xtransfer');

		require_once DIR_CORE . 'cipher.php';
		$this->cipher = Cipher::getInstance();
	}

	public function getAllowedIps(){
		$arr = explode(',', _IN_XTRANS_ALLOWED_IPS);
		$res = array();
		foreach ($arr as $row) {
			list($v1, $v2) = explode('|', $row);
			$res[$v1] = $v2;
		}
		return $res;
	}

	public function withdraw($order_id, $bank_name, $city, $bank_sub, $cardno, $username, $money, $mobile, $bank_mobile){
		$data = array(
			'mobile' => $mobile,
			'money' => $money,
			'cardno' => $cardno,
			'username' => $username,
			'bank_mobile' => $bank_mobile,
			'bank_name' => $bank_name,
			'city' => $city,
			'bank_sub' => $bank_sub,
			'order_id' => $order_id
		);
		$string = $this->pack_string($data);
		$nonce = $this->create_nonce_str();
		$md5sign = $this->data_sign($string, $nonce);
		$request = $this->pack_transfer_data(array(
			'data' => $string,
			'nonce' => $nonce,
			'md5sign' => $md5sign
		));
		$url = $this->cnf['url'] . 'cash/withdraw';
		$response = $this->post_curl($request, $url);
		$resdata = $this->process_fetched_data($response, $url);
		if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
			return $resdata['id'];
		}else{
			return false;
		}
	}

	public function largeAmountRecharge($uor_id, $bank_name, $cardno, $username, $money, $mobile){
		$data = array(
			'mobile' => $mobile,
			'money' => $money,
			'cardno' => $cardno,
			'username' => $username,
			'bank_name' => $bank_name,
			'uor_id' => $uor_id
		);
		$string = $this->pack_string($data);
		$nonce = $this->create_nonce_str();
		$md5sign = $this->data_sign($string, $nonce);
		$request = $this->pack_transfer_data(array(
			'data' => $string,
			'nonce' => $nonce,
			'md5sign' => $md5sign
		));
		$url = $this->cnf['url'] . 'cash/large_amount_recharge';
		$response = $this->post_curl($request, $url);
		$resdata = $this->process_fetched_data($response, $url);
		if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
			return $resdata['id'];
		}else{
			return false;
		}
	}

	public function noticeRechargeListStatus($id, $status){
		$data = array(
			'id' => $id,
			'status' => $status
		);
		$string = $this->pack_string($data);
		$nonce = $this->create_nonce_str();
		$md5sign = $this->data_sign($string, $nonce);
		$request = $this->pack_transfer_data(array(
			'data' => $string,
			'nonce' => $nonce,
			'md5sign' => $md5sign
		));
		$url = $this->cnf['url'] . 'cash/notice_recharge_list_status';
		$response = $this->post_curl($request, $url);
		$resdata = $this->process_fetched_data($response, $url);
		if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
			return true;
		}else{
			return false;
		}
	}

	public function noticeRechargeListUorID($id, $uor_id){
		$data = array(
			'id' => $id,
			'uor_id' => $uor_id
		);
		$string = $this->pack_string($data);
		$nonce = $this->create_nonce_str();
		$md5sign = $this->data_sign($string, $nonce);
		$request = $this->pack_transfer_data(array(
			'data' => $string,
			'nonce' => $nonce,
			'md5sign' => $md5sign
		));
		$url = $this->cnf['url'] . 'cash/notice_recharge_list_uorid';
		$response = $this->post_curl($request, $url);
		$resdata = $this->process_fetched_data($response, $url);
		if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
			return true;
		}else{
			return false;
		}

	}

	public function fetchRechargeList(){
		$resdata = $this->fetch_data('cash/recharge_list');
		if(!empty($resdata)){
			if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
				return $resdata['list'];
			}else{
				return false;
			}
		}
		return array();
	}

	public function fetchNewRechargeInfoList(){
		$resdata = $this->fetch_data('cash/new_recharge_info_list');
		if(!empty($resdata)){
			if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
				return $resdata['list'];
			}else{
				return false;
			}
		}
		return array();
	}

	public function fetchNewProjcarList(){
		$resdata = $this->fetch_data('projcar/new_projcar_lists');
		if(!empty($resdata)){
			if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
				return $resdata['list'];
			}else{
				return false;
			}
		}
		return array();
	}

	public function fetchProjcarZipAndUnzip($file_path, $file_md5, $des_path){
		$tmp_zip = $this->fetch_zip($file_path);
		$cmp_md5 = md5_file($tmp_zip);
		// 2017-09-21 FIX BUG
		// 删除创建的临时文件，否则/tmp会留下很多文件，导致系统硬盘空间不足
		if($cmp_md5 != $file_md5){
			unlink($tmp_zip);
			return false;
		}
		$zip = new ZipArchive();
		if($zip->open($tmp_zip) !== TRUE){
			unlink($tmp_zip);
			return false;
		}
		$zip->extractTo($des_path);
		$zip->close();		
		unlink($tmp_zip);
		return true;
	}
	public function noticeProjcarImported($extid){
		// 2017-09-20 BUG FIX
		// 通知的协议同内部管理系统不一致，导致内部管理系统解析异常
		$data = array(
			'extid' => $extid
		);
		$string = $this->pack_string($data);
		$nonce = $this->create_nonce_str();
		$md5sign = $this->data_sign($string, $nonce);
		$request = $this->pack_transfer_data(array(
			'data' => $string,
			'nonce' => $nonce,
			'md5sign' => $md5sign
		));
		$url = $this->cnf['url'] . 'projcar/notice_projcar_status';
		$response = $this->post_curl($request, $url);
		$resdata = $this->process_fetched_data($response, $url);
		if($resdata && isset($resdata['code']) && $resdata['code'] == _IN_XTRANS_CODE_OK ){
			return true;
		}else{
			return false;
		}
	}

	public function getTemplateAndPhoneByRole($role){
		switch ($role) {
			case _IN_XTRANS_ROLE_ACCOUNTANT:
				$phone = _IN_XTRANS_ACCOUNTANT_PHONE;
				break;
			case _IN_XTRANS_ROLE_FINANCIAL:
				$phone = _IN_XTRANS_FINANCIAL_PHONE;
				break;
			case _IN_XTRANS_ROLE_MANAGER:
				$phone = _IN_XTRANS_MANAGER_PHONE;
				break;
			default:
				return false;
		}
		return array(
			'template' => 'SMS_70535272',
			'sms_type' => 'offline_withdraw',
			'phone' => $phone,
			);
	}

	public function getTemplateAndPhoneByTypeRole($type, $role){
		$template = '';
		switch($type){
			case _IN_XTRANS_TYPE_LARGE_RECHARGE:
				$template = 'SMS_66755307';
				$sms_type = 'large_recharge';
				break;
			case _IN_XTRANS_TYPE_OFFLINE_RECHARGE:
				$template = 'SMS_66770507';
				$sms_type = 'offline_recharge';
				break;
			case _IN_XTRANS_TYPE_PAYBACK_DEPOSIT:
				$template = 'SMS_70410276';
				$sms_type = 'payback_deposit';
				break;
			case _IN_XTRANS_TYPE_OFFLINE_WITHDRAW:
				$template = 'SMS_70535272';
				$sms_type = 'offline_withdraw';
				break;
			default:
				return false;
		}
		switch ($role) {
			case _IN_XTRANS_ROLE_ACCOUNTANT:
				$phone = _IN_XTRANS_ACCOUNTANT_PHONE;
				break;
			case _IN_XTRANS_ROLE_FINANCIAL:
				$phone = _IN_XTRANS_FINANCIAL_PHONE;
				break;
			case _IN_XTRANS_ROLE_MANAGER:
				$phone = _IN_XTRANS_MANAGER_PHONE;
				break;
			default:
				return false;
		}
		return array(
			'template' => $template,
			'sms_type' => $sms_type,
			'phone' => $phone,
			);
	}
	
	protected function fetch_data($method){
		$url = $this->cnf['url'] . $method;
		return $this->process_fetched_data($this->http_get($url), $url, 'GET');
	}

	protected function fetch_zip($file_path){
		$url = $this->cnf['url'] . $file_path;
		$tmpfname = tempnam(sys_get_temp_dir(), 'EG');
		file_put_contents($tmpfname, file_get_contents($url));
		return $tmpfname;
	}

	protected function process_fetched_data($data, $url = '', $method = 'POST'){
		$res = json_decode($data, true);
		$this->log_err('', $res, $url, $method);
		if($res && isset($res['md5sign']) && $res['md5sign']){
			$string = $res['data'];
			$nonce = $res['nonce'];
			$md5sign = $res['md5sign'];
			$cmpsign = $this->data_sign($string, $nonce);
			if($md5sign != $cmpsign){
				return false;
			}
			$data = $this->unpack_string($string);
			return $data;
		}
		return false;
	}

	protected function pack_transfer_data($arr){
		$str = '';
		foreach ($arr as $key => $value) {
			$str .= urlencode($key) . '=' . urlencode($value) . '&';
		}
		if(strlen($str)<1){
			return '';
		}
		return substr($str, 0, -1);
	}
	protected function create_nonce_str($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		$charposmax = strlen($chars) - 1;
		for ($i = 0; $i < $length; $i++) {
			$str .= $chars[mt_rand(0, $charposmax)];
		}
		return $str;
	}
	protected function data_sign($string, $nonce){
		return sha1($nonce . md5($this->cnf['key']) . $string . sha1($this->cnf['iv']) . $nonce);
	}
	protected function pack_string($data){
		$string = json_encode($data);
		return $this->cipher->encryptData( $string, $this->cnf['key'], $this->cnf['iv']);
	}
	protected function unpack_string($string){
		$data = $this->cipher->decryptData( $string, $this->cnf['key'], $this->cnf['iv']);
		return json_decode($data, true);
	}
	protected function http_get($url) {
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 500);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_URL, $url);
		$res = curl_exec($curl);
		curl_close($curl);
		return $res;
	}
	protected function post_curl($str, $url, $second=30){
		//初始化curl
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		//这里设置代理，如果有的话
		//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
		//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		//设置header
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		//post提交方式
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
		//运行curl
		$data = curl_exec($ch);
		//curl_close($ch);
		//返回结果
		if($data){
			curl_close($ch);
			$this->log_err($str, $data, $url, 'POST');
			return $data;
		}else{ 
			$error = curl_errno($ch);
			$data = "curl出错，错误码:$error ";
			$this->log_err($str, $data, $url, 'POST');
			curl_close($ch);
			return false;
		}
	}
	protected function log_err($request, $response, $url, $method){
		if(isset($this->cnf['netlog']) && $this->cnf['netlog']){
			file_put_contents($this->cnf['netlog'], $method . ':' . $url . "\n\n", FILE_APPEND);
			file_put_contents($this->cnf['netlog'], 'REQUEST:' . $request . "\n\n", FILE_APPEND);
			file_put_contents($this->cnf['netlog'], 'RESPONSE:' . $response . "\n\n", FILE_APPEND);
		}
	}

}
