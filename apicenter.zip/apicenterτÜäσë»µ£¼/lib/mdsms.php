<?php
/**
 * @Author Chengzhou Tao
 * 
 */
require_once PATH_LIB_TAOBAO;

class MdsmsLibrary{

	protected $c = null;

	protected $data = array();

	public function init($pack){
		$this->c = new TopClient;
		$this->c->appkey = $pack['appkey'];
		$this->c->secretKey = $pack['secret'];

		$this->data = array(
			'sign' => $pack['sign'],
			'extend' => '',
			'smstype' => 'normal',
			'mobile' => '',
			'smstmpcode' => '',
			'params' => array(),
		);
	}

	public function __construct(){

	}

	public function setParams($params){
		$this->data['params'] = $params;
	}

	public function setTemplate($smstmpcode){
		$this->data['smstmpcode'] = $smstmpcode;
	}

	public function setMobile($mobile){
		$this->data['mobile'] = $mobile;
	}

	public function setEXT($ext){
		$this->data['extend'] = $ext;
	}

	public function send(){
		if(empty($this->data['params'])){
			return '内容不能为空';
		}
		if(empty($this->data['mobile'])){
			return '手机号不能为空';
		}
		
		$req = new AlibabaAliqinFcSmsNumSendRequest;
		$req->setExtend( $this->data['extend'] );
		$req->setSmsType( $this->data['smstype'] );
		$req->setSmsFreeSignName( $this->data['sign'] );
		$req->setSmsParam( json_encode($this->data['params']) );
		$req->setRecNum( $this->data['mobile'] );
		$req->setSmsTemplateCode( $this->data['smstmpcode'] );
		$resp = $this->c->execute($req);
		if($resp && property_exists($resp, 'result') && $resp->result->err_code == '0'){
			return true;
		}
		return $resp->msg . '|' . $resp->sub_code . '|' . $resp->sub_msg;
	}
}
